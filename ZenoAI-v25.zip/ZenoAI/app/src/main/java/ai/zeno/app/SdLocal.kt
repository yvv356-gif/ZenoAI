package ai.zeno.app

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.DocumentsContract
import java.io.ByteArrayOutputStream
import java.io.File
import java.lang.reflect.InvocationTargetException
import java.util.zip.ZipInputStream
import kotlin.random.Random

/**
 * Images 100 % locales avec Stable Diffusion 1.5 (ou un modèle dérivé comme Anything V5), sur le GPU, via le moteur
 * d'images de MediaPipe. Le modèle doit être converti au format MediaPipe (dossier de fichiers .bin) : on l'importe
 * depuis le téléphone (dossier ou ZIP), aucun compte ni internet.
 * Le moteur est appelé par réflexion : si cette version de la bibliothèque est différente, seule cette fonction échoue.
 */
object SdLocal {
    private const val PKG = "com.google.mediapipe.tasks.vision.imagegenerator"
    private var gen: Any? = null

    private fun root(ctx: Context) = File(ctx.filesDir, "sd_model")

    /** Dossier du modèle : si l'import contient un seul sous-dossier, c'est lui. */
    fun modelDir(ctx: Context): File {
        var d = root(ctx)
        while (true) {
            val kids = d.listFiles().orEmpty()
            if (kids.size == 1 && kids[0].isDirectory) d = kids[0] else return d
        }
    }

    fun isInstalled(ctx: Context): Boolean = root(ctx).let { it.isDirectory && it.walkTopDown().any { f -> f.isFile } }

    fun delete(ctx: Context) {
        release()
        root(ctx).deleteRecursively()
    }

    @Synchronized
    fun release() {
        gen?.let { g -> runCatching { g.javaClass.getMethod("close").invoke(g) } }
        gen = null
    }

    private fun safe(name: String) = name.replace(Regex("[^A-Za-z0-9._ -]"), "_")

    /** Copie un dossier choisi dans le sélecteur Android. */
    fun importTree(ctx: Context, tree: Uri, onProgress: (String) -> Unit) {
        release()
        val dest = root(ctx)
        dest.deleteRecursively()
        dest.mkdirs()
        var n = 0
        fun copy(docId: String, to: File) {
            val children = DocumentsContract.buildChildDocumentsUriForTreeDocument(tree, docId)
            ctx.contentResolver.query(
                children,
                arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getString(0)
                    val name = safe(c.getString(1) ?: "fichier")
                    if (c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR) {
                        copy(id, File(to, name).apply { mkdirs() })
                    } else {
                        val uri = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                        ctx.contentResolver.openInputStream(uri)?.use { i -> File(to, name).outputStream().use { o -> i.copyTo(o) } }
                        n++
                        onProgress("Copie du modèle… $n fichier(s)")
                    }
                }
            }
        }
        copy(DocumentsContract.getTreeDocumentId(tree), dest)
    }

    /** Décompresse un ZIP du dossier du modèle. */
    fun importZip(ctx: Context, zip: Uri, onProgress: (String) -> Unit) {
        release()
        val dest = root(ctx)
        dest.deleteRecursively()
        dest.mkdirs()
        var n = 0
        ctx.contentResolver.openInputStream(zip)?.use { raw ->
            ZipInputStream(raw.buffered()).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    val out = File(dest, e.name)
                    if (!out.canonicalPath.startsWith(dest.canonicalPath)) continue
                    if (e.isDirectory) out.mkdirs()
                    else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { z.copyTo(it) }
                        n++
                        onProgress("Décompression… $n fichier(s)")
                    }
                }
            }
        } ?: error("Impossible de lire le fichier")
    }

    @Synchronized
    private fun generator(ctx: Context): Any {
        gen?.let { return it }
        val optCls = Class.forName("$PKG.ImageGenerator\$ImageGeneratorOptions")
        val builderType = optCls.getMethod("builder").returnType
        val builder = optCls.getMethod("builder").invoke(null)!!
        builderType.getMethod("setImageGeneratorModelDirectory", String::class.java).invoke(builder, modelDir(ctx).absolutePath)
        val options = builderType.getMethod("build").invoke(builder)!!
        val genCls = Class.forName("$PKG.ImageGenerator")
        val g = genCls.getMethod("createFromOptions", Context::class.java, optCls).invoke(null, ctx.applicationContext, options)!!
        gen = g
        return g
    }

    /** Génère une image (JPEG). Bloquant : à appeler hors du fil principal. */
    fun generateJpeg(ctx: Context, prompt: String, iterations: Int = 20): ByteArray {
        try {
            val g = generator(ctx)
            val genCls = Class.forName("$PKG.ImageGenerator")
            val result = genCls.getMethod("generate", String::class.java, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType)
                .invoke(g, prompt, iterations, Random.nextInt(1, 1_000_000))!!
            val mpImage = Class.forName("$PKG.ImageGeneratorResult").getMethod("generatedImage").invoke(result)!!
            val bmp = Class.forName("com.google.mediapipe.framework.image.BitmapExtractor")
                .getMethod("extract", Class.forName("com.google.mediapipe.framework.image.MPImage"))
                .invoke(null, mpImage) as Bitmap
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, 92, out)
            return out.toByteArray()
        } catch (e: InvocationTargetException) {
            release()
            throw IllegalStateException(e.targetException?.message ?: "erreur du moteur d'images")
        } catch (e: ClassNotFoundException) {
            throw IllegalStateException("moteur d'images indisponible dans cette version de l'appli")
        }
    }
}
