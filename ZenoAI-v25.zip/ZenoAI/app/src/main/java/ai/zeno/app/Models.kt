package ai.zeno.app

enum class Role { USER, AI }

data class ChatMessage(
    val id: Long,
    val role: Role,
    val text: String,
    val streaming: Boolean = false,
    val status: String = "",
    val imagePath: String? = null,
    val imagePrompt: String = "",
    val sources: String = "",
    val gamePath: String? = null,
    val gameTitle: String = "",
    val zipPath: String? = null
)

data class ChatMeta(val id: String, val title: String, val updatedAt: Long)

sealed interface ModelState {
    data object None : ModelState
    data class Busy(val label: String, val progress: Float? = null) : ModelState
    data object Ready : ModelState
    data class Error(val message: String) : ModelState
}

/** Personnalisation de l'interface. Une couleur à 0 = couleur par défaut. */
data class Look(
    val wallpaper: String = "",
    val userName: String = "Toi",
    val aiName: String = "Zeno",
    val userAvatar: String = "",
    val aiAvatar: String = "",
    val textColor: Int = 0,
    val userBubble: Int = 0,
    val aiBubble: Int = 0,
    val bubbleAlpha: Float = 0.4f
)

/** Modèles proposés. « key » sert à reconnaître le fichier installé d'après son nom. */
data class ModelPreset(val label: String, val sub: String, val url: String, val key: String)

object ModelPresets {
    private const val HF = "https://huggingface.co/"

    val list = listOf(
        ModelPreset(
            "Qwen 2.5 · 1,5 Md (.task, GPU)",
            "Polyvalent et rapide · 1,6 Go · utilise le GPU du téléphone. Aucun compte nécessaire.",
            Prefs.QWEN_URL, "qwen2.5-1.5b-instruct_multi"
        ),
        ModelPreset(
            "Qwen 2.5 Coder · 1,5 Md (code, jeux)",
            "Spécialisé code et jeux · ≈ 1 Go · processeur (GGUF Q4_0, format rapide sur téléphone).",
            HF + "bartowski/Qwen2.5-Coder-1.5B-Instruct-GGUF/resolve/main/Qwen2.5-Coder-1.5B-Instruct-Q4_0.gguf",
            "qwen2.5-coder-1.5b"
        ),
        ModelPreset(
            "Llama 3.2 · 3 Md",
            "Bon compromis vitesse / qualité · ≈ 1,9 Go · processeur (GGUF Q4_0, format rapide sur téléphone).",
            HF + "bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_0.gguf",
            "llama-3.2-3b"
        )
    )

    fun presetFor(name: String): ModelPreset? = list.firstOrNull { name.lowercase().contains(it.key) }
}
