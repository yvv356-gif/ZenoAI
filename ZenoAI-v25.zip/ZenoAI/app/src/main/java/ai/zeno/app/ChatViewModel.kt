package ai.zeno.app

import android.app.Application
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = Prefs(app)
    private val engine = LlmEngine(app)
    private val files = ModelManager(app)
    private val store = ChatStore(app)

    private var nextId = 1L
    private var summary = ""
    private var gen = 0
    private var genJob: Job? = null
    private var summaryJob: Job? = null
    private var dlJob: Job? = null
    private var loadJob: Job? = null

    var messages by mutableStateOf<List<ChatMessage>>(emptyList())
        private set
    var chats by mutableStateOf<List<ChatMeta>>(emptyList())
        private set
    var currentId by mutableStateOf<String?>(null)
        private set
    var busy by mutableStateOf(false)
        private set
    var sdInstalled by mutableStateOf(false)
        private set
    var sdMessage by mutableStateOf("")
        private set

    fun refreshSd() { sdInstalled = SdLocal.isInstalled(getApplication<Application>()) }

    private fun sdImport(block: (Application) -> Unit) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            sdMessage = "Copie du modèle…"
            try {
                withContext(Dispatchers.IO) { block(app) }
                refreshSd()
                sdMessage = if (sdInstalled) "Modèle d'images installé ✓ (il sera utilisé pour « dessine… »)" else "Le dossier est vide."
            } catch (e: Exception) {
                refreshSd()
                sdMessage = "Échec de l'import : ${e.message}"
            }
        }
    }

    fun importSdTree(uri: android.net.Uri) = sdImport { app -> SdLocal.importTree(app, uri) { sdMessage = it } }
    fun importSdZip(uri: android.net.Uri) = sdImport { app -> SdLocal.importZip(app, uri) { sdMessage = it } }
    fun deleteSd() {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { SdLocal.delete(getApplication<Application>()) }
            refreshSd()
            sdMessage = "Modèle d'images supprimé."
        }
    }
    var modelState by mutableStateOf<ModelState>(ModelState.None)
        private set

    var thinking by mutableStateOf(prefs.thinking)
        private set
    var look by mutableStateOf(prefs.loadLook())
        private set
    var agent by mutableStateOf(prefs.agent)
        private set

    /** Modèle choisi (un nom de fichier, ou AUTO) et modèle réellement chargé en mémoire. */
    var activeModel by mutableStateOf(prefs.activeModel)
        private set
    var loadedModel by mutableStateOf("")
        private set
    var installedNames by mutableStateOf<List<String>>(emptyList())
        private set
    /** Téléchargement ou copie en cours : (nom du fichier, progression ou null). */
    var dl by mutableStateOf<Pair<String, Float?>?>(null)
        private set
    var dlMessage by mutableStateOf("")
        private set
    var dlStatus by mutableStateOf("")
        private set

    var webEnabled by mutableStateOf(prefs.web)
    var template by mutableStateOf(prefs.template)
    var maxTokens by mutableStateOf(prefs.maxTokens)
    var modelUrl by mutableStateOf(prefs.modelUrl)
    var imageUrl by mutableStateOf(prefs.imageUrl)

    /** Adresse ouverte dans le navigateur intégré (visible à l'écran). */
    var browseUrl by mutableStateOf<String?>(null)
        private set
    /** Ce que fait l'agent dans le navigateur en ce moment (barre de statut). */
    var browserStatus by mutableStateOf("")
        private set
    var browserBusy by mutableStateOf(false)
        private set
    var browserAnswer by mutableStateOf("")

    /** Cartes mémoire en cours de révision, et si on les révise en quiz (saisie) ou en les retournant. */
    var flashcards by mutableStateOf<FlashcardSet?>(null)
        private set
    var flashcardQuiz by mutableStateOf(false)
        private set
    var decks by mutableStateOf<List<FlashcardSet>>(emptyList())
        private set

    var hfToken by mutableStateOf(prefs.hfToken)
    var imageKey by mutableStateOf(prefs.imageKey)
        private set

    private val decksStore = DeckStore(app)

    private val imageReplies = listOf(
        "Voilà ce que ça donne !",
        "Tiens, regarde ce que j'ai dessiné pour toi.",
        "Et voilà, dis-moi si ça te plaît !",
        "C'est prêt ! Je peux en refaire une autre version si tu veux."
    )

    init {
        chats = runCatching { store.list() }.getOrDefault(emptyList())
        decks = runCatching { decksStore.list() }.getOrDefault(emptyList())
        // Anciennes versions : un seul fichier model.task, rangé avec les autres modèles
        files.migrateOld(ModelManager.safeName(prefs.modelUrl))?.let { name ->
            if (prefs.modelCfg(name) == null) prefs.setModelCfg(name, prefs.template, prefs.maxTokens)
            if (prefs.activeModel.isBlank()) prefs.activeModel = name
        }
        refreshInstalled()
        if (activeModel != AUTO && !files.exists(activeModel)) {
            activeModel = installedNames.firstOrNull().orEmpty()
            prefs.activeModel = activeModel
        }
        if (installedNames.isNotEmpty()) loadModel()
        watchDownloads()
    }

    // ---------- Modèles ----------

    private fun refreshInstalled() {
        installedNames = files.installed().map { it.name }
    }

    /** Famille (template) et contexte d'un modèle : réglages enregistrés, sinon devinés d'après le nom. */
    private fun cfgFor(name: String): Pair<String, Int> {
        prefs.modelCfg(name)?.let { return it }
        val l = name.lowercase()
        val tpl = when {
            l.contains("gemma") -> "gemma"
            l.contains("phi-") -> "phi"
            l.contains("deepseek") -> "deepseek"
            l.contains("llama") -> "llama"
            else -> "chatml"
        }
        val ctx = Regex("ekv(\\d+)").find(l)?.groupValues?.get(1)?.toIntOrNull()
            ?: if (l.endsWith(".gguf")) 2048 else 1280
        return tpl to ctx
    }

    private fun registerModel(name: String) {
        if (prefs.modelCfg(name) == null) {
            val c = cfgFor(name)
            prefs.setModelCfg(name, c.first, c.second)
        }
    }

    fun labelOf(name: String): String = if (name == AUTO) "Auto" else ModelManager.label(name)

    /** Texte du bouton « modèle » de l'écran d'accueil. */
    fun activeLabel(): String = when {
        activeModel == AUTO -> if (loadedModel.isNotBlank()) "Auto · ${ModelManager.label(loadedModel)}" else "Auto"
        activeModel.isBlank() -> "Aucun modèle"
        else -> ModelManager.label(activeModel)
    }

    fun sizeMb(name: String): Long = files.file(name).length() / 1_000_000

    fun isInstalled(preset: ModelPreset): Boolean =
        installedNames.any { it.lowercase().contains(preset.key) }

    fun loadModel() {
        val name = if (activeModel == AUTO) {
            prefs.lastModel.takeIf { files.exists(it) } ?: installedNames.firstOrNull()
        } else activeModel
        if (name == null || !files.exists(name)) { modelState = ModelState.None; return }
        val (tpl, ctx) = cfgFor(name)
        modelState = ModelState.Busy("Chargement de ${ModelManager.label(name)}…")
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            modelState = try {
                engine.load(files.path(name), ctx)
                loadedModel = name
                template = tpl
                maxTokens = ctx
                prefs.lastModel = name
                prefs.template = tpl
                prefs.maxTokens = ctx
                ModelState.Ready
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                ModelState.Error(
                    "Chargement impossible : ${e.message ?: e.javaClass.simpleName}. " +
                        "Le modèle est peut-être trop lourd pour la mémoire du téléphone : choisis-en un plus léger."
                )
            }
        }
    }

    /** Change de modèle sans toucher à la discussion (messages et mémoire sont conservés). */
    fun switchModel(name: String) {
        if (name == activeModel && modelState is ModelState.Ready) return
        if (name != AUTO && !files.exists(name)) return
        if (busy) stopWork()
        activeModel = name
        prefs.activeModel = name
        if (name == AUTO && loadedModel.isNotBlank() && modelState is ModelState.Ready) return
        loadModel()
    }

    /** Lance le téléchargement dans un service d'arrière-plan : il continue appli fermée ou écran éteint. */
    fun downloadModel(url: String) {
        if (url.isBlank() || DownloadState.flow.value != null || dlJob?.isActive == true) return
        val name = ModelManager.safeName(url)
        dlMessage = ""
        dlStatus = "Préparation…"
        dl = name to 0f
        val app = getApplication<Application>()
        val intent = Intent(app, DownloadService::class.java)
            .putExtra(DownloadService.EXTRA_URL, url)
            .putExtra(DownloadService.EXTRA_NAME, name)
            .putExtra(DownloadService.EXTRA_TOKEN, hfToken)
        runCatching { ContextCompat.startForegroundService(app, intent) }.onFailure {
            dl = null
            dlStatus = ""
            dlMessage = "Impossible de démarrer le téléchargement : ${it.message ?: it.javaClass.simpleName}"
        }
    }

    /** Suit le service de téléchargement : progression, fin, erreur. */
    private fun watchDownloads() {
        viewModelScope.launch {
            DownloadState.flow.collect { info ->
                when {
                    info == null -> if (dlJob?.isActive != true) {
                        dl = null
                        dlStatus = ""
                    }
                    info.error != null -> {
                        dl = null
                        dlStatus = ""
                        dlMessage = "Téléchargement : ${info.error}"
                        DownloadState.clear()
                    }
                    info.done -> {
                        dl = null
                        dlStatus = ""
                        registerModel(info.name)
                        refreshInstalled()
                        DownloadState.clear()
                        switchModel(info.name)
                    }
                    else -> {
                        dl = info.name to info.progress
                        dlStatus = info.status
                    }
                }
            }
        }
    }

    fun download() = downloadModel(modelUrl)

    fun cancelDownload() {
        dlJob?.cancel()
        val app = getApplication<Application>()
        runCatching { app.startService(Intent(app, DownloadService::class.java).setAction(DownloadService.ACTION_CANCEL)) }
    }

    fun importModel(uri: Uri) {
        if (dlJob?.isActive == true) return
        dlMessage = ""
        dl = "Copie du modèle…" to null
        dlJob = viewModelScope.launch {
            try {
                val name = ModelManager.safeName(files.displayName(uri).ifBlank { "modele_importe.task" })
                dl = name to null
                files.import(uri, name)
                registerModel(name)
                dl = null
                refreshInstalled()
                switchModel(name)
            } catch (e: CancellationException) {
                dl = null
                throw e
            } catch (e: Exception) {
                dl = null
                dlMessage = "Import : ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    fun deleteModel(name: String) {
        if (name == activeModel || name == loadedModel) return
        files.delete(name)
        refreshInstalled()
    }

    fun applySettings(
        url: String, tpl: String, tokens: Int, web: Boolean, imgUrl: String, token: String,
        iKey: String
    ) {
        val target = if (activeModel == AUTO) loadedModel else activeModel
        val reload = target.isNotBlank() && (tokens != maxTokens || tpl != template)
        if (target.isNotBlank()) prefs.setModelCfg(target, tpl, tokens)
        modelUrl = url.trim().ifBlank { Prefs.QWEN_URL }
        template = tpl
        maxTokens = tokens
        webEnabled = web
        imageUrl = imgUrl.trim().ifBlank { Prefs.IMAGE_URL }
        hfToken = token.trim()
        imageKey = iKey.trim()
        prefs.modelUrl = modelUrl
        prefs.template = tpl
        prefs.maxTokens = tokens
        prefs.web = web
        prefs.imageUrl = imageUrl
        prefs.hfToken = hfToken
        prefs.imageKey = imageKey
        if (reload && files.exists(target) && modelState is ModelState.Ready) loadModel()
    }

    fun setWeb(on: Boolean) {
        webEnabled = on
        prefs.web = on
    }

    fun chooseAgent(on: Boolean) {
        agent = on
        prefs.agent = on
    }

    // ---------- Mode Auto : le meilleur modèle installé pour la tâche ----------

    private enum class TaskKind { CODE, WRITE, COMPLEX, SIMPLE }

    private val writeRx = Regex(
        "(rédige|redige|écris|ecris|poème|poeme|histoire|raconte|traduis|traduction|résume|resume|lettre|mail|email|discours|translate|summarize|story|poem)",
        RegexOption.IGNORE_CASE
    )
    private val mathRx = Regex(
        "(calcule|résous|resous|prouve|démontre|demontre|équation|equation|théorème|theoreme|intégrale|dérivée)",
        RegexOption.IGNORE_CASE
    )

    private fun classify(text: String): TaskKind = when {
        WebSearch.looksLikeCode(text) -> TaskKind.CODE
        writeRx.containsMatchIn(text) -> TaskKind.WRITE
        mathRx.containsMatchIn(text) || thinking == 2 || agent || text.length > 400 -> TaskKind.COMPLEX
        else -> TaskKind.SIMPLE
    }

    /** Taille approximative en milliards de paramètres, lue dans le nom du fichier. */
    private fun sizeOf(name: String): Double =
        Regex("(\\d+(?:\\.\\d+)?)b").find(name.lowercase())?.groupValues?.get(1)?.toDoubleOrNull() ?: 1.5

    private fun pickModel(text: String): String? {
        val inst = installedNames
        if (inst.isEmpty()) return null
        if (inst.size == 1) return inst[0]
        val biggest = inst.maxByOrNull { sizeOf(it) } ?: return null
        val smallest = inst.minByOrNull { sizeOf(it) } ?: return null
        val current = loadedModel.takeIf { it in inst }
        return when (classify(text)) {
            TaskKind.CODE -> inst.filter { it.lowercase().contains("coder") }.maxByOrNull { sizeOf(it) }
                ?: inst.filter { it.lowercase().contains("qwen") }.maxByOrNull { sizeOf(it) } ?: biggest
            TaskKind.WRITE -> inst.filter { it.lowercase().contains("gemma") }.maxByOrNull { sizeOf(it) } ?: biggest
            TaskKind.COMPLEX -> biggest
            TaskKind.SIMPLE -> current ?: smallest
        }
    }

    private suspend fun ensureLoaded(name: String): Boolean {
        if (loadedModel == name) return true
        if (!files.exists(name)) return false
        val (tpl, ctx) = cfgFor(name)
        return try {
            engine.load(files.path(name), ctx)
            loadedModel = name
            template = tpl
            maxTokens = ctx
            prefs.lastModel = name
            true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            false
        }
    }

    private suspend fun autoSwitch(botId: Long, text: String) {
        val want = pickModel(text) ?: return
        if (want == loadedModel) return
        update(botId) { it.copy(status = "Je passe sur ${ModelManager.label(want)} pour cette tâche…") }
        val previous = loadedModel
        if (!ensureLoaded(want) && previous.isNotBlank()) ensureLoaded(previous)
    }

    // ---------- Fichiers ----------

    fun readText(uri: Uri): String = runCatching {
        getApplication<Application>().contentResolver.openInputStream(uri)!!.bufferedReader().use { r ->
            val buf = CharArray(20_000)
            val n = r.read(buf)
            if (n <= 0) "" else String(buf, 0, n)
        }
    }.getOrDefault("")

    fun readGame(path: String): String = runCatching { File(path).readText() }.getOrDefault("")

    fun saveToGallery(path: String): String {
        if (Build.VERSION.SDK_INT < 29) return "Pour enregistrer dans la galerie, il faut Android 10 ou plus."
        return runCatching {
            val resolver = getApplication<Application>().contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "ZenoAI_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ZenoAI")
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)!!
            resolver.openOutputStream(uri)!!.use { out -> File(path).inputStream().use { it.copyTo(out) } }
            "Image enregistrée dans ta galerie ✅"
        }.getOrElse { "Je n'ai pas pu l'enregistrer : ${it.message}" }
    }

    // ---------- Niveau de réflexion ----------

    fun chooseThinking(n: Int) {
        thinking = n.coerceIn(0, 2)
        prefs.thinking = thinking
    }

    fun cycleThinking() = chooseThinking((thinking + 1) % 3)

    // ---------- Personnalisation ----------

    private fun updateLook(f: (Look) -> Look) {
        look = f(look)
        prefs.saveLook(look)
    }

    fun setUserName(s: String) = updateLook { it.copy(userName = s.take(24)) }
    fun setAiName(s: String) = updateLook { it.copy(aiName = s.take(24)) }
    fun setTextColor(c: Int) = updateLook { it.copy(textColor = c) }
    fun setUserBubble(c: Int) = updateLook { it.copy(userBubble = c) }
    fun setAiBubble(c: Int) = updateLook { it.copy(aiBubble = c) }
    fun setBubbleAlpha(a: Float) = updateLook { it.copy(bubbleAlpha = a.coerceIn(0.15f, 1f)) }

    fun importWallpaper(uri: Uri) {
        viewModelScope.launch {
            val p = withContext(Dispatchers.IO) { ImageStore.save(getApplication<Application>(), uri, "wallpaper", 1600) }
            if (p != null) updateLook { it.copy(wallpaper = p) }
        }
    }

    fun clearWallpaper() {
        ImageStore.delete(look.wallpaper)
        updateLook { it.copy(wallpaper = "") }
    }

    fun importAvatar(user: Boolean, uri: Uri) {
        viewModelScope.launch {
            val p = withContext(Dispatchers.IO) {
                ImageStore.save(getApplication<Application>(), uri, if (user) "avatar_user" else "avatar_ai", 256)
            }
            if (p != null) updateLook { if (user) it.copy(userAvatar = p) else it.copy(aiAvatar = p) }
        }
    }

    fun clearAvatar(user: Boolean) {
        ImageStore.delete(if (user) look.userAvatar else look.aiAvatar)
        updateLook { if (user) it.copy(userAvatar = "") else it.copy(aiAvatar = "") }
    }

    fun resetLook() {
        ImageStore.delete(look.wallpaper)
        ImageStore.delete(look.userAvatar)
        ImageStore.delete(look.aiAvatar)
        look = Look()
        prefs.saveLook(look)
    }

    // ---------- Jeux ----------

    /** Envoie une demande de correction avec le code et les erreurs. Renvoie un message si c'est impossible. */
    fun fixGame(errors: String, code: String): String? {
        if (busy) return "Attends la fin de la réponse en cours."
        val msg = "/jeu Corrige ce jeu. Erreurs : ${errors.take(200)}\n```html\n$code\n```"
        if (msg.length > PromptBuilder.gameRequestCapacity(maxTokens)) {
            return "Ce jeu est trop long pour être corrigé avec une mémoire de $maxTokens. " +
                "Passe à un modèle avec plus de contexte, ou relance « /jeu … »."
        }
        send(msg)
        return null
    }

    /** Fabrique un APK installable à partir du jeu et l'enregistre dans Téléchargements. */
    fun exportApk(html: String, title: String, onDone: (String) -> Unit) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            val msg = withContext(Dispatchers.IO) {
                runCatching {
                    if (html.isBlank()) return@runCatching "Je n'ai pas retrouvé le jeu."
                    if (!ApkExporter.available(app)) {
                        return@runCatching "Le moteur d'APK n'est pas inclus dans cette version : " +
                            "il est ajouté par l'étape « shell de jeu » du workflow (voir le README)."
                    }
                    val safe = title.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').ifBlank { "jeu" }.take(24)
                    val out = File(app.cacheDir, "ZenoJeu_$safe.apk")
                    ApkExporter.build(app, html, out)
                    val where = saveApk(out, "ZenoJeu_${safe}_${System.currentTimeMillis() % 100000}.apk")
                    out.delete()
                    where
                }.getOrElse { "Impossible de créer l'APK : ${it.message ?: it.javaClass.simpleName}" }
            }
            onDone(msg)
        }
    }

    private fun saveApk(file: File, name: String): String {
        val app = getApplication<Application>()
        return if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
            app.contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
            "APK enregistré dans Téléchargements : $name. Ouvre-le pour l'installer (Android te demandera peut-être d'autoriser l'installation)."
        } else {
            val dir = app.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: app.filesDir
            val target = File(dir, name)
            file.copyTo(target, overwrite = true)
            "APK enregistré : ${target.absolutePath}"
        }
    }

    // ---------- Historique ----------

    private fun persist() {
        val id = currentId ?: return
        val clean = messages
            .filter {
                it.text.isNotBlank() || it.imagePath != null || it.gamePath != null || it.zipPath != null
            }
            .map { it.copy(streaming = false, status = "") }
        val firstUser = clean.firstOrNull { it.role == Role.USER } ?: return
        val title = firstUser.text.replace(Regex("\\s+"), " ").trim().take(42)
        runCatching {
            store.save(id, title, summary, clean)
            chats = store.list()
        }
    }

    private fun stopWork() {
        gen++
        genJob?.cancel()
        summaryJob?.cancel()
        busy = false
    }

    fun newChat() {
        persist()
        stopWork()
        currentId = null
        summary = ""
        messages = emptyList()
    }

    /** Charge une discussion depuis le disque ; la précédente est sauvegardée puis déchargée de la mémoire. */
    fun openChat(id: String) {
        if (id == currentId) return
        persist()
        stopWork()
        val data = store.load(id) ?: return
        currentId = id
        summary = data.summary
        messages = data.messages
        nextId = (data.messages.maxOfOrNull { it.id } ?: 0L) + 1
    }

    // ---------- Conversation ----------

    private fun update(id: Long, f: (ChatMessage) -> ChatMessage) {
        messages = messages.map { if (it.id == id) f(it) else it }
    }

    fun stop() { genJob?.cancel() }

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || busy) return
        // Actions immédiates sur le téléphone (« ouvre les paramètres », « va sur jbl.com ») : sans modèle, instantané
        val quickReply = if (!agent) QuickPhone.handle(getApplication<Application>(), text) else null
        val wantsImage = ImageGen.isRequest(text)
        val wantsPpt = !wantsImage && Pptx.isRequest(text)
        val wantsFiles = !wantsImage && !wantsPpt && FileTool.isRequest(text)
        val wants3d = !wantsImage && !wantsPpt && !wantsFiles && Model3D.isRequest(text)
        val wantsSite = !wantsImage && !wants3d && SiteTool.isRequest(text)
        val wantsGame = !wantsImage && !wants3d && !wantsSite && GameTool.isRequest(text)
        val wantsCards = !wantsImage && !wants3d && !wantsSite && !wantsGame && Flashcards.isRequest(text)
        val wantsPhone = !wantsImage && !wants3d && !wantsSite && !wantsGame && !wantsCards &&
            PhoneCmd.isRequest(text)
        val gameKind = if (wantsGame) GameLib.detectKind(GameTool.request(text)) else null
        // Une adresse à ouvrir (« va sur jbl.com ») : le navigateur s'ouvre tout de suite, sans attendre le modèle.
        // Le modèle n'intervient qu'en mode agent, pour cliquer et écrire à ta place.
        val directUrl = if (quickReply == null && !wantsImage && !wants3d && !wantsSite && !wantsGame &&
            !wantsCards && !wantsPhone && (agent || isNavigation(text))
        ) Agent.findUrl(text) else null
        // Images, jeux prêts à l'emploi et sites ouverts n'ont pas besoin du modèle local pour s'ouvrir
        val needsModel = directUrl == null && quickReply == null && !(wantsImage || wants3d || (wantsGame && gameKind != null))

        if (currentId == null) currentId = "c${System.currentTimeMillis()}"
        val history = messages
        val userMsg = ChatMessage(nextId++, Role.USER, text)

        if (needsModel && modelState !is ModelState.Ready) {
            messages = messages + userMsg + ChatMessage(
                nextId++, Role.AI,
                "Il me manque mon cerveau 😅 Choisis un modèle avec le bouton en haut de l'écran, puis on discute."
            )
            return
        }

        val botId = nextId++
        messages = messages + userMsg + ChatMessage(
            botId, Role.AI, "", streaming = true,
            status = when {
                quickReply != null -> "J'agis sur le téléphone…"
                wantsPpt -> "Je construis ta présentation…"
                wantsFiles -> "Je crée tes fichiers…"
                wantsImage -> "Je prépare mon dessin…"
                wants3d -> "Je modélise en 3D…"
                wantsGame -> "Je conçois ton jeu…"
                wantsSite -> "Je construis ton site…"
                wantsCards -> "Je prépare tes cartes…"
                wantsPhone -> "Je prends la main sur le téléphone…"
                directUrl != null -> "J'ouvre le site…"
                else -> "Je réfléchis…"
            }
        )
        busy = true
        val my = ++gen

        workStart("Zeno travaille…")
        genJob = viewModelScope.launch {
            var forSummary = ""
            try {
                summaryJob?.join()
                if (needsModel && activeModel == AUTO) autoSwitch(botId, text)
                forSummary = when {
                    quickReply != null -> {
                        update(botId) { it.copy(text = quickReply, streaming = false, status = "") }
                        quickReply
                    }
                    wantsPpt -> doPpt(botId, text)
                    wantsFiles -> doFiles(botId, text)
                    wantsImage -> doImage(botId, text)
                    wants3d -> doModel3d(botId, text)
                    wantsGame -> doGame(botId, text, gameKind)
                    wantsSite -> doSite(botId, text)
                    wantsCards -> doCards(botId, text)
                    wantsPhone -> doPhone(botId, PhoneCmd.request(text))
                    directUrl != null -> doBrowse(botId, text, directUrl)
                    agent -> doAgent(botId, text, history)
                    else -> doChat(botId, text, history)
                }
            } catch (e: CancellationException) {
                update(botId) { it.copy(streaming = false, status = "") }
                throw e
            } catch (e: Throwable) {
                update(botId) {
                    it.copy(
                        text = "Aïe, quelque chose a coincé : ${e.message ?: e.javaClass.simpleName}. " +
                            "Si ton message était long, essaie plus court ou ouvre une nouvelle discussion.",
                        streaming = false, status = ""
                    )
                }
            } finally {
                if (my == gen) {
                    busy = false
                    persist()
                }
                workEnd()
            }
            if (my == gen && forSummary.isNotBlank()) rollSummary(my)
        }
    }

    private fun wantsLinks(text: String) = WebSearch.wantsLinks(text)

    private val navRx = Regex(
        "^\\s*(va|allez|ouvre|ouvrir|montre|affiche|rends-toi|rend-toi|emmène-moi|navigue)\\b",
        RegexOption.IGNORE_CASE
    )

    /** Demande de navigation (« va sur jbl.com », « ouvre … »), même hors mode agent. */
    private fun isNavigation(text: String) = text.length < 200 && navRx.containsMatchIn(text)

    private suspend fun doChat(botId: Long, text: String, history: List<ChatMessage>): String {
        // Calcul simple (« 2+2 ») : réponse immédiate, sans modèle.
        val t = text.trim().trimEnd('=', '?', ' ')
        if (t.length in 3..40 && t.any { it in "+-*/×÷^%" } && t.first().let { it.isDigit() || it == '(' }) {
            Calc.eval(t)?.let { r ->
                val out = "$t = $r"
                update(botId) { it.copy(text = out, streaming = false, status = "") }
                return out
            }
        }
        val long = PromptBuilder.wantsLong(text)
        val memory = Memory.build(history, summary, text, PromptBuilder.memoryBudget(maxTokens, text.length, long))
        var web = WebResult.EMPTY
        val mode = if (webEnabled) WebSearch.modeFor(text, thinking) else WebSearch.Mode.NONE
        if (mode != WebSearch.Mode.NONE) {
            update(botId) {
                it.copy(status = if (mode == WebSearch.Mode.CODE) "Je cherche sur GitHub et Reddit…" else "Je cherche sur le web…")
            }
            web = runCatching {
                kotlinx.coroutines.withTimeoutOrNull(15_000) {
                    WebSearch.gather(
                        text,
                        PromptBuilder.webBudget(maxTokens, memory.length, text.length, long).coerceAtMost(if (thinking == 2) 1500 else 900),
                        mode, thinking, wantsLinks(text)
                    )
                }
            }.getOrNull() ?: WebResult.EMPTY
            update(botId) { it.copy(status = "Je réfléchis…") }
        }
        return answer(botId, text, web, memory, webMissing = mode != WebSearch.Mode.NONE && web.context.isBlank())
    }

    /**
     * Génération avec une limite avant le premier mot (la lecture d'un long prompt peut bloquer très longtemps
     * sur un gros modèle). Renvoie null si rien n'est arrivé dans le délai.
     */
    private suspend fun generateLimited(
        prompt: String, temperature: Float, cap: Int, limitMs: Long,
        first: java.util.concurrent.atomic.AtomicBoolean, onPartial: (String) -> Unit
    ): String? = kotlinx.coroutines.coroutineScope {
        val job = kotlinx.coroutines.async {
            engine.generate(prompt, temperature, cap) { p ->
                first.set(true)
                onPartial(p)
            }
        }
        val ok = kotlinx.coroutines.withTimeoutOrNull(limitMs) {
            while (!first.get() && job.isActive) kotlinx.coroutines.delay(300)
            true
        }
        if (ok == null) {
            job.cancel()
            job.join()
            null
        } else job.await()
    }

    /** Génère la réponse finale à partir de la mémoire et des sources. */
    private suspend fun answer(botId: Long, text: String, web: WebResult, memory: String, webMissing: Boolean = false): String {
        val userName = look.userName.trim().takeIf { it.isNotBlank() && it != "Toi" }.orEmpty()
        val prompt = PromptBuilder.chat(
            template, memory, web.context, text, maxTokens,
            look.aiName.ifBlank { "Zeno" }, userName, thinking
        )
        val base = if (web.context.isNotBlank()) 0.35f else 0.7f
        val temperature = if (thinking == 2) (base - 0.1f).coerceAtLeast(0.2f) else base
        val cap = PromptBuilder.maxCharsFor(text)
        val first = java.util.concurrent.atomic.AtomicBoolean(false)
        val startedAt = System.currentTimeMillis()
        // Compteur visible : on voit que ça travaille (la lecture des sources peut prendre du temps sur un gros modèle)
        val ticker = viewModelScope.launch {
            while (!first.get()) {
                kotlinx.coroutines.delay(1_000)
                if (!first.get()) {
                    val sec = (System.currentTimeMillis() - startedAt) / 1000
                    update(botId) { it.copy(status = "Je réfléchis… ${sec} s" + (if (web.context.isNotBlank()) " (je lis les sources)" else "")) }
                }
            }
        }
        var answer: String? = try {
            generateLimited(prompt, temperature, cap, 180_000L, first) { partial ->
                update(botId) { it.copy(text = PromptBuilder.clean(partial), status = "") }
            }
        } finally {
            ticker.cancel()
        }
        if (answer == null) {
            // Le modèle n'a pas commencé à répondre à temps : on donne quand même ce qui a été trouvé
            val fallback = if (web.context.isNotBlank())
                "Mon modèle met trop de temps à rédiger une réponse, alors voici ce que j'ai trouvé sur le web :\n\n" + web.context.take(1200)
            else
                "Mon modèle met trop de temps à démarrer (plus de 3 minutes). Essaie un modèle plus léger (Qwen 1,5B ou Llama 3.2 3B) dans le menu."
            update(botId) { it.copy(text = fallback, streaming = false, status = "", sources = web.sources.joinToString(" · ")) }
            return fallback
        }
        // Le modèle répond parfois seulement son nom (« Zeno ») : on réessaie avec une consigne complète.
        val aiName = look.aiName.ifBlank { "Zeno" }
        if (answer.trim().trim('.', '!', ':', '*').equals(aiName, true) || answer.trim().length < 3) {
            val retry = PromptBuilder.wrap(
                template, "Tu es un assistant utile. Réponds en français, de façon complète et utile.", text.take(1500)
            )
            answer = engine.generate(retry, 0.7f, cap) { partial ->
                update(botId) { it.copy(text = PromptBuilder.clean(partial), status = "") }
            }
        }
        // Les petits modèles refusent parfois à tort : on réessaie une fois avec une consigne minimale.
        if (answer.trim().length < 160 && Regex("^(je suis désolé|désolé|je ne peux pas|i can't|i'm sorry|sorry)", RegexOption.IGNORE_CASE).containsMatchIn(answer.trim())) {
            val retry = PromptBuilder.wrap(template, "Tu es un assistant utile. Tu réponds toujours en français, directement et sans refuser.", text.take(600))
            answer = engine.generate(retry, 0.7f, cap) { partial ->
                update(botId) { it.copy(text = PromptBuilder.clean(partial), status = "") }
            }
        }
        val finalText = PromptBuilder.clean(answer)
        val shown = if (webMissing && finalText.isNotBlank())
            finalText + "\n\n(Je n'ai rien trouvé sur le web, vérifie ta connexion : réponse avec mes connaissances.)" else finalText
        update(botId) {
            it.copy(
                text = shown, streaming = false, status = "",
                sources = web.sources.joinToString(" · ")
            )
        }
        return finalText
    }

    /** Mode agent : plan → outil → observation, jusqu'à 3 étapes (4 en réflexion élevée), puis réponse. */
    private suspend fun doAgent(botId: Long, text: String, history: List<ChatMessage>): String {
        val long = PromptBuilder.wantsLong(text)
        val memory = Memory.build(history, summary, text, PromptBuilder.memoryBudget(maxTokens, text.length, long))
        val notes = StringBuilder()
        val sources = mutableListOf<String>()
        val maxSteps = when (thinking) { 0 -> 2; 1 -> 3; else -> 4 }
        var step = 0
        var finished = false
        while (step < maxSteps && !finished) {
            step++
            update(botId) { it.copy(status = "Agent · étape $step/$maxSteps : je réfléchis…") }
            val raw = kotlinx.coroutines.withTimeoutOrNull(60_000) { engine.generate(PromptBuilder.agentStep(template, text, notes.toString(), step, maxSteps), 0.2f, 500) {} }.orEmpty()
            val act = Agent.parse(raw, text, step == 1)
            when (act.name) {
                "search", "code" -> {
                    val mode = if (act.name == "code") WebSearch.Mode.CODE else WebSearch.Mode.FACTS
                    update(botId) {
                        it.copy(status = "Agent · étape $step/$maxSteps : je cherche « ${act.input.take(40)} »…")
                    }
                    val r = runCatching {
                        kotlinx.coroutines.withTimeoutOrNull(15_000) {
                            WebSearch.gather(act.input, 450, mode, thinking, wantsLinks(text))
                        }
                    }.getOrNull() ?: WebResult.EMPTY
                    if (r.context.isBlank()) {
                        notes.append("Rien trouvé pour « ${act.input} ».\n")
                    } else {
                        notes.append("Recherche « ${act.input} » :\n").append(r.context).append('\n')
                        r.sources.forEach { if (it !in sources) sources += it }
                    }
                }
                "calc" -> {
                    update(botId) { it.copy(status = "Agent · étape $step/$maxSteps : je calcule…") }
                    val v = Calc.eval(act.input)
                    notes.append("Calcul ${act.input} = ${v ?: "impossible"}\n")
                }
                "open" -> return doBrowse(botId, text, act.input)
                "phone" -> return doPhone(botId, act.input.ifBlank { text })
                "game" -> return doGame(botId, "/jeu ${act.input}", GameLib.detectKind(act.input))
                "site" -> return doSite(botId, "/site ${act.input}")
                "image" -> return doImage(botId, "/image ${act.input}")
                else -> finished = true
            }
        }
        update(botId) { it.copy(status = "Je rédige la réponse…") }
        return answer(botId, text, WebResult(notes.toString().trim(), sources), memory)
    }

    /**
     * Navigateur visible : l'adresse s'ouvre tout de suite, sans attendre le modèle.
     * En mode agent, Zeno lit la page, clique, écrit et défile à ta place, étape par étape, sous tes yeux.
     */
    private suspend fun doBrowse(botId: Long, task: String, rawUrl: String): String {
        val url = Agent.findUrl(rawUrl) ?: rawUrl.trim()
        if (!url.startsWith("http")) {
            update(botId) {
                it.copy(
                    text = "Je n'ai pas trouvé d'adresse à ouvrir. Écris-la par exemple : « va sur jbl.com ».",
                    streaming = false, status = ""
                )
            }
            return ""
        }
        browseUrl = url
        browserBusy = true
        browserStatus = "J'ouvre $url…"
        update(botId) { it.copy(status = "J'ouvre $url…") }
        try {
            WebDriver.open(url)
            if (!agent) {
                val msg = "J'ai ouvert $url dans le navigateur. Active le mode agent si tu veux que je clique, cherche ou remplisse un formulaire à ta place."
                update(botId) { it.copy(text = msg, streaming = false, status = "") }
                return msg
            }
            if (modelState !is ModelState.Ready && activeModel == AUTO) autoSwitch(botId, task)
            if (modelState !is ModelState.Ready) {
                val msg = "J'ai ouvert $url. Charge un modèle IA (menu ☰ → Modèle et réglages) : je pourrai alors cliquer et écrire à ta place."
                update(botId) { it.copy(text = msg, streaming = false, status = "") }
                return msg
            }
            WebDriver.problem()?.let { browserStatus = "⚠ $it" }
            return browserLoop(botId, task, url)
        } finally {
            browserBusy = false
            browserStatus = ""
        }
    }

    /** Barre du bas du navigateur : nouvelle consigne pour Zeno, sur la page déjà ouverte. */
    fun browserInstruct(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || busy) return
        if (currentId == null) currentId = "c${System.currentTimeMillis()}"
        val userMsg = ChatMessage(nextId++, Role.USER, text)
        val botId = nextId++
        messages = messages + userMsg + ChatMessage(botId, Role.AI, "", streaming = true, status = "Je regarde la page…")
        busy = true
        browserAnswer = ""
        val my = ++gen
        workStart("Zeno agit sur le site…")
        genJob = viewModelScope.launch {
            try {
                if (modelState !is ModelState.Ready) {
                    val msg = "Charge d'abord un modèle IA (menu ☰ → Modèle et réglages) pour que je puisse agir sur la page."
                    browserAnswer = msg
                    update(botId) { it.copy(text = msg, streaming = false, status = "") }
                } else {
                    val target = if (isNavigation(text)) Agent.findUrl(text) else null
                    if (target != null) {
                        browseUrl = target
                        WebDriver.open(target)
                    }
                    browserBusy = true
                    browserLoop(botId, text, browseUrl.orEmpty())
                }
            } catch (e: CancellationException) {
                update(botId) { it.copy(streaming = false, status = "") }
                throw e
            } catch (e: Throwable) {
                val msg = "Aïe, ça a coincé : ${e.message ?: e.javaClass.simpleName}"
                browserAnswer = msg
                update(botId) { it.copy(text = msg, streaming = false, status = "") }
            } finally {
                browserBusy = false
                browserStatus = ""
                if (my == gen) {
                    busy = false
                    persist()
                }
                workEnd()
            }
        }
    }

    /** Boucle agent sur la page ouverte : observer, décider, agir. Le résultat s'affiche dans la barre et dans le chat. */
    private suspend fun browserLoop(botId: Long, task: String, url: String): String {
        val answer = ActLoop.run(
            task = task,
            driver = WebDriver,
            system = ActLoop.webSystem(),
            template = template,
            maxSteps = when (thinking) { 0 -> 5; 1 -> 8; else -> 12 },
            ask = { p -> kotlinx.coroutines.withTimeoutOrNull(60_000) { engine.generate(p, 0.2f, 500) {} }.orEmpty() },
            status = { s ->
                browserStatus = s
                update(botId) { it.copy(status = s) }
            },
            log = mutableListOf()
        )
        val finalText = PromptBuilder.clean(answer.ifBlank {
            "Je n'ai pas réussi à finir la tâche sur $url. Donne-moi une autre consigne avec la barre du bas."
        })
        browserAnswer = finalText
        update(botId) { it.copy(text = finalText, streaming = false, status = "") }
        return finalText
    }

    /** Contrôle du téléphone : Zeno lit l'écran et agit (ouvrir une appli, toucher, écrire…). Nécessite le service d'accessibilité. */
    private suspend fun doPhone(botId: Long, task: String): String {
        if (!PhoneDriver.connected()) {
            val msg = "Pour que je contrôle ton téléphone, active-moi une fois : menu ☰ → Modèle et réglages → Contrôle du téléphone → " +
                "Ouvrir les réglages d'accessibilité, puis active « ZenoAI ». Ensuite, redemande-moi."
            update(botId) { it.copy(text = msg, streaming = false, status = "") }
            return ""
        }
        if (modelState !is ModelState.Ready) {
            update(botId) { it.copy(text = "Charge d'abord un modèle IA : il me faut un cerveau pour décider quoi toucher.", streaming = false, status = "") }
            return ""
        }
        val answer = ActLoop.run(
            task = task,
            driver = PhoneDriver,
            system = ActLoop.phoneSystem(),
            template = template,
            maxSteps = when (thinking) { 0 -> 6; 1 -> 9; else -> 12 },
            ask = { p -> kotlinx.coroutines.withTimeoutOrNull(60_000) { engine.generate(p, 0.2f, 500) {} }.orEmpty() },
            status = { s -> update(botId) { it.copy(status = s) } },
            log = mutableListOf()
        )
        val finalText = answer.ifBlank { "Je n'ai pas réussi à finir sur ton téléphone. Tu peux vérifier l'écran." }
        update(botId) { it.copy(text = PromptBuilder.clean(finalText), streaming = false, status = "") }
        return finalText
    }

    /** Dossiers, fichiers et ZIP : l'IA écrit les fichiers, l'appli les crée et les range dans un ZIP. */
    private suspend fun doFiles(botId: Long, text: String): String {
        val request = FileTool.request(text)
        if (request.isBlank()) {
            update(botId) { it.copy(text = "Dis-moi quoi créer, par exemple : « crée un dossier avec un fichier README et un script Python ».", streaming = false, status = "") }
            return ""
        }
        if (modelState !is ModelState.Ready) {
            update(botId) { it.copy(text = "Charge d'abord un modèle IA pour écrire tes fichiers.", streaming = false, status = "") }
            return ""
        }
        update(botId) { it.copy(status = "J'écris tes fichiers…") }
        val raw = engine.generate(FileTool.prompt(template, request), 0.3f, 6000) {}
        val list = FileTool.parse(PromptBuilder.clean(raw))
        if (list.isEmpty()) {
            update(botId) {
                it.copy(
                    text = "Je n'ai pas réussi à créer les fichiers. Précise ce que tu veux dedans, par exemple « un fichier notes.txt avec une liste de courses ».",
                    streaming = false, status = ""
                )
            }
            return ""
        }
        val name = FileTool.projectName(request)
        val base = File(getApplication<Application>().filesDir, "projects")
        val out = withContext(Dispatchers.IO) { FileTool.write(base, name, list) }
        val page = FileTool.webPage(list)?.let { files.saveGame(it) }
        val isZip = out.name.endsWith(".zip")
        update(botId) {
            it.copy(
                text = (if (isZip) "J'ai créé ${list.size} fichier(s) dans le dossier « $name », rangés dans un ZIP.\n\n" else "Ton fichier est prêt.\n\n") +
                    "```\n${FileTool.tree(name, list)}\n```" +
                    (if (page != null) "\n\nCe projet a une page web : touche Jouer pour la voir tout de suite." else ""),
                streaming = false, status = "", zipPath = out.absolutePath, gameTitle = if (isZip) name else out.name,
                gamePath = page?.absolutePath
            )
        }
        return "J'ai créé ${list.size} fichier(s) : $name."
    }

    /** PowerPoint : l'IA écrit le plan, l'appli fabrique le .pptx et un aperçu à feuilleter. */
    private suspend fun doPpt(botId: Long, text: String): String {
        val request = Pptx.request(text)
        if (request.isBlank()) {
            update(botId) { it.copy(text = "Dis-moi le sujet, par exemple : « fais un PowerPoint sur les volcans ».", streaming = false, status = "") }
            return ""
        }
        if (modelState !is ModelState.Ready) {
            update(botId) { it.copy(text = "Charge d'abord un modèle IA pour écrire ta présentation.", streaming = false, status = "") }
            return ""
        }
        update(botId) { it.copy(status = "J'écris ta présentation…") }
        val raw = engine.generate(Pptx.prompt(template, request), 0.4f, 3500) {}
        val deck = Pptx.parse(PromptBuilder.clean(raw), request.take(60))
        if (deck == null) {
            update(botId) {
                it.copy(
                    text = "Je n'ai pas réussi à écrire la présentation. Réessaie avec un sujet plus précis, ou choisis un modèle un peu plus gros.",
                    streaming = false, status = ""
                )
            }
            return ""
        }
        val file = File(getApplication<Application>().filesDir, "ppt/" + Pptx.fileName(deck.title))
        withContext(Dispatchers.IO) { Pptx.write(deck, file) }
        val preview = files.saveGame(Pptx.preview(deck))
        update(botId) {
            it.copy(
                text = "Ta présentation « ${deck.title} » est prête : ${deck.slides.size + 1} diapos. Touche Voir pour la feuilleter, " +
                    "puis Enregistrer pour avoir le fichier PowerPoint (.pptx).",
                streaming = false, status = "", zipPath = file.absolutePath, gamePath = preview.absolutePath, gameTitle = deck.title
            )
        }
        return "J'ai créé une présentation PowerPoint : ${deck.title}."
    }

    /** Modèle 3D : l'IA décrit l'objet en formes simples (ou un objet de base prêt à l'emploi), affiché et exporté en .stl. */
    private suspend fun doModel3d(botId: Long, text: String): String {
        val request = Model3D.request(text)
        if (request.isBlank()) {
            update(botId) { it.copy(text = "Décris l'objet, par exemple : une petite maison, un robot, une table.", streaming = false, status = "") }
            return ""
        }
        var shapes: String? = null
        if (modelState is ModelState.Ready) {
            update(botId) { it.copy(status = "Je modélise ton objet…") }
            val raw = kotlinx.coroutines.withTimeoutOrNull(90_000) { engine.generate(Model3D.prompt(template, request), 0.4f, 2500) {} }.orEmpty()
            shapes = Model3D.shapes(PromptBuilder.clean(raw))
        }
        val basic = shapes == null
        val finalShapes = shapes ?: Model3D.fallback(request)
        val title = request.take(28).ifBlank { "Modèle 3D" }
        val page = files.saveGame(Model3D.html(title, finalShapes))
        val stlFile = File(getApplication<Application>().filesDir, "models3d/" + Model3D.fileName(request))
        withContext(Dispatchers.IO) {
            stlFile.parentFile?.mkdirs()
            stlFile.writeText(Model3D.stl(title, finalShapes))
        }
        update(botId) {
            it.copy(
                text = "Ton modèle 3D est prêt" + (if (basic) " (version de base)" else "") + " ! Touche Ici pour le tourner dans le chat " +
                    "(dessus, dessous, côté), ou Jouer en plein écran. Enregistrer te donne le fichier .stl " +
                    "(Blender, impression 3D…).",
                streaming = false, status = "", zipPath = stlFile.absolutePath, gamePath = page.absolutePath, gameTitle = title
            )
        }
        return "J'ai modélisé en 3D : ${request.take(80)}."
    }

    /** Cartes mémoire : l'IA locale écrit les cartes, l'appli les affiche en révision interactive. */
    private suspend fun doCards(botId: Long, text: String): String {
        val topic = Flashcards.topic(text)
        if (topic.isBlank()) {
            update(botId) { it.copy(text = "Dis-moi le sujet, par exemple : « fais-moi des cartes mémoire sur les capitales d'Europe ».", streaming = false, status = "") }
            return ""
        }
        if (modelState !is ModelState.Ready) {
            update(botId) { it.copy(text = "Charge d'abord un modèle IA (Menu ☰ → Modèle et réglages) pour créer des cartes.", streaming = false, status = "") }
            return ""
        }
        update(botId) { it.copy(status = "Je prépare tes cartes…") }
        val want = Flashcards.count(text)
        val cards = mutableListOf<Flashcard>()
        var fails = 0
        var rounds = 0
        // Par petits lots de 5 : on voit avancer, et le nombre demandé est respecté
        while (cards.size < want && fails < 2 && rounds < want + 4) {
            rounds++
            val k = minOf(5, want - cards.size)
            val prompt = if (fails == 0) Flashcards.prompt(template, topic, k, cards.map { it.front }) else PromptBuilder.wrap(
                template, "Tu écris des cartes de révision. Une carte par ligne : question :: réponse.",
                "Sujet : ${topic.take(200)}. Écris $k cartes."
            )
            val raw = engine.generate(prompt, 0.5f, 220 * k) { partial ->
                val n = cards.size + partial.count { it == '\n' }.coerceAtMost(k)
                update(botId) { it.copy(status = "J'écris tes cartes… (${minOf(n, want)}/$want)") }
            }
            val seen = cards.map { it.front.lowercase() }.toSet()
            val fresh = Flashcards.parse(PromptBuilder.clean(raw)).filter { it.front.lowercase() !in seen }
            if (fresh.isEmpty()) {
                fails++
            } else {
                fails = 0
                cards += fresh.take(want - cards.size)
            }
        }
        if (cards.size < 2) {
            update(botId) { it.copy(text = "Je n'ai pas réussi à écrire les cartes. Essaie avec un sujet plus précis, ou un modèle un peu plus gros.", streaming = false, status = "") }
            return ""
        }
        val set = FlashcardSet("d${System.currentTimeMillis()}", topic, cards)
        decksStore.save(set)
        decks = decksStore.list()
        val page = files.saveGame(Flashcards.html(topic, cards))
        update(botId) {
            it.copy(
                text = "Tes ${cards.size} cartes sur « $topic » sont prêtes" +
                    (if (cards.size < want) " (tu en voulais $want, je n'ai pas pu en écrire plus)" else "") +
                    " ! Touche Ici pour les réviser dans le chat (touche une carte pour la retourner), ou Jouer en plein écran.",
                streaming = false, status = "", gamePath = page.absolutePath, gameTitle = "Cartes : " + topic.take(24)
            )
        }
        return "J'ai créé ${cards.size} cartes sur $topic."
    }

    // ---------- Cartes mémoire : decks, révision, quiz ----------

    /** Ouvre un deck enregistré, en révision (carte retournable) ou en quiz (réponse tapée). */
    fun openDeck(set: FlashcardSet, quiz: Boolean) {
        flashcardQuiz = quiz
        flashcards = set
    }

    /** Enregistre la note d'une carte (« Je savais » / « À revoir ») dans le deck. */
    fun gradeCard(index: Int, knewIt: Boolean) {
        val set = flashcards ?: return
        val updated = Flashcards.grade(set, index, knewIt)
        flashcards = updated
        decksStore.save(updated)
        decks = decksStore.list()
    }

    fun closeFlashcards() {
        flashcards = null
    }

    fun deleteDeck(id: String) {
        decksStore.delete(id)
        decks = decksStore.list()
    }

    // ---------- Navigateur, enregistrement de fichiers ----------

    private var working = 0

    private fun workStart(text: String) {
        working++
        runCatching { WorkService.start(getApplication<Application>(), text) }
    }

    private fun workEnd() {
        working = (working - 1).coerceAtLeast(0)
        if (working == 0) {
            viewModelScope.launch {
                kotlinx.coroutines.delay(1_500)
                if (working == 0) runCatching { WorkService.stop(getApplication<Application>()) }
            }
        }
    }

    /** Ferme le navigateur. Si l'agent y travaillait, il s'arrête. */
    fun closeBrowser() {
        if (browserBusy) stop()
        browseUrl = null
        browserAnswer = ""
        WebDriver.detach()
    }

    /** Enregistre un fichier créé par l'appli dans Téléchargements (sans bloquer l'écran). */
    fun saveFile(path: String, name: String, mime: String, onDone: (String) -> Unit) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            val msg = withContext(Dispatchers.IO) {
                runCatching {
                    val file = File(path)
                    if (Build.VERSION.SDK_INT >= 29) {
                        val values = ContentValues().apply {
                            put(MediaStore.Downloads.DISPLAY_NAME, name)
                            put(MediaStore.Downloads.MIME_TYPE, mime)
                            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        }
                        val uri = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
                        app.contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
                        "Enregistré dans Téléchargements : $name ✅"
                    } else {
                        val dir = app.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: app.filesDir
                        val target = File(dir, name)
                        file.copyTo(target, overwrite = true)
                        "Enregistré : ${target.absolutePath}"
                    }
                }.getOrElse { "Je n'ai pas pu enregistrer le fichier : ${it.message ?: it.javaClass.simpleName}" }
            }
            onDone(msg)
        }
    }

    /** Un jeu : soit un jeu prêt à l'emploi personnalisé par l'IA, soit du code HTML écrit par l'IA. */
    private suspend fun doGame(botId: Long, text: String, kind0: String?): String {
        val request = GameTool.request(text)
        val app = getApplication<Application>()
        var kind = kind0
        var note = ""
        // Aucun jeu connu pour cette demande : l'IA écrit elle-même le code (quel que soit le niveau de réflexion).
        // Sans modèle chargé, on propose le jeu prêt à l'emploi le plus proche.
        if (kind == null && modelState !is ModelState.Ready) {
            kind = GameLib.fallbackKind(request)
            note = " Charge un modèle IA pour que j'écrive un jeu sur mesure ; en attendant, voici le jeu prêt à l'emploi le plus proche."
        }
        val chosen: String? = kind
        if (chosen != null) {
            update(botId) { it.copy(status = "Je conçois ton jeu ${GameLib.label(chosen)}…") }
            val spec = GameLib.parseSpec("", chosen, request)
            val html = withContext(Dispatchers.IO) { GameLib.build(app, spec) }
            val f = files.saveGame(html)
            update(botId) {
                it.copy(
                    text = "Ton jeu « ${spec.title} » est prêt ! Touche Jouer pour l'essayer tout de suite, " +
                        "ou APK pour l'installer sur ton téléphone.$note",
                    streaming = false, status = "", gamePath = f.absolutePath, gameTitle = spec.title
                )
            }
            return "J'ai créé le jeu ${spec.title} (${GameLib.label(chosen)})."
        }

        // L'IA écrit le code du jeu elle-même (5 minutes maximum)
        update(botId) { it.copy(status = "Je programme ton jeu…") }
        val prompt = PromptBuilder.game(template, request, maxTokens)
        val answer = kotlinx.coroutines.withTimeoutOrNull(300_000) {
            engine.generate(prompt, 0.5f, 9000) { partial ->
                update(botId) { it.copy(status = "Je programme ton jeu… (${partial.length / 40} lignes)") }
            }
        }.orEmpty()
        val finalText = PromptBuilder.clean(answer)
        var block = Regex("```(?:html)?[ \\t]*\\n([\\s\\S]*?)(?:```|$)").find(finalText)?.groupValues?.get(1).orEmpty().trim()
        if (block.isEmpty() && finalText.contains("<script", true)) block = finalText.substring(finalText.indexOf('<')).trim()
        // Code coupé avant la fin : on referme les balises ouvertes
        if (block.contains("<script", true) && !block.contains("</script>", true)) block += "\n</script>"
        if (block.contains("<body", true) && !block.contains("</body>", true)) block += "\n</body>"
        val isHtml = block.contains("<script", true) || block.contains("<canvas", true)
        if (isHtml) {
            val f = files.saveGame(block)
            update(botId) {
                it.copy(
                    text = "Voilà ton jeu ! Touche Ici pour y jouer dans le chat, ou Jouer en plein écran.",
                    streaming = false, status = "", gamePath = f.absolutePath,
                    gameTitle = request.take(28).ifBlank { "Ton jeu" }
                )
            }
        } else {
            // Le modèle n'a pas réussi : un jeu prêt à l'emploi prend le relais (selon la demande, pas toujours le même)
            val fk = GameLib.fallbackKind(request)
            val spec = GameLib.parseSpec("", fk, request)
            val html = withContext(Dispatchers.IO) { GameLib.build(app, spec) }
            val f = files.saveGame(html)
            update(botId) {
                it.copy(
                    text = "Je n'ai pas réussi à programmer « ${request.take(30)} » (mon modèle est trop petit pour ça). " +
                        "Voici le jeu prêt à l'emploi le plus proche : ${GameLib.label(fk)}. " +
                        "Avec un modèle plus gros (Qwen Coder 7B, par exemple), j'écris des jeux sur mesure.",
                    streaming = false, status = "", gamePath = f.absolutePath, gameTitle = spec.title
                )
            }
        }
        return "J'ai créé un jeu : ${request.take(80)}."
    }

    /** Site web : l'IA écrit la page, l'appli l'affiche (Jouer = aperçu) et peut l'exporter en APK. */
    private suspend fun doSite(botId: Long, text: String): String {
        val request = SiteTool.request(text)
        update(botId) { it.copy(status = "Je construis ton site…") }
        val answer = engine.generate(PromptBuilder.site(template, request, maxTokens), 0.5f) { partial ->
            update(botId) { it.copy(text = PromptBuilder.clean(partial), status = "") }
        }
        val finalText = PromptBuilder.clean(answer)
        val block = Regex("```(?:html)?[ \\t]*\\n([\\s\\S]*?)(?:```|$)").find(finalText)?.groupValues?.get(1).orEmpty()
        if (block.contains("<", false) && (block.contains("<body", true) || block.contains("<html", true) || block.contains("<div", true))) {
            val f = files.saveGame(block.trim())
            val rest = finalText.replace(Regex("```(?:html)?[ \\t]*\\n[\\s\\S]*?(?:```|$)"), "").trim()
            update(botId) {
                it.copy(
                    text = rest.ifBlank { "Voilà ton site ! Touche Jouer pour l'ouvrir, ou APK pour l'installer." },
                    streaming = false, status = "", gamePath = f.absolutePath,
                    gameTitle = "Site : " + request.take(22).ifBlank { "ma page" }
                )
            }
        } else {
            update(botId) { it.copy(text = finalText, streaming = false, status = "") }
        }
        return "J'ai créé un site web : ${request.take(80)}."
    }

    private suspend fun doImage(botId: Long, text: String): String {
        val request = text.removePrefix("/image").trim()
        var prompt = request
        if (modelState is ModelState.Ready && (thinking > 0 || SdLocal.isInstalled(getApplication<Application>())) && request.length < 40) {
            val better = runCatching {
                PromptBuilder.cleanImagePrompt(
                    kotlinx.coroutines.withTimeoutOrNull(25_000) { engine.generate(PromptBuilder.imagePrompt(template, request), 0.6f, 220) {} }.orEmpty()
                )
            }.getOrNull()
            if (!better.isNullOrBlank() && better.length > 5) prompt = better
        }
        val app = getApplication<Application>()
        val local = SdLocal.isInstalled(app)
        update(botId) { it.copy(status = if (local) "Je dessine en local sur le GPU… (1 à 2 minutes)" else "Je dessine…") }
        return try {
            val bytes = withContext(Dispatchers.IO) {
                if (local) SdLocal.generateJpeg(app, prompt) else ImageGen.fetch(imageUrl, prompt, imageKey)
            }
            val file = files.saveImage(bytes)
            update(botId) {
                it.copy(
                    text = imageReplies.random(), streaming = false, status = "",
                    imagePath = file.absolutePath, imagePrompt = prompt
                )
            }
            "J'ai généré une image (prompt : $prompt)."
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            update(botId) {
                it.copy(
                    text = if (local)
                        "Je n'ai pas réussi à dessiner en local (${e.message ?: "erreur"}). Vérifie que le dossier importé est bien un modèle Stable Diffusion converti pour MediaPipe."
                    else
                        "Je n'ai pas réussi à dessiner ça (${e.message ?: "erreur réseau"}). Vérifie ta connexion et réessaie dans un instant.",
                    streaming = false, status = ""
                )
            }
            ""
        }
    }

    /**
     * Les 3 premières questions et le dernier échange sont repris tels quels par Memory.build.
     * Le résumé ne contient donc que les échanges du milieu, ajoutés un par un.
     */
    private fun rollSummary(my: Int) {
        val turns = Memory.turns(messages.filter { it.text.isNotBlank() })
        val idx = turns.size - 2
        if (idx < 3) return
        startSummary(my, turns[idx])
    }

    private fun startSummary(my: Int, t: Turn) {
        val line = "• " + t.q.replace(Regex("\\s+"), " ").take(120) + " → " + t.a.replace(Regex("\\s+"), " ").take(200)
        val merged = (summary + "\n" + line).trim()
        if (merged.length <= 800) {
            summary = merged
            persist()
            return
        }
        val tpl = template
        val previous = summary
        summaryJob = viewModelScope.launch {
            runCatching {
                val s = engine.generate(PromptBuilder.summary(tpl, previous, t), 0.3f) {}
                if (my == gen) {
                    summary = PromptBuilder.clean(s).take(700)
                    persist()
                }
            }
        }
    }

    override fun onCleared() {
        persist()
        engine.close()
        super.onCleared()
    }

    companion object {
        const val AUTO = "@auto"
    }
}
