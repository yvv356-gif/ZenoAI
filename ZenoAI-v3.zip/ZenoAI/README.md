# ZenoAI

Assistant IA mobile (Android) : texte généré **sur le téléphone**, avec accès internet pour la recherche web et les images.

- Moteur : MediaPipe LLM Inference (modèles `.task` : Qwen2.5-1.5B par défaut, ou Gemma 3 1B)
- Réponses directes : 1 à 4 phrases par défaut ; plus long seulement pour un développement, du code ou un tableau (Zeno décide)
- Niveau de réflexion **bas / moyen / élevé** (cerveau en haut de l'écran) : vitesse contre profondeur
- À chaque message, l'IA relit un **résumé** de la conversation
- Recherche web **multi-sources** : Wikipédia (langue + EN) et DuckDuckGo pour les faits ; GitHub, Reddit et DuckDuckGo pour le code ; `/web` pour forcer
- Tableaux Markdown affichés dans les bulles
- Jeux : `/jeu snake` → jeu HTML/JS écrit par Zeno, bouton **Jouer** pour le tester dans l'app (WebView sans réseau), erreurs captées et bouton **Corriger**
- Menu ☰ → **Personnalisation** : fond d'écran, profil (nom + photo) de toi et de l'IA, couleur du texte et des encadrés, opacité
- Images : « dessine… », « génère une image de… » ou `/image …` (service en ligne Pollinations)
- Historique : chaque discussion est gardée sur le téléphone ; un clic la recharge, la précédente est déchargée de la mémoire

## Compiler
Pousse le zip (ou le dossier) sur GitHub avec `.github/workflows/build.yml` :
**Actions → Build ZenoAI APK → Artifacts**.

## Premier lancement
Menu ☰ → *Modèle et réglages* → **Télécharger** (≈ 1,6 Go) ou **Importer** un `.task`.

## Nouveautés
- Bouton du modèle sur l'écran d'accueil : Auto, Qwen, Gemma… (la discussion est conservée), mode agent, niveau de réflexion
- Mémoire : les 3 premières questions, le dernier échange et les échanges pertinents restent dans le prompt
- Jeux prêts à l'emploi (assets/games) personnalisés par l'IA, aperçu jouable, export APK (module `gameshell`, signé sur le téléphone avec apksig)
- Sites web : `/site …` (aperçu + APK) ; vidéos : `/video …` (Pollinations, clé requise) ; images : même clé
- Liens cliquables dans les réponses et les sources
- Le workflow compile d'abord `:gameshell:assembleRelease` et copie l'APK dans `app/src/main/assets/game-shell.apk`
