package ai.zeno.app

enum class Role { USER, AI }

data class ChatMessage(
    val id: Long,
    val role: Role,
    val text: String,
    val streaming: Boolean = false,
    val status: String = "",
    val imagePath: String? = null,
    val imagePrompt: String = "",
    val sources: String = "",
    val gamePath: String? = null,
    val gameTitle: String = "",
    val videoPath: String? = null
)

data class ChatMeta(val id: String, val title: String, val updatedAt: Long)

sealed interface ModelState {
    data object None : ModelState
    data class Busy(val label: String, val progress: Float? = null) : ModelState
    data object Ready : ModelState
    data class Error(val message: String) : ModelState
}

/** Personnalisation de l'interface. Une couleur à 0 = couleur par défaut. */
data class Look(
    val wallpaper: String = "",
    val userName: String = "Toi",
    val aiName: String = "Zeno",
    val userAvatar: String = "",
    val aiAvatar: String = "",
    val textColor: Int = 0,
    val userBubble: Int = 0,
    val aiBubble: Int = 0,
    val bubbleAlpha: Float = 0.4f
)

/** Modèles proposés. « key » sert à reconnaître le fichier installé d'après son nom. */
data class ModelPreset(val label: String, val sub: String, val url: String, val key: String)

object ModelPresets {
    const val GEMMA2_URL =
        "https://huggingface.co/litert-community/Gemma2-2B-IT/resolve/main/Gemma2-2B-IT_multi-prefill-seq_q8_ekv1280.task"

    val list = listOf(
        ModelPreset(
            "Qwen 2.5 · 7 Md",
            "Le plus puissant, mais ≈ 8 Go de mémoire vive. Je n'ai trouvé aucun fichier officiel à ce format : importe ton fichier .task.",
            "", "qwen2.5-7b"
        ),
        ModelPreset(
            "Gemma 2 · 2 Md",
            "Très à l'aise à l'écrit · ≈ 2,6 Go · ≈ 6 Go de mémoire vive · demande d'accepter la licence Gemma et ton jeton Hugging Face.",
            GEMMA2_URL, "gemma2-2b"
        ),
        ModelPreset(
            "Qwen 2.5 · 1,5 Md (léger)",
            "Rapide, bon en code · ≈ 1,6 Go · le choix des vieux téléphones.",
            Prefs.QWEN_URL, "qwen2.5-1.5b"
        )
    )

    fun presetFor(name: String): ModelPreset? = list.firstOrNull { name.lowercase().contains(it.key) }
}
