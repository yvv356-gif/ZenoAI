package ai.zeno.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.android.apksig.ApkSigner
import java.io.File
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import javax.security.auth.x500.X500Principal

/**
 * Fabrique un vrai APK installable à partir d'un jeu HTML :
 * on prend « game-shell.apk » (une mini-appli WebView, module :gameshell, ajouté aux assets par le workflow),
 * on y glisse le jeu (assets/game.html), on change le nom de package (pour pouvoir installer plusieurs jeux),
 * puis on le signe avec une clé générée sur le téléphone.
 */
object ApkExporter {

    private const val ALIAS = "zeno_games"
    private const val TOKEN = "n0000"

    fun available(context: Context): Boolean =
        runCatching { context.assets.open("game-shell.apk").close(); true }.getOrDefault(false)

    fun build(context: Context, html: String, output: File) {
        val unsigned = File(context.cacheDir, "game_unsigned.apk")
        val suffix = "n" + (1000..9999).random()
        context.assets.open("game-shell.apk").use { input ->
            ZipInputStream(input).use { zin ->
                ZipOutputStream(unsigned.outputStream().buffered()).use { zout ->
                    while (true) {
                        val e = zin.nextEntry ?: break
                        val name = e.name
                        if (e.isDirectory || name.startsWith("META-INF/")) continue
                        var data = zin.readBytes()
                        if (name == "AndroidManifest.xml") data = patchPackage(data, suffix)
                        zout.putNextEntry(ZipEntry(name))
                        zout.write(data)
                        zout.closeEntry()
                    }
                    zout.putNextEntry(ZipEntry("assets/game.html"))
                    zout.write(html.toByteArray(Charsets.UTF_8))
                    zout.closeEntry()
                }
            }
        }
        try {
            sign(unsigned, output)
        } finally {
            unsigned.delete()
        }
    }

    /** Remplace « n0000 » par « nXXXX » (même longueur) dans le manifeste binaire, en UTF-8 et en UTF-16. */
    private fun patchPackage(manifest: ByteArray, suffix: String): ByteArray {
        val out = manifest.copyOf()
        replaceAll(out, TOKEN.toByteArray(Charsets.UTF_8), suffix.toByteArray(Charsets.UTF_8))
        replaceAll(out, TOKEN.toByteArray(Charsets.UTF_16LE), suffix.toByteArray(Charsets.UTF_16LE))
        return out
    }

    private fun replaceAll(data: ByteArray, from: ByteArray, to: ByteArray) {
        var i = 0
        while (i <= data.size - from.size) {
            var ok = true
            for (j in from.indices) if (data[i + j] != from[j]) { ok = false; break }
            if (ok) {
                for (j in to.indices) data[i + j] = to[j]
                i += from.size
            } else i++
        }
    }

    private fun sign(input: File, output: File) {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!ks.containsAlias(ALIAS)) {
            val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore")
            kpg.initialize(
                KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN)
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
                    .setKeySize(2048)
                    .setCertificateSubject(X500Principal("CN=ZenoAI Games"))
                    .build()
            )
            kpg.generateKeyPair()
        }
        val key = ks.getKey(ALIAS, null) as PrivateKey
        val cert = ks.getCertificate(ALIAS) as X509Certificate
        val signer = ApkSigner.Builder(listOf(ApkSigner.SignerConfig.Builder("zeno", key, listOf(cert)).build()))
            .setInputApk(input)
            .setOutputApk(output)
            .setMinSdkVersion(26)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(false)
            .setCreatedBy("ZenoAI")
            .build()
        signer.sign()
    }
}
