package ai.zeno.app

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/** Enveloppe autour de MediaPipe LLM Inference : le modèle tourne sur le téléphone. */
class LlmEngine(private val context: Context) {

    private var llm: LlmInference? = null
    private val mutex = Mutex()

    suspend fun load(path: String, maxTokens: Int) = withContext(Dispatchers.Default) {
        mutex.withLock {
            llm?.close()
            llm = null
            val options = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(path)
                .setMaxTokens(maxTokens)
                .build()
            llm = LlmInference.createFromOptions(context, options)
        }
    }

    /** Réponse en streaming. Une session neuve par requête : le contexte vient du résumé. */
    suspend fun generate(
        prompt: String,
        temperature: Float = 0.6f,
        onPartial: (String) -> Unit
    ): String = withContext(Dispatchers.Default) {
        mutex.withLock {
            val engine = llm ?: error("Modèle non chargé")
            val sessionOptions = LlmInferenceSession.LlmInferenceSessionOptions.builder()
                .setTopK(40)
                .setTopP(0.9f)
                .setTemperature(temperature)
                .build()
            val session = LlmInferenceSession.createFromOptions(engine, sessionOptions)
            try {
                session.addQueryChunk(prompt)
                val sb = StringBuilder()
                suspendCancellableCoroutine<Unit> { cont ->
                    session.generateResponseAsync { partial, done ->
                        sb.append(partial)
                        onPartial(sb.toString())
                        if (done && cont.isActive) cont.resume(Unit)
                    }
                    cont.invokeOnCancellation {
                        runCatching { session.cancelGenerateResponseAsync() }
                    }
                }
                sb.toString()
            } finally {
                runCatching { session.close() }
            }
        }
    }

    fun close() {
        runCatching { llm?.close() }
        llm = null
    }
}
