package com.zenoai.app.engine

import android.app.ActivityManager
import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.zenoai.app.data.Fmt
import com.zenoai.app.data.ModelInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

fun interface TokenCallback { fun onToken(t: String) }

object NativeLlm {
    init { System.loadLibrary("zenollm") }
    external fun load(path: String, threads: Int, nCtx: Int, mlock: Boolean): Boolean
    external fun generate(roles: Array<String>, contents: Array<String>, maxTokens: Int, cb: TokenCallback): String
    external fun stop()
    external fun unload()
}

class LlmEngine(private val ctx: Context) {
    var loadedId: String? = null; private set
    private var mp: LlmInference? = null
    private var fmt = Fmt.GGUF
    private val lock = Mutex()
    @Volatile private var onPart: ((String, Boolean) -> Unit)? = null

    /** Tous les cœurs du processeur, et un contexte dimensionné sur la RAM réellement disponible. */
    private val threads = Runtime.getRuntime().availableProcessors().coerceAtLeast(2)
    private fun memInfo() = ActivityManager.MemoryInfo().also { (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(it) }
    fun availMb() = memInfo().availMem / 1_048_576
    private fun ctxSize(): Int = when (val gb = (availMb() / 1024).toInt()) { in 0..2 -> 2048; in 3..5 -> 4096; in 6..9 -> 8192; else -> if (gb > 14) 16384 else 8192 }

    suspend fun load(m: ModelInfo, file: File) = lock.withLock {
        withContext(Dispatchers.Default) {
            unloadInternal()
            fmt = m.fmt
            if (m.fmt == Fmt.GGUF) {
                val lockRam = file.length() / 1_048_576 < availMb() * 0.6   // verrouille en RAM si ça tient
                check(NativeLlm.load(file.absolutePath, threads, ctxSize(), lockRam)) { "Chargement impossible (RAM insuffisante ou fichier invalide)" }
            } else {
                mp = LlmInference.createFromOptions(ctx, LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(file.absolutePath).setMaxTokens(1280)
                    .setResultListener { part, done -> onPart?.invoke(part ?: "", done) }.build())
            }
            loadedId = m.id
        }
    }

    private fun unloadInternal() { if (loadedId != null) { if (fmt == Fmt.GGUF) NativeLlm.unload() else { mp?.close(); mp = null } }; loadedId = null }

    suspend fun chat(messages: List<Pair<String, String>>, maxTokens: Int = 1024, onToken: (String) -> Unit): String = lock.withLock {
        withContext(Dispatchers.Default) {
            if (fmt == Fmt.GGUF) {
                NativeLlm.generate(messages.map { it.first }.toTypedArray(), messages.map { it.second }.toTypedArray(), maxTokens, TokenCallback { onToken(it) })
            } else {
                val prompt = messages.joinToString("") { "<|im_start|>${it.first}\n${it.second}<|im_end|>\n" } + "<|im_start|>assistant\n"
                val sb = StringBuilder()
                suspendCancellableCoroutine<Unit> { c ->
                    onPart = { part, done ->
                        if (part.isNotEmpty()) { sb.append(part); onToken(part) }
                        if (done && c.isActive) c.resume(Unit)
                    }
                    mp!!.generateResponseAsync(prompt)
                }
                sb.toString()
            }
        }
    }

    fun stop() { if (fmt == Fmt.GGUF) NativeLlm.stop() }
}
