package com.zenoai.app

import android.app.Application
import java.io.File

/** Enregistre la cause d'un plantage pour l'afficher au prochain lancement. */
class ZenoApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { File(filesDir, "crash.txt").writeText("Thread ${t.name}\n" + android.util.Log.getStackTraceString(e).take(3500)) } catch (_: Exception) {}
            old?.uncaughtException(t, e)
        }
    }
}
