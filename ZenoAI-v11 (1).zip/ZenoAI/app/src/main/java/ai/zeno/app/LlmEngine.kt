package ai.zeno.app

import android.content.Context
import android.net.Uri
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import org.nehuatl.llamacpp.LlamaHelper
import java.io.File
import kotlin.coroutines.resume

/**
 * Moteur IA local, deux formats :
 * - .task : MediaPipe (Gemma, Qwen, Phi… convertis pour Google)
 * - .gguf : llama.cpp (Qwen2.5-Coder, Llama 3.x, Gemma 2…)
 */
class LlmEngine(private val context: Context) {

    private var llm: LlmInference? = null
    private var gguf: LlamaHelper? = null
    private var ggufCtx = 2048
    private val mutex = Mutex()

    private val ggufScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val ggufFlow = MutableSharedFlow<LlamaHelper.LLMEvent>(
        replay = 0,
        extraBufferCapacity = 256,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    suspend fun load(path: String, maxTokens: Int) = withContext(Dispatchers.Default) {
        mutex.withLock {
            releaseAll()
            if (path.endsWith(".gguf", ignoreCase = true)) loadGguf(path, maxTokens) else loadTask(path, maxTokens)
        }
    }

    private fun loadTask(path: String, maxTokens: Int) {
        // GPU d'abord (beaucoup plus rapide, moins de chauffe) ; repli sur le CPU si le téléphone ne le gère pas.
        llm = runCatching {
            LlmInference.createFromOptions(
                context,
                LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(path)
                    .setMaxTokens(maxTokens)
                    .setPreferredBackend(LlmInference.Backend.GPU)
                    .build()
            )
        }.getOrElse {
            LlmInference.createFromOptions(
                context,
                LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(path)
                    .setMaxTokens(maxTokens)
                    .build()
            )
        }
    }

    private suspend fun loadGguf(path: String, ctx: Int) {
        val helper = LlamaHelper(
            contentResolver = context.contentResolver,
            scope = ggufScope,
            sharedFlow = ggufFlow
        )
        val loaded = CompletableDeferred<Unit>()
        val watcher = ggufScope.launch {
            ggufFlow.collect { ev ->
                if (ev is LlamaHelper.LLMEvent.Error) {
                    loaded.completeExceptionally(IllegalStateException("chargement impossible : ${ev.message}"))
                }
            }
        }
        try {
            withTimeoutOrNull(2_000) { ggufFlow.subscriptionCount.first { it > 0 } }
            helper.load(path = Uri.fromFile(File(path)).toString(), contextLength = ctx) {
                loaded.complete(Unit)
            }
            withTimeout(300_000) { loaded.await() }
        } catch (e: Throwable) {
            runCatching { helper.release() }
            throw e
        } finally {
            watcher.cancel()
        }
        gguf = helper
        ggufCtx = ctx
    }

    /**
     * Réponse en streaming. Une session neuve par requête : le contexte vient de la mémoire de la conversation.
     * (La température ne s'applique qu'aux modèles .task ; llama.cpp utilise ses réglages par défaut.)
     */
    suspend fun generate(
        prompt: String,
        temperature: Float = 0.6f,
        maxChars: Int = 0,
        onPartial: (String) -> Unit
    ): String = withContext(Dispatchers.Default) {
        mutex.withLock {
            if (gguf != null) generateGguf(prompt, maxChars, onPartial) else generateTask(prompt, temperature, onPartial)
        }
    }

    private suspend fun generateTask(prompt: String, temperature: Float, onPartial: (String) -> Unit): String {
        val engine = llm ?: error("Modèle non chargé")
        val sessionOptions = LlmInferenceSession.LlmInferenceSessionOptions.builder()
            .setTopK(40)
            .setTopP(0.9f)
            .setTemperature(temperature)
            .build()
        val session = LlmInferenceSession.createFromOptions(engine, sessionOptions)
        try {
            session.addQueryChunk(prompt)
            val sb = StringBuilder()
            suspendCancellableCoroutine<Unit> { cont ->
                session.generateResponseAsync { partial, done ->
                    sb.append(partial)
                    onPartial(sb.toString())
                    if (done && cont.isActive) cont.resume(Unit)
                }
                cont.invokeOnCancellation {
                    runCatching { session.cancelGenerateResponseAsync() }
                }
            }
            return sb.toString()
        } finally {
            runCatching { session.close() }
        }
    }

    private suspend fun generateGguf(prompt: String, maxCharsArg: Int, onPartial: (String) -> Unit): String = coroutineScope {
        val helper = gguf ?: error("Modèle non chargé")
        val sb = StringBuilder()
        val done = CompletableDeferred<Unit>()
        val maxChars = if (maxCharsArg > 0) minOf(maxCharsArg, ggufCtx * 4) else ggufCtx * 4
        val collector = launch(Dispatchers.IO) {
            ggufFlow.collect { ev ->
                when (ev) {
                    is LlamaHelper.LLMEvent.Ongoing -> {
                        sb.append(ev.word)
                        // Le modèle ne s'arrête pas toujours seul : on coupe dès qu'il ouvre un nouveau tour.
                        val cut = STOPS.map { sb.indexOf(it) }.filter { it >= 0 }.minOrNull()
                        if (cut != null) {
                            sb.setLength(cut)
                            onPartial(sb.toString())
                            runCatching { helper.abort() }
                            done.complete(Unit)
                            return@collect
                        }
                        onPartial(sb.toString())
                        if (sb.length > maxChars) {
                            runCatching { helper.abort() }
                            done.complete(Unit)
                        }
                    }
                    is LlamaHelper.LLMEvent.Done -> done.complete(Unit)
                    is LlamaHelper.LLMEvent.Error ->
                        done.completeExceptionally(IllegalStateException("génération interrompue : ${ev.message}"))
                    else -> {}
                }
            }
        }
        try {
            withTimeoutOrNull(2_000) { ggufFlow.subscriptionCount.first { it > 0 } }
            helper.predict(prompt)
            done.await()
        } catch (e: CancellationException) {
            runCatching { helper.abort() }
            throw e
        } finally {
            collector.cancel()
            runCatching { helper.stopPrediction() }
        }
        sb.toString()
    }

    private companion object {
        val STOPS = listOf(
            "<|im_end|>", "<|im_start|>", "<|endoftext|>", "<|eot_id|>", "<|end_of_text|>",
            "<end_of_turn>", "<start_of_turn>", "\n[Message de l'utilisateur]", "\nUtilisateur :"
        )
    }

    private fun releaseAll() {
        runCatching { llm?.close() }
        llm = null
        gguf?.let { h ->
            runCatching { h.abort() }
            runCatching { h.release() }
        }
        gguf = null
    }

    fun close() {
        releaseAll()
    }
}
