package ai.zeno.app

import java.io.File

/**
 * Modélisation 3D : l'IA écrit un script OpenSCAD (.scad), ouvrable dans OpenSCAD (PC) ou
 * un visualiseur .scad pour Android, et exportable en STL pour l'impression 3D.
 */
object Model3D {

    private val verbRx = Regex(
        "\\b(crée|cree|créer|creer|fais|fais-moi|faire|génère|genere|générer|generer|modélise|modelise|modéliser|dessine|conçois|concois|make|create|design|build)\\b",
        RegexOption.IGNORE_CASE
    )
    private val nounRx = Regex(
        "(modèle 3d|modele 3d|objet 3d|pièce 3d|piece 3d|en 3d|openscad|impression 3d|fichier stl|\\bstl\\b|\\b3d\\b)",
        RegexOption.IGNORE_CASE
    )

    fun isRequest(text: String): Boolean {
        val t = text.trim()
        if (t.startsWith("/3d", ignoreCase = true)) return true
        if (t.length > 300 || t.contains("```")) return false
        if (Regex("\\b(jeu|jeux|game)\\b", RegexOption.IGNORE_CASE).containsMatchIn(t)) return false
        return verbRx.containsMatchIn(t) && nounRx.containsMatchIn(t)
    }

    fun request(text: String): String =
        text.trim().replace(Regex("^/3d\\s*", RegexOption.IGNORE_CASE), "").trim()

    private const val SYSTEM =
        "Tu es un expert en modélisation 3D avec OpenSCAD. Écris UN script OpenSCAD complet pour l'objet demandé. " +
            "Utilise cube, sphere, cylinder, translate, rotate, difference, union, avec des dimensions en millimètres " +
            "et des variables en haut du fichier. \$fn = 48 pour les formes rondes. " +
            "Réponds uniquement avec le code, dans un bloc ```openscad."

    fun prompt(template: String, request: String): String =
        PromptBuilder.wrap(template, SYSTEM, "Objet demandé : ${request.take(300)}\nRéponds uniquement avec le code OpenSCAD.")

    /** Extrait le script, ou null s'il n'a pas l'air d'un script OpenSCAD. */
    fun script(raw: String): String? {
        val block = Regex("```(?:openscad|scad)?[ \\t]*\\n([\\s\\S]*?)(?:```|$)").find(raw)?.groupValues?.get(1) ?: raw
        val code = block.trim()
        val ok = Regex("\\b(cube|sphere|cylinder|difference|union|linear_extrude|polygon)\\b").containsMatchIn(code)
        return code.takeIf { ok }
    }

    fun fileName(request: String): String {
        val safe = request.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').take(24).ifBlank { "objet" }
        return "Zeno3D_${safe}_${System.currentTimeMillis() % 100000}.scad"
    }

    fun write(code: String, file: File) {
        file.parentFile?.mkdirs()
        file.writeText("// Modèle 3D créé par ZenoAI (OpenSCAD)\n$code\n")
    }
}
