package ai.zeno.app

import android.graphics.BitmapFactory
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.random.Random

/** Génération d'images via un service en ligne (Pollinations par défaut, sans clé). */
object ImageGen {

    private val verbRx = Regex(
        "\\b(génère|génere|générer|generer|genere|crée|cree|créer|creer|dessine|dessiner|fais|fais-moi|imagine|montre|make|generate|create|draw|paint)\\b",
        RegexOption.IGNORE_CASE
    )
    private val nounRx = Regex(
        "\\b(image|images|photo|photos|illustration|dessin|logo|affiche|wallpaper|fond d'écran|picture|drawing|painting|portrait|avatar)\\b",
        RegexOption.IGNORE_CASE
    )

    fun isRequest(text: String): Boolean {
        val t = text.trim()
        if (t.startsWith("/image", ignoreCase = true)) return true
        if (t.length > 300 || t.contains("```")) return false
        return verbRx.containsMatchIn(t) && nounRx.containsMatchIn(t)
    }

    fun fetch(template: String, prompt: String): ByteArray {
        val variants = listOf(template, template.replace("model=flux", "model=turbo"))
            .distinct()
        var last: Exception = IllegalStateException("Service d'images indisponible")
        for (t in variants) {
            try {
                return download(build(t, prompt))
            } catch (e: Exception) {
                last = e
            }
        }
        throw last
    }

    private fun build(template: String, prompt: String): String {
        val enc = URLEncoder.encode(prompt, "UTF-8").replace("+", "%20")
        return template
            .replace("{prompt}", enc)
            .replace("{seed}", Random.nextInt(1, 999_999).toString())
    }

    private fun download(url: String): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 120_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "ZenoAI/1.0")
        try {
            c.connect()
            if (c.responseCode !in 200..299) error("le service d'images a répondu HTTP ${c.responseCode}")
            val bytes = c.inputStream.use { it.readBytes() }
            if (bytes.size > 15_000_000) error("image trop lourde")
            val ok = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) != null
            if (!ok) error("réponse du service d'images invalide")
            return bytes
        } finally {
            c.disconnect()
        }
    }
}
