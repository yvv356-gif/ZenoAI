package ai.zeno.app

import android.app.Application
import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = Prefs(app)
    private val engine = LlmEngine(app)
    private val files = ModelManager(app)
    private val store = ChatStore(app)

    private var nextId = 1L
    private var summary = ""
    private var gen = 0
    private var genJob: Job? = null
    private var summaryJob: Job? = null
    private var dlJob: Job? = null

    var messages by mutableStateOf<List<ChatMessage>>(emptyList())
        private set
    var chats by mutableStateOf<List<ChatMeta>>(emptyList())
        private set
    var currentId by mutableStateOf<String?>(null)
        private set
    var busy by mutableStateOf(false)
        private set
    var modelState by mutableStateOf<ModelState>(ModelState.None)
        private set

    var thinking by mutableStateOf(prefs.thinking)
        private set
    var look by mutableStateOf(prefs.loadLook())
        private set

    var webEnabled by mutableStateOf(prefs.web)
    var template by mutableStateOf(prefs.template)
    var maxTokens by mutableStateOf(prefs.maxTokens)
    var modelUrl by mutableStateOf(prefs.modelUrl)
    var imageUrl by mutableStateOf(prefs.imageUrl)
    var hfToken by mutableStateOf(prefs.hfToken)

    private val imageReplies = listOf(
        "Voilà ce que ça donne !",
        "Tiens, regarde ce que j'ai dessiné pour toi.",
        "Et voilà, dis-moi si ça te plaît !",
        "C'est prêt ! Je peux en refaire une autre version si tu veux."
    )

    init {
        chats = runCatching { store.list() }.getOrDefault(emptyList())
        if (files.exists()) loadModel()
    }

    // ---------- Modèle ----------

    fun loadModel() {
        if (!files.exists()) { modelState = ModelState.None; return }
        modelState = ModelState.Busy("Chargement du modèle…")
        viewModelScope.launch {
            modelState = try {
                engine.load(files.path(), maxTokens)
                ModelState.Ready
            } catch (e: Throwable) {
                ModelState.Error("Chargement impossible : ${e.message ?: e.javaClass.simpleName}. Vérifie la famille du modèle et le contexte dans les réglages.")
            }
        }
    }

    /** Devine la famille du modèle et la taille de contexte d'après le nom du fichier. */
    private fun autoDetect(fileName: String) {
        val l = fileName.lowercase()
        if (l.contains("gemma")) template = "gemma"
        else if (l.contains("qwen") || l.contains("phi") || l.contains("smol")) template = "chatml"
        Regex("ekv(\\d+)").find(l)?.let { maxTokens = it.groupValues[1].toInt() }
        prefs.template = template
        prefs.maxTokens = maxTokens
    }

    fun download() {
        if (dlJob?.isActive == true) return
        modelState = ModelState.Busy("Téléchargement…", 0f)
        dlJob = viewModelScope.launch {
            try {
                files.download(modelUrl, hfToken) { p -> modelState = ModelState.Busy("Téléchargement…", p) }
                autoDetect(modelUrl.substringBefore('?').substringAfterLast('/'))
                loadModel()
            } catch (e: CancellationException) {
                modelState = if (files.exists()) ModelState.Ready else ModelState.None
                throw e
            } catch (e: Exception) {
                modelState = ModelState.Error("Téléchargement : ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun importModel(uri: Uri) {
        modelState = ModelState.Busy("Copie du modèle…")
        viewModelScope.launch {
            try {
                val name = files.displayName(uri)
                files.import(uri)
                autoDetect(name)
                loadModel()
            } catch (e: Exception) {
                modelState = ModelState.Error("Import : ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun applySettings(url: String, tpl: String, tokens: Int, web: Boolean, imgUrl: String, token: String) {
        val reload = tokens != maxTokens || tpl != template
        modelUrl = url.trim().ifBlank { Prefs.QWEN_URL }
        template = tpl
        maxTokens = tokens
        webEnabled = web
        imageUrl = imgUrl.trim().ifBlank { Prefs.IMAGE_URL }
        hfToken = token.trim()
        prefs.modelUrl = modelUrl
        prefs.template = tpl
        prefs.maxTokens = tokens
        prefs.web = web
        prefs.imageUrl = imageUrl
        prefs.hfToken = hfToken
        if (reload && files.exists() && modelState is ModelState.Ready) loadModel()
    }

    fun setWeb(on: Boolean) {
        webEnabled = on
        prefs.web = on
    }

    fun readText(uri: Uri): String = runCatching {
        getApplication<Application>().contentResolver.openInputStream(uri)!!.bufferedReader().use { r ->
            val buf = CharArray(20_000)
            val n = r.read(buf)
            if (n <= 0) "" else String(buf, 0, n)
        }
    }.getOrDefault("")

    fun saveToGallery(path: String): String {
        if (Build.VERSION.SDK_INT < 29) return "Pour enregistrer dans la galerie, il faut Android 10 ou plus."
        return runCatching {
            val resolver = getApplication<Application>().contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "ZenoAI_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ZenoAI")
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)!!
            resolver.openOutputStream(uri)!!.use { out -> File(path).inputStream().use { it.copyTo(out) } }
            "Image enregistrée dans ta galerie ✅"
        }.getOrElse { "Je n'ai pas pu l'enregistrer : ${it.message}" }
    }

    // ---------- Niveau de réflexion ----------

    fun setThinking(n: Int) {
        thinking = n.coerceIn(0, 2)
        prefs.thinking = thinking
    }

    fun cycleThinking() = setThinking((thinking + 1) % 3)

    // ---------- Personnalisation ----------

    private fun updateLook(f: (Look) -> Look) {
        look = f(look)
        prefs.saveLook(look)
    }

    fun setUserName(s: String) = updateLook { it.copy(userName = s.take(24)) }
    fun setAiName(s: String) = updateLook { it.copy(aiName = s.take(24)) }
    fun setTextColor(c: Int) = updateLook { it.copy(textColor = c) }
    fun setUserBubble(c: Int) = updateLook { it.copy(userBubble = c) }
    fun setAiBubble(c: Int) = updateLook { it.copy(aiBubble = c) }
    fun setBubbleAlpha(a: Float) = updateLook { it.copy(bubbleAlpha = a.coerceIn(0.15f, 1f)) }

    fun importWallpaper(uri: Uri) {
        viewModelScope.launch {
            val p = withContext(Dispatchers.IO) { ImageStore.save(getApplication<Application>(), uri, "wallpaper", 1600) }
            if (p != null) updateLook { it.copy(wallpaper = p) }
        }
    }

    fun clearWallpaper() {
        ImageStore.delete(look.wallpaper)
        updateLook { it.copy(wallpaper = "") }
    }

    fun importAvatar(user: Boolean, uri: Uri) {
        viewModelScope.launch {
            val p = withContext(Dispatchers.IO) {
                ImageStore.save(getApplication<Application>(), uri, if (user) "avatar_user" else "avatar_ai", 256)
            }
            if (p != null) updateLook { if (user) it.copy(userAvatar = p) else it.copy(aiAvatar = p) }
        }
    }

    fun clearAvatar(user: Boolean) {
        ImageStore.delete(if (user) look.userAvatar else look.aiAvatar)
        updateLook { if (user) it.copy(userAvatar = "") else it.copy(aiAvatar = "") }
    }

    fun resetLook() {
        ImageStore.delete(look.wallpaper)
        ImageStore.delete(look.userAvatar)
        ImageStore.delete(look.aiAvatar)
        look = Look()
        prefs.saveLook(look)
    }

    // ---------- Jeux ----------

    /** Envoie une demande de correction avec le code et les erreurs. Renvoie un message si c'est impossible. */
    fun fixGame(errors: String, code: String): String? {
        if (busy) return "Attends la fin de la réponse en cours."
        val msg = "/jeu Corrige ce jeu. Erreurs : ${errors.take(200)}\n```html\n$code\n```"
        if (msg.length > PromptBuilder.gameRequestCapacity(maxTokens)) {
            return "Ce jeu est trop long pour être corrigé avec une mémoire de $maxTokens. " +
                "Passe à 2048 ou 4096 dans les réglages, ou relance « /jeu … »."
        }
        send(msg)
        return null
    }

    // ---------- Historique ----------

    private fun persist() {
        val id = currentId ?: return
        val clean = messages
            .filter { it.text.isNotBlank() || it.imagePath != null }
            .map { it.copy(streaming = false, status = "") }
        val firstUser = clean.firstOrNull { it.role == Role.USER } ?: return
        val title = firstUser.text.replace(Regex("\\s+"), " ").trim().take(42)
        runCatching {
            store.save(id, title, summary, clean)
            chats = store.list()
        }
    }

    private fun stopWork() {
        gen++
        genJob?.cancel()
        summaryJob?.cancel()
        busy = false
    }

    fun newChat() {
        persist()
        stopWork()
        currentId = null
        summary = ""
        messages = emptyList()
    }

    /** Charge une discussion depuis le disque ; la précédente est sauvegardée puis déchargée de la mémoire. */
    fun openChat(id: String) {
        if (id == currentId) return
        persist()
        stopWork()
        val data = store.load(id) ?: return
        currentId = id
        summary = data.summary
        messages = data.messages
        nextId = (data.messages.maxOfOrNull { it.id } ?: 0L) + 1
    }

    // ---------- Conversation ----------

    private fun update(id: Long, f: (ChatMessage) -> ChatMessage) {
        messages = messages.map { if (it.id == id) f(it) else it }
    }

    fun stop() { genJob?.cancel() }

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || busy) return
        val wantsImage = ImageGen.isRequest(text)
        val wantsGame = !wantsImage && GameTool.isRequest(text)

        if (currentId == null) currentId = "c${System.currentTimeMillis()}"
        val userMsg = ChatMessage(nextId++, Role.USER, text)

        if (!wantsImage && modelState !is ModelState.Ready) {
            messages = messages + userMsg + ChatMessage(
                nextId++, Role.AI,
                "Il me manque mon cerveau 😅 Installe un modèle : menu ☰ → Modèle et réglages, puis on discute."
            )
            return
        }

        val botId = nextId++
        messages = messages + userMsg + ChatMessage(
            botId, Role.AI, "", streaming = true,
            status = if (wantsImage) "Je prépare mon dessin…" else "Je réfléchis…"
        )
        busy = true
        val my = ++gen

        genJob = viewModelScope.launch {
            var forSummary = ""
            try {
                summaryJob?.join()
                forSummary = if (wantsImage) doImage(botId, text) else doChat(botId, text, wantsGame)
            } catch (e: CancellationException) {
                update(botId) { it.copy(streaming = false, status = "") }
                throw e
            } catch (e: Throwable) {
                update(botId) {
                    it.copy(
                        text = "Aïe, quelque chose a coincé : ${e.message ?: e.javaClass.simpleName}. " +
                            "Si ton message était long, essaie plus court ou ouvre une nouvelle discussion.",
                        streaming = false, status = ""
                    )
                }
            } finally {
                if (my == gen) {
                    busy = false
                    persist()
                }
            }
            if (my == gen && forSummary.isNotBlank() && modelState is ModelState.Ready) {
                startSummary(my, text, forSummary)
            }
        }
    }

    private suspend fun doChat(botId: Long, text: String, game: Boolean = false): String {
        if (game) return doGame(botId, text)
        var web = WebResult.EMPTY
        val mode = if (webEnabled) WebSearch.modeFor(text, thinking) else WebSearch.Mode.NONE
        if (mode != WebSearch.Mode.NONE) {
            update(botId) {
                it.copy(status = if (mode == WebSearch.Mode.CODE) "Je cherche sur GitHub et Reddit…" else "Je cherche sur le web…")
            }
            web = runCatching {
                WebSearch.gather(
                    text,
                    PromptBuilder.webBudget(maxTokens, summary.length, text.length, PromptBuilder.wantsLong(text)),
                    mode, thinking
                )
            }.getOrDefault(WebResult.EMPTY)
            update(botId) { it.copy(status = "Je réfléchis…") }
        }
        val userName = look.userName.trim().takeIf { it.isNotBlank() && it != "Toi" }.orEmpty()
        val prompt = PromptBuilder.chat(
            template, summary, web.context, text, maxTokens,
            look.aiName.ifBlank { "Zeno" }, userName, thinking
        )
        val base = if (web.context.isNotBlank()) 0.35f else 0.7f
        val temperature = if (thinking == 2) (base - 0.1f).coerceAtLeast(0.2f) else base
        val answer = engine.generate(prompt, temperature) { partial ->
            update(botId) { it.copy(text = PromptBuilder.clean(partial), status = "") }
        }
        val finalText = PromptBuilder.clean(answer)
        update(botId) {
            it.copy(
                text = finalText, streaming = false, status = "",
                sources = web.sources.joinToString(" · ")
            )
        }
        return finalText
    }

    /** Écrit un jeu HTML/JS ; l'app propose ensuite « Jouer » pour le tester sans l'installer. */
    private suspend fun doGame(botId: Long, text: String): String {
        update(botId) { it.copy(status = "Je programme ton jeu…") }
        val request = GameTool.request(text)
        val prompt = PromptBuilder.game(template, request, maxTokens)
        val answer = engine.generate(prompt, 0.5f) { partial ->
            update(botId) { it.copy(text = PromptBuilder.clean(partial), status = "") }
        }
        val finalText = PromptBuilder.clean(answer)
        update(botId) { it.copy(text = finalText, streaming = false, status = "") }
        return "J'ai créé un jeu : ${request.take(80)}."
    }

    private suspend fun doImage(botId: Long, text: String): String {
        val request = text.removePrefix("/image").trim()
        var prompt = request
        if (modelState is ModelState.Ready) {
            val better = runCatching {
                PromptBuilder.cleanImagePrompt(
                    engine.generate(PromptBuilder.imagePrompt(template, request), 0.6f) {}
                )
            }.getOrNull()
            if (!better.isNullOrBlank() && better.length > 5) prompt = better
        }
        update(botId) { it.copy(status = "Je dessine…") }
        return try {
            val bytes = withContext(Dispatchers.IO) { ImageGen.fetch(imageUrl, prompt) }
            val file = files.saveImage(bytes)
            update(botId) {
                it.copy(
                    text = imageReplies.random(), streaming = false, status = "",
                    imagePath = file.absolutePath, imagePrompt = prompt
                )
            }
            "J'ai généré une image (prompt : $prompt)."
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            update(botId) {
                it.copy(
                    text = "Je n'ai pas réussi à dessiner ça (${e.message ?: "erreur réseau"}). " +
                        "Vérifie ta connexion et réessaie dans un instant.",
                    streaming = false, status = ""
                )
            }
            ""
        }
    }

    private fun startSummary(my: Int, user: String, ai: String) {
        // Tant que le résumé reste court, on l'écrit directement : aucun calcul du modèle,
        // donc pas d'attente avant le message suivant (important sur les vieux téléphones).
        val merged = (summary + "\nU: " + user.replace(Regex("\\s+"), " ").take(150) +
            "\nZ: " + ai.replace(Regex("\\s+"), " ").take(250)).trim()
        if (merged.length <= 600) {
            summary = merged
            persist()
            return
        }
        val tpl = template
        val previous = summary
        summaryJob = viewModelScope.launch {
            runCatching {
                val s = engine.generate(PromptBuilder.summary(tpl, previous, user, ai), 0.3f) {}
                if (my == gen) {
                    summary = PromptBuilder.clean(s).take(700)
                    persist()
                }
            }
        }
    }

    override fun onCleared() {
        persist()
        engine.close()
        super.onCleared()
    }
}
