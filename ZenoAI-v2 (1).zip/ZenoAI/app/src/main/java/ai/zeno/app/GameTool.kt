package ai.zeno.app

/**
 * Outil « jeux » : Zeno écrit un jeu HTML/JavaScript en un seul fichier.
 * L'app le lance dans une WebView isolée (sans réseau) pour le tester sans rien installer.
 * Il n'y a pas d'étape de compilation : le navigateur exécute le code, et les erreurs sont captées.
 */
object GameTool {

    private val verbRx = Regex(
        "\\b(crée|cree|créer|creer|fais|fais-moi|génère|genere|générer|generer|programme|développe|developpe|make|create|build|write)\\b",
        RegexOption.IGNORE_CASE
    )
    private val nounRx = Regex("\\b(jeu|jeux|mini-jeu|minijeu|game)\\b", RegexOption.IGNORE_CASE)
    private val otherLangRx = Regex(
        "\\b(python|kotlin|java|c\\+\\+|c#|unity|godot|lua|rust|swift|unreal|pygame)\\b",
        RegexOption.IGNORE_CASE
    )

    fun isRequest(text: String): Boolean {
        val t = text.trim()
        if (t.startsWith("/jeu", ignoreCase = true)) return true
        if (t.length > 300 || t.contains("```")) return false
        if (otherLangRx.containsMatchIn(t)) return false
        return verbRx.containsMatchIn(t) && nounRx.containsMatchIn(t)
    }

    fun request(text: String): String =
        text.trim().replace(Regex("^/jeu\\s*", RegexOption.IGNORE_CASE), "").trim()
}
