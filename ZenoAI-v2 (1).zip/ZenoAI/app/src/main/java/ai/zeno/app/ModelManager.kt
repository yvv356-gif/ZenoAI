package ai.zeno.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class ModelManager(private val context: Context) {

    private val dir get() = File(context.filesDir, "model").apply { mkdirs() }
    private val imagesDir get() = File(context.filesDir, "images").apply { mkdirs() }
    private val modelFile get() = File(dir, "model.task")

    fun exists() = modelFile.exists() && modelFile.length() > 1_000_000
    fun path(): String = modelFile.absolutePath

    fun saveImage(bytes: ByteArray): File {
        val f = File(imagesDir, "img_${System.currentTimeMillis()}.jpg")
        f.writeBytes(bytes)
        return f
    }

    fun displayName(uri: Uri): String = runCatching {
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) c.getString(i) else ""
        }.orEmpty()
    }.getOrDefault("")

    /** Téléchargement avec redirections gérées à la main (le jeton HF n'est envoyé qu'à huggingface.co). */
    suspend fun download(url: String, token: String, onProgress: (Float?) -> Unit) = withContext(Dispatchers.IO) {
        val tmp = File(dir, "model.part")
        var current = url
        var conn: HttpURLConnection? = null
        for (i in 0..6) {
            val u = URL(current)
            val c = u.openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 20_000
            c.readTimeout = 30_000
            c.setRequestProperty("User-Agent", "ZenoAI/1.0")
            if (token.isNotBlank() && u.host.endsWith("huggingface.co")) {
                c.setRequestProperty("Authorization", "Bearer ${token.trim()}")
            }
            c.connect()
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: error("Redirection invalide")
                current = URL(u, loc).toString()
                c.disconnect()
                continue
            }
            conn = c
            break
        }
        val c = conn ?: error("Trop de redirections")
        try {
            val code = c.responseCode
            if (code == 401 || code == 403) {
                error("Accès refusé (HTTP $code). Ce modèle demande d'accepter sa licence sur huggingface.co puis d'ajouter ton jeton dans les réglages.")
            }
            if (code !in 200..299) error("HTTP $code (URL incorrecte ?)")
            val total = c.contentLengthLong
            var done = 0L
            var lastPct = -1
            c.inputStream.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val pct = (done * 100 / total).toInt()
                            if (pct != lastPct) { lastPct = pct; onProgress(done.toFloat() / total) }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            tmp.delete()
            throw e
        } finally {
            c.disconnect()
        }
        modelFile.delete()
        if (!tmp.renameTo(modelFile)) error("Impossible d'enregistrer le modèle")
    }

    suspend fun import(uri: Uri) = withContext(Dispatchers.IO) {
        val tmp = File(dir, "model.part")
        context.contentResolver.openInputStream(uri)!!.use { input ->
            tmp.outputStream().use { out -> input.copyTo(out, 256 * 1024) }
        }
        modelFile.delete()
        if (!tmp.renameTo(modelFile)) error("Impossible d'enregistrer le modèle")
    }
}
