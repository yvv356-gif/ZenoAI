package ai.zeno.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.Normalizer

/** box : niveau de révision (0 = à revoir, 4 = bien sue). Plus la carte est haute, plus elle revient rarement. */
data class Flashcard(val front: String, val back: String, val box: Int = 0)

data class FlashcardSet(val id: String, val topic: String, val cards: List<Flashcard>)

/** Cartes mémoire écrites par l'IA locale, sauvegardées en decks, révisées à l'écran ou en quiz. */
object Flashcards {

    private val cmdRx = Regex("^/(cartes|flashcards)\\b", RegexOption.IGNORE_CASE)

    private const val SYSTEM =
        "Tu crées des cartes mémoire. Écris uniquement des lignes, une par carte, au format exact : question :: réponse courte. " +
            "Pas de numéro, pas de titre, pas d'autre texte."

    private val naturalRx = Regex(
        "\\b(crée|cree|créer|creer|fais|faire|génère|genere|générer|prépare|prepare)\\b.{0,60}\\b(cartes? (?:mémoire|memoire|de révision|de revision|interactives?)|flashcards?|fiches? de r[ée]vision)",
        RegexOption.IGNORE_CASE
    )

    fun isRequest(text: String): Boolean = cmdRx.containsMatchIn(text.trim()) || (text.length < 600 && naturalRx.containsMatchIn(text))

    fun topic(text: String): String = text.trim().replace(cmdRx, "").trim()

    fun prompt(template: String, topic: String): String =
        PromptBuilder.wrap(
            template, SYSTEM,
            "Sujet : ${topic.take(200)}\nÉcris 6 cartes courtes et exactes, dans la langue du sujet, au format question :: réponse."
        )

    private val bulletRx = Regex("^\\s*(?:[-*•]+|\\d+[.)])\\s*")
    private val splitRx = Regex("\\s*(?:::|\\|\\||\\||→|=>|->)\\s*")

    /** Lit les cartes : lignes « question :: réponse » (ou « Q : … R : … »), ou un tableau JSON. */
    fun parse(raw: String): List<Flashcard> {
        val out = mutableListOf<Flashcard>()
        val json = Regex("\\[[\\s\\S]*\\]").find(raw)?.value
        if (json != null) runCatching {
            val arr = JSONArray(json)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val f = listOf("recto", "question", "q", "front").map { o.optString(it).trim() }.firstOrNull { it.isNotEmpty() } ?: ""
                val b = listOf("verso", "reponse", "réponse", "r", "answer", "back").map { o.optString(it).trim() }.firstOrNull { it.isNotEmpty() } ?: ""
                if (f.isNotEmpty() && b.isNotEmpty()) out += Flashcard(f.take(200), b.take(400))
            }
        }
        if (out.size >= 2) return out.take(20)
        out.clear()
        var pendingQ: String? = null
        for (line0 in raw.lines()) {
            val line = line0.replace(bulletRx, "").replace("**", "").trim()
            if (line.isEmpty()) continue
            val qm = Regex("^(?:q|question)\\s*[:：]\\s*(.+)$", RegexOption.IGNORE_CASE).find(line)
            val rm = Regex("^(?:r|réponse|reponse|a|answer)\\s*[:：]\\s*(.+)$", RegexOption.IGNORE_CASE).find(line)
            if (qm != null) { pendingQ = qm.groupValues[1].trim(); continue }
            if (rm != null && pendingQ != null) { out += Flashcard(pendingQ.take(200), rm.groupValues[1].trim().take(400)); pendingQ = null; continue }
            val parts = line.split(splitRx, limit = 2)
            if (parts.size == 2 && parts[0].isNotBlank() && parts[1].isNotBlank()) {
                out += Flashcard(parts[0].trim().take(200), parts[1].trim().take(400))
            } else if (line.contains('?')) {
                val i = line.indexOf('?')
                val q = line.substring(0, i + 1).trim(); val r = line.substring(i + 1).trim().trimStart('-', ':', ' ')
                if (q.length > 3 && r.isNotEmpty()) out += Flashcard(q.take(200), r.take(400))
            }
        }
        return out.take(20)
    }

    /** Cartes à retourner, directement dans le chat (page autonome). */
    fun html(topic: String, cards: List<Flashcard>): String {
        val data = JSONArray(cards.map { JSONArray().put(it.front).put(it.back) }).toString().replace("</", "<\\/")
        val title = topic.replace(Regex("[<>&\"']"), " ")
        return PAGE.replace("__DATA__", data).replace("__TITLE__", title)
    }

    private val PAGE = """<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>html,body{margin:0;height:100%;background:#12141c;color:#fff;font-family:sans-serif;overflow:hidden;touch-action:manipulation}
#t{text-align:center;padding:14px 12px 4px;color:#9fa8d8;font-size:14px}
#bar{height:5px;background:#252a40;margin:6px 16px;border-radius:3px}#bar i{display:block;height:100%;width:0;background:#3FA7B8;border-radius:3px;transition:width .3s}
#stage{position:absolute;top:64px;bottom:84px;left:0;right:0;display:flex;align-items:center;justify-content:center;perspective:900px}
#card{width:min(88vw,520px);height:min(60vh,340px);position:relative;transform-style:preserve-3d;transition:transform .5s;cursor:pointer}
#card.f{transform:rotateY(180deg)}
.face{position:absolute;inset:0;border-radius:20px;display:flex;align-items:center;justify-content:center;text-align:center;padding:22px;box-sizing:border-box;font-size:22px;line-height:1.35;backface-visibility:hidden;-webkit-backface-visibility:hidden;box-shadow:0 8px 28px #0008}
.front{background:linear-gradient(135deg,#2b3a67,#3a2f6b)}.back{background:linear-gradient(135deg,#1d5c66,#2a8a6b);transform:rotateY(180deg)}
#hint{position:absolute;bottom:8px;left:0;right:0;text-align:center;font-size:12px;color:#ffffff88}
#b{position:fixed;left:0;right:0;bottom:16px;display:flex;gap:12px;justify-content:center}
button{border:0;border-radius:16px;padding:14px 22px;font-size:16px;color:#fff}
#no{background:#a8463a}#yes{background:#2f8f5b}#end{display:none;position:absolute;inset:0;flex-direction:column;align-items:center;justify-content:center;gap:16px;font-size:24px;background:#12141c}
#again{background:#3FA7B8}</style></head><body>
<div id="t">__TITLE__</div><div id="bar"><i id="p"></i></div>
<div id="stage"><div id="card" onclick="flip()"><div class="face front" id="fq"></div><div class="face back" id="fa"></div></div></div>
<div id="b"><button id="no" onclick="grade(false)">À revoir</button><button id="yes" onclick="grade(true)">Je savais</button></div>
<div id="end"><div id="sc"></div><button id="again" onclick="start()">Recommencer</button></div>
<script>
var C=__DATA__,order=[],i=0,ok=0,shown=false;
function start(){order=C.map(function(_,k){return k}).sort(function(){return Math.random()-0.5});i=0;ok=0;document.getElementById('end').style.display='none';show()}
function show(){document.getElementById('card').className='';shown=false;
 var c=C[order[i]];document.getElementById('fq').textContent=c[0];document.getElementById('fa').textContent=c[1];
 document.getElementById('p').style.width=(i/C.length*100)+'%'}
function flip(){document.getElementById('card').classList.toggle('f')}
function grade(k){if(k)ok++;i++;if(i>=C.length){document.getElementById('p').style.width='100%';
 document.getElementById('sc').textContent='Score : '+ok+' / '+C.length;document.getElementById('end').style.display='flex'}else show()}
start();
</script></body></html>"""

    /** Ordre de révision : les cartes mal sues d'abord, mélangées à l'intérieur de chaque niveau. */
    fun session(set: FlashcardSet): List<Int> =
        set.cards.indices.sortedWith(compareBy<Int> { set.cards[it].box }.thenBy { (it * 7919) % 97 })

    /** Met à jour le niveau d'une carte après « Je savais » (monte) ou « À revoir » (retombe à zéro). */
    fun grade(set: FlashcardSet, index: Int, knewIt: Boolean): FlashcardSet {
        val cards = set.cards.toMutableList()
        val c = cards[index]
        cards[index] = c.copy(box = if (knewIt) minOf(c.box + 1, 4) else 0)
        return set.copy(cards = cards)
    }

    /** Compare une réponse tapée avec la réponse attendue, sans accents ni ponctuation. */
    fun matches(typed: String, expected: String): Boolean {
        val a = normalize(typed)
        val b = normalize(expected)
        if (a.isEmpty() || b.isEmpty()) return false
        return a == b || (a.length >= 4 && b.contains(a)) || (b.length >= 4 && a.contains(b))
    }

    private fun normalize(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
}

/** Decks sauvegardés sur le téléphone : un fichier JSON par deck. */
class DeckStore(context: Context) {

    private val dir = File(context.filesDir, "cards").apply { mkdirs() }

    fun list(): List<FlashcardSet> = (dir.listFiles { f -> f.name.endsWith(".json") } ?: emptyArray())
        .mapNotNull { f -> runCatching { decode(f.readText()) }.getOrNull() }
        .sortedByDescending { it.id }

    fun save(set: FlashcardSet) {
        val arr = JSONArray()
        set.cards.forEach { c ->
            arr.put(JSONObject().put("recto", c.front).put("verso", c.back).put("box", c.box))
        }
        val o = JSONObject().put("id", set.id).put("topic", set.topic).put("cards", arr)
        File(dir, "${set.id}.json").writeText(o.toString())
    }

    fun delete(id: String) {
        File(dir, "$id.json").delete()
    }

    private fun decode(text: String): FlashcardSet {
        val o = JSONObject(text)
        val arr = o.getJSONArray("cards")
        val cards = (0 until arr.length()).map {
            val c = arr.getJSONObject(it)
            Flashcard(c.getString("recto"), c.getString("verso"), c.optInt("box", 0))
        }
        return FlashcardSet(o.getString("id"), o.getString("topic"), cards)
    }
}
