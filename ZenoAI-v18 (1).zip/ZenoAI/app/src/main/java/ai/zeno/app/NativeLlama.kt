package ai.zeno.app

import android.content.ContentResolver
import android.net.Uri
import kotlinx.coroutines.runBlocking
import org.nehuatl.llamacpp.LlamaAndroid
import java.io.File

/** Choix du nombre de threads : uniquement les cœurs rapides (les petits cœurs ralentissent tout le monde). */
object CpuPlan {
    fun threads(): Int {
        val cores = Runtime.getRuntime().availableProcessors()
        val freqs = (0 until cores).mapNotNull { i ->
            runCatching { File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq").readText().trim().toLong() }.getOrNull()
        }
        if (freqs.size == cores && freqs.isNotEmpty()) {
            val max = freqs.max()
            return freqs.count { it >= max * 0.7 }.coerceIn(2, 6)
        }
        return (cores / 2).coerceIn(2, 6)
    }
}

/**
 * Accès direct au moteur llama.cpp (sans l'assistant LlamaHelper, qui impose ses réglages) :
 * nombre de threads et taille de lot choisis par ZenoAI. Le GPU n'est pas géré par cette version du moteur.
 */
class NativeLlama(private val resolver: ContentResolver) {
    private val llama = LlamaAndroid(resolver)
    private var id = -1
    @Volatile private var sink: ((String) -> Boolean)? = null
    @Volatile private var interrupted = false

    fun load(path: String, ctx: Int, threads: Int) {
        val uri = Uri.fromFile(File(path))
        val pfd = resolver.openFileDescriptor(uri, "r") ?: error("Impossible d'ouvrir le modèle")
        val fd = pfd.detachFd()
        val config = hashMapOf<String, Any>(
            "model" to uri.toString(),
            "model_fd" to fd,
            "use_mmap" to true,
            "use_mlock" to false,
            "n_ctx" to ctx,
            "embedding" to false,
            "n_batch" to 512,
            "n_threads" to threads,
            "n_gpu_layers" to 0,
            "vocab_only" to false,
            "lora" to "",
            "lora_scaled" to 1.0f,
            "rope_freq_base" to 0.0f,
            "rope_freq_scale" to 0.0f,
            "mmproj_fd" to -1
        )
        val res = llama.startEngine(config) { tokenMap ->
            val tok = (tokenMap as? Map<*, *>)?.get("token") as? String
            if (tok != null && sink?.invoke(tok) == false && !interrupted) {
                interrupted = true
                runCatching { runBlocking { llama.stopCompletion(id) } }
            }
        }
        id = ((res as? Map<*, *>)?.get("contextId") as? Number)?.toInt() ?: error("Contexte non créé")
    }

    /** Bloquant. `onToken` renvoie false pour arrêter la génération. */
    fun generate(prompt: String, threads: Int, onToken: (String) -> Boolean) {
        interrupted = false
        sink = onToken
        try {
            llama.launchCompletion(
                id,
                hashMapOf<String, Any>("prompt" to prompt, "emit_partial_completion" to true, "n_threads" to threads)
            )
        } finally {
            sink = null
        }
    }

    fun release() {
        if (id >= 0) runCatching { llama.releaseContext(id) }
        id = -1
    }
}
