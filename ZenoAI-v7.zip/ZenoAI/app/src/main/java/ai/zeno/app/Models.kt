package ai.zeno.app

enum class Role { USER, AI }

data class ChatMessage(
    val id: Long,
    val role: Role,
    val text: String,
    val streaming: Boolean = false,
    val status: String = "",
    val imagePath: String? = null,
    val imagePrompt: String = "",
    val sources: String = "",
    val gamePath: String? = null,
    val gameTitle: String = "",
    val videoPath: String? = null
)

data class ChatMeta(val id: String, val title: String, val updatedAt: Long)

sealed interface ModelState {
    data object None : ModelState
    data class Busy(val label: String, val progress: Float? = null) : ModelState
    data object Ready : ModelState
    data class Error(val message: String) : ModelState
}

/** Personnalisation de l'interface. Une couleur à 0 = couleur par défaut. */
data class Look(
    val wallpaper: String = "",
    val userName: String = "Toi",
    val aiName: String = "Zeno",
    val userAvatar: String = "",
    val aiAvatar: String = "",
    val textColor: Int = 0,
    val userBubble: Int = 0,
    val aiBubble: Int = 0,
    val bubbleAlpha: Float = 0.4f
)

/** Modèles proposés. « key » sert à reconnaître le fichier installé d'après son nom. */
data class ModelPreset(val label: String, val sub: String, val url: String, val key: String)

object ModelPresets {
    private const val HF = "https://huggingface.co/"

    val list = listOf(
        ModelPreset(
            "Qwen2.5-Coder · 7 Md",
            "Le meilleur pour le code · 4,7 Go · ≈ 6 Go de mémoire vive · lent sur téléphone (format GGUF, llama.cpp).",
            HF + "bartowski/Qwen2.5-Coder-7B-Instruct-GGUF/resolve/main/Qwen2.5-Coder-7B-Instruct-Q4_K_M.gguf",
            "qwen2.5-coder-7b"
        ),
        ModelPreset(
            "Llama 3.1 · 8 Md (Instruct)",
            "Le plus puissant en général · 4,9 Go · ≈ 7 Go de mémoire vive · lent sur téléphone (GGUF).",
            HF + "bartowski/Meta-Llama-3.1-8B-Instruct-GGUF/resolve/main/Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf",
            "llama-3.1-8b"
        ),
        ModelPreset(
            "Llama 3.2 · 3 Md",
            "Bon compromis vitesse / qualité · 2,0 Go · ≈ 3 Go de mémoire vive (GGUF).",
            HF + "bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf",
            "llama-3.2-3b"
        ),
        ModelPreset(
            "Gemma 2 · 2 Md",
            "Très à l'aise à l'écrit · 1,7 Go · ≈ 2,5 Go de mémoire vive (GGUF).",
            HF + "bartowski/gemma-2-2b-it-GGUF/resolve/main/gemma-2-2b-it-Q4_K_M.gguf",
            "gemma-2-2b"
        ),
        ModelPreset(
            "Qwen 2.5 · 1,5 Md (léger)",
            "Rapide, bon en code · 1,6 Go · le choix des vieux téléphones (format .task, MediaPipe).",
            Prefs.QWEN_URL, "qwen2.5-1.5b"
        )
    )

    fun presetFor(name: String): ModelPreset? = list.firstOrNull { name.lowercase().contains(it.key) }
}
