package ai.zeno.app

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** État du téléchargement en cours, partagé entre le service d'arrière-plan et l'écran. */
object DownloadState {
    data class Info(
        val name: String,
        val progress: Float?,
        val status: String,
        val error: String? = null,
        val done: Boolean = false
    )

    private val state = MutableStateFlow<Info?>(null)
    val flow: StateFlow<Info?> = state

    fun set(info: Info?) { state.value = info }
    fun clear() { state.value = null }
}
