package ai.zeno.app

data class Turn(val q: String, val a: String)

/**
 * Mémoire de la conversation. Le contexte du modèle est petit : on n'y met donc pas tout, mais
 * toujours (par priorité) le dernier échange, les 3 premières questions, les anciens échanges
 * qui ressemblent à la question posée, puis un résumé du reste.
 */
object Memory {

    private val recallRx = Regex(
        "premi[èe]re?s?|1[èe]re|au d[ée]but|tout [àa] l'heure|pr[ée]c[ée]dent|plus t[ôo]t|avant|rappelle|redis|first|earlier|previous|before|remind",
        RegexOption.IGNORE_CASE
    )
    private val stop = setOf(
        "avec", "dans", "pour", "vous", "nous", "cette", "comme", "mais", "plus", "tout", "tous", "être", "avoir",
        "fait", "faire", "quel", "quelle", "quand", "comment", "pourquoi", "that", "this", "with", "what", "from",
        "have", "your", "there", "about"
    )

    private fun words(s: String): Set<String> =
        Regex("[\\p{L}\\p{N}]{4,}").findAll(s.lowercase()).map { it.value }.filter { it !in stop }.toSet()

    private fun one(s: String, n: Int): String {
        val t = s.replace(Regex("\\s+"), " ").trim()
        return if (t.length > n) t.take(n - 1) + "…" else t
    }

    /** Découpe l'historique en échanges question / réponse. */
    fun turns(history: List<ChatMessage>): List<Turn> {
        val out = mutableListOf<Turn>()
        var i = 0
        while (i < history.size) {
            val m = history[i]
            if (m.role == Role.USER) {
                val a = history.getOrNull(i + 1)?.takeIf { it.role == Role.AI }
                if (m.text.isNotBlank()) out += Turn(m.text, a?.text.orEmpty())
                i += if (a != null) 2 else 1
            } else i++
        }
        return out
    }

    fun build(history: List<ChatMessage>, summary: String, question: String, budget: Int): String {
        val ts = turns(history)
        if (ts.isEmpty() && summary.isBlank()) return ""
        var left = budget
        val sb = StringBuilder()
        fun add(label: String, body: String) {
            if (body.isBlank() || left < 60) return
            val line = "$label : $body\n"
            val cut = if (line.length > left) line.take(left) else line
            sb.append(cut)
            left -= cut.length
        }

        val recall = recallRx.containsMatchIn(question)
        val last = ts.lastOrNull()
        val older = if (ts.size > 1) ts.dropLast(1) else emptyList()

        // 1) Le dernier échange
        if (last != null) add("Dernier échange", "Utilisateur : ${one(last.q, 150)} / Toi : ${one(last.a, 240)}")

        // 2) Les premières questions : on ne les oublie jamais
        val first = older.take(3)
        if (first.isNotEmpty()) {
            val n = if (recall) 200 else 110
            val body = first.mapIndexed { i, t ->
                "${i + 1}) ${one(t.q, n)}" + (if (recall && i == 0 && t.a.isNotBlank()) " → ${one(t.a, 160)}" else "")
            }.joinToString(" ")
            add("Premières questions de la discussion", body)
        }

        // 3) Anciens échanges qui ressemblent à la question
        val qw = words(question)
        if (qw.isNotEmpty()) {
            older.filter { it !in first }
                .map { it to words(it.q + " " + it.a).intersect(qw).size }
                .filter { it.second >= 2 || (it.second >= 1 && qw.size <= 3) }
                .sortedByDescending { it.second }
                .take(2)
                .forEach { add("Rappel", "${one(it.first.q, 100)} → ${one(it.first.a, 160)}") }
        }

        // 4) Résumé du reste
        add("Résumé", one(summary, left.coerceAtLeast(0)))
        return sb.toString().trim()
    }
}
