package ai.zeno.app

import java.time.LocalDate

object PromptBuilder {

    private const val SYS_EST = 880

    private val longRx = Regex(
        "(développ|developp|détaill|detaill|explique|expliqu|rédige|redige|dissertation|\\bplan\\b|argument|compar|tableau|étape|etape|tutoriel|résume|resume|analyse|\\bcode\\b|programme|fonction|script|\\bclass\\b|application|\\bappli\\b|écris|ecris|write|explain|essay|\\btable\\b|step)",
        RegexOption.IGNORE_CASE
    )

    /** Vrai si la demande appelle une réponse longue (développement, code, tableau...). */
    fun wantsLong(user: String) = user.length > 400 || longRx.containsMatchIn(user)

    /** level : 0 = bas (rapide), 1 = moyen, 2 = élevé (approfondi). */
    private fun system(ai: String, user: String, level: Int): String {
        val sb = StringBuilder()
        sb.append("Tu es ").append(ai.ifBlank { "Zeno" }).append(". ")
        if (user.isNotBlank()) sb.append("L'utilisateur s'appelle ").append(user).append(". ")
        sb.append("Par défaut : 1 à 4 phrases, un seul paragraphe, droit au but (pas d'intro, pas de bonjour, pas de question de relance). ")
        sb.append("Tu décides de la longueur : 1 phrase si ça suffit ; pour un développement construit, une explication détaillée ou du code, écris autant que nécessaire avec de courts titres. ")
        sb.append("Pour comparer des données, fais un tableau Markdown (| A | B | puis | --- | --- |). ")
        sb.append("Tutoie, réponds dans la langue de l'utilisateur. ")
        sb.append("L'appli te donne des outils : /image, /video et /jeu (jeux jouables, exportables en APK) : ne dis jamais que tu ne peux pas, indique la commande. ")
        sb.append("Les liens (https://… ou [texte](url)) sont cliquables. ")
        sb.append("La mémoire de la conversation t'est fournie : appuie-toi dessus. ")
        sb.append("Faits : appuie-toi sur les sources fournies, signale les contradictions, n'invente jamais. ")
        sb.append("Code : bloc complet ```langage prêt à lancer, puis 1 phrase d'explication.")
        when (level) {
            0 -> sb.append(" Réponds au plus court.")
            2 -> sb.append(" Analyse la question, compare les sources et vérifie ta réponse avant de conclure.")
        }
        return sb.toString()
    }

    private const val SKELETON =
        "<!DOCTYPE html><meta name='viewport' content='width=device-width,initial-scale=1'>" +
        "<body style='margin:0;background:#111;touch-action:none'><canvas id=c></canvas><script>" +
        "const c=document.getElementById('c'),x=c.getContext('2d');c.width=innerWidth;c.height=innerHeight;" +
        "function loop(){requestAnimationFrame(loop)}loop()</script>"

    private const val GAME_SYSTEM =
        "Tu es Zeno, expert en jeux web. Réponds avec UN seul bloc ```html : un jeu complet dans un seul fichier " +
        "(HTML, CSS et JavaScript, <canvas>), sans bibliothèque ni image externe. " +
        "Commandes tactiles ET clavier, score, game over et bouton Rejouer. Code court et simple, sans commentaires. " +
        "Ensuite une seule phrase : les commandes. Base de départ : " + SKELETON

    private const val SITE_SYSTEM =
        "Tu es Zeno, développeur web. Réponds avec UN seul bloc ```html : une page web complète en un seul fichier " +
        "(HTML, CSS et un peu de JavaScript), adaptée au mobile, design moderne, sans bibliothèque ni image externe " +
        "(emojis et dégradés CSS à la place). Ensuite une seule phrase."

    private const val SUMMARY_SYSTEM =
        "Tu résumes des conversations. Écris uniquement le résumé, sans introduction."

    private const val IMAGE_SYSTEM =
        "Tu écris des prompts pour un générateur d'images. Tu réponds uniquement avec le prompt."

    private const val AGENT_SYSTEM =
        "Tu es un agent. Pour répondre, tu utilises UN outil à la fois. Réponds uniquement avec un JSON : " +
        "{\"action\":\"...\",\"input\":\"...\"}. Outils : search (chercher sur le web), code (chercher sur GitHub et Reddit), " +
        "calc (calcul, ex. 12*(3+4)), game (créer un jeu), site (créer un site web), image (créer une image), video (créer une vidéo), " +
        "answer (tu as assez d'informations : tu peux répondre)."

    fun wrap(template: String, system: String, user: String): String = when (template) {
        "gemma" -> "<start_of_turn>user\n$system\n\n$user<end_of_turn>\n<start_of_turn>model\n"
        "llama" -> "<|start_header_id|>system<|end_header_id|>\n\n$system<|eot_id|>" +
            "<|start_header_id|>user<|end_header_id|>\n\n$user<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n"
        else -> "<|im_start|>system\n$system<|im_end|>\n<|im_start|>user\n$user<|im_end|>\n<|im_start|>assistant\n"
    }

    /** Budget en caractères pour tout le prompt ; une réponse longue garde plus de place pour écrire. */
    private fun promptChars(maxTokens: Int, long: Boolean) =
        (maxTokens * 3.0 * (if (long) 0.5 else 0.68)).toInt()

    private fun available(maxTokens: Int, sysLen: Int, long: Boolean) =
        (promptChars(maxTokens, long) - sysLen - 140).coerceAtLeast(500)

    /** Place disponible pour la mémoire de la conversation. */
    fun memoryBudget(maxTokens: Int, userLen: Int, long: Boolean): Int {
        val avail = available(maxTokens, SYS_EST, long)
        val rem = avail - minOf(userLen, avail / 2)
        return (rem * 0.5).toInt().coerceAtLeast(200)
    }

    /** Place disponible pour les sources web, une fois le message et la mémoire comptés. */
    fun webBudget(maxTokens: Int, memoryLen: Int, userLen: Int, long: Boolean): Int {
        val avail = available(maxTokens, SYS_EST, long)
        val rem = avail - minOf(userLen, avail / 2)
        val m = minOf(memoryLen, (rem * 0.5).toInt())
        return (rem - m).coerceAtLeast(250)
    }

    /** Taille maximale (en caractères) d'une demande de jeu, code à corriger compris. */
    fun gameRequestCapacity(maxTokens: Int): Int =
        ((maxTokens * 3.0 * 0.45).toInt() - GAME_SYSTEM.length - 100).coerceAtLeast(300)

    fun chat(
        template: String, memory: String, web: String, user: String, maxTokens: Int,
        aiName: String, userName: String, level: Int
    ): String {
        val long = wantsLong(user)
        val sys = system(aiName, userName, level)
        val avail = available(maxTokens, sys.length, long)
        val u = user.take(avail / 2)
        val rem = avail - u.length
        val m = memory.take((rem * 0.5).toInt())
        val w = web.take((rem - m.length).coerceAtLeast(0))

        val sb = StringBuilder()
        sb.append("Date du jour : ").append(LocalDate.now()).append("\n\n")
        if (m.isNotBlank()) sb.append("[Mémoire de la conversation]\n").append(m).append("\n\n")
        if (w.isNotBlank()) sb.append("[Sources]\n").append(w).append("\n\n")
        sb.append("[Message de l'utilisateur]\n").append(u)
        if (w.isNotBlank() && !long && level != 0) sb.append("\n\n[Réponds en 1 à 4 phrases maximum.]")
        return wrap(template, sys, sb.toString())
    }

    fun game(template: String, request: String, maxTokens: Int): String {
        val cap = gameRequestCapacity(maxTokens)
        val r = request.ifBlank { "un petit jeu simple et amusant" }.take(cap)
        return wrap(template, GAME_SYSTEM, "Jeu demandé : $r")
    }

    fun site(template: String, request: String, maxTokens: Int): String {
        val cap = gameRequestCapacity(maxTokens)
        return wrap(template, SITE_SYSTEM, "Site demandé : " + request.ifBlank { "une page de présentation simple et jolie" }.take(cap))
    }

    /** L'IA personnalise un jeu prêt à l'emploi : un petit JSON suffit. */
    fun gameSpec(template: String, label: String, request: String): String {
        val user = "Jeu : $label. Demande : ${request.take(200)}\n" +
            "Réponds uniquement avec ce JSON : {\"titre\":\"nom court et fun\",\"couleur\":\"#rrggbb\"," +
            "\"emoji\":\"un seul emoji adapté\",\"vitesse\":5} (vitesse de 1 lent à 10 rapide)."
        return wrap(template, "Tu personnalises des mini-jeux. Tu réponds uniquement avec un JSON valide.", user)
    }

    fun agentStep(template: String, question: String, notes: String, step: Int, max: Int): String {
        val user = "Question : ${question.take(300)}\n" +
            "Observations déjà obtenues : ${if (notes.isBlank()) "(aucune)" else notes.takeLast(600)}\n" +
            "Étape $step/$max. Quelle est la prochaine action ?"
        return wrap(template, AGENT_SYSTEM, user)
    }

    fun summary(template: String, previous: String, turn: Turn): String {
        val sb = StringBuilder()
        sb.append("Mets à jour le résumé de cette conversation en 100 mots maximum, dans la langue de la conversation. ")
        sb.append("Garde : le sujet, les faits, les décisions, les préférences de l'utilisateur et les points clés du code.\n\n")
        sb.append("[Résumé précédent]\n").append(if (previous.isBlank()) "(aucun)" else previous).append("\n\n")
        sb.append("[Échange à ajouter]\nUtilisateur : ").append(turn.q.take(600)).append("\n")
        sb.append("Assistant : ").append(turn.a.take(1100))
        return wrap(template, SUMMARY_SYSTEM, sb.toString())
    }

    fun imagePrompt(template: String, request: String): String {
        val user = "Demande de l'utilisateur : ${request.take(400)}\n\n" +
            "Écris UN seul prompt en anglais, précis et visuel (sujet, style, lumière, ambiance), 40 mots maximum. " +
            "Réponds uniquement avec le prompt."
        return wrap(template, IMAGE_SYSTEM, user)
    }

    fun videoPrompt(template: String, request: String): String {
        val user = "Demande de l'utilisateur : ${request.take(400)}\n\n" +
            "Écris UN seul prompt en anglais pour un générateur de vidéo réaliste : sujet, action, décor, caméra, lumière. " +
            "50 mots maximum. Réponds uniquement avec le prompt."
        return wrap(template, IMAGE_SYSTEM, user)
    }

    fun cleanImagePrompt(s: String): String = clean(s)
        .lineSequence().firstOrNull { it.isNotBlank() }.orEmpty()
        .replace(Regex("^(prompt|image prompt)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
        .trim().trim('"', '«', '»', '“', '”')
        .take(400)

    private val partialToken = Regex("(<\\|[a-z_]*\\|?>?|<end_of[a-z_]*>?|<start_of[a-z_]*>?)$")

    fun clean(s: String): String = s
        .replace("<|im_end|>", "")
        .replace("<|endoftext|>", "")
        .replace("<end_of_turn>", "")
        .replace("<|eot_id|>", "")
        .replace("<|end_of_text|>", "")
        .replace(partialToken, "")
        .trim()
}
