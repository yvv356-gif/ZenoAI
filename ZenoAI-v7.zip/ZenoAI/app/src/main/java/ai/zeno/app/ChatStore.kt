package ai.zeno.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class LoadedChat(val summary: String, val messages: List<ChatMessage>)

/**
 * Historique des discussions : un fichier JSON par discussion, jamais supprimé.
 * En mémoire il n'y a que la discussion ouverte ; les autres restent sur le disque
 * et sont chargées quand on clique dessus.
 */
class ChatStore(context: Context) {

    private val dir = File(context.filesDir, "chats").apply { mkdirs() }
    private val index = File(dir, "index.json")

    fun list(): List<ChatMeta> {
        val fromIndex = runCatching {
            val arr = JSONArray(index.readText())
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                ChatMeta(o.getString("id"), o.getString("title"), o.getLong("updatedAt"))
            }
        }.getOrNull()
        val metas = fromIndex ?: rebuild()
        return metas.sortedByDescending { it.updatedAt }
    }

    private fun rebuild(): List<ChatMeta> {
        val metas = (dir.listFiles { f -> f.name.endsWith(".json") && f.name != "index.json" } ?: emptyArray())
            .mapNotNull { f ->
                runCatching {
                    val o = JSONObject(f.readText())
                    ChatMeta(o.getString("id"), o.getString("title"), o.getLong("updatedAt"))
                }.getOrNull()
            }
        writeIndex(metas)
        return metas
    }

    private fun writeIndex(metas: List<ChatMeta>) {
        val arr = JSONArray()
        metas.forEach {
            arr.put(JSONObject().put("id", it.id).put("title", it.title).put("updatedAt", it.updatedAt))
        }
        val tmp = File(dir, "index.tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(index)
    }

    fun save(id: String, title: String, summary: String, messages: List<ChatMessage>) {
        val now = System.currentTimeMillis()
        val msgs = JSONArray()
        messages.forEach { m ->
            msgs.put(
                JSONObject()
                    .put("id", m.id)
                    .put("role", m.role.name)
                    .put("text", m.text)
                    .put("imagePath", m.imagePath ?: JSONObject.NULL)
                    .put("imagePrompt", m.imagePrompt)
                    .put("sources", m.sources)
                    .put("gamePath", m.gamePath ?: JSONObject.NULL)
                    .put("gameTitle", m.gameTitle)
                    .put("videoPath", m.videoPath ?: JSONObject.NULL)
            )
        }
        val o = JSONObject()
            .put("id", id).put("title", title).put("updatedAt", now)
            .put("summary", summary).put("messages", msgs)
        val tmp = File(dir, "$id.tmp")
        tmp.writeText(o.toString())
        tmp.renameTo(File(dir, "$id.json"))

        val metas = list().filter { it.id != id } + ChatMeta(id, title, now)
        writeIndex(metas)
    }

    fun load(id: String): LoadedChat? = runCatching {
        val o = JSONObject(File(dir, "$id.json").readText())
        val arr = o.getJSONArray("messages")
        val msgs = (0 until arr.length()).map {
            val m = arr.getJSONObject(it)
            ChatMessage(
                id = m.getLong("id"),
                role = Role.valueOf(m.getString("role")),
                text = m.getString("text"),
                imagePath = if (m.isNull("imagePath")) null else m.getString("imagePath"),
                imagePrompt = m.optString("imagePrompt"),
                sources = m.optString("sources"),
                gamePath = if (m.isNull("gamePath")) null else m.optString("gamePath").ifBlank { null },
                gameTitle = m.optString("gameTitle"),
                videoPath = if (m.isNull("videoPath")) null else m.optString("videoPath").ifBlank { null }
            )
        }
        LoadedChat(o.optString("summary"), msgs)
    }.getOrNull()
}
