package ai.zeno.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Télécharge un modèle en arrière-plan : service de premier plan (notification avec progression
 * et bouton Annuler), reprise automatique après une coupure réseau, écran éteint ou appli fermée.
 */
class DownloadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            val j = job
            if (j != null && j.isActive) j.cancel() else stopSelf()
            return START_NOT_STICKY
        }
        val url = intent?.getStringExtra(EXTRA_URL)
        if (url.isNullOrBlank()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (job?.isActive == true) return START_NOT_STICKY
        val name = intent?.getStringExtra(EXTRA_NAME) ?: ModelManager.safeName(url)
        val token = intent?.getStringExtra(EXTRA_TOKEN).orEmpty()

        ensureChannel()
        val first = notification(name, "Préparation…", null)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, first, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIF_ID, first)
        }
        acquireWake()
        DownloadState.set(DownloadState.Info(name, 0f, "Préparation…"))
        job = scope.launch { download(url, token, name) }
        return START_NOT_STICKY
    }

    private suspend fun download(url: String, token: String, name: String) {
        val files = ModelManager(applicationContext)
        var failure: String? = null
        var ok = false
        try {
            files.downloadResumable(url, token, name) { done, total, speed, status ->
                val progress = if (total > 0) done.toFloat() / total else null
                val text = status.ifBlank { describe(done, total, speed) }
                DownloadState.set(DownloadState.Info(name, progress, text))
                notify(notification(name, text, progress))
            }
            ok = true
        } catch (e: CancellationException) {
            files.deletePart(name)
            DownloadState.clear()
        } catch (e: Exception) {
            failure = e.message ?: e.javaClass.simpleName
        } finally {
            releaseWake()
            stopForeground(STOP_FOREGROUND_REMOVE)
            when {
                ok -> {
                    notify(finalNotification(name, "Modèle installé : ${ModelManager.label(name)}"))
                    DownloadState.set(DownloadState.Info(name, 1f, "Terminé", done = true))
                }
                failure != null -> {
                    notify(finalNotification(name, "Échec : $failure"))
                    DownloadState.set(DownloadState.Info(name, null, "", error = failure))
                }
            }
            stopSelf()
        }
    }

    private fun describe(done: Long, total: Long, speed: Long): String {
        fun go(b: Long) = "%.2f".format(java.util.Locale.US, b / 1e9)
        val sp = if (speed > 0) " · ${"%.1f".format(java.util.Locale.US, speed / 1e6)} Mo/s" else ""
        return if (total > 0) "${done * 100 / total} % · ${go(done)} / ${go(total)} Go$sp" else "${go(done)} Go$sp"
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Téléchargement des modèles", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun openApp(): PendingIntent? {
        val launch = packageManager.getLaunchIntentForPackage(packageName) ?: return null
        return PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_IMMUTABLE)
    }

    private fun notification(name: String, text: String, progress: Float?): Notification {
        val cancel = PendingIntent.getService(
            this, 1, Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL), PendingIntent.FLAG_IMMUTABLE
        )
        val b = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Téléchargement : ${ModelManager.label(name)}")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp())
            .addAction(0, "Annuler", cancel)
        if (progress != null) b.setProgress(100, (progress * 100).toInt(), false) else b.setProgress(0, 0, true)
        return b.build()
    }

    private fun finalNotification(name: String, text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(ModelManager.label(name))
            .setContentText(text)
            .setAutoCancel(true)
            .setContentIntent(openApp())
            .build()

    private fun notify(n: Notification) {
        runCatching {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIF_ID, n)
        }
    }

    private fun acquireWake() {
        runCatching {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ZenoAI:download").apply { acquire(6 * 60 * 60 * 1000L) }
        }
    }

    private fun releaseWake() {
        runCatching { wake?.takeIf { it.isHeld }?.release() }
        wake = null
    }

    override fun onDestroy() {
        releaseWake()
        super.onDestroy()
    }

    companion object {
        const val EXTRA_URL = "url"
        const val EXTRA_NAME = "name"
        const val EXTRA_TOKEN = "token"
        const val ACTION_CANCEL = "ai.zeno.app.CANCEL_DOWNLOAD"
        private const val CHANNEL = "model_download"
        private const val NOTIF_ID = 4711
    }
}
