package ai.zeno.app

import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Génération de vidéos via un service en ligne (Pollinations, API unifiée gen.pollinations.ai).
 * Aucun téléphone ne peut produire de vidéo réaliste seul : le calcul se fait sur leurs serveurs,
 * avec ta clé API (crédits « Pollen »). La qualité dépend du modèle vidéo choisi côté service.
 */
object VideoGen {

    private val verbRx = Regex(
        "\\b(génère|génere|générer|generer|genere|crée|cree|créer|creer|fais|fais-moi|faire|produis|anime|make|generate|create)\\b",
        RegexOption.IGNORE_CASE
    )
    private val nounRx = Regex("\\b(vidéo|video|vidéos|videos|clip|court-métrage|film d'animation)\\b", RegexOption.IGNORE_CASE)
    private val gameVideoRx = Regex("jeux?\\s+vid[ée]o", RegexOption.IGNORE_CASE)

    fun isRequest(text: String): Boolean {
        val t = text.trim()
        if (t.startsWith("/video", ignoreCase = true) || t.startsWith("/vidéo", ignoreCase = true)) return true
        if (t.length > 300 || t.contains("```") || gameVideoRx.containsMatchIn(t)) return false
        return verbRx.containsMatchIn(t) && nounRx.containsMatchIn(t)
    }

    fun request(text: String): String =
        text.trim().replace(Regex("^/vid[ée]o\\s*", RegexOption.IGNORE_CASE), "").trim()

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    fun fetch(key: String, model: String, prompt: String, target: File) {
        val base = "https://gen.pollinations.ai/video/${enc(prompt)}?key=${enc(key.trim())}"
        val modelPart = if (model.isNotBlank()) "&model=${enc(model.trim())}" else ""
        val variants = listOf(
            "$base$modelPart&duration=5&aspectRatio=16:9",
            "$base$modelPart"
        )
        var last: Exception = IllegalStateException("Service vidéo indisponible")
        for (u in variants) {
            try {
                download(u, target)
                return
            } catch (e: IllegalArgumentException) {
                last = e   // paramètres refusés : on retente sans
            }
        }
        throw last
    }

    private fun download(url: String, target: File) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 300_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "ZenoAI/1.0")
        try {
            c.connect()
            val code = c.responseCode
            when {
                code == 401 || code == 403 -> error("clé API refusée (HTTP $code). Vérifie-la dans les réglages.")
                code == 402 -> error("crédits insuffisants sur ton compte Pollinations (HTTP 402).")
                code == 400 -> throw IllegalArgumentException("requête refusée (HTTP 400)")
                code !in 200..299 -> error("le service vidéo a répondu HTTP $code")
            }
            val type = c.contentType.orEmpty()
            if (!type.startsWith("video") && !type.contains("octet-stream")) {
                val msg = runCatching { c.inputStream.bufferedReader().readText().take(200) }.getOrDefault("")
                error("réponse inattendue du service vidéo ($type) $msg")
            }
            var total = 0L
            c.inputStream.use { input ->
                target.outputStream().use { out ->
                    val buf = ByteArray(128 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        total += n
                        if (total > 80_000_000) error("vidéo trop lourde")
                    }
                }
            }
            if (total < 10_000) {
                target.delete()
                error("vidéo vide reçue")
            }
        } catch (e: Exception) {
            target.delete()
            throw e
        } finally {
            c.disconnect()
        }
    }
}
