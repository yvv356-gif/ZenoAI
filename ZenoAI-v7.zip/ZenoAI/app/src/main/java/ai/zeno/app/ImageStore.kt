package ai.zeno.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File

/** Copie une image choisie par l'utilisateur en la réduisant (léger pour les vieux téléphones). */
object ImageStore {

    private fun dir(context: Context) = File(context.filesDir, "look").apply { mkdirs() }

    /** Enregistre l'image sous "<name>_<horodatage>.jpg" et supprime les anciennes versions. Renvoie le chemin. */
    fun save(context: Context, uri: Uri, name: String, maxSide: Int): String? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxSide || bounds.outHeight / (sample * 2) >= maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: return null

        val scale = maxSide.toFloat() / maxOf(bmp.width, bmp.height)
        val out = if (scale < 1f) {
            Bitmap.createScaledBitmap(
                bmp,
                (bmp.width * scale).toInt().coerceAtLeast(1),
                (bmp.height * scale).toInt().coerceAtLeast(1),
                true
            )
        } else bmp

        val d = dir(context)
        val f = File(d, "${name}_${System.currentTimeMillis()}.jpg")
        f.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        if (out !== bmp) bmp.recycle()
        out.recycle()

        d.listFiles()?.filter { it.name.startsWith("${name}_") && it != f }?.forEach { it.delete() }
        return f.absolutePath
    }

    fun delete(path: String) {
        if (path.isNotBlank()) runCatching { File(path).delete() }
    }
}
