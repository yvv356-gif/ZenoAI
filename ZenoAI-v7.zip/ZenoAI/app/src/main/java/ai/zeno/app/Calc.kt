package ai.zeno.app

/** Petite calculatrice (outil de l'agent) : + - * / % ^ et parenthèses. */
object Calc {

    fun eval(expr: String): String? = runCatching {
        val s = expr.replace(',', '.').replace('×', '*').replace('÷', '/')
            .replace(Regex("(?<=[\\d)])\\s*[xX]\\s*(?=[\\d(])"), "*")
            .replace(Regex("\\s+"), "")
        if (s.isEmpty() || !s.all { it.isDigit() || it in "+-*/%^()." }) return null
        val v = Parser(s).parse()
        if (v.isNaN() || v.isInfinite()) return null
        if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString()
        else "%.6f".format(java.util.Locale.US, v).trimEnd('0').trimEnd('.')
    }.getOrNull()

    private class Parser(val s: String) {
        var i = 0
        fun parse(): Double {
            val v = expr()
            if (i != s.length) error("syntaxe")
            return v
        }
        fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }
        fun term(): Double {
            var v = pow()
            while (i < s.length && (s[i] == '*' || s[i] == '/' || s[i] == '%')) {
                val op = s[i++]
                val r = pow()
                v = when (op) { '*' -> v * r; '/' -> v / r; else -> v % r }
            }
            return v
        }
        fun pow(): Double {
            val b = unary()
            if (i < s.length && s[i] == '^') { i++; return Math.pow(b, pow()) }
            return b
        }
        fun unary(): Double {
            if (i < s.length && s[i] == '-') { i++; return -unary() }
            if (i < s.length && s[i] == '+') { i++; return unary() }
            return atom()
        }
        fun atom(): Double {
            if (i >= s.length) error("syntaxe")
            if (s[i] == '(') {
                i++
                val v = expr()
                if (i >= s.length || s[i] != ')') error("syntaxe")
                i++
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) error("syntaxe")
            return s.substring(st, i).toDouble()
        }
    }
}
