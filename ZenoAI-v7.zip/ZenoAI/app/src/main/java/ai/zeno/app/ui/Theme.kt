package ai.zeno.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF1B1B2F)
val Teal = Color(0xFF3FA7B8)
val Violet = Color(0xFF7C6CF0)
val GlassAi = Color(0x66B7DEFF)
val GlassUser = Color(0x66CDB8F5)
val GlassWhite = Color(0x80FFFFFF)

@Composable
fun ZenoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Violet,
            onPrimary = Color.White,
            surface = Color.White,
            onSurface = Ink,
            background = Color.White
        ),
        content = content
    )
}
