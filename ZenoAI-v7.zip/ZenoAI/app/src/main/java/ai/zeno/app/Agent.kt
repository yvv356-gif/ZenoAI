package ai.zeno.app

import org.json.JSONObject

data class AgentAction(val name: String, val input: String)

/** Mode agent : l'IA choisit un outil à chaque étape (recherche, code, calcul, jeu, image, vidéo) puis répond. */
object Agent {

    private fun norm(a: String): String = when (a.trim().lowercase()) {
        "search", "recherche", "web", "chercher", "rechercher" -> "search"
        "code", "github", "reddit" -> "code"
        "calc", "calcul", "calculer", "calculatrice" -> "calc"
        "game", "jeu" -> "game"
        "site", "siteweb", "page" -> "site"
        "image", "dessin" -> "image"
        "video", "vidéo" -> "video"
        else -> "answer"
    }

    fun parse(raw: String, question: String, firstStep: Boolean): AgentAction {
        val parsed = runCatching {
            val m = Regex("\\{[\\s\\S]*?\\}").find(raw)?.value ?: error("pas de JSON")
            val o = JSONObject(m)
            val a = norm(o.optString("action", o.optString("outil", "answer")))
            val inp = o.optString("input", o.optString("entrée", o.optString("entree", ""))).trim()
            AgentAction(a, inp.ifBlank { if (a == "answer") "" else question }.take(160))
        }.getOrNull()
        if (parsed != null) return parsed
        if (firstStep) {
            when (WebSearch.modeFor(question, 2)) {
                WebSearch.Mode.CODE -> return AgentAction("code", question.take(160))
                WebSearch.Mode.FACTS -> return AgentAction("search", question.take(160))
                else -> {}
            }
        }
        return AgentAction("answer", "")
    }
}
