plugins {
    id("com.android.application")
}

// Mini-appli « coquille » : une WebView plein écran qui lance assets/game.html.
// Zeno y glisse le jeu, change le nom du package (n0000) et signe l'APK sur le téléphone.
android {
    namespace = "ai.zeno.gameshell"
    compileSdk = 35

    defaultConfig {
        applicationId = "ai.zeno.game.n0000"
        minSdk = 26
        targetSdk = 29
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}
