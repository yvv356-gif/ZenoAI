# ZenoAI

Assistant IA mobile (Android) : texte généré **sur le téléphone**, avec accès internet pour la recherche web et les images.

- Moteur : MediaPipe LLM Inference (modèles `.task` : Qwen2.5-1.5B par défaut, ou Gemma 3 1B)
- Réponses directes : 1 à 4 phrases par défaut ; plus long seulement pour un développement, du code ou un tableau (Zeno décide)
- Niveau de réflexion **bas / moyen / élevé** (cerveau en haut de l'écran) : vitesse contre profondeur
- À chaque message, l'IA relit un **résumé** de la conversation
- Recherche web **multi-sources** : Wikipédia (langue + EN) et DuckDuckGo pour les faits ; GitHub, Reddit et DuckDuckGo pour le code ; `/web` pour forcer
- Tableaux Markdown affichés dans les bulles
- Jeux : `/jeu snake` → jeu HTML/JS écrit par Zeno, bouton **Jouer** pour le tester dans l'app (WebView sans réseau), erreurs captées et bouton **Corriger**
- Menu ☰ → **Personnalisation** : fond d'écran, profil (nom + photo) de toi et de l'IA, couleur du texte et des encadrés, opacité
- Images : « dessine… », « génère une image de… » ou `/image …` (service en ligne Pollinations)
- Historique : chaque discussion est gardée sur le téléphone ; un clic la recharge, la précédente est déchargée de la mémoire

## Compiler
Pousse le zip (ou le dossier) sur GitHub avec `.github/workflows/build.yml` :
**Actions → Build ZenoAI APK → Artifacts**.

## Premier lancement
Menu ☰ → *Modèle et réglages* → **Télécharger** (≈ 1,6 Go) ou **Importer** un `.task`.

## Nouveautés
- Bouton du modèle sur l'écran d'accueil : Auto, Qwen, Gemma… (la discussion est conservée), mode agent, niveau de réflexion
- Mémoire : les 3 premières questions, le dernier échange et les échanges pertinents restent dans le prompt
- Jeux prêts à l'emploi (assets/games) personnalisés par l'IA, aperçu jouable, export APK (module `gameshell`, signé sur le téléphone avec apksig)
- Sites web : `/site …` (aperçu + APK) ; vidéos : `/video …` (Pollinations, clé requise) ; images : même clé
- Liens cliquables dans les réponses et les sources
- Le workflow compile d'abord `:gameshell:assembleRelease` et copie l'APK dans `app/src/main/assets/game-shell.apk`

## Moteurs IA
- `.task` : MediaPipe (Gemma, Qwen 1,5B…)
- `.gguf` : llama.cpp via `io.github.ljcamargo:llamacpp-kotlin` (Qwen2.5-Coder 7B, Llama 3.1 8B, Llama 3.2 3B, Gemma 2 2B — fichiers bartowski, quantification Q4_K_M)
- Le mode Auto choisit parmi les modèles installés : code → Coder/Qwen, écriture → Gemma, tâche complexe → le plus gros, sinon le modèle déjà chargé

## Téléchargement en arrière-plan
`DownloadService` (service de premier plan, type dataSync) : notification avec progression et bouton Annuler, reprise automatique (en-tête Range) après une coupure réseau, wake lock. L'état passe par `DownloadState` ; `ChatViewModel` l'observe et active le modèle à la fin.
