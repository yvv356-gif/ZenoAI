package ai.zeno.app

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Un bloc de code trouvé dans une réponse de l'IA. */
data class CodeSnippet(val lang: String, val ext: String, val code: String, val nameHint: String?)

enum class SaveKind { CREATED, MODIFIED, UNCHANGED }

data class SavedFile(val path: String, val kind: SaveKind)

/**
 * Lecture des blocs de code d'une réponse, et assemblage d'une page web quand le HTML, le CSS
 * et le JavaScript sont écrits dans des blocs séparés. Pas de dépendance Android : testable seul.
 */
object CodeBlocks {

    private val fence = Regex("(?s)```([A-Za-z0-9_+#.\\-]*)[ \\t]*\\r?\\n(.*?)\\r?\\n?```")

    private val extByLang = mapOf(
        "python" to "py", "py" to "py", "python3" to "py",
        "javascript" to "js", "js" to "js", "node" to "js", "mjs" to "js",
        "typescript" to "ts", "ts" to "ts",
        "html" to "html", "htm" to "html",
        "css" to "css",
        "json" to "json",
        "kotlin" to "kt", "kt" to "kt",
        "java" to "java",
        "bash" to "sh", "sh" to "sh", "shell" to "sh", "zsh" to "sh",
        "c" to "c", "cpp" to "cpp", "c++" to "cpp", "csharp" to "cs", "c#" to "cs",
        "go" to "go", "rust" to "rs", "rs" to "rs", "php" to "php", "ruby" to "rb", "rb" to "rb",
        "swift" to "swift", "lua" to "lua", "sql" to "sql",
        "yaml" to "yml", "yml" to "yml", "xml" to "xml", "svg" to "svg",
        "markdown" to "md", "md" to "md"
    )

    fun extFor(lang: String): String? = extByLang[lang.trim().lowercase()]

    private val commentHint = Regex(
        "^\\s*(?:#|//|--|/\\*|<!--)\\s*(?:file(?:name)?|fichier|nom)\\s*[:=]\\s*([\\w][\\w./\\-]{0,60}\\.[A-Za-z0-9]{1,5})",
        RegexOption.IGNORE_CASE
    )
    private val alone = Regex(
        "^[#>*\\-\\s]*(?:fichier|file|nom)?\\s*:?\\s*[`*_\"']*([\\w][\\w./\\-]{0,60}\\.[A-Za-z0-9]{1,5})[`*_\"']*\\s*:?\\s*$",
        RegexOption.IGNORE_CASE
    )
    private val inSentence = Regex(
        "(?:fichier|file|dans|in|nommé|named|called)\\s+[`*\"']([\\w][\\w./\\-]{0,60}\\.[A-Za-z0-9]{1,5})[`*\"']",
        RegexOption.IGNORE_CASE
    )

    /** Blocs terminés (un bloc coupé par la limite de mémoire du modèle est ignoré). */
    fun extract(text: String): List<CodeSnippet> {
        val out = mutableListOf<CodeSnippet>()
        for (m in fence.findAll(text)) {
            val lang = m.groupValues[1]
            val ext = extFor(lang) ?: continue
            val code = m.groupValues[2].trimEnd()
            if (code.isBlank()) continue
            val before = text.substring(0, m.range.first).trimEnd().lines().lastOrNull().orEmpty()
            var hint = commentHint.find(code.lineSequence().firstOrNull().orEmpty())?.groupValues?.get(1)
                ?: alone.find(before)?.groupValues?.get(1)
                ?: inSentence.find(before)?.groupValues?.get(1)
            if (hint != null && hint.substringAfterLast('.').lowercase() != ext) hint = null
            out += CodeSnippet(lang, ext, code, hint)
        }
        return out
    }

    fun worthSaving(b: CodeSnippet): Boolean =
        b.nameHint != null || b.code.lines().count { it.isNotBlank() } >= 4

    /** Page autonome : css et js nommés intégrés ; css/js « orphelins » ajoutés s'ils ne sont pas référencés. */
    fun page(html: String, byName: Map<String, String>, orphanCss: List<String>, orphanJs: List<String>): String {
        fun find(ref: String): String? {
            val base = ref.substringAfterLast('/').lowercase()
            return byName.entries.firstOrNull { it.key.substringAfterLast('/').lowercase() == base }?.value
        }
        var h = html
        var hasStyle = Regex("<style", RegexOption.IGNORE_CASE).containsMatchIn(h)
        var hasScript = Regex("<script[^>]*>[\\s\\S]*?\\S[\\s\\S]*?</script>", RegexOption.IGNORE_CASE).containsMatchIn(h)
        h = Regex("<link[^>]+href=[\"']([^\"']+\\.css)[\"'][^>]*>", RegexOption.IGNORE_CASE).replace(h) { m ->
            find(m.groupValues[1])?.also { hasStyle = true }?.let { "<style>$it</style>" } ?: m.value
        }
        h = Regex("<script[^>]+src=[\"']([^\"']+\\.js)[\"'][^>]*>\\s*</script>", RegexOption.IGNORE_CASE).replace(h) { m ->
            find(m.groupValues[1])?.also { hasScript = true }?.let { "<script>${it.replace("</", "<\\/")}</script>" } ?: m.value
        }
        if (!hasStyle && orphanCss.isNotEmpty()) {
            val style = "<style>\n${orphanCss.joinToString("\n")}\n</style>"
            h = if (Regex("</head>", RegexOption.IGNORE_CASE).containsMatchIn(h))
                h.replaceFirst(Regex("</head>", RegexOption.IGNORE_CASE), Regex.escapeReplacement(style) + "</head>")
            else style + "\n" + h
        }
        if (!hasScript && orphanJs.isNotEmpty()) {
            val script = "<script>\n${orphanJs.joinToString("\n").replace("</", "<\\/")}\n</script>"
            h = if (Regex("</body>", RegexOption.IGNORE_CASE).containsMatchIn(h))
                h.replaceFirst(Regex("</body>", RegexOption.IGNORE_CASE), Regex.escapeReplacement(script) + "</body>")
            else h + "\n" + script
        }
        return h
    }

    /** Page à afficher pour le bloc HTML touché : on y joint les blocs css/js de la même réponse. */
    fun pageFromMessage(htmlCode: String, messageText: String): String {
        val blocks = extract(messageText)
        val css = blocks.filter { it.ext == "css" }
        val js = blocks.filter { it.ext == "js" }
        val named = (css + js).filter { it.nameHint != null }.associate { it.nameHint!! to it.code }
        return page(htmlCode, named, css.filter { it.nameHint == null }.map { it.code }, js.filter { it.nameHint == null }.map { it.code })
    }
}

/**
 * Dossier de travail : un dossier par projet (un projet par discussion par défaut).
 * Les fichiers générés y sont créés ou mis à jour ; l'ancienne version est gardée dans .history.
 * Emplacement : dossier de l'appli sur la mémoire du téléphone (visible en branchant le téléphone
 * à un ordinateur : Android/data/ai.zeno.app/files/workspace). Il disparaît si l'appli est désinstallée :
 * « Exporter en ZIP » le copie dans Téléchargements.
 */
class Workspace(context: Context) {

    val root: File = (context.getExternalFilesDir("workspace") ?: File(context.filesDir, "workspace")).apply { mkdirs() }
    private val cache = context.cacheDir

    fun dir(project: String): File = File(root, FileTool.projectName(project))

    fun projects(): List<String> =
        (root.listFiles { f -> f.isDirectory } ?: emptyArray()).sortedByDescending { it.lastModified() }.map { it.name }

    fun files(project: String): List<String> {
        val base = dir(project)
        if (!base.isDirectory) return emptyList()
        return base.walkTopDown()
            .onEnter { it.name != HISTORY }
            .filter { it.isFile && !it.name.endsWith(".tmp") }
            .map { it.relativeTo(base).path.replace('\\', '/') }
            .sorted().take(500).toList()
    }

    fun read(project: String, rel: String): String? {
        val f = resolve(project, rel) ?: return null
        if (!f.isFile || f.length() > 400_000) return null
        return runCatching { f.readText() }.getOrNull()
    }

    fun write(project: String, rel: String, content: String): SavedFile? {
        val path = cleanRel(rel) ?: return null
        val base = dir(project).apply { mkdirs() }
        val dest = File(base, path)
        if (!dest.canonicalPath.startsWith(base.canonicalPath + File.separator)) return null
        val existed = dest.isFile
        if (existed) {
            if (runCatching { dest.readText() }.getOrNull() == content) return SavedFile(path, SaveKind.UNCHANGED)
            backup(base, path, dest)
        }
        dest.parentFile?.mkdirs()
        val tmp = File(dest.parentFile, dest.name + ".tmp")
        tmp.writeText(content)
        if (!tmp.renameTo(dest)) { dest.writeText(content); tmp.delete() }
        base.setLastModified(System.currentTimeMillis())
        return SavedFile(path, if (existed) SaveKind.MODIFIED else SaveKind.CREATED)
    }

    fun delete(project: String, rel: String): Boolean = resolve(project, rel)?.takeIf { it.isFile }?.delete() ?: false

    fun deleteProject(project: String): Boolean {
        val d = dir(project)
        return d.isDirectory && d.canonicalPath.startsWith(root.canonicalPath + File.separator) && d.deleteRecursively()
    }

    /** ZIP du projet (sans l'historique), dans le cache, prêt à enregistrer dans Téléchargements. */
    fun zip(project: String): File? {
        val list = files(project)
        if (list.isEmpty()) return null
        val name = dir(project).name
        val out = File(cache, "$name.zip")
        ZipOutputStream(out.outputStream().buffered()).use { z ->
            for (rel in list) {
                val f = File(dir(project), rel)
                z.putNextEntry(ZipEntry("$name/$rel"))
                f.inputStream().use { it.copyTo(z) }
                z.closeEntry()
            }
        }
        return out
    }

    /** Page web du projet (index.html avec css/js locaux intégrés), ou null. */
    fun page(project: String): String? {
        val web = files(project).filter { it.substringAfterLast('.', "").lowercase() in setOf("html", "htm", "css", "js") }
        val list = web.mapNotNull { p -> read(project, p)?.let { ProjFile(p, it) } }
        return FileTool.webPage(list)
    }

    /** Fichier du projet cité dans le message (« modifie app.py… »), s'il existe. */
    fun mentioned(project: String, text: String): String? =
        files(project).filter { p ->
            val base = p.substringAfterLast('/')
            base.length >= 3 && (text.contains(p, true) || text.contains(base, true))
        }.maxByOrNull { it.length }

    /** Contenu actuel du fichier, à joindre à la demande pour que l'IA le modifie (coupé selon la mémoire du modèle). */
    fun fileContext(project: String, rel: String, maxChars: Int): String {
        val body = read(project, rel) ?: return ""
        val cut = if (body.length > maxChars) body.take(maxChars) + "\n… (fichier coupé)" else body
        val ext = rel.substringAfterLast('.', "")
        return "\n\n(Si tu modifies le fichier « $rel », renvoie-le complet dans un seul bloc de code.)\n" +
            "Fichier actuel :\n```$ext\n$cut\n```"
    }

    /** Enregistre les blocs de code d'une réponse. [target] : fichier cité par l'utilisateur, à remplacer. */
    fun saveBlocks(project: String, text: String, target: String?): List<SavedFile> {
        val blocks = CodeBlocks.extract(text).filter { CodeBlocks.worthSaving(it) }
        if (blocks.isEmpty()) return emptyList()
        val hasHtml = blocks.any { it.ext == "html" }
        val targetExt = target?.substringAfterLast('.', "")?.lowercase()
        val single = target.takeIf { targetExt != null && blocks.count { b -> b.ext == targetExt } == 1 }
        val used = mutableSetOf<String>()
        val saved = mutableListOf<SavedFile>()
        for (b in blocks) {
            val first = b.nameHint
                ?: single?.takeIf { b.ext == targetExt }
                ?: defaultName(b.ext, hasHtml)
            var name = first
            var n = 2
            while (!used.add(name.lowercase())) {
                name = first.substringBeforeLast('.') + "_" + n + "." + first.substringAfterLast('.')
                n++
            }
            write(project, name, b.code)?.let { saved += it }
        }
        return saved
    }

    private fun defaultName(ext: String, hasHtml: Boolean): String = when (ext) {
        "html" -> "index.html"
        "css" -> "style.css"
        "js" -> if (hasHtml) "script.js" else "main.js"
        else -> "main.$ext"
    }

    private fun resolve(project: String, rel: String): File? {
        val path = cleanRel(rel) ?: return null
        val base = dir(project)
        val f = File(base, path)
        return if (f.canonicalPath.startsWith(base.canonicalPath + File.separator)) f else null
    }

    private fun backup(base: File, path: String, file: File) {
        runCatching {
            val hist = File(base, HISTORY).apply { mkdirs() }
            val key = path.replace("/", "__")
            val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
            file.copyTo(File(hist, "$key.$stamp"), overwrite = true)
            hist.listFiles { f -> f.name.startsWith("$key.") }
                ?.sortedByDescending { it.name }?.drop(10)?.forEach { it.delete() }
        }
    }

    companion object {
        const val HISTORY = ".history"

        fun cleanRel(raw: String): String? {
            val p = raw.trim().replace('\\', '/').trimStart('/')
            val parts = p.split('/').filter { it.isNotBlank() && it != "." }
            if (parts.isEmpty() || parts.size > 6 || parts.any { it == ".." || it == HISTORY }) return null
            val safe = parts.map { seg -> seg.filter { it.isLetterOrDigit() || it in "._- " }.trim().take(60) }
            if (safe.any { it.isBlank() || it.startsWith(".") }) return null
            return safe.joinToString("/").take(150)
        }

        /** Nom stable du projet d'une discussion : début de la première question + fin de l'identifiant. */
        fun projectFor(chatId: String, firstUserText: String): String =
            FileTool.projectName(firstUserText).take(18).trimEnd('_').ifBlank { "projet" } + "_" + chatId.takeLast(4)

        /** Résumé enregistré dans le message : 1re ligne = projet, puis « C chemin » (créé) ou « M chemin » (modifié). */
        fun encodeSaved(project: String, saved: List<SavedFile>): String {
            val lines = saved.filter { it.kind != SaveKind.UNCHANGED }
                .map { (if (it.kind == SaveKind.CREATED) "C " else "M ") + it.path }
            return if (lines.isEmpty()) "" else (listOf(project) + lines).joinToString("\n")
        }
    }
}
