package ai.zeno.app

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Outil « jeux » : Zeno écrit un jeu HTML/JavaScript en un seul fichier.
 * L'app le lance dans une WebView isolée (sans réseau) pour le tester sans rien installer.
 */
object GameTool {

    private val verbRx = Regex(
        "\\b(crée|cree|créer|creer|fais|fais-moi|génère|genere|générer|generer|programme|développe|developpe|make|create|build|write)\\b",
        RegexOption.IGNORE_CASE
    )
    private val nounRx = Regex("\\b(jeu|jeux|mini-jeu|minijeu|game)\\b", RegexOption.IGNORE_CASE)
    private val otherLangRx = Regex(
        "\\b(python|kotlin|java|c\\+\\+|c#|unity|godot|lua|rust|swift|unreal|pygame)\\b",
        RegexOption.IGNORE_CASE
    )

    fun isRequest(text: String): Boolean {
        val t = text.trim()
        if (t.startsWith("/jeu", ignoreCase = true)) return true
        if (t.length > 300 || t.contains("```")) return false
        if (otherLangRx.containsMatchIn(t)) return false
        return verbRx.containsMatchIn(t) && nounRx.containsMatchIn(t)
    }

    fun request(text: String): String =
        text.trim().replace(Regex("^/jeu\\s*", RegexOption.IGNORE_CASE), "").trim()

    fun generateGameHtml(gameDescription: String): String {
        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="utf-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Zeno Game Preview</title>
                <style>
                    body { margin: 0; background: #111; color: #fff; text-align: center; font-family: sans-serif; overflow: hidden; }
                    canvas { background: #222; display: block; margin: 10px auto; border: 2px solid #555; touch-action: none; }
                    p { font-size: 14px; color: #aaa; margin: 5px; }
                </style>
            </head>
            <body>
                <h3 style="margin:8px 0;">🎮 Aperçu : $gameDescription</h3>
                <canvas id="gameCanvas" width="360" height="260"></canvas>
                <p>Touche l'écran ou utilise les flèches pour jouer</p>
                <script>
                    const canvas = document.getElementById("gameCanvas");
                    const ctx = canvas.getContext("2d");
                    let x = 160, y = 110;
                    
                    function draw() {
                        ctx.clearRect(0, 0, canvas.width, canvas.height);
                        ctx.fillStyle = "#00FFCC";
                        ctx.beginPath();
                        ctx.arc(x, y, 20, 0, Math.PI * 2);
                        ctx.fill();
                    }
                    
                    window.addEventListener("keydown", (e) => {
                        if(e.key === "ArrowRight") x = Math.min(canvas.width - 20, x + 15);
                        if(e.key === "ArrowLeft") x = Math.max(20, x - 15);
                        if(e.key === "ArrowUp") y = Math.max(20, y - 15);
                        if(e.key === "ArrowDown") y = Math.min(canvas.height - 20, y + 15);
                        draw();
                    });

                    canvas.addEventListener("touchmove", (e) => {
                        const rect = canvas.getBoundingClientRect();
                        const touch = e.touches[0];
                        x = touch.clientX - rect.left;
                        y = touch.clientY - rect.top;
                        draw();
                        e.preventDefault();
                    });

                    draw();
                </script>
            </body>
            </html>
        """.trimIndent()
    }

    fun exportGameAsZip(context: Context, gameHtmlContent: String): File {
        val zipFile = File(context.cacheDir, "zeno_game_source.zip")
        ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
            val entry = ZipEntry("index.html")
            zos.putNextEntry(entry)
            zos.write(gameHtmlContent.toByteArray())
            zos.closeEntry()
        }
        return zipFile
    }
}
