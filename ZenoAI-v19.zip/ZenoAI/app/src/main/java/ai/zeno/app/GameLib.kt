package ai.zeno.app

import android.content.Context
import org.json.JSONObject

data class GameSpec(
    val kind: String, val title: String, val color: String,
    val bg: String, val icon: String, val speed: Int
)

/**
 * Jeux prêts à l'emploi (dossier assets/games). L'IA choisit le jeu et le personnalise
 * (titre, couleur, emoji, vitesse) : c'est bien plus fiable que de lui faire écrire tout le code.
 */
object GameLib {

    private class Def(
        val kind: String, val label: String, val keys: Regex,
        val icon: String, val color: String, val bg: String
    )

    private val defs = listOf(
        Def("tetris", "Tetris", Regex("tetris|blocs? (?:qui )?tomb|briques? (?:qui )?tomb"), "🧱", "#22d3ee", "#0b1020"),
        Def("pong", "Pong", Regex("\\bpong\\b|ping.?pong|raquette|tennis"), "🏓", "#4ade80", "#0b1020"),
        Def("taupe", "Tape-taupe", Regex("taupe|whack|marteau|tape.?tape"), "🐹", "#f59e0b", "#1c1917"),
        Def("simon", "Simon", Regex("\\bsimon\\b|séquence|sequence|reproduire les couleurs"), "🎵", "#4ade80", "#111827"),
        Def("demineur", "Démineur", Regex("d[ée]mineur|minesweeper|champ de mines"), "💣", "#38bdf8", "#0f172a"),
        Def("labyrinthe", "Labyrinthe", Regex("labyrinthe|maze|d[ée]dale|sortie du"), "🌀", "#a78bfa", "#0b1020"),
        Def("2048", "2048", Regex("2048|tuiles"), "🔢", "#f59e0b", "#1f2937"),
        Def("snake", "Serpent", Regex("serpent|snake|nokia"), "🍎", "#4ade80", "#0f172a"),
        Def("breakout", "Casse-briques", Regex("casse.?brique|breakout|arkanoid|briques"), "❤", "#38bdf8", "#0b1020"),
        Def("flappy", "Flappy", Regex("flappy|oiseau|tuyaux|flap\\b"), "🐦", "#34d399", "#0b3b5a"),
        Def("invaders", "Space Invaders", Regex("invader|space|vaisseau|espace|alien|galaxie|shooter"), "👾", "#f472b6", "#05010f"),
        Def("memory", "Memory", Regex("memory|mémoire|memoire|paires|cartes"), "❓", "#8b5cf6", "#111827"),
        Def("morpion", "Morpion", Regex("morpion|tic.?tac|oxo|croix et ronds"), "❌", "#f59e0b", "#111827"),
        Def("dodge", "Course", Regex("course|racing|voiture|runner|esquive|éviter|eviter|dodge|auto\\b"), "🚗", "#ef4444", "#1c1917")
    )

    private val colorWords = listOf(
        Regex("rouge|red") to "#ef4444", Regex("bleu|blue") to "#3b82f6", Regex("vert|green") to "#22c55e",
        Regex("jaune|yellow") to "#facc15", Regex("orange") to "#f97316", Regex("violet|purple") to "#a855f7",
        Regex("rose|pink") to "#ec4899", Regex("cyan|turquoise") to "#22d3ee", Regex("blanc|white") to "#f8fafc",
        Regex("dor[ée]|gold") to "#fbbf24"
    )

    /** Liste lisible des jeux disponibles (pour demander à l'IA de choisir). */
    fun menu(): String = defs.joinToString(", ") { it.label }

    /** Choix de secours quand rien ne correspond : varie selon la demande (plus jamais toujours le même jeu). */
    fun fallbackKind(request: String): String = defs[Math.floorMod(request.lowercase().hashCode(), defs.size)].kind

    fun label(kind: String): String = defs.firstOrNull { it.kind == kind }?.label ?: kind

    /** Quel jeu prêt à l'emploi correspond à la demande ? null = aucun (l'IA écrira alors le code). */
    fun detectKind(request: String): String? {
        val r = request.lowercase()
        if (r.contains("```")) return null
        return defs.firstOrNull { it.keys.containsMatchIn(r) }?.kind
    }

    private fun firstEmoji(s: String): String? {
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            val n = Character.charCount(cp)
            if (cp in 0x1F300..0x1FAFF || cp in 0x2600..0x27BF) return s.substring(i, i + n)
            i += n
        }
        return null
    }

    private fun cleanIcon(s: String) = s.filter { it != '\'' && it != '\\' && it != '<' && it != '>' && it != '&' && it != '\n' }

    /** Lit la réponse de l'IA (un petit JSON) ; ce qui est invalide est remplacé par des valeurs sûres. */
    fun parseSpec(raw: String, kind: String, request: String): GameSpec {
        val d = defs.first { it.kind == kind }
        var title = d.label
        var color = d.color
        var icon = d.icon
        var speed = 5
        runCatching {
            val m = Regex("\\{[\\s\\S]*?\\}").find(raw)?.value ?: return@runCatching
            val o = JSONObject(m)
            o.optString("titre", o.optString("title", "")).trim().takeIf { it.length in 2..28 }?.let { title = it }
            o.optString("couleur", o.optString("color", "")).trim()
                .takeIf { Regex("#[0-9a-fA-F]{6}").matches(it) }?.let { color = it }
            cleanIcon(o.optString("emoji", o.optString("icon", "")).trim())
                .takeIf { it.isNotEmpty() && it.length <= 4 && it.codePointAt(0) > 0x2000 }?.let { icon = it }
            o.optInt("vitesse", o.optInt("speed", 0)).takeIf { it in 1..10 }?.let { speed = it }
        }
        // Ce que l'utilisateur écrit explicitement passe avant le choix de l'IA
        val r = request.lowercase()
        colorWords.firstOrNull { it.first.containsMatchIn(r) }?.let { color = it.second }
        firstEmoji(request)?.let { icon = it }
        if (Regex("rapide|difficile|hard|vite").containsMatchIn(r)) speed = 8
        if (Regex("lent|facile|easy|débutant|debutant").containsMatchIn(r)) speed = 3
        return GameSpec(kind, title, color, d.bg, icon, speed)
    }

    fun defaultSpec(kind: String, request: String) = parseSpec("", kind, request)

    private fun htmlEscape(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    fun build(context: Context, spec: GameSpec): String {
        val tpl = context.assets.open("games/${spec.kind}.html").bufferedReader().use { it.readText() }
        return tpl
            .replace("__TITLE__", htmlEscape(spec.title))
            .replace("__COLOR__", spec.color)
            .replace("__BG__", spec.bg)
            .replace("__ICON__", cleanIcon(spec.icon))
            .replace("__SPEED__", spec.speed.toString())
    }
}
