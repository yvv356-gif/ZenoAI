package ai.zeno.app

import org.json.JSONArray

data class Flashcard(val front: String, val back: String)

data class FlashcardSet(val topic: String, val cards: List<Flashcard>)

/** Cartes mémoire écrites par l'IA locale (JSON), puis révisées à l'écran (carte retournable). */
object Flashcards {

    private val cmdRx = Regex("^/(cartes|flashcards)\\b", RegexOption.IGNORE_CASE)

    private const val SYSTEM =
        "Tu crées des cartes mémoire. Réponds uniquement avec un tableau JSON, sans texte autour ni balises. " +
            "Format : [{\"recto\":\"question ou mot\",\"verso\":\"réponse courte\"}]"

    fun isRequest(text: String): Boolean = cmdRx.containsMatchIn(text.trim())

    fun topic(text: String): String = text.trim().replace(cmdRx, "").trim()

    fun prompt(template: String, topic: String): String =
        PromptBuilder.wrap(
            template, SYSTEM,
            "Sujet : ${topic.take(200)}\nCrée 8 cartes courtes et exactes, dans la langue du sujet. Réponds uniquement avec le JSON."
        )

    fun parse(raw: String): List<Flashcard> {
        val json = Regex("\\[[\\s\\S]*\\]").find(raw)?.value ?: return emptyList()
        return runCatching {
            val arr = JSONArray(json)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val front = o.optString("recto").trim()
                val back = o.optString("verso").trim()
                if (front.isEmpty() || back.isEmpty()) null else Flashcard(front.take(200), back.take(400))
            }
        }.getOrDefault(emptyList()).take(20)
    }
}
