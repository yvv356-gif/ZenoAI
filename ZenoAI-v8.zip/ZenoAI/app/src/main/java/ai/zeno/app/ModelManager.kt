package ai.zeno.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Fichiers de l'appli : plusieurs modèles installés côte à côte, images, jeux et vidéos générés. */
class ModelManager(private val context: Context) {

    private val dir get() = File(context.filesDir, "models").apply { mkdirs() }
    private val imagesDir get() = File(context.filesDir, "images").apply { mkdirs() }
    private val gamesDir get() = File(context.filesDir, "games").apply { mkdirs() }
    private val videosDir get() = File(context.filesDir, "videos").apply { mkdirs() }

    /** Anciennes versions : un seul fichier model.task. On le range avec les autres modèles. */
    fun migrateOld(name: String): String? {
        val old = File(File(context.filesDir, "model"), "model.task")
        if (!old.exists() || old.length() < 1_000_000) return null
        val target = File(dir, name)
        if (target.exists()) return null
        return if (old.renameTo(target)) name else null
    }

    fun installed(): List<File> =
        (dir.listFiles { f -> f.isFile && (f.name.endsWith(".task") || f.name.endsWith(".gguf")) && f.length() > 1_000_000 } ?: emptyArray())
            .sortedBy { it.name }

    fun file(name: String) = File(dir, name)
    fun exists(name: String) = name.isNotBlank() && file(name).let { it.exists() && it.length() > 1_000_000 }
    fun path(name: String): String = file(name).absolutePath
    fun delete(name: String) { file(name).delete() }

    fun saveImage(bytes: ByteArray): File {
        val f = File(imagesDir, "img_${System.currentTimeMillis()}.jpg")
        f.writeBytes(bytes)
        return f
    }

    fun saveGame(html: String): File {
        val f = File(gamesDir, "game_${System.currentTimeMillis()}.html")
        f.writeText(html)
        return f
    }

    fun newVideoFile() = File(videosDir, "vid_${System.currentTimeMillis()}.mp4")

    fun displayName(uri: Uri): String = runCatching {
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) c.getString(i) else ""
        }.orEmpty()
    }.getOrDefault("")

    /** Téléchargement avec redirections gérées à la main (le jeton HF n'est envoyé qu'à huggingface.co). */
    suspend fun download(url: String, token: String, name: String, onProgress: (Float?) -> Unit) = withContext(Dispatchers.IO) {
        val tmp = File(dir, "$name.part")
        var current = url
        var conn: HttpURLConnection? = null
        for (i in 0..6) {
            val u = URL(current)
            val c = u.openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 20_000
            c.readTimeout = 30_000
            c.setRequestProperty("User-Agent", "ZenoAI/1.0")
            if (token.isNotBlank() && u.host.endsWith("huggingface.co")) {
                c.setRequestProperty("Authorization", "Bearer ${token.trim()}")
            }
            c.connect()
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: error("Redirection invalide")
                current = URL(u, loc).toString()
                c.disconnect()
                continue
            }
            conn = c
            break
        }
        val c = conn ?: error("Trop de redirections")
        try {
            val code = c.responseCode
            if (code == 401 || code == 403) {
                error("Accès refusé (HTTP $code). Ce modèle demande d'accepter sa licence sur huggingface.co puis d'ajouter ton jeton dans les réglages.")
            }
            if (code !in 200..299) error("HTTP $code (URL incorrecte ?)")
            val total = c.contentLengthLong
            if (total > 0 && dir.usableSpace < total + 300_000_000L) {
                error("pas assez d'espace : il faut ${(total + 300_000_000L) / 1_000_000_000L + 1} Go libres (il en reste ${dir.usableSpace / 1_000_000_000L})")
            }
            var done = 0L
            var lastPct = -1
            c.inputStream.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val pct = (done * 100 / total).toInt()
                            if (pct != lastPct) { lastPct = pct; onProgress(done.toFloat() / total) }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            tmp.delete()
            throw e
        } finally {
            c.disconnect()
        }
        val target = file(name)
        target.delete()
        if (!tmp.renameTo(target)) error("Impossible d'enregistrer le modèle")
    }

    fun deletePart(name: String) { File(dir, "$name.part").delete() }

    /**
     * Téléchargement qui reprend là où il s'est arrêté (en-tête Range) et retente après une coupure réseau.
     * onProgress(octets reçus, taille totale ou -1, octets/s, message d'état éventuel).
     */
    suspend fun downloadResumable(
        url: String, token: String, name: String,
        onProgress: (Long, Long, Long, String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val part = File(dir, "$name.part")
        var attempt = 0
        while (true) {
            currentCoroutineContext().ensureActive()
            try {
                transfer(url, token, part, onProgress)
                break
            } catch (e: IOException) {
                attempt++
                if (attempt > 40) {
                    throw IllegalStateException("réseau indisponible après plusieurs tentatives (${e.message})")
                }
                val wait = minOf(30, attempt * 3)
                onProgress(part.length(), -1L, 0L, "Connexion perdue, nouvel essai dans ${wait} s…")
                delay(wait * 1000L)
            }
        }
        if (name.endsWith(".gguf")) {
            val magic = ByteArray(4)
            val read = part.inputStream().use { it.read(magic) }
            if (read < 4 || String(magic, Charsets.ISO_8859_1) != "GGUF") {
                part.delete()
                error("le fichier reçu n'est pas un modèle GGUF valide (adresse incorrecte ?)")
            }
        }
        val target = file(name)
        target.delete()
        if (!part.renameTo(target)) error("impossible d'enregistrer le modèle")
    }

    private suspend fun transfer(url: String, token: String, part: File, onProgress: (Long, Long, Long, String) -> Unit) {
        var existing = if (part.exists()) part.length() else 0L
        var current = url
        var conn: HttpURLConnection? = null
        for (i in 0..8) {
            val u = URL(current)
            val c = u.openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 20_000
            c.readTimeout = 30_000
            c.setRequestProperty("User-Agent", "ZenoAI/1.0")
            if (existing > 0) c.setRequestProperty("Range", "bytes=$existing-")
            if (token.isNotBlank() && u.host.endsWith("huggingface.co")) {
                c.setRequestProperty("Authorization", "Bearer ${token.trim()}")
            }
            c.connect()
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: error("redirection invalide")
                current = URL(u, loc).toString()
                c.disconnect()
                continue
            }
            conn = c
            break
        }
        val c = conn ?: error("trop de redirections")
        try {
            val code = c.responseCode
            if (code == 401 || code == 403) {
                error("accès refusé (HTTP $code) : ce modèle demande d'accepter sa licence sur huggingface.co et un jeton dans les réglages")
            }
            if (code == 416) {
                part.delete()
                throw IOException("reprise impossible, nouvel essai depuis le début")
            }
            if (code == 408 || code == 425 || code == 429 || code >= 500) {
                throw IOException("serveur occupé ou indisponible (HTTP $code), nouvel essai")
            }
            if (code !in 200..299) error("HTTP $code (adresse incorrecte ?)")
            val resumed = code == 206
            if (!resumed && existing > 0) {
                part.delete()
                existing = 0L
            }
            val len = c.contentLengthLong
            val total = if (len > 0) existing + len else -1L
            if (total > 0 && dir.usableSpace < (total - existing) + 300_000_000L) {
                error("pas assez d'espace : il faut ${(total - existing + 300_000_000L) / 1_000_000_000L + 1} Go libres (il en reste ${dir.usableSpace / 1_000_000_000L})")
            }
            var done = existing
            var tick = System.currentTimeMillis()
            var tickBytes = done
            c.inputStream.use { input ->
                FileOutputStream(part, resumed).use { out ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - tick >= 800) {
                            val speed = (done - tickBytes) * 1000 / (now - tick)
                            onProgress(done, total, speed, "")
                            tick = now
                            tickBytes = done
                        }
                    }
                }
            }
            if (total > 0 && done < total) throw IOException("téléchargement interrompu")
            onProgress(done, total, 0L, "")
        } finally {
            c.disconnect()
        }
    }

    suspend fun import(uri: Uri, name: String) = withContext(Dispatchers.IO) {
        val tmp = File(dir, "$name.part")
        context.contentResolver.openInputStream(uri)!!.use { input ->
            tmp.outputStream().use { out -> input.copyTo(out, 256 * 1024) }
        }
        val target = file(name)
        target.delete()
        if (!tmp.renameTo(target)) error("Impossible d'enregistrer le modèle")
    }

    companion object {
        /** Nom de fichier propre (.task ou .gguf) tiré d'une URL ou d'un nom. */
        fun safeName(raw: String): String {
            var n = raw.substringBefore('?').substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_")
            if (n.isBlank()) n = "model"
            if (!n.endsWith(".task") && !n.endsWith(".gguf")) n += ".task"
            return n
        }

        /** Nom lisible d'un fichier modèle. */
        fun label(name: String): String {
            ModelPresets.presetFor(name)?.let { return it.label }
            return name.removeSuffix(".task").removeSuffix(".gguf").replace("_multi-prefill-seq", "").replace('_', ' ')
        }
    }
}
