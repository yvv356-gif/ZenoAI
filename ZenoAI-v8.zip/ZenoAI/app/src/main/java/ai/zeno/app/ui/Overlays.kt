package ai.zeno.app.ui

import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ai.zeno.app.Flashcard

/** Navigateur intégré : la page ouverte par l'agent s'affiche à l'écran pour que tu suives chaque étape. */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserDialog(url: String, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        url,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.weight(1f).padding(start = 12.dp)
                    )
                    IconButton(onClick = onClose) {
                        Icon(Icons.Filled.Close, contentDescription = "Fermer le navigateur")
                    }
                }
                AndroidView(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    factory = { ctx ->
                        WebView(ctx).apply {
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            webViewClient = WebViewClient()
                        }
                    },
                    update = { view -> if (view.tag != url) { view.tag = url; view.loadUrl(url) } }
                )
            }
        }
    }
}

/** Révision de cartes mémoire : on touche la carte pour la retourner, puis on indique si on la savait. */
@Composable
fun FlashcardDialog(topic: String, cards: List<Flashcard>, onClose: () -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    var showBack by remember { mutableStateOf(false) }
    var known by remember { mutableIntStateOf(0) }
    var done by remember { mutableStateOf(false) }
    val flip by animateFloatAsState(targetValue = if (showBack) 180f else 0f, label = "flip")

    fun answer(knewIt: Boolean) {
        if (knewIt) known += 1
        showBack = false
        if (index < cards.lastIndex) index += 1 else done = true
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        topic,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = "Fermer") }
                }
                Spacer(Modifier.weight(1f))
                if (done) {
                    Text(
                        "Révision terminée : $known sur ${cards.size} sues",
                        style = MaterialTheme.typography.titleLarge,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { index = 0; known = 0; done = false; showBack = false }) { Text("Recommencer") }
                } else {
                    Text("Carte ${index + 1} sur ${cards.size}", style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 260.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .clickable { showBack = !showBack }
                            .graphicsLayer { rotationY = flip; cameraDistance = 16f * density },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (flip < 90f) cards[index].front else cards[index].back,
                            style = MaterialTheme.typography.headlineSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .padding(24.dp)
                                .graphicsLayer { rotationY = if (flip >= 90f) 180f else 0f }
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (showBack) "Touche la carte pour revoir la question" else "Touche la carte pour voir la réponse",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.weight(1f))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { answer(false) }, modifier = Modifier.weight(1f)) { Text("À revoir") }
                        Button(onClick = { answer(true) }, modifier = Modifier.weight(1f)) { Text("Je savais") }
                    }
                }
            }
        }
    }
}
