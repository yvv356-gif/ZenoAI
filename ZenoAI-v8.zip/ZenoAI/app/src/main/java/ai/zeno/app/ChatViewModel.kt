package ai.zeno.app

import android.app.Application
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = Prefs(app)
    private val engine = LlmEngine(app)
    private val files = ModelManager(app)
    private val store = ChatStore(app)

    private var nextId = 1L
    private var summary = ""
    private var gen = 0
    private var genJob: Job? = null
    private var summaryJob: Job? = null
    private var dlJob: Job? = null
    private var loadJob: Job? = null

    var messages by mutableStateOf<List<ChatMessage>>(emptyList())
        private set
    var chats by mutableStateOf<List<ChatMeta>>(emptyList())
        private set
    var currentId by mutableStateOf<String?>(null)
        private set
    var busy by mutableStateOf(false)
        private set
    var modelState by mutableStateOf<ModelState>(ModelState.None)
        private set

    var thinking by mutableStateOf(prefs.thinking)
        private set
    var look by mutableStateOf(prefs.loadLook())
        private set
    var agent by mutableStateOf(prefs.agent)
        private set

    /** Modèle choisi (un nom de fichier, ou AUTO) et modèle réellement chargé en mémoire. */
    var activeModel by mutableStateOf(prefs.activeModel)
        private set
    var loadedModel by mutableStateOf("")
        private set
    var installedNames by mutableStateOf<List<String>>(emptyList())
        private set
    /** Téléchargement ou copie en cours : (nom du fichier, progression ou null). */
    var dl by mutableStateOf<Pair<String, Float?>?>(null)
        private set
    var dlMessage by mutableStateOf("")
        private set
    var dlStatus by mutableStateOf("")
        private set

    var webEnabled by mutableStateOf(prefs.web)
    var template by mutableStateOf(prefs.template)
    var maxTokens by mutableStateOf(prefs.maxTokens)
    var modelUrl by mutableStateOf(prefs.modelUrl)
    var imageUrl by mutableStateOf(prefs.imageUrl)

    /** Adresse ouverte par l'agent dans le navigateur intégré (visible à l'écran). */
    var browseUrl by mutableStateOf<String?>(null)

    /** Cartes mémoire en cours de révision. */
    var flashcards by mutableStateOf<FlashcardSet?>(null)
    var hfToken by mutableStateOf(prefs.hfToken)
    var videoKey by mutableStateOf(prefs.videoKey)
    var videoModel by mutableStateOf(prefs.videoModel)

    private val imageReplies = listOf(
        "Voilà ce que ça donne !",
        "Tiens, regarde ce que j'ai dessiné pour toi.",
        "Et voilà, dis-moi si ça te plaît !",
        "C'est prêt ! Je peux en refaire une autre version si tu veux."
    )

    init {
        chats = runCatching { store.list() }.getOrDefault(emptyList())
        // Anciennes versions : un seul fichier model.task, rangé avec les autres modèles
        files.migrateOld(ModelManager.safeName(prefs.modelUrl))?.let { name ->
            if (prefs.modelCfg(name) == null) prefs.setModelCfg(name, prefs.template, prefs.maxTokens)
            if (prefs.activeModel.isBlank()) prefs.activeModel = name
        }
        refreshInstalled()
        if (activeModel != AUTO && !files.exists(activeModel)) {
            activeModel = installedNames.firstOrNull().orEmpty()
            prefs.activeModel = activeModel
        }
        if (installedNames.isNotEmpty()) loadModel()
        watchDownloads()
    }

    // ---------- Modèles ----------

    private fun refreshInstalled() {
        installedNames = files.installed().map { it.name }
    }

    /** Famille (template) et contexte d'un modèle : réglages enregistrés, sinon devinés d'après le nom. */
    private fun cfgFor(name: String): Pair<String, Int> {
        prefs.modelCfg(name)?.let { return it }
        val l = name.lowercase()
        val tpl = when {
            l.contains("gemma") -> "gemma"
            l.contains("llama") -> "llama"
            else -> "chatml"
        }
        val ctx = Regex("ekv(\\d+)").find(l)?.groupValues?.get(1)?.toIntOrNull()
            ?: if (l.endsWith(".gguf")) 2048 else 1280
        return tpl to ctx
    }

    private fun registerModel(name: String) {
        if (prefs.modelCfg(name) == null) {
            val c = cfgFor(name)
            prefs.setModelCfg(name, c.first, c.second)
        }
    }

    fun labelOf(name: String): String = if (name == AUTO) "Auto" else ModelManager.label(name)

    /** Texte du bouton « modèle » de l'écran d'accueil. */
    fun activeLabel(): String = when {
        activeModel == AUTO -> if (loadedModel.isNotBlank()) "Auto · ${ModelManager.label(loadedModel)}" else "Auto"
        activeModel.isBlank() -> "Aucun modèle"
        else -> ModelManager.label(activeModel)
    }

    fun sizeMb(name: String): Long = files.file(name).length() / 1_000_000

    fun isInstalled(preset: ModelPreset): Boolean =
        installedNames.any { it.lowercase().contains(preset.key) }

    fun loadModel() {
        val name = if (activeModel == AUTO) {
            prefs.lastModel.takeIf { files.exists(it) } ?: installedNames.firstOrNull()
        } else activeModel
        if (name == null || !files.exists(name)) { modelState = ModelState.None; return }
        val (tpl, ctx) = cfgFor(name)
        modelState = ModelState.Busy("Chargement de ${ModelManager.label(name)}…")
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            modelState = try {
                engine.load(files.path(name), ctx)
                loadedModel = name
                template = tpl
                maxTokens = ctx
                prefs.lastModel = name
                prefs.template = tpl
                prefs.maxTokens = ctx
                ModelState.Ready
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                ModelState.Error(
                    "Chargement impossible : ${e.message ?: e.javaClass.simpleName}. " +
                        "Le modèle est peut-être trop lourd pour la mémoire du téléphone : choisis-en un plus léger."
                )
            }
        }
    }

    /** Change de modèle sans toucher à la discussion (messages et mémoire sont conservés). */
    fun switchModel(name: String) {
        if (name == activeModel && modelState is ModelState.Ready) return
        if (name != AUTO && !files.exists(name)) return
        if (busy) stopWork()
        activeModel = name
        prefs.activeModel = name
        if (name == AUTO && loadedModel.isNotBlank() && modelState is ModelState.Ready) return
        loadModel()
    }

    /** Lance le téléchargement dans un service d'arrière-plan : il continue appli fermée ou écran éteint. */
    fun downloadModel(url: String) {
        if (url.isBlank() || DownloadState.flow.value != null || dlJob?.isActive == true) return
        val name = ModelManager.safeName(url)
        dlMessage = ""
        dlStatus = "Préparation…"
        dl = name to 0f
        val app = getApplication<Application>()
        val intent = Intent(app, DownloadService::class.java)
            .putExtra(DownloadService.EXTRA_URL, url)
            .putExtra(DownloadService.EXTRA_NAME, name)
            .putExtra(DownloadService.EXTRA_TOKEN, hfToken)
        runCatching { ContextCompat.startForegroundService(app, intent) }.onFailure {
            dl = null
            dlStatus = ""
            dlMessage = "Impossible de démarrer le téléchargement : ${it.message ?: it.javaClass.simpleName}"
        }
    }

    /** Suit le service de téléchargement : progression, fin, erreur. */
    private fun watchDownloads() {
        viewModelScope.launch {
            DownloadState.flow.collect { info ->
                when {
                    info == null -> if (dlJob?.isActive != true) {
                        dl = null
                        dlStatus = ""
                    }
                    info.error != null -> {
                        dl = null
                        dlStatus = ""
                        dlMessage = "Téléchargement : ${info.error}"
                        DownloadState.clear()
                    }
                    info.done -> {
                        dl = null
                        dlStatus = ""
                        registerModel(info.name)
                        refreshInstalled()
                        DownloadState.clear()
                        switchModel(info.name)
                    }
                    else -> {
                        dl = info.name to info.progress
                        dlStatus = info.status
                    }
                }
            }
        }
    }

    fun download() = downloadModel(modelUrl)

    fun cancelDownload() {
        dlJob?.cancel()
        val app = getApplication<Application>()
        runCatching { app.startService(Intent(app, DownloadService::class.java).setAction(DownloadService.ACTION_CANCEL)) }
    }

    fun importModel(uri: Uri) {
        if (dlJob?.isActive == true) return
        dlMessage = ""
        dl = "Copie du modèle…" to null
        dlJob = viewModelScope.launch {
            try {
                val name = ModelManager.safeName(files.displayName(uri).ifBlank { "modele_importe.task" })
                dl = name to null
                files.import(uri, name)
                registerModel(name)
                dl = null
                refreshInstalled()
                switchModel(name)
            } catch (e: CancellationException) {
                dl = null
                throw e
            } catch (e: Exception) {
                dl = null
                dlMessage = "Import : ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    fun deleteModel(name: String) {
        if (name == activeModel || name == loadedModel) return
        files.delete(name)
        refreshInstalled()
    }

    fun applySettings(
        url: String, tpl: String, tokens: Int, web: Boolean, imgUrl: String, token: String,
        vKey: String, vModel: String
    ) {
        val target = if (activeModel == AUTO) loadedModel else activeModel
        val reload = target.isNotBlank() && (tokens != maxTokens || tpl != template)
        if (target.isNotBlank()) prefs.setModelCfg(target, tpl, tokens)
        modelUrl = url.trim().ifBlank { Prefs.QWEN_URL }
        template = tpl
        maxTokens = tokens
        webEnabled = web
        imageUrl = imgUrl.trim().ifBlank { Prefs.IMAGE_URL }
        hfToken = token.trim()
        videoKey = vKey.trim()
        videoModel = vModel.trim()
        prefs.modelUrl = modelUrl
        prefs.template = tpl
        prefs.maxTokens = tokens
        prefs.web = web
        prefs.imageUrl = imageUrl
        prefs.hfToken = hfToken
        prefs.videoKey = videoKey
        prefs.videoModel = videoModel
        if (reload && files.exists(target) && modelState is ModelState.Ready) loadModel()
    }

    fun setWeb(on: Boolean) {
        webEnabled = on
        prefs.web = on
    }

    fun chooseAgent(on: Boolean) {
        agent = on
        prefs.agent = on
    }

    // ---------- Mode Auto : le meilleur modèle installé pour la tâche ----------

    private enum class TaskKind { CODE, WRITE, COMPLEX, SIMPLE }

    private val writeRx = Regex(
        "(rédige|redige|écris|ecris|poème|poeme|histoire|raconte|traduis|traduction|résume|resume|lettre|mail|email|discours|translate|summarize|story|poem)",
        RegexOption.IGNORE_CASE
    )
    private val mathRx = Regex(
        "(calcule|résous|resous|prouve|démontre|demontre|équation|equation|théorème|theoreme|intégrale|dérivée)",
        RegexOption.IGNORE_CASE
    )

    private fun classify(text: String): TaskKind = when {
        WebSearch.looksLikeCode(text) -> TaskKind.CODE
        writeRx.containsMatchIn(text) -> TaskKind.WRITE
        mathRx.containsMatchIn(text) || thinking == 2 || agent || text.length > 400 -> TaskKind.COMPLEX
        else -> TaskKind.SIMPLE
    }

    /** Taille approximative en milliards de paramètres, lue dans le nom du fichier. */
    private fun sizeOf(name: String): Double =
        Regex("(\\d+(?:\\.\\d+)?)b").find(name.lowercase())?.groupValues?.get(1)?.toDoubleOrNull() ?: 1.5

    private fun pickModel(text: String): String? {
        val inst = installedNames
        if (inst.isEmpty()) return null
        if (inst.size == 1) return inst[0]
        val biggest = inst.maxByOrNull { sizeOf(it) } ?: return null
        val smallest = inst.minByOrNull { sizeOf(it) } ?: return null
        val current = loadedModel.takeIf { it in inst }
        return when (classify(text)) {
            TaskKind.CODE -> inst.filter { it.lowercase().contains("coder") }.maxByOrNull { sizeOf(it) }
                ?: inst.filter { it.lowercase().contains("qwen") }.maxByOrNull { sizeOf(it) } ?: biggest
            TaskKind.WRITE -> inst.filter { it.lowercase().contains("gemma") }.maxByOrNull { sizeOf(it) } ?: biggest
            TaskKind.COMPLEX -> biggest
            TaskKind.SIMPLE -> current ?: smallest
        }
    }

    private suspend fun ensureLoaded(name: String): Boolean {
        if (loadedModel == name) return true
        if (!files.exists(name)) return false
        val (tpl, ctx) = cfgFor(name)
        return try {
            engine.load(files.path(name), ctx)
            loadedModel = name
            template = tpl
            maxTokens = ctx
            prefs.lastModel = name
            true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            false
        }
    }

    private suspend fun autoSwitch(botId: Long, text: String) {
        val want = pickModel(text) ?: return
        if (want == loadedModel) return
        update(botId) { it.copy(status = "Je passe sur ${ModelManager.label(want)} pour cette tâche…") }
        val previous = loadedModel
        if (!ensureLoaded(want) && previous.isNotBlank()) ensureLoaded(previous)
    }

    // ---------- Fichiers ----------

    fun readText(uri: Uri): String = runCatching {
        getApplication<Application>().contentResolver.openInputStream(uri)!!.bufferedReader().use { r ->
            val buf = CharArray(20_000)
            val n = r.read(buf)
            if (n <= 0) "" else String(buf, 0, n)
        }
    }.getOrDefault("")

    fun readGame(path: String): String = runCatching { File(path).readText() }.getOrDefault("")

    fun saveToGallery(path: String): String {
        if (Build.VERSION.SDK_INT < 29) return "Pour enregistrer dans la galerie, il faut Android 10 ou plus."
        return runCatching {
            val resolver = getApplication<Application>().contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "ZenoAI_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ZenoAI")
            }
            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)!!
            resolver.openOutputStream(uri)!!.use { out -> File(path).inputStream().use { it.copyTo(out) } }
            "Image enregistrée dans ta galerie ✅"
        }.getOrElse { "Je n'ai pas pu l'enregistrer : ${it.message}" }
    }

    fun saveVideoToGallery(path: String): String {
        if (Build.VERSION.SDK_INT < 29) return "Pour enregistrer dans la galerie, il faut Android 10 ou plus."
        return runCatching {
            val resolver = getApplication<Application>().contentResolver
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "ZenoAI_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ZenoAI")
            }
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)!!
            resolver.openOutputStream(uri)!!.use { out -> File(path).inputStream().use { it.copyTo(out) } }
            "Vidéo enregistrée dans ta galerie ✅"
        }.getOrElse { "Je n'ai pas pu l'enregistrer : ${it.message}" }
    }

    // ---------- Niveau de réflexion ----------

    fun chooseThinking(n: Int) {
        thinking = n.coerceIn(0, 2)
        prefs.thinking = thinking
    }

    fun cycleThinking() = chooseThinking((thinking + 1) % 3)

    // ---------- Personnalisation ----------

    private fun updateLook(f: (Look) -> Look) {
        look = f(look)
        prefs.saveLook(look)
    }

    fun setUserName(s: String) = updateLook { it.copy(userName = s.take(24)) }
    fun setAiName(s: String) = updateLook { it.copy(aiName = s.take(24)) }
    fun setTextColor(c: Int) = updateLook { it.copy(textColor = c) }
    fun setUserBubble(c: Int) = updateLook { it.copy(userBubble = c) }
    fun setAiBubble(c: Int) = updateLook { it.copy(aiBubble = c) }
    fun setBubbleAlpha(a: Float) = updateLook { it.copy(bubbleAlpha = a.coerceIn(0.15f, 1f)) }

    fun importWallpaper(uri: Uri) {
        viewModelScope.launch {
            val p = withContext(Dispatchers.IO) { ImageStore.save(getApplication<Application>(), uri, "wallpaper", 1600) }
            if (p != null) updateLook { it.copy(wallpaper = p) }
        }
    }

    fun clearWallpaper() {
        ImageStore.delete(look.wallpaper)
        updateLook { it.copy(wallpaper = "") }
    }

    fun importAvatar(user: Boolean, uri: Uri) {
        viewModelScope.launch {
            val p = withContext(Dispatchers.IO) {
                ImageStore.save(getApplication<Application>(), uri, if (user) "avatar_user" else "avatar_ai", 256)
            }
            if (p != null) updateLook { if (user) it.copy(userAvatar = p) else it.copy(aiAvatar = p) }
        }
    }

    fun clearAvatar(user: Boolean) {
        ImageStore.delete(if (user) look.userAvatar else look.aiAvatar)
        updateLook { if (user) it.copy(userAvatar = "") else it.copy(aiAvatar = "") }
    }

    fun resetLook() {
        ImageStore.delete(look.wallpaper)
        ImageStore.delete(look.userAvatar)
        ImageStore.delete(look.aiAvatar)
        look = Look()
        prefs.saveLook(look)
    }

    // ---------- Jeux ----------

    /** Envoie une demande de correction avec le code et les erreurs. Renvoie un message si c'est impossible. */
    fun fixGame(errors: String, code: String): String? {
        if (busy) return "Attends la fin de la réponse en cours."
        val msg = "/jeu Corrige ce jeu. Erreurs : ${errors.take(200)}\n```html\n$code\n```"
        if (msg.length > PromptBuilder.gameRequestCapacity(maxTokens)) {
            return "Ce jeu est trop long pour être corrigé avec une mémoire de $maxTokens. " +
                "Passe à un modèle avec plus de contexte, ou relance « /jeu … »."
        }
        send(msg)
        return null
    }

    /** Fabrique un APK installable à partir du jeu et l'enregistre dans Téléchargements. */
    fun exportApk(html: String, title: String, onDone: (String) -> Unit) {
        val app = getApplication<Application>()
        viewModelScope.launch {
            val msg = withContext(Dispatchers.IO) {
                runCatching {
                    if (html.isBlank()) return@runCatching "Je n'ai pas retrouvé le jeu."
                    if (!ApkExporter.available(app)) {
                        return@runCatching "Le moteur d'APK n'est pas inclus dans cette version : " +
                            "il est ajouté par l'étape « shell de jeu » du workflow (voir le README)."
                    }
                    val safe = title.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').ifBlank { "jeu" }.take(24)
                    val out = File(app.cacheDir, "ZenoJeu_$safe.apk")
                    ApkExporter.build(app, html, out)
                    val where = saveApk(out, "ZenoJeu_${safe}_${System.currentTimeMillis() % 100000}.apk")
                    out.delete()
                    where
                }.getOrElse { "Impossible de créer l'APK : ${it.message ?: it.javaClass.simpleName}" }
            }
            onDone(msg)
        }
    }

    private fun saveApk(file: File, name: String): String {
        val app = getApplication<Application>()
        return if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)!!
            app.contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
            "APK enregistré dans Téléchargements : $name. Ouvre-le pour l'installer (Android te demandera peut-être d'autoriser l'installation)."
        } else {
            val dir = app.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: app.filesDir
            val target = File(dir, name)
            file.copyTo(target, overwrite = true)
            "APK enregistré : ${target.absolutePath}"
        }
    }

    // ---------- Historique ----------

    private fun persist() {
        val id = currentId ?: return
        val clean = messages
            .filter { it.text.isNotBlank() || it.imagePath != null || it.gamePath != null || it.videoPath != null }
            .map { it.copy(streaming = false, status = "") }
        val firstUser = clean.firstOrNull { it.role == Role.USER } ?: return
        val title = firstUser.text.replace(Regex("\\s+"), " ").trim().take(42)
        runCatching {
            store.save(id, title, summary, clean)
            chats = store.list()
        }
    }

    private fun stopWork() {
        gen++
        genJob?.cancel()
        summaryJob?.cancel()
        busy = false
    }

    fun newChat() {
        persist()
        stopWork()
        currentId = null
        summary = ""
        messages = emptyList()
    }

    /** Charge une discussion depuis le disque ; la précédente est sauvegardée puis déchargée de la mémoire. */
    fun openChat(id: String) {
        if (id == currentId) return
        persist()
        stopWork()
        val data = store.load(id) ?: return
        currentId = id
        summary = data.summary
        messages = data.messages
        nextId = (data.messages.maxOfOrNull { it.id } ?: 0L) + 1
    }

    // ---------- Conversation ----------

    private fun update(id: Long, f: (ChatMessage) -> ChatMessage) {
        messages = messages.map { if (it.id == id) f(it) else it }
    }

    fun stop() { genJob?.cancel() }

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || busy) return
        val wantsVideo = VideoGen.isRequest(text)
        val wantsImage = !wantsVideo && ImageGen.isRequest(text)
        val wantsSite = !wantsVideo && !wantsImage && SiteTool.isRequest(text)
        val wantsGame = !wantsVideo && !wantsImage && !wantsSite && GameTool.isRequest(text)
        val wantsCards = !wantsVideo && !wantsImage && !wantsSite && !wantsGame && Flashcards.isRequest(text)
        val gameKind = if (wantsGame) GameLib.detectKind(GameTool.request(text)) else null
        // Images, vidéos et jeux prêts à l'emploi n'ont pas besoin du modèle local
        val needsModel = !(wantsVideo || wantsImage || (wantsGame && gameKind != null))

        if (currentId == null) currentId = "c${System.currentTimeMillis()}"
        val history = messages
        val userMsg = ChatMessage(nextId++, Role.USER, text)

        if (needsModel && modelState !is ModelState.Ready) {
            messages = messages + userMsg + ChatMessage(
                nextId++, Role.AI,
                "Il me manque mon cerveau 😅 Choisis un modèle avec le bouton en haut de l'écran, puis on discute."
            )
            return
        }

        val botId = nextId++
        messages = messages + userMsg + ChatMessage(
            botId, Role.AI, "", streaming = true,
            status = when {
                wantsVideo -> "Je prépare ta vidéo…"
                wantsImage -> "Je prépare mon dessin…"
                wantsGame -> "Je conçois ton jeu…"
                wantsSite -> "Je construis ton site…"
                wantsCards -> "Je prépare tes cartes…"
                else -> "Je réfléchis…"
            }
        )
        busy = true
        val my = ++gen

        genJob = viewModelScope.launch {
            var forSummary = ""
            try {
                summaryJob?.join()
                if (needsModel && activeModel == AUTO) autoSwitch(botId, text)
                forSummary = when {
                    wantsVideo -> doVideo(botId, text)
                    wantsImage -> doImage(botId, text)
                    wantsGame -> doGame(botId, text, gameKind)
                    wantsSite -> doSite(botId, text)
                    wantsCards -> doCards(botId, text)
                    agent -> doAgent(botId, text, history)
                    else -> doChat(botId, text, history)
                }
            } catch (e: CancellationException) {
                update(botId) { it.copy(streaming = false, status = "") }
                throw e
            } catch (e: Throwable) {
                update(botId) {
                    it.copy(
                        text = "Aïe, quelque chose a coincé : ${e.message ?: e.javaClass.simpleName}. " +
                            "Si ton message était long, essaie plus court ou ouvre une nouvelle discussion.",
                        streaming = false, status = ""
                    )
                }
            } finally {
                if (my == gen) {
                    busy = false
                    persist()
                }
            }
            if (my == gen && forSummary.isNotBlank()) rollSummary(my)
        }
    }

    private fun wantsLinks(text: String) = WebSearch.wantsLinks(text)

    private suspend fun doChat(botId: Long, text: String, history: List<ChatMessage>): String {
        val long = PromptBuilder.wantsLong(text)
        val memory = Memory.build(history, summary, text, PromptBuilder.memoryBudget(maxTokens, text.length, long))
        var web = WebResult.EMPTY
        val mode = if (webEnabled) WebSearch.modeFor(text, thinking) else WebSearch.Mode.NONE
        if (mode != WebSearch.Mode.NONE) {
            update(botId) {
                it.copy(status = if (mode == WebSearch.Mode.CODE) "Je cherche sur GitHub et Reddit…" else "Je cherche sur le web…")
            }
            web = runCatching {
                WebSearch.gather(
                    text, PromptBuilder.webBudget(maxTokens, memory.length, text.length, long),
                    mode, thinking, wantsLinks(text)
                )
            }.getOrDefault(WebResult.EMPTY)
            update(botId) { it.copy(status = "Je réfléchis…") }
        }
        return answer(botId, text, web, memory)
    }

    /** Génère la réponse finale à partir de la mémoire et des sources. */
    private suspend fun answer(botId: Long, text: String, web: WebResult, memory: String): String {
        val userName = look.userName.trim().takeIf { it.isNotBlank() && it != "Toi" }.orEmpty()
        val prompt = PromptBuilder.chat(
            template, memory, web.context, text, maxTokens,
            look.aiName.ifBlank { "Zeno" }, userName, thinking
        )
        val base = if (web.context.isNotBlank()) 0.35f else 0.7f
        val temperature = if (thinking == 2) (base - 0.1f).coerceAtLeast(0.2f) else base
        val answer = engine.generate(prompt, temperature) { partial ->
            update(botId) { it.copy(text = PromptBuilder.clean(partial), status = "") }
        }
        val finalText = PromptBuilder.clean(answer)
        update(botId) {
            it.copy(
                text = finalText, streaming = false, status = "",
                sources = web.sources.joinToString(" · ")
            )
        }
        return finalText
    }

    /** Mode agent : plan → outil → observation, jusqu'à 3 étapes (4 en réflexion élevée), puis réponse. */
    private suspend fun doAgent(botId: Long, text: String, history: List<ChatMessage>): String {
        val long = PromptBuilder.wantsLong(text)
        val memory = Memory.build(history, summary, text, PromptBuilder.memoryBudget(maxTokens, text.length, long))
        val notes = StringBuilder()
        val sources = mutableListOf<String>()
        val maxSteps = when (thinking) { 0 -> 2; 1 -> 3; else -> 4 }
        var step = 0
        var finished = false
        while (step < maxSteps && !finished) {
            step++
            // Adresse citée dans la demande : on ouvre la page sans solliciter le modèle.
            val direct = if (step == 1) Agent.findUrl(text) else null
            if (direct != null) {
                openPage(botId, direct, notes)
                break
            }
            update(botId) { it.copy(status = "Agent · étape $step/$maxSteps : je réfléchis…") }
            val raw = engine.generate(PromptBuilder.agentStep(template, text, notes.toString(), step, maxSteps), 0.2f) {}
            val act = Agent.parse(raw, text, step == 1)
            when (act.name) {
                "search", "code" -> {
                    val mode = if (act.name == "code") WebSearch.Mode.CODE else WebSearch.Mode.FACTS
                    update(botId) {
                        it.copy(status = "Agent · étape $step/$maxSteps : je cherche « ${act.input.take(40)} »…")
                    }
                    val r = runCatching {
                        WebSearch.gather(act.input, 450, mode, thinking, wantsLinks(text))
                    }.getOrDefault(WebResult.EMPTY)
                    if (r.context.isBlank()) {
                        notes.append("Rien trouvé pour « ${act.input} ».\n")
                    } else {
                        notes.append("Recherche « ${act.input} » :\n").append(r.context).append('\n')
                        r.sources.forEach { if (it !in sources) sources += it }
                    }
                }
                "calc" -> {
                    update(botId) { it.copy(status = "Agent · étape $step/$maxSteps : je calcule…") }
                    val v = Calc.eval(act.input)
                    notes.append("Calcul ${act.input} = ${v ?: "impossible"}\n")
                }
                "open" -> { openPage(botId, act.input, notes); finished = true }
                "game" -> return doGame(botId, "/jeu ${act.input}", GameLib.detectKind(act.input))
                "site" -> return doSite(botId, "/site ${act.input}")
                "image" -> return doImage(botId, "/image ${act.input}")
                "video" -> return doVideo(botId, "/video ${act.input}")
                else -> finished = true
            }
        }
        update(botId) { it.copy(status = "Je rédige la réponse…") }
        return answer(botId, text, WebResult(notes.toString().trim(), sources), memory)
    }

    /** Ouvre une adresse dans le navigateur intégré (visible à l'écran) et lit son texte pour la réponse. */
    private suspend fun openPage(botId: Long, rawUrl: String, notes: StringBuilder) {
        val url = Agent.findUrl(rawUrl) ?: rawUrl.trim()
        if (url.isBlank()) {
            notes.append("Aucune adresse à ouvrir.\n")
            return
        }
        update(botId) { it.copy(status = "Agent · j'ouvre $url…") }
        browseUrl = url
        val pageText = withContext(Dispatchers.IO) {
            runCatching {
                org.jsoup.Jsoup.connect(url).userAgent("ZenoAI/1.0").timeout(15_000).get().body().text().take(1500)
            }.getOrDefault("")
        }
        notes.append("Page ouverte à l'écran : $url\n")
        notes.append(if (pageText.isBlank()) "Le texte de la page n'a pas pu être lu.\n" else "Texte de la page : $pageText\n")
    }

    /** Cartes mémoire : l'IA locale écrit les cartes, l'appli les affiche en révision interactive. */
    private suspend fun doCards(botId: Long, text: String): String {
        val topic = Flashcards.topic(text)
        if (topic.isBlank()) {
            update(botId) { it.copy(text = "Dis-moi le sujet, par exemple : /cartes les capitales d'Europe", streaming = false, status = "") }
            return ""
        }
        if (modelState !is ModelState.Ready) {
            update(botId) { it.copy(text = "Charge d'abord un modèle IA (Menu ☰ → Modèle et réglages) pour créer des cartes.", streaming = false, status = "") }
            return ""
        }
        update(botId) { it.copy(status = "Je prépare tes cartes…") }
        val raw = engine.generate(Flashcards.prompt(template, topic), 0.4f) {}
        val cards = Flashcards.parse(raw)
        if (cards.isEmpty()) {
            update(botId) { it.copy(text = "Je n'ai pas réussi à écrire les cartes. Essaie avec un sujet plus précis.", streaming = false, status = "") }
            return ""
        }
        flashcards = FlashcardSet(topic, cards)
        update(botId) { it.copy(text = "Tes ${cards.size} cartes sur « $topic » sont prêtes. Touche une carte pour voir la réponse.", streaming = false, status = "") }
        return "J'ai créé ${cards.size} cartes sur $topic."
    }

    /** Un jeu : soit un jeu prêt à l'emploi personnalisé par l'IA, soit du code HTML écrit par l'IA. */
    private suspend fun doGame(botId: Long, text: String, kind: String?): String {
        val request = GameTool.request(text)
        val app = getApplication<Application>()
        if (kind != null) {
            update(botId) { it.copy(status = "Je conçois ton jeu ${GameLib.label(kind)}…") }
            var raw = ""
            if (modelState is ModelState.Ready) {
                raw = runCatching {
                    engine.generate(PromptBuilder.gameSpec(template, GameLib.label(kind), request), 0.4f) {}
                }.getOrDefault("")
            }
            val spec = GameLib.parseSpec(raw, kind, request)
            val html = withContext(Dispatchers.IO) { GameLib.build(app, spec) }
            val f = files.saveGame(html)
            update(botId) {
                it.copy(
                    text = "Ton jeu « ${spec.title} » est prêt ! Touche Jouer pour l'essayer tout de suite, " +
                        "ou APK pour l'installer sur ton téléphone.",
                    streaming = false, status = "", gamePath = f.absolutePath, gameTitle = spec.title
                )
            }
            return "J'ai créé le jeu ${spec.title} (${GameLib.label(kind)})."
        }

        // Pas de jeu prêt à l'emploi pour cette demande : l'IA écrit le code elle-même
        update(botId) { it.copy(status = "Je programme ton jeu…") }
        val prompt = PromptBuilder.game(template, request, maxTokens)
        val answer = engine.generate(prompt, 0.5f) { partial ->
            update(botId) { it.copy(text = PromptBuilder.clean(partial), status = "") }
        }
        val finalText = PromptBuilder.clean(answer)
        val block = Regex("```(?:html)?[ \\t]*\\n([\\s\\S]*?)(?:```|$)").find(finalText)?.groupValues?.get(1).orEmpty()
        val isHtml = block.contains("<script", true) || block.contains("<canvas", true) || block.contains("<html", true)
        if (isHtml) {
            val f = files.saveGame(block.trim())
            val rest = finalText.replace(Regex("```(?:html)?[ \\t]*\\n[\\s\\S]*?(?:```|$)"), "").trim()
            update(botId) {
                it.copy(
                    text = rest.ifBlank { "Voilà ton jeu ! Touche Jouer pour le tester." },
                    streaming = false, status = "", gamePath = f.absolutePath,
                    gameTitle = request.take(28).ifBlank { "Ton jeu" }
                )
            }
        } else {
            update(botId) { it.copy(text = finalText, streaming = false, status = "") }
        }
        return "J'ai créé un jeu : ${request.take(80)}."
    }

    /** Site web : l'IA écrit la page, l'appli l'affiche (Jouer = aperçu) et peut l'exporter en APK. */
    private suspend fun doSite(botId: Long, text: String): String {
        val request = SiteTool.request(text)
        update(botId) { it.copy(status = "Je construis ton site…") }
        val answer = engine.generate(PromptBuilder.site(template, request, maxTokens), 0.5f) { partial ->
            update(botId) { it.copy(text = PromptBuilder.clean(partial), status = "") }
        }
        val finalText = PromptBuilder.clean(answer)
        val block = Regex("```(?:html)?[ \\t]*\\n([\\s\\S]*?)(?:```|$)").find(finalText)?.groupValues?.get(1).orEmpty()
        if (block.contains("<", false) && (block.contains("<body", true) || block.contains("<html", true) || block.contains("<div", true))) {
            val f = files.saveGame(block.trim())
            val rest = finalText.replace(Regex("```(?:html)?[ \\t]*\\n[\\s\\S]*?(?:```|$)"), "").trim()
            update(botId) {
                it.copy(
                    text = rest.ifBlank { "Voilà ton site ! Touche Jouer pour l'ouvrir, ou APK pour l'installer." },
                    streaming = false, status = "", gamePath = f.absolutePath,
                    gameTitle = "Site : " + request.take(22).ifBlank { "ma page" }
                )
            }
        } else {
            update(botId) { it.copy(text = finalText, streaming = false, status = "") }
        }
        return "J'ai créé un site web : ${request.take(80)}."
    }

    private suspend fun doVideo(botId: Long, text: String): String {
        val request = VideoGen.request(text)
        if (videoKey.isBlank()) {
            update(botId) {
                it.copy(
                    text = "Pour créer des vidéos, il me faut une clé API Pollinations : le calcul se fait sur leurs serveurs, " +
                        "aucun téléphone ne peut produire de vidéo réaliste seul. " +
                        "Crée ta clé sur https://enter.pollinations.ai/keys (les vidéos consomment des crédits), " +
                        "puis colle-la dans menu ☰ → Modèle et réglages → Vidéo.",
                    streaming = false, status = ""
                )
            }
            return ""
        }
        if (request.isBlank()) {
            update(botId) {
                it.copy(text = "Décris la vidéo : par exemple « /video un renard dans la neige au lever du soleil ».", streaming = false, status = "")
            }
            return ""
        }
        var prompt = request
        if (modelState is ModelState.Ready) {
            val better = runCatching {
                PromptBuilder.cleanImagePrompt(engine.generate(PromptBuilder.videoPrompt(template, request), 0.6f) {})
            }.getOrNull()
            if (!better.isNullOrBlank() && better.length > 5) prompt = better
        }
        prompt += ", ultra realistic, cinematic lighting, natural motion, 4K"
        update(botId) { it.copy(status = "Je génère la vidéo… (1 à 3 minutes)") }
        val file = files.newVideoFile()
        return try {
            withContext(Dispatchers.IO) { VideoGen.fetch(videoKey, videoModel, prompt, file) }
            update(botId) {
                it.copy(
                    text = "Ta vidéo est prête !", streaming = false, status = "",
                    videoPath = file.absolutePath, imagePrompt = prompt
                )
            }
            "J'ai généré une vidéo (prompt : $prompt)."
        } catch (e: CancellationException) {
            file.delete()
            throw e
        } catch (e: Exception) {
            file.delete()
            update(botId) {
                it.copy(
                    text = "Je n'ai pas réussi à créer la vidéo : ${e.message ?: "erreur réseau"}.",
                    streaming = false, status = ""
                )
            }
            ""
        }
    }

    private suspend fun doImage(botId: Long, text: String): String {
        val request = text.removePrefix("/image").trim()
        var prompt = request
        if (modelState is ModelState.Ready) {
            val better = runCatching {
                PromptBuilder.cleanImagePrompt(
                    engine.generate(PromptBuilder.imagePrompt(template, request), 0.6f) {}
                )
            }.getOrNull()
            if (!better.isNullOrBlank() && better.length > 5) prompt = better
        }
        update(botId) { it.copy(status = "Je dessine…") }
        return try {
            val bytes = withContext(Dispatchers.IO) { ImageGen.fetch(imageUrl, prompt, videoKey) }
            val file = files.saveImage(bytes)
            update(botId) {
                it.copy(
                    text = imageReplies.random(), streaming = false, status = "",
                    imagePath = file.absolutePath, imagePrompt = prompt
                )
            }
            "J'ai généré une image (prompt : $prompt)."
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            update(botId) {
                it.copy(
                    text = "Je n'ai pas réussi à dessiner ça (${e.message ?: "erreur réseau"}). " +
                        "Vérifie ta connexion et réessaie dans un instant.",
                    streaming = false, status = ""
                )
            }
            ""
        }
    }

    /**
     * Les 3 premières questions et le dernier échange sont repris tels quels par Memory.build.
     * Le résumé ne contient donc que les échanges du milieu, ajoutés un par un.
     */
    private fun rollSummary(my: Int) {
        val turns = Memory.turns(messages.filter { it.text.isNotBlank() })
        val idx = turns.size - 2
        if (idx < 3) return
        startSummary(my, turns[idx])
    }

    private fun startSummary(my: Int, t: Turn) {
        val line = "• " + t.q.replace(Regex("\\s+"), " ").take(120) + " → " + t.a.replace(Regex("\\s+"), " ").take(200)
        val merged = (summary + "\n" + line).trim()
        if (merged.length <= 800) {
            summary = merged
            persist()
            return
        }
        val tpl = template
        val previous = summary
        summaryJob = viewModelScope.launch {
            runCatching {
                val s = engine.generate(PromptBuilder.summary(tpl, previous, t), 0.3f) {}
                if (my == gen) {
                    summary = PromptBuilder.clean(s).take(700)
                    persist()
                }
            }
        }
    }

    override fun onCleared() {
        persist()
        engine.close()
        super.onCleared()
    }

    companion object {
        const val AUTO = "@auto"
    }
}
