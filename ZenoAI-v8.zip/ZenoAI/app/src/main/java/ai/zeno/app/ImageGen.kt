package ai.zeno.app

import android.graphics.BitmapFactory
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.random.Random

/** Génération d'images via un service en ligne (Pollinations par défaut, sans clé). */
object ImageGen {

    private val verbRx = Regex(
        "\\b(génère|génere|générer|generer|genere|crée|cree|créer|creer|dessine|dessiner|fais|fais-moi|imagine|montre|make|generate|create|draw|paint)\\b",
        RegexOption.IGNORE_CASE
    )
    private val nounRx = Regex(
        "\\b(image|images|photo|photos|illustration|dessin|logo|affiche|wallpaper|fond d'écran|picture|drawing|painting|portrait|avatar)\\b",
        RegexOption.IGNORE_CASE
    )

    fun isRequest(text: String): Boolean {
        val t = text.trim()
        if (t.startsWith("/image", ignoreCase = true)) return true
        if (t.length > 300 || t.contains("```")) return false
        return verbRx.containsMatchIn(t) && nounRx.containsMatchIn(t)
    }

    private const val GEN = "https://gen.pollinations.ai/image/{prompt}?model=flux&width=768&height=768&seed={seed}&nologo=true"
    private const val GEN_TURBO = "https://gen.pollinations.ai/image/{prompt}?model=turbo&width=768&height=768&seed={seed}&nologo=true"
    private const val LEGACY = "https://image.pollinations.ai/prompt/{prompt}?model=flux&width=768&height=768&seed={seed}&nologo=true"

    /** Essaie plusieurs adresses : la tienne, la nouvelle API Pollinations (avec ta clé si tu en as une), puis l'ancienne. */
    fun fetch(template: String, prompt: String, key: String = ""): ByteArray {
        val k = key.trim()
        val withKey = { t: String -> if (k.isBlank()) t else t + (if (t.contains("?")) "&" else "?") + "key=" + URLEncoder.encode(k, "UTF-8") }
        val variants = listOf(
            withKey(template), withKey(GEN), withKey(GEN_TURBO), template, LEGACY
        ).distinct()
        var last: Exception = IllegalStateException("Service d'images indisponible")
        var denied = false
        for (t in variants) {
            try {
                return download(build(t, prompt), k)
            } catch (e: SecurityException) {
                denied = true
                last = e
            } catch (e: Exception) {
                last = e
            }
        }
        if (denied) {
            throw IllegalStateException(
                if (k.isBlank()) "le service d'images demande une clé gratuite : crée-la sur https://enter.pollinations.ai/keys puis colle-la dans Réglages → Vidéo (la même clé sert aux images)"
                else "ta clé du service d'images est refusée ou sans crédit : vérifie-la dans Réglages → Vidéo"
            )
        }
        throw last
    }

    private fun build(template: String, prompt: String): String {
        val enc = URLEncoder.encode(prompt, "UTF-8").replace("+", "%20")
        return template
            .replace("{prompt}", enc)
            .replace("{seed}", Random.nextInt(1, 999_999).toString())
    }

    private fun download(url: String, key: String): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 120_000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "ZenoAI/1.0")
        if (key.isNotBlank() && url.contains("gen.pollinations.ai")) c.setRequestProperty("Authorization", "Bearer $key")
        try {
            c.connect()
            if (c.responseCode in listOf(401, 402, 403)) throw SecurityException("accès refusé (HTTP ${c.responseCode})")
            if (c.responseCode !in 200..299) error("le service d'images a répondu HTTP ${c.responseCode}")
            val bytes = c.inputStream.use { it.readBytes() }
            if (bytes.size > 15_000_000) error("image trop lourde")
            val ok = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) != null
            if (!ok) error("réponse du service d'images invalide")
            return bytes
        } finally {
            c.disconnect()
        }
    }
}
