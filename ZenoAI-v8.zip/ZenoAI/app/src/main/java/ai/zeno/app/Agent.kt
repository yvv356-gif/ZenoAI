package ai.zeno.app

import org.json.JSONObject

data class AgentAction(val name: String, val input: String)

/** Mode agent : l'IA choisit un outil à chaque étape (recherche, code, calcul, jeu, site, image, vidéo, page web) puis répond. */
object Agent {

    private val tlds = "com|fr|org|net|io|ai|co|uk|de|be|ch|eu|app|dev|tv|info|shop|gouv|edu|gov|ca|jp|it|es"
    private val spacedRx = Regex("([a-z0-9-]+)\\.\\s+($tlds)\\b", RegexOption.IGNORE_CASE)
    private val urlRx = Regex(
        "https?://[^\\s]+|(?<![\\w@.-])(?:[a-z0-9-]+\\.)+(?:$tlds)(?:/[^\\s]*)?",
        RegexOption.IGNORE_CASE
    )

    /** Adresse web citée dans un texte (« jbl. com », « jbl.com », « https://… »), renvoyée en https. */
    fun findUrl(text: String): String? {
        val t = text.replace(spacedRx, "$1.$2")
        val raw = urlRx.find(t)?.value?.trimEnd('.', ',', ';', ')', '!', '?', '"', '»') ?: return null
        return if (raw.startsWith("http", ignoreCase = true)) raw else "https://$raw"
    }

    private fun norm(a: String): String = when (a.trim().lowercase()) {
        "search", "recherche", "web", "chercher", "rechercher" -> "search"
        "code", "github", "reddit" -> "code"
        "calc", "calcul", "calculer", "calculatrice" -> "calc"
        "game", "jeu" -> "game"
        "site", "siteweb", "page" -> "site"
        "image", "dessin" -> "image"
        "video", "vidéo" -> "video"
        "open", "ouvrir", "ouvre", "navigateur", "navigate", "browse", "url", "page_web" -> "open"
        else -> "answer"
    }

    fun parse(raw: String, question: String, firstStep: Boolean): AgentAction {
        // Une adresse citée dans la question : on ouvre le site tout de suite, sans attendre le modèle.
        if (firstStep) findUrl(question)?.let { return AgentAction("open", it) }
        val parsed = runCatching {
            val m = Regex("\\{[\\s\\S]*?\\}").find(raw)?.value ?: error("pas de JSON")
            val o = JSONObject(m)
            val a = norm(o.optString("action", o.optString("outil", "answer")))
            val inp = o.optString("input", o.optString("entrée", o.optString("entree", ""))).trim()
            AgentAction(a, inp.ifBlank { if (a == "answer") "" else question }.take(160))
        }.getOrNull()
        if (parsed != null) return parsed
        if (firstStep) {
            when (WebSearch.modeFor(question, 2)) {
                WebSearch.Mode.CODE -> return AgentAction("code", question.take(160))
                WebSearch.Mode.FACTS -> return AgentAction("search", question.take(160))
                else -> {}
            }
        }
        return AgentAction("answer", "")
    }
}
