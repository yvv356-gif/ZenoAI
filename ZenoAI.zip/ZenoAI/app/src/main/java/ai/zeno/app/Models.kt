package ai.zeno.app

enum class Role { USER, AI }

data class ChatMessage(
    val id: Long,
    val role: Role,
    val text: String,
    val streaming: Boolean = false,
    val status: String = ""
)

sealed interface ModelState {
    data object None : ModelState
    data class Busy(val label: String, val progress: Float? = null) : ModelState
    data object Ready : ModelState
    data class Error(val message: String) : ModelState
}
