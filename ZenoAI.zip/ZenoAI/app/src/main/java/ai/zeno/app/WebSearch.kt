package ai.zeno.app

import android.net.Uri
import org.jsoup.Jsoup
import org.json.JSONObject
import java.net.URLEncoder
import java.util.Locale

/** Accès internet : recherche DuckDuckGo (repli Wikipédia). Le modèle reste local, seule la requête sort. */
object WebSearch {

    private val keywords = listOf(
        "aujourd'hui", "actualité", "actu ", "météo", "meteo", "dernier", "dernière", "récent", "prix",
        "cours de", "score", "résultat", "horaire", "ouvert", "news", "latest", "today", "weather",
        "current", "price", "2025", "2026", "qui est le", "combien coûte", "recherche"
    )

    fun needsWeb(q: String): Boolean {
        val l = q.lowercase()
        return l.startsWith("/web") || keywords.any { l.contains(it) }
    }

    fun search(rawQuery: String, max: Int = 3): String {
        val q = rawQuery.removePrefix("/web").trim().take(200)
        val ddg = runCatching { duckDuckGo(q, max) }.getOrDefault("")
        if (ddg.isNotBlank()) return ddg
        return runCatching { wikipedia(q, max) }.getOrDefault("")
    }

    private fun duckDuckGo(q: String, max: Int): String {
        val doc = Jsoup.connect("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8"))
            .userAgent("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36")
            .timeout(8000)
            .get()
        val lines = mutableListOf<String>()
        for (r in doc.select("div.result")) {
            val title = r.selectFirst("a.result__a")?.text().orEmpty()
            val snippet = r.selectFirst(".result__snippet")?.text().orEmpty()
            val href = r.selectFirst("a.result__a")?.attr("href").orEmpty()
            val real = Uri.parse(href).getQueryParameter("uddg") ?: href
            val host = runCatching { Uri.parse(real).host }.getOrNull().orEmpty()
            if (title.isNotBlank() && snippet.isNotBlank()) {
                lines += "- $title : ${snippet.take(220)} ($host)"
            }
            if (lines.size >= max) break
        }
        return lines.joinToString("\n")
    }

    private fun wikipedia(q: String, max: Int): String {
        val lang = Locale.getDefault().language.ifBlank { "fr" }
        val url = "https://$lang.wikipedia.org/w/api.php?action=query&list=search&format=json&srlimit=$max&srsearch=" +
            URLEncoder.encode(q, "UTF-8")
        val body = Jsoup.connect(url).ignoreContentType(true).timeout(8000).execute().body()
        val arr = JSONObject(body).getJSONObject("query").getJSONArray("search")
        val lines = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            lines += "- ${o.getString("title")} : ${Jsoup.parse(o.getString("snippet")).text().take(220)} ($lang.wikipedia.org)"
        }
        return lines.joinToString("\n")
    }
}
