package ai.zeno.app

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("zeno", Context.MODE_PRIVATE)

    var modelUrl: String
        get() = sp.getString("url", DEFAULT_URL) ?: DEFAULT_URL
        set(v) { sp.edit().putString("url", v).apply() }

    /** "chatml" (Qwen, Phi...) ou "gemma" */
    var template: String
        get() = sp.getString("template", "chatml") ?: "chatml"
        set(v) { sp.edit().putString("template", v).apply() }

    /** Taille de contexte (prompt + réponse). Doit correspondre au modèle (ekv1280 = 1280). */
    var maxTokens: Int
        get() = sp.getInt("maxTokens", 1280)
        set(v) { sp.edit().putInt("maxTokens", v).apply() }

    var web: Boolean
        get() = sp.getBoolean("web", true)
        set(v) { sp.edit().putBoolean("web", v).apply() }

    companion object {
        const val DEFAULT_URL =
            "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task"
    }
}
