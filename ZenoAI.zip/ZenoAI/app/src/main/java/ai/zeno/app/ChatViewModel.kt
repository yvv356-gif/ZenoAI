package ai.zeno.app

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = Prefs(app)
    private val engine = LlmEngine(app)
    private val files = ModelManager(app)

    private var nextId = 1L
    private var summary = ""
    private var genJob: Job? = null
    private var summaryJob: Job? = null
    private var dlJob: Job? = null

    var messages by mutableStateOf(listOf(greeting()))
        private set
    var busy by mutableStateOf(false)
        private set
    var modelState by mutableStateOf<ModelState>(ModelState.None)
        private set

    var webEnabled by mutableStateOf(prefs.web)
    var template by mutableStateOf(prefs.template)
    var maxTokens by mutableStateOf(prefs.maxTokens)
    var modelUrl by mutableStateOf(prefs.modelUrl)

    val suggestions = listOf(
        "Écris une fonction Python qui trie une liste de dictionnaires",
        "Une idée de repas rapide pour ce soir ?",
        "Traduis « bon appétit » dans 5 langues"
    )

    init {
        if (files.exists()) loadModel()
    }

    private fun greeting() = ChatMessage(
        id = 0, role = Role.AI,
        text = "Bonjour ! Je suis ZenoAI, votre assistant IA local. Code, questions du quotidien, idées, traductions : posez-moi ce que vous voulez."
    )

    // ---------- Modèle ----------

    fun loadModel() {
        if (!files.exists()) { modelState = ModelState.None; return }
        modelState = ModelState.Busy("Chargement du modèle…")
        viewModelScope.launch {
            modelState = try {
                engine.load(files.path(), maxTokens)
                ModelState.Ready
            } catch (e: Throwable) {
                ModelState.Error("Chargement impossible : ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun download() {
        if (dlJob?.isActive == true) return
        modelState = ModelState.Busy("Téléchargement…", 0f)
        dlJob = viewModelScope.launch {
            try {
                files.download(modelUrl) { p -> modelState = ModelState.Busy("Téléchargement…", p) }
                loadModel()
            } catch (e: CancellationException) {
                modelState = if (files.exists()) ModelState.Ready else ModelState.None
                throw e
            } catch (e: Exception) {
                modelState = ModelState.Error("Téléchargement : ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun cancelDownload() { dlJob?.cancel() }

    fun importModel(uri: Uri) {
        modelState = ModelState.Busy("Copie du modèle…")
        viewModelScope.launch {
            try {
                files.import(uri)
                loadModel()
            } catch (e: Exception) {
                modelState = ModelState.Error("Import : ${e.message ?: e.javaClass.simpleName}")
            }
        }
    }

    fun applySettings(url: String, tpl: String, tokens: Int, web: Boolean) {
        val reload = tokens != maxTokens
        modelUrl = url.trim().ifBlank { Prefs.DEFAULT_URL }
        template = tpl
        maxTokens = tokens
        webEnabled = web
        prefs.modelUrl = modelUrl
        prefs.template = tpl
        prefs.maxTokens = tokens
        prefs.web = web
        if (reload && files.exists() && modelState is ModelState.Ready) loadModel()
    }

    fun setWeb(on: Boolean) {
        webEnabled = on
        prefs.web = on
    }

    fun readText(uri: Uri): String = runCatching {
        getApplication<Application>().contentResolver.openInputStream(uri)!!.bufferedReader().use { r ->
            val buf = CharArray(20_000)
            val n = r.read(buf)
            if (n <= 0) "" else String(buf, 0, n)
        }
    }.getOrDefault("")

    // ---------- Conversation ----------

    private fun update(id: Long, f: (ChatMessage) -> ChatMessage) {
        messages = messages.map { if (it.id == id) f(it) else it }
    }

    fun newChat() {
        genJob?.cancel()
        summaryJob?.cancel()
        summary = ""
        busy = false
        messages = listOf(greeting())
    }

    fun stop() { genJob?.cancel() }

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty() || busy) return
        if (modelState !is ModelState.Ready) {
            messages = messages + ChatMessage(nextId++, Role.AI, "Installez d'abord un modèle (menu ☰ → Modèle et réglages).")
            return
        }
        val botId = nextId++
        messages = messages +
            ChatMessage(nextId++, Role.USER, text) +
            ChatMessage(botId, Role.AI, "", streaming = true, status = "Réflexion…")
        busy = true

        genJob = viewModelScope.launch {
            var answer = ""
            try {
                // 1) On attend la fin du résumé de l'échange précédent
                summaryJob?.join()

                // 2) Recherche web si nécessaire
                var web = ""
                if (webEnabled && WebSearch.needsWeb(text)) {
                    update(botId) { it.copy(status = "Recherche sur le web…") }
                    web = withContext(Dispatchers.IO) { runCatching { WebSearch.search(text) }.getOrDefault("") }
                }
                update(botId) { it.copy(status = "Réflexion…") }

                // 3) Prompt = consignes + résumé de la conversation + (web) + message
                val prompt = PromptBuilder.chat(template, summary, web, text, maxTokens)
                answer = engine.generate(prompt) { partial ->
                    update(botId) { it.copy(text = PromptBuilder.clean(partial), status = "") }
                }
                update(botId) { it.copy(text = PromptBuilder.clean(answer), streaming = false, status = "") }
            } catch (e: CancellationException) {
                update(botId) { it.copy(streaming = false, status = "") }
                throw e
            } catch (e: Throwable) {
                update(botId) {
                    it.copy(
                        text = "Erreur : ${e.message ?: e.javaClass.simpleName}\n(Message trop long pour la taille de contexte ? Essayez un message plus court ou « Nouvelle conversation ».)",
                        streaming = false, status = ""
                    )
                }
            } finally {
                busy = false
            }

            // 4) Résumé mis à jour en arrière-plan pour le prochain message
            val clean = PromptBuilder.clean(answer)
            if (clean.isNotBlank()) {
                val tpl = template
                val previous = summary
                summaryJob = viewModelScope.launch {
                    runCatching {
                        val s = engine.generate(PromptBuilder.summary(tpl, previous, text, clean)) {}
                        summary = PromptBuilder.clean(s).take(900)
                    }
                }
            }
        }
    }

    override fun onCleared() {
        engine.close()
        super.onCleared()
    }
}
