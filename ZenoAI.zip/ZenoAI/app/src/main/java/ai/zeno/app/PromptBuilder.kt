package ai.zeno.app

import java.time.LocalDate

object PromptBuilder {

    private const val SYSTEM =
        "Tu es ZenoAI, un assistant IA qui tourne en local sur le téléphone de l'utilisateur. " +
        "Réponds toujours dans la langue du dernier message de l'utilisateur (tu maîtrises presque toutes les langues). " +
        "Va droit au but : pas de salutation, pas de reformulation de la question, pas de phrases de remplissage. " +
        "Réponses courtes et précises, plus détaillées seulement si on te le demande. " +
        "En programmation tu es un expert : donne du code complet, correct et prêt à l'emploi dans des blocs ```langage, " +
        "suivi d'une explication de 1 à 3 lignes maximum. " +
        "Pour la vie quotidienne (cuisine, santé, voyage, budget, démarches...) donne des conseils concrets et pratiques. " +
        "Si un résumé de la conversation est fourni, tiens-en compte. " +
        "Si des résultats web sont fournis, appuie-toi dessus et cite le site entre parenthèses. " +
        "Si tu ne sais pas, dis-le simplement sans inventer."

    private const val SUMMARY_SYSTEM =
        "Tu résumes des conversations. Écris uniquement le résumé, sans introduction."

    fun wrap(template: String, system: String, user: String): String = when (template) {
        "gemma" -> "<start_of_turn>user\n$system\n\n$user<end_of_turn>\n<start_of_turn>model\n"
        else -> "<|im_start|>system\n$system<|im_end|>\n<|im_start|>user\n$user<|im_end|>\n<|im_start|>assistant\n"
    }

    fun chat(template: String, summary: String, web: String, user: String, maxChars: Int): String {
        val sb = StringBuilder()
        sb.append("Date du jour : ").append(LocalDate.now()).append("\n\n")
        if (summary.isNotBlank()) sb.append("[Résumé de la conversation jusqu'ici]\n").append(summary).append("\n\n")
        if (web.isNotBlank()) sb.append("[Résultats web]\n").append(web).append("\n\n")
        sb.append("[Message de l'utilisateur]\n").append(user.take(maxChars))
        return wrap(template, SYSTEM, sb.toString())
    }

    fun summary(template: String, previous: String, user: String, ai: String): String {
        val sb = StringBuilder()
        sb.append("Mets à jour le résumé de cette conversation en 100 mots maximum, dans la langue de la conversation. ")
        sb.append("Garde : le sujet, les faits, les décisions, les préférences de l'utilisateur et les points clés du code.\n\n")
        sb.append("[Résumé précédent]\n").append(if (previous.isBlank()) "(aucun)" else previous).append("\n\n")
        sb.append("[Dernier échange]\nUtilisateur : ").append(user.take(600)).append("\n")
        sb.append("Assistant : ").append(ai.take(1100))
        return wrap(template, SUMMARY_SYSTEM, sb.toString())
    }

    fun clean(s: String): String = s
        .replace("<|im_end|>", "")
        .replace("<|endoftext|>", "")
        .replace("<end_of_turn>", "")
        .trim()
}
