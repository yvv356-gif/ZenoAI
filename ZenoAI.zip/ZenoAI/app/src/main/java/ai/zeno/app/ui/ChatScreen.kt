package ai.zeno.app.ui

import ai.zeno.app.ChatMessage
import ai.zeno.app.ChatViewModel
import ai.zeno.app.ModelState
import ai.zeno.app.Role
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel) {
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val itemCount = vm.messages.size + if (vm.messages.size == 1) vm.suggestions.size else 0
    LaunchedEffect(itemCount, vm.messages.lastOrNull()?.text) {
        if (itemCount > 0) listState.scrollToItem(itemCount - 1, 100000)
    }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (t != null) input = (input + " " + t).trim()
    }
    val attachLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val txt = vm.readText(uri)
            if (txt.isNotBlank()) input = (input + "\n```\n" + txt + "\n```").trim()
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importModel(uri)
    }

    fun launchMic() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        }
        try { micLauncher.launch(i) } catch (_: Exception) { }
    }

    fun doSend() {
        if (!vm.busy && input.isNotBlank()) {
            vm.send(input)
            input = ""
        }
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = Color(0xF5FFFFFF)) {
                Text(
                    "ZENOAI", fontSize = 26.sp, fontWeight = FontWeight.Light, letterSpacing = 5.sp,
                    color = Ink, modifier = Modifier.padding(24.dp)
                )
                NavigationDrawerItem(
                    label = { Text("Nouvelle conversation") },
                    icon = { Icon(Icons.Default.Add, null) },
                    selected = false,
                    onClick = { vm.newChat(); scope.launch { drawer.close() } },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                NavigationDrawerItem(
                    label = { Text("Modèle et réglages") },
                    icon = { Icon(Icons.Default.Settings, null) },
                    selected = false,
                    onClick = { showSettings = true; scope.launch { drawer.close() } },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
            }
        }
    ) {
        Box(Modifier.fillMaxSize()) {
            AuroraBackground()
            Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
                // Barre du haut
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { scope.launch { drawer.open() } }) {
                        Icon(Icons.Default.Menu, "Menu", tint = Ink, modifier = Modifier.size(30.dp))
                    }
                    Text(
                        "ZENOAI", fontSize = 30.sp, fontWeight = FontWeight.Light,
                        letterSpacing = 6.sp, color = Ink, modifier = Modifier.padding(start = 8.dp)
                    )
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { vm.setWeb(!vm.webEnabled) }) {
                        Icon(
                            Icons.Default.Public, "Recherche web",
                            tint = if (vm.webEnabled) Teal else Color(0xFF9AA0B5),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                // Bandeau d'état du modèle
                val st = vm.modelState
                if (st !is ModelState.Ready) {
                    Glass(
                        Modifier.padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth(),
                        RoundedCornerShape(18.dp), GlassWhite, onClick = { showSettings = true }
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(
                                when (st) {
                                    ModelState.None -> "Aucun modèle installé. Touchez ici pour l'installer."
                                    is ModelState.Busy -> st.label
                                    is ModelState.Error -> st.message
                                    ModelState.Ready -> ""
                                },
                                fontSize = 14.sp, color = Ink
                            )
                            if (st is ModelState.Busy) {
                                Spacer(Modifier.height(8.dp))
                                val p = st.progress
                                if (p != null) LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
                                else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }
                }

                // Messages
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(vm.messages, key = { it.id }) { MessageRow(it) }
                    if (vm.messages.size == 1) {
                        items(vm.suggestions) { s ->
                            Glass(Modifier.fillMaxWidth(), RoundedCornerShape(40.dp), GlassWhite, onClick = { vm.send(s) }) {
                                Text(
                                    s, color = Teal, fontSize = 17.sp, textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp)
                                )
                            }
                        }
                    }
                }

                // Barre de saisie
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Glass(Modifier.weight(1f), RoundedCornerShape(30.dp), GlassWhite) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextField(
                                value = input,
                                onValueChange = { input = it },
                                placeholder = { Text("Écrivez votre message…", color = Color(0xFF7D8298)) },
                                modifier = Modifier.weight(1f),
                                maxLines = 5,
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent,
                                    focusedTextColor = Ink,
                                    unfocusedTextColor = Ink
                                )
                            )
                            IconButton(onClick = { launchMic() }) {
                                Icon(Icons.Default.Mic, "Micro", tint = Color(0xFF4A4F66))
                            }
                            IconButton(onClick = { attachLauncher.launch(arrayOf("*/*")) }) {
                                Icon(Icons.Default.AttachFile, "Joindre un fichier texte", tint = Color(0xFF4A4F66))
                            }
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Box(
                        Modifier.size(54.dp).clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Teal, Violet)))
                            .clickable { if (vm.busy) vm.stop() else doSend() },
                        contentAlignment = Alignment.Center
                    ) {
                        if (vm.busy) Icon(Icons.Default.Stop, "Stop", tint = Color.White, modifier = Modifier.size(28.dp))
                        else Icon(Icons.AutoMirrored.Filled.Send, "Envoyer", tint = Color.White, modifier = Modifier.size(26.dp))
                    }
                }
            }
        }
    }

    if (showSettings) {
        SettingsDialog(vm, onDismiss = { showSettings = false }, onImport = { importLauncher.launch(arrayOf("*/*")) })
    }
}

// ---------- Décor ----------

@Composable
fun AuroraBackground() {
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFFE4FAFF), Color(0xFFEEEBFF), Color(0xFFE2F4FF))))
        fun blob(color: Color, cx: Float, cy: Float, r: Float) {
            drawCircle(
                brush = Brush.radialGradient(listOf(color, Color.Transparent), center = Offset(size.width * cx, size.height * cy), radius = r),
                radius = r,
                center = Offset(size.width * cx, size.height * cy)
            )
        }
        blob(Color(0xAA7EE8F5), 0.05f, 0.10f, size.width * 0.9f)
        blob(Color(0x99A98BF5), 0.95f, 0.38f, size.width * 0.8f)
        blob(Color(0x8890C8FF), 0.10f, 0.62f, size.width * 0.8f)
        blob(Color(0x99B8A0F8), 0.85f, 0.92f, size.width * 0.9f)
    }
}

@Composable
fun Glass(
    modifier: Modifier = Modifier,
    shape: RoundedCornerShape = RoundedCornerShape(24.dp),
    tint: Color = GlassWhite,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier
            .shadow(6.dp, shape, ambientColor = Color(0x33557799), spotColor = Color(0x33557799))
            .clip(shape)
            .background(tint)
            .border(1.dp, Color.White.copy(alpha = 0.7f), shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        content = content
    )
}

@Composable
fun Avatar() {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Violet, Teal))),
        contentAlignment = Alignment.Center
    ) { Text("Z", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
}

// ---------- Messages ----------

@Composable
fun MessageRow(m: ChatMessage) {
    val isUser = m.role == Role.USER
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        if (!isUser) { Avatar(); Spacer(Modifier.width(8.dp)) }
        Glass(
            Modifier.widthIn(max = 320.dp),
            RoundedCornerShape(24.dp),
            if (isUser) GlassUser else GlassAi
        ) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(
                    if (isUser) "Vous" else "ZenoAI (IA)",
                    fontWeight = FontWeight.Medium, fontSize = 15.sp, color = Ink,
                    modifier = if (isUser) Modifier.align(Alignment.End) else Modifier
                )
                Spacer(Modifier.height(4.dp))
                if (m.text.isBlank() && m.streaming) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = Teal)
                        Spacer(Modifier.width(8.dp))
                        Text(m.status.ifBlank { "Réflexion…" }, fontStyle = FontStyle.Italic, color = Color(0xFF4A4F66), fontSize = 15.sp)
                    }
                } else {
                    MessageBody(m.text)
                }
            }
        }
    }
}

private sealed interface Seg {
    data class Txt(val s: String) : Seg
    data class Code(val lang: String, val code: String) : Seg
}

private val fenceRegex = Regex("```([\\w+#.-]*)[ \\t]*\\n?([\\s\\S]*?)(?:```|\$)")

private fun parseSegments(t: String): List<Seg> {
    val out = mutableListOf<Seg>()
    var last = 0
    for (m in fenceRegex.findAll(t)) {
        if (m.range.first > last) out += Seg.Txt(t.substring(last, m.range.first))
        out += Seg.Code(m.groupValues[1], m.groupValues[2].trimEnd())
        last = m.range.last + 1
    }
    if (last < t.length) out += Seg.Txt(t.substring(last))
    return out
}

private val inlineRegex = Regex("\\*\\*(.+?)\\*\\*|`([^`]+)`")
private val headerRegex = Regex("(?m)^#{1,6}\\s*")

private fun inline(raw: String): AnnotatedString {
    val s = raw.replace(headerRegex, "")
    return buildAnnotatedString {
        var last = 0
        for (m in inlineRegex.findAll(s)) {
            append(s.substring(last, m.range.first))
            if (m.groups[1] != null) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(m.groupValues[1]) }
            } else {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = Color(0x22000000))) { append(m.groupValues[2]) }
            }
            last = m.range.last + 1
        }
        append(s.substring(last))
    }
}

@Composable
fun MessageBody(text: String) {
    SelectionContainer {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for (seg in parseSegments(text)) {
                when (seg) {
                    is Seg.Txt -> if (seg.s.isNotBlank()) {
                        Text(inline(seg.s.trim()), fontSize = 17.sp, lineHeight = 24.sp, color = Ink)
                    }
                    is Seg.Code -> CodeBlock(seg.lang, seg.code)
                }
            }
        }
    }
}

@Composable
fun CodeBlock(lang: String, code: String) {
    val clipboard = LocalClipboardManager.current
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF1E1E2E))) {
        Row(
            Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(lang.ifBlank { "code" }, color = Color(0xFF9AA0C0), fontSize = 12.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = { clipboard.setText(AnnotatedString(code)) }) {
                Icon(Icons.Default.ContentCopy, "Copier", tint = Color(0xFF9AA0C0), modifier = Modifier.size(18.dp))
            }
        }
        Text(
            code, color = Color(0xFFE6E6F0), fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 18.sp,
            modifier = Modifier.horizontalScroll(rememberScrollState()).padding(start = 12.dp, end = 12.dp, bottom = 12.dp)
        )
    }
}

// ---------- Réglages ----------

@Composable
fun SettingsDialog(vm: ChatViewModel, onDismiss: () -> Unit, onImport: () -> Unit) {
    var url by remember { mutableStateOf(vm.modelUrl) }
    var tpl by remember { mutableStateOf(vm.template) }
    var tokens by remember { mutableIntStateOf(vm.maxTokens) }
    var web by remember { mutableStateOf(vm.webEnabled) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Modèle et réglages") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val st = vm.modelState
                Text(
                    when (st) {
                        ModelState.None -> "Aucun modèle installé."
                        is ModelState.Busy -> st.label
                        is ModelState.Error -> st.message
                        ModelState.Ready -> "Modèle prêt (100 % local)."
                    },
                    fontWeight = FontWeight.Medium
                )
                if (st is ModelState.Busy) {
                    val p = st.progress
                    if (p != null) LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                OutlinedTextField(
                    value = url, onValueChange = { url = it },
                    label = { Text("URL du modèle (.task)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        vm.applySettings(url, tpl, tokens, web)
                        vm.download()
                    }) { Text("Télécharger") }
                    OutlinedButton(onClick = onImport) { Text("Importer") }
                }
                Text("Format de prompt", fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = tpl == "chatml", onClick = { tpl = "chatml" }, label = { Text("ChatML (Qwen)") })
                    FilterChip(selected = tpl == "gemma", onClick = { tpl = "gemma" }, label = { Text("Gemma") })
                }
                Text("Contexte (doit correspondre au modèle : ekv1280, ekv4096…)", fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1280, 2048, 4096).forEach { n ->
                        FilterChip(selected = tokens == n, onClick = { tokens = n }, label = { Text("$n") })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Recherche web automatique", modifier = Modifier.weight(1f))
                    Switch(checked = web, onCheckedChange = { web = it })
                }
                Text(
                    "Le modèle tourne sur votre téléphone. Seules les recherches web (si activées) utilisent internet.",
                    fontSize = 12.sp, color = Color(0xFF5A6078)
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { vm.applySettings(url, tpl, tokens, web); onDismiss() }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}
