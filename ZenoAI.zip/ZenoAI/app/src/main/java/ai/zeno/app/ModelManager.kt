package ai.zeno.app

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class ModelManager(private val context: Context) {

    private val dir get() = File(context.filesDir, "model").apply { mkdirs() }
    private val modelFile get() = File(dir, "model.task")

    fun exists() = modelFile.exists() && modelFile.length() > 1_000_000
    fun path(): String = modelFile.absolutePath

    suspend fun download(url: String, onProgress: (Float?) -> Unit) = withContext(Dispatchers.IO) {
        val tmp = File(dir, "model.part")
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 20_000
        conn.readTimeout = 30_000
        conn.instanceFollowRedirects = true
        conn.setRequestProperty("User-Agent", "ZenoAI/1.0")
        try {
            conn.connect()
            if (conn.responseCode !in 200..299) error("HTTP ${conn.responseCode} (le modèle est peut-être protégé ou l'URL incorrecte)")
            val total = conn.contentLengthLong
            var done = 0L
            var lastPct = -1
            conn.inputStream.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(256 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val pct = (done * 100 / total).toInt()
                            if (pct != lastPct) { lastPct = pct; onProgress(done.toFloat() / total) }
                        }
                    }
                }
            }
        } catch (e: Exception) {
            tmp.delete()
            throw e
        } finally {
            conn.disconnect()
        }
        modelFile.delete()
        if (!tmp.renameTo(modelFile)) error("Impossible d'enregistrer le modèle")
    }

    suspend fun import(uri: Uri) = withContext(Dispatchers.IO) {
        val tmp = File(dir, "model.part")
        context.contentResolver.openInputStream(uri)!!.use { input ->
            tmp.outputStream().use { out -> input.copyTo(out, 256 * 1024) }
        }
        modelFile.delete()
        if (!tmp.renameTo(modelFile)) error("Impossible d'enregistrer le modèle")
    }

    fun delete() { modelFile.delete() }
}
