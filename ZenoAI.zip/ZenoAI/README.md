# ZenoAI

Assistant IA mobile **100 % local** (Android) avec accès internet pour la recherche web.

- Moteur : MediaPipe LLM Inference (modèles `.task`, par défaut Qwen2.5-1.5B-Instruct — multilingue + code)
- Interface : style « aurore » à bulles vitrées, inspirée d'AURA
- À chaque message, l'IA relit un **résumé** de la conversation (mis à jour après chaque réponse)
- Réponses directes, code complet en blocs copiables, questions du quotidien
- Recherche web (DuckDuckGo, repli Wikipédia) déclenchée automatiquement ou avec `/web ma question`

## Compiler
Poussez ce dossier sur GitHub : le workflow `.github/workflows/build.yml` produit l'APK
(onglet **Actions → Build ZenoAI APK → Artifacts**). Un tag `v1.0` crée aussi une release.

En local : `gradle assembleDebug` (Gradle 8.9, JDK 17, Android SDK 35).

## Premier lancement
Menu ☰ → *Modèle et réglages* → **Télécharger** (≈ 1,6 Go) ou **Importer** un fichier `.task`.
Contexte : 1280 pour les fichiers `ekv1280`, 4096 pour `ekv4096`. Format de prompt : ChatML (Qwen) ou Gemma.
