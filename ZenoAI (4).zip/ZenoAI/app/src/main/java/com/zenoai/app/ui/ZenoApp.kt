package com.zenoai.app.ui

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.WebView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import com.zenoai.app.*
import com.zenoai.app.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val Violet = Color(0xFF7B6FE8)
val SheetBg = Color(0xFFEBE6F2)
val Ink = Color(0xFF1B1B2F)
val BgBrush = Brush.linearGradient(listOf(Color(0xFFB8EEF7), Color(0xFFD0DAF8), Color(0xFFD9CFF5)))

enum class Screen { CHAT, AGENT, HISTORY, CUSTOM }

fun loadBmp(path: String, sample: Int): ImageBitmap? = runCatching {
    BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })?.asImageBitmap()
}.getOrNull()

@Composable
fun ZenoApp(vm: ChatVM) {
    var screen by remember { mutableStateOf(Screen.CHAT) }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) { if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS) }
    val p = vm.prefs
    MaterialTheme(colorScheme = lightColorScheme(primary = Violet)) {
        Box(Modifier.fillMaxSize().background(BgBrush)) {
            p.bgPath?.let { bg ->
                val bmp = remember(bg) { loadBmp(bg, 4) }
                if (bmp != null) {
                    Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    Box(Modifier.fillMaxSize().background(Color.White.copy(alpha = .38f)))
                }
            }
            ModalNavigationDrawer(drawerState = drawer, gesturesEnabled = screen == Screen.CHAT, drawerContent = {
                ModalDrawerSheet {
                    Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(p.userAvatar, p.userName.ifBlank { "Moi" }, 44.dp); Spacer(Modifier.width(12.dp))
                        Text(p.userName.ifBlank { "Utilisateur" }, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                    }
                    HorizontalDivider()
                    fun go(s: Screen, f: () -> Unit = {}) { f(); screen = s; scope.launch { drawer.close() } }
                    NavigationDrawerItem(label = { Text("Nouvelle discussion") }, selected = false, icon = { Icon(Icons.Default.Add, null) },
                        onClick = { go(Screen.CHAT) { vm.newChat() } })
                    NavigationDrawerItem(label = { Text("Historique des discussions") }, selected = false, icon = { Icon(Icons.Default.History, null) },
                        onClick = { go(Screen.HISTORY) { vm.refreshHistory() } })
                    NavigationDrawerItem(label = { Text("Personnalisation") }, selected = false, icon = { Icon(Icons.Default.Tune, null) },
                        onClick = { go(Screen.CUSTOM) })
                }
            }) {
                Box(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
                    when (screen) {
                        Screen.CHAT -> ChatScreen(vm, { scope.launch { drawer.open() } }, { screen = Screen.AGENT })
                        Screen.AGENT -> AgentScreen(vm) { screen = Screen.CHAT }
                        Screen.HISTORY -> HistoryScreen(vm, { screen = Screen.CHAT }) { vm.openChat(it); screen = Screen.CHAT }
                        Screen.CUSTOM -> CustomScreen(vm) { screen = Screen.CHAT }
                    }
                }
            }
        }
    }
}

@Composable
fun Avatar(path: String?, letter: String, size: Dp = 30.dp) {
    val bmp = remember(path) { path?.let { loadBmp(it, 4) } }
    if (bmp != null) Image(bmp, null, Modifier.size(size).clip(CircleShape), contentScale = ContentScale.Crop)
    else Box(Modifier.size(size).clip(CircleShape).background(Violet), contentAlignment = Alignment.Center) {
        Text(letter.take(1).uppercase(), color = Color.White, fontSize = (size.value * 0.45f).sp)
    }
}

@Composable
fun ChatScreen(vm: ChatVM, openMenu: () -> Unit, openAgent: () -> Unit) {
    val ctx = LocalContext.current
    val p = vm.prefs
    var showSheet by remember { mutableStateOf(false) }
    var effortMenu by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    val fileL = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let(vm::attachFile) }

    // ----- micro : reconnaissance vocale (hors ligne si le pack de langue est installé) -----
    var listening by remember { mutableStateOf(false) }
    val recognizer = remember { if (SpeechRecognizer.isRecognitionAvailable(ctx)) SpeechRecognizer.createSpeechRecognizer(ctx) else null }
    DisposableEffect(Unit) { onDispose { recognizer?.destroy() } }
    fun listen() {
        val r = recognizer ?: run { vm.status = "Reconnaissance vocale indisponible sur ce téléphone."; return }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(b: Bundle?) { listening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false }
            override fun onError(e: Int) { listening = false }
            override fun onEvent(t: Int, b: Bundle?) {}
            override fun onPartialResults(b: Bundle?) { b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { input = it } }
            override fun onResults(b: Bundle?) { listening = false; b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { input = it } }
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        })
    }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) listen() }
    fun onMic() {
        if (listening) { recognizer?.stopListening(); listening = false }
        else if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) listen()
        else micPerm.launch(Manifest.permission.RECORD_AUDIO)
    }

    val showThinking = vm.busy && (vm.messages.lastOrNull()?.let { it.role == "user" || it.text.isBlank() } ?: true)
    LaunchedEffect(vm.messages.size, vm.messages.lastOrNull()?.text, showThinking) { list.scrollToItem((vm.messages.size).coerceAtLeast(0)) }

    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(openMenu) { Icon(Icons.Default.Menu, "Menu", Modifier.size(26.dp), tint = Ink) }
            Text(p.aiName.uppercase(), fontSize = 22.sp, fontWeight = FontWeight.Light, letterSpacing = 6.sp, color = Ink, maxLines = 1, modifier = Modifier.weight(1f))
            Box {
                Column(Modifier.clip(RoundedCornerShape(12.dp)).clickable { effortMenu = true }.padding(horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Psychology, "Effort", tint = Color(0xFF5FA2B8), modifier = Modifier.size(26.dp)); Text(vm.effortLabel(), fontSize = 10.sp, color = Ink)
                }
                DropdownMenu(effortMenu, { effortMenu = false }) {
                    listOf("Bas", "Moyen", "Élevé").forEachIndexed { i, l -> DropdownMenuItem(text = { Text(l) }, onClick = { vm.effort = i; effortMenu = false },
                        trailingIcon = { if (vm.effort == i) Icon(Icons.Default.Check, null) }) }
                }
            }
            IconButton({ vm.webOn = !vm.webOn }) { Icon(Icons.Default.Public, "Web", tint = if (vm.webOn) Color(0xFF4F9BB5) else Color.Gray, modifier = Modifier.size(28.dp)) }
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(Modifier.weight(1f).clickable { showSheet = true }) {
                Icon(Icons.Default.Memory, null, tint = Color(0xFF5FA2B8), modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp))
                Text(vm.chipLabel(), fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f), color = Ink)
                Icon(Icons.Default.ArrowDropDown, null)
            }
            Pill(Modifier.clickable { openAgent() }) { Icon(Icons.Default.SmartToy, null, tint = Color.Gray, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(6.dp)); Text("Agent", fontSize = 13.sp, color = Ink) }
        }
        if (vm.status.isNotBlank()) Text(vm.status, Modifier.padding(top = 4.dp), fontSize = 11.sp, color = Color(0xFF55557A))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, contentPadding = PaddingValues(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.messages, key = { it.id }) { Bubble(it, vm) }
            if (showThinking) item(key = "thinking") { Thinking(vm) }
        }
        vm.pendingName?.let { n ->
            Row(Modifier.padding(bottom = 6.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = .7f)).padding(start = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AttachFile, null, Modifier.size(16.dp)); Spacer(Modifier.width(6.dp)); Text(n, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 220.dp))
                IconButton({ vm.clearAttachment() }, Modifier.size(32.dp)) { Icon(Icons.Default.Close, null, Modifier.size(16.dp)) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f).clip(RoundedCornerShape(28.dp)).background(Color.White.copy(alpha = .6f)).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    if (input.isEmpty()) Text("Écris ton message…", color = Color(0xFF6B6B88), fontSize = 15.sp)
                    BasicTextField(input, { input = it }, textStyle = TextStyle(fontSize = 15.sp, color = Ink), maxLines = 5)
                }
                Icon(Icons.Default.Mic, "Micro", tint = if (listening) Color.Red else Ink, modifier = Modifier.size(24.dp).clickable { onMic() }); Spacer(Modifier.width(14.dp))
                Icon(Icons.Default.AttachFile, "Fichier", tint = Ink, modifier = Modifier.size(24.dp).clickable { fileL.launch("*/*") })
            }
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(50.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF5FA2B8), Violet)))
                .clickable { if (vm.busy) vm.stop() else { vm.send(input); input = "" } }, contentAlignment = Alignment.Center) {
                Icon(if (vm.busy) Icons.Default.Stop else Icons.Default.Send, if (vm.busy) "Arrêter" else "Envoyer", tint = Color.White, modifier = Modifier.size(24.dp))
            }
        }
    }
    if (showSheet) ModelSheet(vm) { showSheet = false }
}

@Composable
fun Thinking(vm: ChatVM) {
    var secs by remember { mutableStateOf(0) }
    LaunchedEffect(vm.busySince) { while (vm.busySince > 0) { secs = ((System.currentTimeMillis() - vm.busySince) / 1000).toInt(); delay(250) } }
    val t = rememberInfiniteTransition(label = "dots")
    val a by t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(650), RepeatMode.Reverse), label = "a")
    Row(verticalAlignment = Alignment.CenterVertically) {
        Avatar(vm.prefs.aiAvatar, vm.prefs.aiName, 28.dp); Spacer(Modifier.width(8.dp))
        Column(Modifier.clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha = .75f)).padding(horizontal = 14.dp, vertical = 10.dp)) {
            Text(vm.prefs.aiName, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            Row(verticalAlignment = Alignment.CenterVertically) {
                listOf(a, 1.25f - a, a).forEach { Box(Modifier.padding(end = 4.dp).size(7.dp).alpha(it.coerceIn(0.2f, 1f)).clip(CircleShape).background(Violet)) }
                Spacer(Modifier.width(4.dp))
                Text(if (vm.status.isNotBlank()) vm.status else "réfléchit…", fontSize = 12.sp, color = Color(0xFF55557A))
                Text("  ${secs} s", fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Violet)
            }
        }
    }
}

@Composable
fun Pill(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) =
    Row(modifier.clip(RoundedCornerShape(24.dp)).background(Color.White.copy(alpha = .5f)).border(1.dp, Color.White, RoundedCornerShape(24.dp)).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically, content = content)

@Composable
fun Bubble(m: Msg, vm: ChatVM) {
    val me = m.role == "user"
    val p = vm.prefs
    val fs = (15 * p.fontScale).sp
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (me) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.Top) {
        if (!me) { Avatar(p.aiAvatar, p.aiName, 28.dp); Spacer(Modifier.width(8.dp)) }
        Column(Modifier.weight(1f, fill = false), horizontalAlignment = if (me) Alignment.End else Alignment.Start) {
            if (m.text.isNotBlank()) Text(m.text, fontSize = fs, lineHeight = fs * 1.35f, color = if (me) Color.White else Ink,
                modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(if (me) Violet else Color.White.copy(alpha = .75f)).padding(12.dp))
            when (val a = m.attach) {
                is Attach.Img -> {
                    val bmp = remember(a.path) { loadBmp(a.path, 1) }
                    if (bmp != null) Image(bmp, null, Modifier.padding(top = 6.dp).size(260.dp).clip(RoundedCornerShape(16.dp)))
                    SmallBtn("Télécharger l'image") { vm.saveToDownloads(a) }
                }
                is Attach.Stl -> SmallBtn("Télécharger ${a.name}") { vm.saveToDownloads(a) }
                is Attach.Game -> {
                    GamePreview(a.html)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SmallBtn("Télécharger en APK") { vm.exportApk(a.html) }
                        SmallBtn("HTML") { vm.saveToDownloads(a) }
                    }
                }
                null -> {}
            }
        }
        if (me) { Spacer(Modifier.width(8.dp)); Avatar(p.userAvatar, p.userName.ifBlank { "Moi" }, 28.dp) }
    }
}

@Composable fun SmallBtn(t: String, onClick: () -> Unit) =
    Button(onClick, Modifier.padding(top = 6.dp), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text(t, fontSize = 13.sp) }

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GamePreview(html: String) {
    AndroidView(factory = { c -> WebView(c).apply { settings.javaScriptEnabled = true; settings.domStorageEnabled = true
        loadDataWithBaseURL("https://zeno.local/", html, "text/html", "utf-8", null) } },
        modifier = Modifier.padding(top = 6.dp).fillMaxWidth().height(360.dp).clip(RoundedCornerShape(16.dp)))
}

@Composable
fun HistoryScreen(vm: ChatVM, back: () -> Unit, open: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(back) { Icon(Icons.Default.ArrowBack, null) }; Text("Historique", fontSize = 20.sp) }
        if (vm.history.isEmpty()) Text("Aucune discussion pour l'instant.", Modifier.padding(16.dp), color = Color(0xFF55557A))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.history, key = { it.id }) { c ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = .65f)).clickable { open(c.id) }.padding(start = 16.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(c.title, Modifier.weight(1f), fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    IconButton({ vm.deleteChat(c.id) }) { Icon(Icons.Default.Delete, "Supprimer", tint = Color(0xFF8A4B4B)) }
                }
            }
        }
    }
}

@Composable
fun CustomScreen(vm: ChatVM, back: () -> Unit) {
    val p = vm.prefs
    val bgL = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> vm.setImage("bg", u) } }
    val aiL = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> vm.setImage("ai", u) } }
    val meL = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let { u -> vm.setImage("me", u) } }
    val fc = OutlinedTextFieldDefaults.colors(focusedContainerColor = Color.White.copy(alpha = .6f), unfocusedContainerColor = Color.White.copy(alpha = .6f))
    Column(Modifier.fillMaxSize().padding(14.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(back) { Icon(Icons.Default.ArrowBack, null) }; Text("Personnalisation", fontSize = 20.sp) }
        OutlinedTextField(p.aiName, { p.aiName = it; p.save() }, Modifier.fillMaxWidth(), label = { Text("Nom de l'IA") }, singleLine = true, colors = fc)
        OutlinedTextField(p.userName, { p.userName = it; p.save() }, Modifier.fillMaxWidth(), label = { Text("Ton nom") }, singleLine = true, colors = fc)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Avatar(p.aiAvatar, p.aiName, 44.dp)
            Button({ aiL.launch("image/*") }, colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("Photo de l'IA", fontSize = 13.sp) }
            TextButton({ vm.setImage("ai", null) }) { Text("Retirer") }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Avatar(p.userAvatar, p.userName.ifBlank { "Moi" }, 44.dp)
            Button({ meL.launch("image/*") }, colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("Ma photo", fontSize = 13.sp) }
            TextButton({ vm.setImage("me", null) }) { Text("Retirer") }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button({ bgL.launch("image/*") }, colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("Photo de fond", fontSize = 13.sp) }
            TextButton({ vm.setImage("bg", null) }) { Text("Fond par défaut") }
        }
        Text("Taille de l'écriture : ${(p.fontScale * 100).toInt()} %", fontSize = 14.sp)
        Slider(p.fontScale, { p.fontScale = it }, valueRange = 0.8f..1.4f, onValueChangeFinished = { p.save() })
        Text("Aperçu : ceci est la taille du texte des messages.", fontSize = (15 * p.fontScale).sp)
    }
}

@Composable
fun ModelSheet(vm: ChatVM, close: () -> Unit) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let(vm::importFile) }
    Dialog(onDismissRequest = close) {
        Surface(shape = RoundedCornerShape(28.dp), color = SheetBg, modifier = Modifier.fillMaxWidth().fillMaxHeight(.9f)) {
            Column(Modifier.padding(20.dp)) {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    Text("Changer de modèle", fontSize = 22.sp, color = Ink)
                    Spacer(Modifier.height(8.dp))
                    Text("Ta discussion est conservée quand tu changes de modèle.", color = Color(0xFF55557A), fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    RadioRow(vm.selected == "auto", "Auto", "Choisit le meilleur modèle installé pour chaque tâche : code, écriture, calcul… (change de modèle seulement si besoin).") { vm.selected = "auto" }
                    vm.installed.forEach { m -> RadioRow(vm.selected == m.id, m.label, "${m.sizeMb} Mo") { vm.selected = m.id } }
                    val todo = Catalog.all.filter { c -> vm.installed.none { it.id == c.id } }
                    if (todo.isNotEmpty()) {
                        Spacer(Modifier.height(14.dp)); Text("À installer", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                        todo.forEach { m ->
                            Spacer(Modifier.height(10.dp))
                            Text(m.label, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color(0xFF3A3A55))
                            Text(m.desc, color = Color(0xFF6B6B88), fontSize = 12.sp)
                            Spacer(Modifier.height(6.dp))
                            val pr = vm.progress[m.id]
                            if (pr != null) { LinearProgressIndicator(progress = { pr }, Modifier.fillMaxWidth()); Text("${(pr * 100).toInt()} %", fontSize = 12.sp) }
                            else Button({ vm.install(m) }, contentPadding = PaddingValues(horizontal = 18.dp, vertical = 6.dp), colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("Installer", fontSize = 14.sp) }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Les modèles GGUF (llama.cpp) et .task (MediaPipe) sont acceptés. Un gros modèle demande beaucoup de place (jusqu'à 5 Go) et de mémoire vive, et répond lentement sur un téléphone : s'il ne se charge pas, reviens à un modèle léger. Le mode Auto choisit pour toi.", color = Color(0xFF55557A), fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton({ picker.launch("*/*") }) { Text("Importer un fichier", color = Violet, fontSize = 14.sp) }
                        Spacer(Modifier.width(8.dp))
                        TextButton({ ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Réglages", color = Violet, fontSize = 14.sp) }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(close) { Text("Fermer", color = Violet, fontSize = 16.sp) } }
            }
        }
    }
}

@Composable
fun RadioRow(sel: Boolean, title: String, sub: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(sel, onClick, colors = RadioButtonDefaults.colors(selectedColor = Violet))
        Column(Modifier.padding(start = 8.dp)) { Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Ink); Text(sub, color = Color(0xFF55557A), fontSize = 12.sp) }
    }
}
