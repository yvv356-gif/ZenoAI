package com.zenoai.app.tools

import org.jsoup.Jsoup
import java.net.URLEncoder

data class WebResult(val title: String, val url: String, val snippet: String)

object WebSearch {
    /** DuckDuckGo version HTML : aucune clé API. */
    fun search(q: String, max: Int = 5): List<WebResult> = try {
        val doc = Jsoup.connect("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8"))
            .userAgent("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36").timeout(8000).get()
        doc.select(".result").mapNotNull { r ->
            val a = r.selectFirst(".result__a") ?: return@mapNotNull null
            WebResult(a.text(), a.attr("href"), r.selectFirst(".result__snippet")?.text().orEmpty())
        }.take(max)
    } catch (e: Exception) { emptyList() }
}
