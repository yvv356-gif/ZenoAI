package com.zenoai.app.data

import android.content.Context
import java.io.File

enum class Fmt { GGUF, TASK }
enum class Kind { GENERAL, CODE, WRITE }

data class ModelInfo(
    val id: String,
    val label: String,       // ex. "SmolLM2 · 1,7 Md (ultra léger)"
    val desc: String,
    val repo: String,
    val file: String,
    val sizeMb: Int,
    val ramGb: Float,
    val fmt: Fmt = Fmt.GGUF,
    val kind: Kind = Kind.GENERAL,
)

object Catalog {
    val all = listOf(
        ModelInfo("smollm2", "SmolLM2 · 1,7 Md (ultra léger)", "Très réactif · ≈ 1,1 Go · ≈ 2 Go de mémoire vive (GGUF Q4_0, format rapide sur téléphone).",
            "bartowski/SmolLM2-1.7B-Instruct-GGUF", "SmolLM2-1.7B-Instruct-Q4_0.gguf", 1100, 2f),
        ModelInfo("qwen25", "Qwen 2.5 · 1,5 Md (polyvalent)", "Rapide, bon en code · ≈ 1 Go · ≈ 2 Go de mémoire vive (GGUF Q4_0, format rapide sur téléphone).",
            "Qwen/Qwen2.5-1.5B-Instruct-GGUF", "qwen2.5-1.5b-instruct-q4_0.gguf", 1000, 2f),
        ModelInfo("qwen25coder15", "Qwen 2.5 Coder · 1,5 Md (code, jeux, 3D)", "Spécialisé code, logique de jeu et scripts 3D OpenSCAD · ≈ 1 Go (GGUF Q4_0, format rapide sur téléphone).",
            "Qwen/Qwen2.5-Coder-1.5B-Instruct-GGUF", "qwen2.5-coder-1.5b-instruct-q4_0.gguf", 1000, 2f, kind = Kind.CODE),
        ModelInfo("llama32_1b", "Llama 3.2 · 1 Md (rapide, rédaction)", "Rapide pour écrire et discuter · ≈ 0,8 Go (GGUF Q4_0, format rapide sur téléphone).",
            "bartowski/Llama-3.2-1B-Instruct-GGUF", "Llama-3.2-1B-Instruct-Q4_0.gguf", 800, 1.5f, kind = Kind.WRITE),
        ModelInfo("llama32_3b", "Llama 3.2 · 3 Md", "Bon compromis vitesse / qualité · 2,0 Go · ≈ 3 Go de mémoire vive (GGUF).",
            "bartowski/Llama-3.2-3B-Instruct-GGUF", "Llama-3.2-3B-Instruct-Q4_K_M.gguf", 2000, 3f, kind = Kind.WRITE),
        ModelInfo("gemma2", "Gemma 2 · 2 Md", "Très à l'aise à l'écrit · 1,7 Go · ≈ 2,5 Go de mémoire vive (GGUF).",
            "bartowski/gemma-2-2b-it-GGUF", "gemma-2-2b-it-Q4_K_M.gguf", 1700, 2.5f, kind = Kind.WRITE),
        ModelInfo("qwen25_task", "Qwen 2.5 · 1,5 Md (.task, GPU)", "Format MediaPipe : utilise le GPU du téléphone quand il le permet · 1,6 Go.",
            "litert-community/Qwen2.5-1.5B-Instruct", "Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task", 1600, 2.5f, fmt = Fmt.TASK),
        ModelInfo("llama31_8b", "Llama 3.1 · 8 Md (lourd)", "Le plus puissant en général · 4,9 Go · ≈ 7 Go de mémoire vive · lent sur téléphone.",
            "bartowski/Meta-Llama-3.1-8B-Instruct-GGUF", "Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf", 4900, 7f),
        ModelInfo("qwen25coder7", "Qwen2.5-Coder · 7 Md (lourd)", "Meilleur code · 4683 Mo · ≈ 7 Go de mémoire vive.",
            "Qwen/Qwen2.5-Coder-7B-Instruct-GGUF", "qwen2.5-coder-7b-instruct-q4_k_m.gguf", 4683, 7f, kind = Kind.CODE),
        ModelInfo("qwen25coder32", "Qwen 2.5 Coder · 32 Md (très lourd)", "Le meilleur en code · ≈ 19,9 Go de stockage · ≈ 24 Go de mémoire vive. Réservé aux appareils avec 24 Go de RAM ou plus.",
            "bartowski/Qwen2.5-Coder-32B-Instruct-GGUF", "Qwen2.5-Coder-32B-Instruct-Q4_K_M.gguf", 19900, 24f, kind = Kind.CODE),
    )
    fun url(m: ModelInfo) = "https://huggingface.co/${m.repo}/resolve/main/${m.file}"
}

class ModelStore(ctx: Context) {
    val dir = File(ctx.filesDir, "models").also { it.mkdirs() }
    fun file(m: ModelInfo) = File(dir, m.file)
    fun isInstalled(m: ModelInfo) = file(m).let { it.exists() && it.length() > 1_000_000 }
    /** Fichiers importés à la main (hors catalogue). */
    fun customs(): List<ModelInfo> {
        val known = Catalog.all.map { it.file }.toSet()
        return dir.listFiles().orEmpty()
            .filter { it.isFile && !it.name.endsWith(".part") && it.name !in known }
            .map {
                val mb = (it.length() / 1_048_576).toInt()
                ModelInfo("custom:" + it.name, it.name, "Modèle importé", "", it.name, mb, mb / 1024f * 1.3f + 0.5f,
                    if (it.name.endsWith(".task")) Fmt.TASK else Fmt.GGUF)
            }
    }
}
