package ai.zeno.app.ui

import ai.zeno.app.ChatMessage
import ai.zeno.app.ChatViewModel
import ai.zeno.app.Look
import ai.zeno.app.ModelState
import ai.zeno.app.Prefs
import ai.zeno.app.Role
import android.content.Intent
import android.graphics.BitmapFactory
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val dateFmt = SimpleDateFormat("d MMM · HH:mm", Locale.getDefault())

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel) {
    val ctx = LocalContext.current
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var showSettings by remember { mutableStateOf(false) }
    var showLook by remember { mutableStateOf(false) }
    var showFlashcards by remember { mutableStateOf(false) }
    val look = vm.look
    val userBmp = remember(look.userAvatar) { loadBmp(look.userAvatar) }
    val aiBmp = remember(look.aiAvatar) { loadBmp(look.aiAvatar) }
    val listState = rememberLazyListState()

    val itemCount = vm.messages.size
    LaunchedEffect(itemCount, vm.messages.lastOrNull()?.text, vm.currentId) {
        if (itemCount > 0) listState.scrollToItem(itemCount - 1, 100000)
    }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val t = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (t != null) input = (input + " " + t).trim()
    }
    val attachLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val txt = vm.readText(uri)
            if (txt.isNotBlank()) input = (input + "\n```\n" + txt + "\n```").trim()
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importModel(uri)
    }
    val wallpaperLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.importWallpaper(uri)
    }
    val userAvatarLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.importAvatar(true, uri)
    }
    val aiAvatarLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.importAvatar(false, uri)
    }

    fun launchMic() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        }
        try { micLauncher.launch(i) } catch (_: Exception) { }
    }

    fun doSend() {
        if (!vm.busy && input.isNotBlank()) {
            vm.send(input)
            input = ""
        }
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = Color(0xF7FFFFFF)) {
                Text(
                    "ZENOAI", fontSize = 26.sp, fontWeight = FontWeight.Light, letterSpacing = 5.sp,
                    color = Ink, modifier = Modifier.padding(24.dp)
                )
                NavigationDrawerItem(
                    label = { Text("Nouvelle discussion") },
                    icon = { Icon(Icons.Default.Add, null) },
                    selected = false,
                    onClick = { vm.newChat(); scope.launch { drawer.close() } },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                NavigationDrawerItem(
                    label = { Text("Flashcards interactives") },
                    icon = { Icon(Icons.Default.Style, null) },
                    selected = false,
                    onClick = { showFlashcards = true; scope.launch { drawer.close() } },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                NavigationDrawerItem(
                    label = { Text("Personnalisation") },
                    icon = { Icon(Icons.Default.Palette, null) },
                    selected = false,
                    onClick = { showLook = true; scope.launch { drawer.close() } },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                NavigationDrawerItem(
                    label = { Text("Modèle et réglages") },
                    icon = { Icon(Icons.Default.Settings, null) },
                    selected = false,
                    onClick = { showSettings = true; scope.launch { drawer.close() } },
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                Text(
                    "Historique", fontSize = 13.sp, color = Color(0xFF6A7088),
                    modifier = Modifier.padding(start = 28.dp, top = 16.dp, bottom = 4.dp)
                )
                if (vm.chats.isEmpty()) {
                    Text(
                        "Tes discussions seront gardées ici.", fontSize = 14.sp, color = Color(0xFF8A8FA3),
                        modifier = Modifier.padding(horizontal = 28.dp, vertical = 8.dp)
                    )
                }
                LazyColumn(Modifier.weight(1f)) {
                    items(vm.chats, key = { it.id }) { c ->
                        NavigationDrawerItem(
                            label = {
                                Column {
                                    Text(c.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(dateFmt.format(Date(c.updatedAt)), fontSize = 12.sp, color = Color(0xFF8A8FA3))
                                }
                            },
                            selected = c.id == vm.currentId,
                            onClick = { vm.openChat(c.id); scope.launch { drawer.close() } },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }
    ) {
        Box(Modifier.fillMaxSize()) {
            Background(look.wallpaper)
            Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
                // Barre du haut
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { scope.launch { drawer.open() } }) {
                        Icon(Icons.Default.Menu, "Menu", tint = Ink, modifier = Modifier.size(30.dp))
                    }
                    Text(
                        "ZENOAI", fontSize = 30.sp, fontWeight = FontWeight.Light,
                        letterSpacing = 6.sp, color = Ink, modifier = Modifier.padding(start = 8.dp)
                    )
                    Spacer(Modifier.weight(1f))
                    Column(
                        Modifier.clip(RoundedCornerShape(14.dp)).clickable {
                            vm.cycleThinking()
                            Toast.makeText(
                                ctx,
                                when (vm.thinking) {
                                    0 -> "Réflexion basse : réponses rapides"
                                    1 -> "Réflexion moyenne"
                                    else -> "Réflexion élevée : plus de sources, plus lent"
                                },
                                Toast.LENGTH_SHORT
                            ).show()
                        }.padding(horizontal = 6.dp, vertical = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.Psychology, "Niveau de réflexion",
                            tint = when (vm.thinking) {
                                0 -> Color(0xFF9AA0B5)
                                1 -> Teal
                                else -> Violet
                            },
                            modifier = Modifier.size(26.dp)
                        )
                        Text(listOf("Bas", "Moyen", "Élevé")[vm.thinking], fontSize = 10.sp, color = Ink)
                    }
                    IconButton(onClick = { vm.setWeb(!vm.webEnabled) }) {
                        Icon(
                            Icons.Default.Public, "Recherche web",
                            tint = if (vm.webEnabled) Teal else Color(0xFF9AA0B5),
                            modifier = Modifier.size(28.dp)
                        )
                    }
                }

                // Bandeau d'état du modèle
                val st = vm.modelState
                if (st !is ModelState.Ready) {
                    Glass(
                        Modifier.padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth(),
                        RoundedCornerShape(18.dp), GlassWhite, onClick = { showSettings = true }
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(
                                when (st) {
                                    ModelState.None -> "Je n'ai pas encore de modèle. Touche ici pour l'installer."
                                    is ModelState.Busy -> st.label
                                    is ModelState.Error -> st.message
                                    ModelState.Ready -> ""
                                },
                                fontSize = 14.sp, color = Ink
                            )
                            if (st is ModelState.Busy) {
                                Spacer(Modifier.height(8.dp))
                                val p = st.progress
                                if (p != null) LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
                                else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            }
                        }
                    }
                }

                // Messages
                LazyColumn(
                    state = listState,
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(vm.messages, key = { it.id }) { m ->
                        MessageRow(
                            m, look, userBmp, aiBmp,
                            onSaveImage = { path -> Toast.makeText(ctx, vm.saveToGallery(path), Toast.LENGTH_SHORT).show() }
                        )
                    }
                }

                // Barre de saisie
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Glass(Modifier.weight(1f), RoundedCornerShape(30.dp), GlassWhite) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            TextField(
                                value = input,
                                onValueChange = { input = it },
                                placeholder = { Text("Écris ton message…", color = Color(0xFF7D8298)) },
                                modifier = Modifier.weight(1f),
                                maxLines = 5,
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent,
                                    unfocusedContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent,
                                    unfocusedIndicatorColor = Color.Transparent,
                                    focusedTextColor = Ink,
                                    unfocusedTextColor = Ink
                                )
                            )
                            IconButton(onClick = { launchMic() }) {
                                Icon(Icons.Default.Mic, "Micro", tint = Color(0xFF4A4F66))
                            }
                            IconButton(onClick = { attachLauncher.launch(arrayOf("*/*")) }) {
                                Icon(Icons.Default.AttachFile, "Joindre un fichier texte", tint = Color(0xFF4A4F66))
                            }
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Box(
                        Modifier.size(54.dp).clip(CircleShape)
                            .background(Brush.linearGradient(listOf(Teal, Violet)))
                            .clickable { if (vm.busy) vm.stop() else doSend() },
                        contentAlignment = Alignment.Center
                    ) {
                        if (vm.busy) Icon(Icons.Default.Stop, "Stop", tint = Color.White, modifier = Modifier.size(28.dp))
                        else Icon(Icons.AutoMirrored.Filled.Send, "Envoyer", tint = Color.White, modifier = Modifier.size(26.dp))
                    }
                }
            }
        }
    }

    if (showSettings) {
        SettingsDialog(vm, onDismiss = { showSettings = false }, onImport = { importLauncher.launch(arrayOf("*/*")) })
    }
    if (showLook) {
        LookDialog(
            vm, userBmp, aiBmp,
            onWallpaper = { wallpaperLauncher.launch("image/*") },
            onUserAvatar = { userAvatarLauncher.launch("image/*") },
            onAiAvatar = { aiAvatarLauncher.launch("image/*") },
            onDismiss = { showLook = false }
        )
    }
    if (showFlashcards) {
        FlashcardsDialog(vm, onDismiss = { showFlashcards = false })
    }
}

private fun loadBmp(path: String): ImageBitmap? =
    if (path.isBlank()) null else runCatching { BitmapFactory.decodeFile(path)?.asImageBitmap() }.getOrNull()

private fun bubbleColor(chosen: Int, default: Color, alpha: Float): Color =
    (if (chosen == 0) default else Color(chosen)).copy(alpha = alpha)

@Composable
fun Background(path: String) {
    val bmp = remember(path) { loadBmp(path) }
    if (bmp == null) AuroraBackground()
    else Image(bitmap = bmp, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
}

// ---------- Décor ----------

@Composable
fun AuroraBackground() {
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFFE4FAFF), Color(0xFFEEEBFF), Color(0xFFE2F4FF))))
        fun blob(color: Color, cx: Float, cy: Float, r: Float) {
            drawCircle(
                brush = Brush.radialGradient(listOf(color, Color.Transparent), center = Offset(size.width * cx, size.height * cy), radius = r),
                radius = r,
                center = Offset(size.width * cx, size.height * cy)
            )
        }
        blob(Color(0xAA7EE8F5), 0.05f, 0.10f, size.width * 0.9f)
        blob(Color(0x99A98BF5), 0.95f, 0.38f, size.width * 0.8f)
        blob(Color(0x8890C8FF), 0.10f, 0.62f, size.width * 0.8f)
        blob(Color(0x99B8A0F8), 0.85f, 0.92f, size.width * 0.9f)
    }
}

@Composable
fun Glass(
    modifier: Modifier = Modifier,
    shape: RoundedCornerShape = RoundedCornerShape(24.dp),
    tint: Color = GlassWhite,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier
            .shadow(6.dp, shape, ambientColor = Color(0x33557799), spotColor = Color(0x33557799))
            .clip(shape)
            .background(tint)
            .border(1.dp, Color.White.copy(alpha = 0.7f), shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        content = content
    )
}

@Composable
fun Avatar(name: String, bmp: ImageBitmap?, size: Dp = 44.dp) {
    Box(
        Modifier.size(size).clip(CircleShape).background(Brush.linearGradient(listOf(Violet, Teal))),
        contentAlignment = Alignment.Center
    ) {
        if (bmp != null) {
            Image(bitmap = bmp, contentDescription = name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Text(
                name.trim().take(1).uppercase().ifBlank { "Z" },
                color = Color.White, fontSize = (size.value / 2).sp, fontWeight = FontWeight.Bold
            )
        }
    }
}

// ---------- Messages ----------

@Composable
fun MessageRow(
    m: ChatMessage, look: Look, userBmp: ImageBitmap?, aiBmp: ImageBitmap?,
    onSaveImage: (String) -> Unit
) {
    val isUser = m.role == Role.USER
    val txt = if (look.textColor == 0) Ink else Color(look.textColor)
    val tint = if (isUser) bubbleColor(look.userBubble, Color(0xFFCDB8F5), look.bubbleAlpha)
    else bubbleColor(look.aiBubble, Color(0xFFB7DEFF), look.bubbleAlpha)
    val name = if (isUser) look.userName.ifBlank { "Toi" } else look.aiName.ifBlank { "Zeno" }
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        if (!isUser) { Avatar(name, aiBmp); Spacer(Modifier.width(8.dp)) }
        Glass(
            Modifier.weight(1f, fill = false).widthIn(max = 320.dp),
            RoundedCornerShape(24.dp),
            tint
        ) {
            Column(Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(
                    name,
                    fontWeight = FontWeight.Medium, fontSize = 15.sp, color = txt,
                    modifier = if (isUser) Modifier.align(Alignment.End) else Modifier
                )
                Spacer(Modifier.height(4.dp))
                if (m.text.isBlank() && m.streaming) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = Teal)
                        Spacer(Modifier.width(8.dp))
                        Text(m.status.ifBlank { "Je réfléchis…" }, fontStyle = FontStyle.Italic, color = Color(0xFF4A4F66), fontSize = 15.sp)
                    }
                } else {
                    if (m.status.isNotBlank()) {
                        Text(m.status, fontStyle = FontStyle.Italic, color = Color(0xFF4A4F66), fontSize = 13.sp)
                    }
                    MessageBody(m.text, txt)
                    if (m.imagePath != null) {
                        Spacer(Modifier.height(8.dp))
                        GeneratedImage(m.imagePath, m.imagePrompt) { onSaveImage(m.imagePath) }
                    }
                    if (m.sources.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text("Sources : ${m.sources}", fontSize = 12.sp, color = Color(0xFF5A6078))
                    }
                }
            }
        }
        if (isUser) { Spacer(Modifier.width(8.dp)); Avatar(name, userBmp, 36.dp) }
    }
}

@Composable
fun GeneratedImage(path: String, prompt: String, onSave: () -> Unit) {
    val bmp = remember(path) { BitmapFactory.decodeFile(path)?.asImageBitmap() }
    if (bmp == null) {
        Text("(image introuvable)", fontSize = 13.sp, color = Color(0xFF5A6078))
        return
    }
    Column {
        Image(
            bitmap = bmp,
            contentDescription = prompt,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .width(260.dp)
                .aspectRatio(bmp.width.toFloat() / bmp.height.toFloat())
                .clip(RoundedCornerShape(16.dp))
        )
        if (prompt.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            Text("Prompt : $prompt", fontSize = 12.sp, fontStyle = FontStyle.Italic, color = Color(0xFF5A6078), modifier = Modifier.widthIn(max = 260.dp))
        }
        TextButton(onClick = onSave) {
            Icon(Icons.Default.Download, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Enregistrer dans la galerie")
        }
    }
}

private sealed interface Seg {
    data class Txt(val s: String) : Seg
    data class Code(val lang: String, val code: String) : Seg
    data class Table(val header: List<String>, val rows: List<List<String>>) : Seg
}

private val fenceRegex = Regex("```([\\w+#.-]*)[ \\t]*\\n?([\\s\\S]*?)(?:```|\$)")
private val sepRx = Regex("^\\|?\\s*:?-{2,}:?\\s*(\\|\\s*:?-{2,}:?\\s*)*\\|?$")

private fun splitCells(line: String): List<String> {
    var t = line.trim()
    if (t.startsWith("|")) t = t.substring(1)
    if (t.endsWith("|")) t = t.dropLast(1)
    return t.split("|").map { it.trim() }
}

/** Repère les tableaux Markdown (ligne d'en-tête suivie d'une ligne | --- | --- |). */
private fun splitTables(txt: String): List<Seg> {
    val lines = txt.split("\n")
    val out = mutableListOf<Seg>()
    val buf = StringBuilder()
    fun flush() {
        if (buf.isNotBlank()) out += Seg.Txt(buf.toString())
        buf.setLength(0)
    }
    var i = 0
    while (i < lines.size) {
        val l = lines[i]
        val next = lines.getOrNull(i + 1)
        if (l.contains("|") && next != null && next.contains("-") && sepRx.matches(next.trim())) {
            flush()
            val rows = mutableListOf<List<String>>()
            var j = i + 2
            while (j < lines.size && lines[j].isNotBlank() && lines[j].contains("|")) {
                rows += splitCells(lines[j])
                j++
            }
            out += Seg.Table(splitCells(l), rows)
            i = j
        } else {
            buf.append(l).append('\n')
            i++
        }
    }
    flush()
    return out
}

private fun parseSegments(t: String): List<Seg> {
    val out = mutableListOf<Seg>()
    fun addText(x: String) { out += splitTables(x) }
    var last = 0
    for (m in fenceRegex.findAll(t)) {
        if (m.range.first > last) addText(t.substring(last, m.range.first))
        out += Seg.Code(m.groupValues[1], m.groupValues[2].trimEnd())
        last = m.range.last + 1
    }
    if (last < t.length) addText(t.substring(last))
    return out
}

private val inlineRegex = Regex("\\*\\*(.+?)\\*\\*|`([^`]+)`")
private val headerRegex = Regex("(?m)^#{1,6}\\s*")

private fun inline(raw: String): AnnotatedString {
    val s = raw.replace(headerRegex, "")
    return buildAnnotatedString {
        var last = 0
        for (m in inlineRegex.findAll(s)) {
            append(s.substring(last, m.range.first))
            if (m.groups[1] != null) {
                withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(m.groupValues[1]) }
            } else {
                withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = Color(0x22000000))) { append(m.groupValues[2]) }
            }
            last = m.range.last + 1
        }
        append(s.substring(last))
    }
}

@Composable
fun MessageBody(text: String, color: Color = Ink) {
    if (text.isBlank()) return
    SelectionContainer {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for (seg in parseSegments(text)) {
                when (seg) {
                    is Seg.Txt -> if (seg.s.isNotBlank()) {
                        Text(inline(seg.s.trim()), fontSize = 17.sp, lineHeight = 24.sp, color = color)
                    }
                    is Seg.Table -> TableView(seg.header, seg.rows, color)
                    is Seg.Code -> CodeBlock(seg.lang, seg.code)
                }
            }
        }
    }
}

@Composable
private fun TableView(header: List<String>, rows: List<List<String>>, color: Color) {
    val cols = header.size.coerceAtLeast(1)
    val widths = List(cols) { c ->
        val longest = maxOf(header.getOrNull(c)?.length ?: 0, rows.maxOfOrNull { it.getOrNull(c)?.length ?: 0 } ?: 0)
        (longest * 8 + 24).coerceIn(64, 190).dp
    }
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier.clip(shape).border(1.dp, color.copy(alpha = 0.3f), shape).horizontalScroll(rememberScrollState())
    ) {
        Row(Modifier.background(color.copy(alpha = 0.12f))) {
            for (c in 0 until cols) {
                Text(
                    inline(header.getOrElse(c) { "" }), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = color,
                    modifier = Modifier.width(widths[c]).padding(8.dp)
                )
            }
        }
        for (r in rows) {
            HorizontalDivider(color = color.copy(alpha = 0.2f))
            Row {
                for (c in 0 until cols) {
                    Text(
                        inline(r.getOrElse(c) { "" }), fontSize = 14.sp, color = color,
                        modifier = Modifier.width(widths[c]).padding(8.dp)
                    )
                }
            }
        }
    }
}


@Composable
private fun CodeBlock(lang: String, code: String) {
    val clipboard = LocalClipboardManager.current
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF1E1E2E))) {
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(lang.ifBlank { "code" }, color = Color(0xFF9AA0C0), fontSize = 12.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = { clipboard.setText(AnnotatedString(code)) }) {
                Icon(Icons.Default.ContentCopy, "Copier", tint = Color(0xFF9AA0C0), modifier = Modifier.size(18.dp))
            }
        }
        Text(code, color = Color(0xFFE6E6F0), fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 18.sp,
            modifier = Modifier.horizontalScroll(rememberScrollState()).padding(start = 12.dp, end = 12.dp, bottom = 12.dp))
    }
}

// ---------- Flashcards interactives ----------

@Composable
fun FlashcardsDialog(vm: ChatViewModel, onDismiss: () -> Unit) {
    var topic by remember { mutableStateOf("") }
    val deck = vm.activeFlashcardDeck
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFFF5F6FC)) {
            Column(Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 18.dp, vertical = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { if (deck != null) vm.closeFlashcards() else onDismiss() }) {
                        Icon(Icons.Default.ArrowBack, "Retour", tint = Ink)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("FLASHCARDS", color = Ink, fontSize = 20.sp, letterSpacing = 2.sp, fontWeight = FontWeight.SemiBold)
                        Text(if (deck == null) "Apprends en mémorisant" else deck.title, color = Color(0xFF68708A), fontSize = 12.sp, maxLines = 1)
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "Fermer", tint = Ink) }
                }
                if (deck == null) {
                    Spacer(Modifier.height(12.dp))
                    Text("Créer un paquet", color = Ink, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
                    Text("Entre un sujet ou colle directement tes notes de cours ici, puis crée tes cartes.", color = Color(0xFF68708A), fontSize = 14.sp)
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = topic, onValueChange = { topic = it }, modifier = Modifier.fillMaxWidth(),
                        label = { Text("Sujet du paquet") }, placeholder = { Text("Ex. : la Révolution française ou colle ton cours ici") },
                        shape = RoundedCornerShape(18.dp), maxLines = 3
                    )
                    Button(
                        onClick = { vm.createFlashcards(topic) }, enabled = topic.isNotBlank() && !vm.flashcardBusy,
                        modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Teal), shape = RoundedCornerShape(16.dp)
                    ) {
                        if (vm.flashcardBusy) CircularProgressIndicator(Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                        else Icon(Icons.Default.AutoAwesome, null)
                        Spacer(Modifier.width(8.dp)); Text(if (vm.flashcardBusy) "Création en cours…" else "Créer avec Zeno")
                    }
                    if (vm.flashcardError.isNotBlank()) Text(vm.flashcardError, color = Color(0xFFB3261E), fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                    Spacer(Modifier.height(22.dp))
                    Text("Mes paquets", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    if (vm.flashcardDecks.isEmpty()) {
                        Text("Aucun paquet pour le moment. Crée ton premier paquet de révision ci-dessus.", color = Color(0xFF68708A), fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp))
                    } else {
                        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            vm.flashcardDecks.forEach { d ->
                                Card(
                                    modifier = Modifier.fillMaxWidth().clickable { vm.openFlashcardDeck(d.id) },
                                    shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color.White),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                                ) {
                                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Style, null, tint = Teal, modifier = Modifier.size(28.dp))
                                        Spacer(Modifier.width(12.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(d.title, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text("${d.cards.size} cartes · ${d.mastered} connues", color = Color(0xFF68708A), fontSize = 12.sp)
                                            LinearProgressIndicator(
                                                progress = { if (d.cards.isEmpty()) 0f else d.mastered.toFloat() / d.cards.size },
                                                modifier = Modifier.fillMaxWidth().padding(top = 6.dp), color = Teal
                                            )
                                        }
                                        IconButton(onClick = { vm.deleteFlashcardDeck(d.id) }) { Icon(Icons.Default.DeleteOutline, "Supprimer", tint = Color(0xFF8A8FA3)) }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    val current = deck.cards.getOrNull(vm.flashcardIndex)
                    if (current == null) {
                        Text("Ce paquet ne contient aucune carte.", color = Ink)
                    } else {
                        Spacer(Modifier.height(24.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Carte ${vm.flashcardIndex + 1} / ${deck.cards.size}", color = Color(0xFF68708A), modifier = Modifier.weight(1f))
                            Text("${deck.mastered} maîtrisées", color = Teal, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        }
                        LinearProgressIndicator(
                            progress = { (vm.flashcardIndex + 1).toFloat() / deck.cards.size.coerceAtLeast(1) },
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp), color = Teal
                        )
                        Spacer(Modifier.weight(1f))
                        Card(
                            modifier = Modifier.fillMaxWidth().heightIn(min = 260.dp).clickable { vm.flipFlashcard() },
                            shape = RoundedCornerShape(28.dp),
                            colors = CardDefaults.cardColors(containerColor = if (vm.flashcardAnswerVisible) Color(0xFFE8F7F4) else Color.White),
                            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                        ) {
                            Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Text(if (vm.flashcardAnswerVisible) "RÉPONSE" else "QUESTION", color = Teal, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                                Spacer(Modifier.height(24.dp))
                                Text(
                                    if (vm.flashcardAnswerVisible) current.back else current.front,
                                    color = Ink, fontSize = 22.sp, lineHeight = 30.sp, fontWeight = FontWeight.Medium,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                                Spacer(Modifier.height(24.dp))
                                Text("Touche la carte pour ${if (vm.flashcardAnswerVisible) "revoir la question" else "voir la réponse"}", color = Color(0xFF7D8298), fontSize = 12.sp)
                            }
                        }
                        Spacer(Modifier.weight(1f))
                        if (vm.flashcardAnswerVisible) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                OutlinedButton(onClick = { vm.rateFlashcard(false) }, modifier = Modifier.weight(1f).height(54.dp), shape = RoundedCornerShape(16.dp)) {
                                    Icon(Icons.Default.Replay, null); Spacer(Modifier.width(6.dp)); Text("À revoir")
                                }
                                Button(onClick = { vm.rateFlashcard(true) }, modifier = Modifier.weight(1f).height(54.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Teal)) {
                                    Icon(Icons.Default.Check, null); Spacer(Modifier.width(6.dp)); Text("Je connais")
                                }
                            }
                        } else {
                            Button(onClick = { vm.flipFlashcard() }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp), colors = ButtonDefaults.buttonColors(containerColor = Teal)) {
                                Icon(Icons.Default.Visibility, null); Spacer(Modifier.width(8.dp)); Text("Afficher la réponse")
                            }
                        }
                        TextButton(onClick = { vm.closeFlashcards() }, modifier = Modifier.align(Alignment.CenterHorizontally)) { Text("Retour aux paquets") }
                    }
                }
            }
        }
    }
}

// ---------- Personnalisation ----------

private val textPalette = listOf(0, 0xFF1B1B2F.toInt(), 0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFF0D2B52.toInt(), 0xFF4B2A8A.toInt(), 0xFF14532D.toInt(), 0xFF8B1E3F.toInt())
private val bubblePalette = listOf(0, 0xFFFFFFFF.toInt(), 0xFFB7DEFF.toInt(), 0xFFCDB8F5.toInt(), 0xFFF9C6D9.toInt(), 0xFFBFF0D4.toInt(), 0xFFFFF2B3.toInt(), 0xFF2B2D42.toInt(), 0xFF000000.toInt())

@Composable
private fun ColorRow(options: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (c in options) {
            Box(
                Modifier.size(34.dp).clip(CircleShape)
                    .background(if (c == 0) Color(0xFFEDEFF7) else Color(c))
                    .border(if (c == selected) 3.dp else 1.dp, if (c == selected) Violet else Color(0x55000000), CircleShape)
                    .clickable { onPick(c) },
                contentAlignment = Alignment.Center
            ) { if (c == 0) Text("A", fontSize = 13.sp, color = Ink) }
        }
    }
}

@Composable
private fun ProfileEditor(
    title: String, name: String, bmp: ImageBitmap?, onName: (String) -> Unit,
    onPhoto: () -> Unit, onRemove: () -> Unit
) {
    SectionTitle(title)
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Avatar(name, bmp, 52.dp)
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            OutlinedTextField(value = name, onValueChange = onName, singleLine = true, label = { Text("Nom") })
            Row {
                TextButton(onClick = onPhoto) { Text("Choisir une photo") }
                TextButton(onClick = onRemove) { Text("Retirer") }
            }
        }
    }
}

@Composable
fun LookDialog(
    vm: ChatViewModel, userBmp: ImageBitmap?, aiBmp: ImageBitmap?,
    onWallpaper: () -> Unit, onUserAvatar: () -> Unit, onAiAvatar: () -> Unit, onDismiss: () -> Unit
) {
    val look = vm.look
    val txt = if (look.textColor == 0) Ink else Color(look.textColor)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Personnalisation") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Aperçu
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).height(150.dp)) {
                    Background(look.wallpaper)
                    Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Glass(Modifier.align(Alignment.End), RoundedCornerShape(18.dp), bubbleColor(look.userBubble, Color(0xFFCDB8F5), look.bubbleAlpha)) {
                            Text("Salut !", color = txt, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp))
                        }
                        Glass(Modifier, RoundedCornerShape(18.dp), bubbleColor(look.aiBubble, Color(0xFFB7DEFF), look.bubbleAlpha)) {
                            Text("Coucou, je suis ${look.aiName.ifBlank { "Zeno" }}.", color = txt, fontSize = 15.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp))
                        }
                    }
                }

                SectionTitle("Fond d'écran")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onWallpaper) { Text("Importer une image") }
                    OutlinedButton(onClick = { vm.clearWallpaper() }) { Text("Retirer") }
                }

                ProfileEditor("Mon profil", look.userName, userBmp, { vm.setUserName(it) }, onUserAvatar) { vm.clearAvatar(true) }
                ProfileEditor("Profil de l'IA", look.aiName, aiBmp, { vm.setAiName(it) }, onAiAvatar) { vm.clearAvatar(false) }

                SectionTitle("Couleur du texte")
                ColorRow(textPalette, look.textColor) { vm.setTextColor(it) }
                SectionTitle("Encadré de mes messages")
                ColorRow(bubblePalette, look.userBubble) { vm.setUserBubble(it) }
                SectionTitle("Encadré des messages de l'IA")
                ColorRow(bubblePalette, look.aiBubble) { vm.setAiBubble(it) }

                SectionTitle("Opacité des encadrés")
                Slider(value = look.bubbleAlpha, onValueChange = { vm.setBubbleAlpha(it) }, valueRange = 0.15f..1f)
                Hint("Augmente l'opacité si ton fond d'écran rend le texte difficile à lire. Le cercle « A » remet la couleur d'origine.")

                TextButton(onClick = { vm.resetLook() }) { Text("Tout réinitialiser") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("OK") } }
    )
}

// ---------- Réglages ----------

@Composable
private fun SectionTitle(t: String) {
    Text(t, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = Ink, modifier = Modifier.padding(top = 6.dp))
}

@Composable
private fun Hint(t: String) {
    Text(t, fontSize = 12.sp, lineHeight = 16.sp, color = Color(0xFF5A6078))
}

@Composable
fun SettingsDialog(vm: ChatViewModel, onDismiss: () -> Unit, onImport: () -> Unit) {
    var url by remember { mutableStateOf(vm.modelUrl) }
    var tpl by remember { mutableStateOf(vm.template) }
    var tokens by remember { mutableIntStateOf(vm.maxTokens) }
    var web by remember { mutableStateOf(vm.webEnabled) }
    var imgUrl by remember { mutableStateOf(vm.imageUrl) }
    var token by remember { mutableStateOf(vm.hfToken) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Modèle et réglages") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                val st = vm.modelState
                Text(
                    when (st) {
                        ModelState.None -> "Aucun modèle installé pour l'instant."
                        is ModelState.Busy -> st.label
                        is ModelState.Error -> st.message
                        ModelState.Ready -> "Modèle prêt : il tourne sur ton téléphone."
                    },
                    fontWeight = FontWeight.Medium
                )
                if (st is ModelState.Busy) {
                    val p = st.progress
                    if (p != null) LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }

                SectionTitle("Choisir un modèle")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = url == Prefs.QWEN_URL,
                        onClick = { url = Prefs.QWEN_URL; tpl = "chatml"; tokens = 1280 },
                        label = { Text("Qwen 1.5B") }
                    )
                    FilterChip(
                        selected = url == Prefs.GEMMA_URL,
                        onClick = { url = Prefs.GEMMA_URL; tpl = "gemma"; tokens = 2048 },
                        label = { Text("Gemma 3 1B") }
                    )
                }
                Hint("Qwen 1.5B (≈ 1,6 Go) : très bon en code et multilingue, accès libre, recommandé. Gemma 3 1B : plus léger, très à l'aise à l'écrit, mais protégé : il faut accepter sa licence sur huggingface.co et mettre ton jeton plus bas.")
                OutlinedTextField(
                    value = url, onValueChange = { url = it },
                    label = { Text("Lien du modèle (.task)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = token, onValueChange = { token = it },
                    label = { Text("Jeton Hugging Face (facultatif)") },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        vm.applySettings(url, tpl, tokens, web, imgUrl, token)
                        vm.download()
                    }) { Text("Télécharger") }
                    OutlinedButton(onClick = onImport) { Text("Importer un fichier") }
                }
                Hint("Après un téléchargement ou un import, la famille et le contexte sont réglés automatiquement d'après le nom du fichier.")

                SectionTitle("Famille du modèle : Qwen ou Gemma ?")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = tpl == "chatml", onClick = { tpl = "chatml" }, label = { Text("Qwen / Phi") })
                    FilterChip(selected = tpl == "gemma", onClick = { tpl = "gemma" }, label = { Text("Gemma") })
                }
                Hint("Chaque famille de modèles « parle » avec sa propre mise en forme des messages. Choisis celle de ton fichier : Qwen (ou Phi) → « Qwen / Phi », Gemma → « Gemma ». Si tu te trompes, les réponses deviennent bizarres, se répètent ou s'arrêtent au milieu.")

                SectionTitle("Mémoire de la discussion : 1280, 2048 ou 4096 ?")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1280, 2048, 4096).forEach { n ->
                        FilterChip(selected = tokens == n, onClick = { tokens = n }, label = { Text("$n") })
                    }
                }
                Hint("C'est la quantité de texte que Zeno peut garder en tête en une fois (ta question, le résumé, les sources web et sa réponse).\n• 1280 : rapide et léger, idéal pour discuter et les questions courtes.\n• 2048 : bon équilibre, plus à l'aise pour le code et les recherches web.\n• 4096 : longues discussions, gros morceaux de code, plusieurs sources ; plus lent et plus gourmand en mémoire.\nLe chiffre doit être celui du fichier (« ekv1280 », « ekv2048 »… dans son nom), sinon le modèle ne se charge pas.")

                SectionTitle("Niveau de réflexion")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Bas", "Moyen", "Élevé").forEachIndexed { i, label ->
                        FilterChip(selected = vm.thinking == i, onClick = { vm.chooseThinking(i) }, label = { Text(label) })
                    }
                }
                Hint("Bas : le plus rapide, réponses courtes, recherche web seulement pour l'actualité ou avec « /web ». Moyen : équilibre. Élevé : plus de sources (dont Reddit et le README GitHub), vérification des réponses ; plus lent, et surtout utile avec une mémoire de 2048 ou 4096. Tu peux aussi changer de niveau avec le cerveau en haut de l'écran.")

                SectionTitle("Recherche web")
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Recherche automatique", modifier = Modifier.weight(1f))
                    Switch(checked = web, onCheckedChange = { web = it })
                }
                Hint("Pour les questions de faits, Zeno croise Wikipédia (ta langue et anglais) et DuckDuckGo. Pour le code, il consulte GitHub, Reddit et DuckDuckGo. Écris « /web » devant ta question pour forcer la recherche.")

                SectionTitle("Flashcards interactives")
                Hint("Depuis le menu, ouvre Flashcards interactives puis indique un sujet ou un cours. Zeno crée un paquet de cartes recto-verso. Touche une carte pour révéler la réponse, puis indique si tu la connais ou si tu dois la revoir. Les paquets et tes progrès sont enregistrés sur ce téléphone.")

                SectionTitle("Images")
                OutlinedTextField(
                    value = imgUrl, onValueChange = { imgUrl = it },
                    label = { Text("Service d'images") },
                    modifier = Modifier.fillMaxWidth()
                )
                Hint("Demande par exemple « dessine un chat astronaute » ou « /image un coucher de soleil ». Les images sont créées par un service en ligne gratuit (Pollinations) ; {prompt} et {seed} sont remplacés automatiquement.")

                Hint("Le texte est généré sur ton téléphone. Seuls les recherches web et les dessins passent par internet.")
            }
        },
        confirmButton = {
            TextButton(onClick = { vm.applySettings(url, tpl, tokens, web, imgUrl, token); onDismiss() }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Fermer") } }
    )
}
