package ai.zeno.app

import java.time.LocalDate

object PromptBuilder {

    private const val SYS_EST = 620

    private val longRx = Regex(
        "(développ|developp|détaill|detaill|explique|expliqu|rédige|redige|dissertation|\\bplan\\b|argument|compar|tableau|étape|etape|tutoriel|résume|resume|analyse|\\bcode\\b|programme|fonction|script|\\bclass\\b|application|\\bappli\\b|écris|ecris|write|explain|essay|\\btable\\b|step)",
        RegexOption.IGNORE_CASE
    )

    /** Vrai si la demande appelle une réponse longue (développement, code, tableau...). */
    fun wantsLong(user: String) = user.length > 400 || longRx.containsMatchIn(user)

    /** level : 0 = bas (rapide), 1 = moyen, 2 = élevé (approfondi). */
    private fun system(ai: String, user: String, level: Int): String {
        val sb = StringBuilder()
        sb.append("Tu es ").append(ai.ifBlank { "Zeno" }).append(". ")
        if (user.isNotBlank()) sb.append("L'utilisateur s'appelle ").append(user).append(". ")
        sb.append("Par défaut : 1 à 4 phrases, un seul paragraphe, droit au but (pas d'intro, pas de bonjour, pas de question de relance). ")
        sb.append("Tu décides de la longueur : 1 phrase si ça suffit ; pour un développement construit, une explication détaillée ou du code, écris autant que nécessaire avec de courts titres. ")
        sb.append("Pour comparer des données, fais un tableau Markdown (| A | B | puis | --- | --- |). ")
        sb.append("Tutoie, réponds dans la langue de l'utilisateur. ")
        sb.append("Faits : appuie-toi sur les sources fournies, signale les contradictions, n'invente jamais. ")
        sb.append("Code : bloc complet ```langage prêt à lancer, puis 1 phrase d'explication.")
        when (level) {
            0 -> sb.append(" Réponds au plus court.")
            2 -> sb.append(" Analyse la question, compare les sources et vérifie ta réponse avant de conclure.")
        }
        return sb.toString()
    }

    private const val SUMMARY_SYSTEM =
        "Tu résumes des conversations. Écris uniquement le résumé, sans introduction."

    private const val IMAGE_SYSTEM =
        "Tu écris des prompts pour un générateur d'images. Tu réponds uniquement avec le prompt."

    fun wrap(template: String, system: String, user: String): String = when (template) {
        "gemma" -> "<start_of_turn>user\n$system\n\n$user<end_of_turn>\n<start_of_turn>model\n"
        else -> "<|im_start|>system\n$system<|im_end|>\n<|im_start|>user\n$user<|im_end|>\n<|im_start|>assistant\n"
    }

    /** Budget en caractères pour tout le prompt ; une réponse longue garde plus de place pour écrire. */
    private fun promptChars(maxTokens: Int, long: Boolean) =
        (maxTokens * 3.0 * (if (long) 0.5 else 0.68)).toInt()

    private fun available(maxTokens: Int, sysLen: Int, long: Boolean) =
        (promptChars(maxTokens, long) - sysLen - 140).coerceAtLeast(500)

    /** Place disponible pour les sources web, une fois le message et le résumé comptés. */
    fun webBudget(maxTokens: Int, summaryLen: Int, userLen: Int, long: Boolean): Int {
        val avail = available(maxTokens, SYS_EST, long)
        val u = minOf(userLen, avail / 2)
        val rem = avail - u
        val s = minOf(summaryLen, (rem * 0.35).toInt())
        return (rem - s).coerceAtLeast(250)
    }

    /** Demande un paquet de cartes au format JSON strict, facile à parser sur Android. */
    fun flashcards(template: String, topic: String, maxTokens: Int): String {
        val system = "Tu es un excellent professeur. Crée exactement 10 flashcards de révision en français sur le sujet demandé. " +
            "Adapte le niveau au sujet. Chaque recto pose une seule question claire ; chaque verso donne une réponse exacte et concise. " +
            "Réponds uniquement par un tableau JSON valide, sans Markdown ni texte autour, sous cette forme : " +
            "[{\"front\":\"Question\",\"back\":\"Réponse\"}]. " +
            "Pas de commentaires, pas de champs supplémentaires."
        val request = topic.trim().take((maxTokens * 2).coerceIn(500, 3000))
        return wrap(template, system, "Sujet du paquet : $request")
    }

    fun chat(
        template: String, summary: String, web: String, user: String, maxTokens: Int,
        aiName: String, userName: String, level: Int
    ): String {
        val long = wantsLong(user)
        val sys = system(aiName, userName, level)
        val avail = available(maxTokens, sys.length, long)
        val u = user.take(avail / 2)
        val rem = avail - u.length
        val s = summary.take((rem * 0.35).toInt())
        val w = web.take((rem - s.length).coerceAtLeast(0))

        val sb = StringBuilder()
        sb.append("Date du jour : ").append(LocalDate.now()).append("\n\n")
        if (s.isNotBlank()) sb.append("[Résumé de la conversation jusqu'ici]\n").append(s).append("\n\n")
        if (w.isNotBlank()) sb.append("[Sources]\n").append(w).append("\n\n")
        sb.append("[Message de l'utilisateur]\n").append(u)
        if (w.isNotBlank() && !long && level != 0) sb.append("\n\n[Réponds en 1 à 4 phrases maximum.]")
        return wrap(template, sys, sb.toString())
    }

    fun summary(template: String, previous: String, user: String, ai: String): String {
        val sb = StringBuilder()
        sb.append("Mets à jour le résumé de cette conversation en 100 mots maximum, dans la langue de la conversation. ")
        sb.append("Garde : le sujet, les faits, les décisions, les préférences de l'utilisateur et les points clés du code.\n\n")
        sb.append("[Résumé précédent]\n").append(if (previous.isBlank()) "(aucun)" else previous).append("\n\n")
        sb.append("[Dernier échange]\nUtilisateur : ").append(user.take(600)).append("\n")
        sb.append("Assistant : ").append(ai.take(1100))
        return wrap(template, SUMMARY_SYSTEM, sb.toString())
    }

    fun imagePrompt(template: String, request: String): String {
        val user = "Demande de l'utilisateur : ${request.take(400)}\n\n" +
            "Écris UN seul prompt en anglais, précis et visuel (sujet, style, lumière, ambiance), 40 mots maximum. " +
            "Réponds uniquement avec le prompt."
        return wrap(template, IMAGE_SYSTEM, user)
    }

    fun cleanImagePrompt(s: String): String = clean(s)
        .lineSequence().firstOrNull { it.isNotBlank() }.orEmpty()
        .replace(Regex("^(prompt|image prompt)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
        .trim().trim('"', '«', '»', '“', '”')
        .take(400)

    private val partialToken = Regex("(<\\|[a-z_]*\\|?>?|<end_of[a-z_]*>?|<start_of[a-z_]*>?)$")

    fun clean(s: String): String = s
        .replace("<|im_end|>", "")
        .replace("<|endoftext|>", "")
        .replace("<end_of_turn>", "")
        .replace(partialToken, "")
        .trim()
}
