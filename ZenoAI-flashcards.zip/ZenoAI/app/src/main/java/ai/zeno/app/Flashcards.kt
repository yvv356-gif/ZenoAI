package ai.zeno.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Une carte et son historique de révision. */
data class FlashcardItem(
    val id: Long,
    val front: String,
    val back: String,
    val known: Boolean = false,
    val attempts: Int = 0
)

data class FlashcardDeck(
    val id: String,
    val title: String,
    val createdAt: Long,
    val cards: List<FlashcardItem>
) {
    val mastered: Int get() = cards.count { it.known }
}

/** Stockage privé local : les paquets et progrès restent sur le téléphone. */
class FlashcardStore(context: Context) {
    private val file = File(context.filesDir, "flashcards.json")

    fun load(): List<FlashcardDeck> = runCatching {
        val root = JSONArray(file.readText())
        (0 until root.length()).map { i ->
            val d = root.getJSONObject(i)
            val a = d.getJSONArray("cards")
            val cards = (0 until a.length()).map { j ->
                val c = a.getJSONObject(j)
                FlashcardItem(c.getLong("id"), c.getString("front"), c.getString("back"), c.optBoolean("known"), c.optInt("attempts"))
            }
            FlashcardDeck(d.getString("id"), d.getString("title"), d.getLong("createdAt"), cards)
        }
    }.getOrDefault(emptyList())

    fun save(decks: List<FlashcardDeck>) {
        val root = JSONArray()
        decks.forEach { d ->
            val cards = JSONArray()
            d.cards.forEach { c ->
                cards.put(JSONObject().put("id", c.id).put("front", c.front).put("back", c.back)
                    .put("known", c.known).put("attempts", c.attempts))
            }
            root.put(JSONObject().put("id", d.id).put("title", d.title).put("createdAt", d.createdAt).put("cards", cards))
        }
        val tmp = File(file.parentFile, "flashcards.tmp")
        tmp.writeText(root.toString())
        if (!tmp.renameTo(file)) { file.writeText(root.toString()); tmp.delete() }
    }
}
