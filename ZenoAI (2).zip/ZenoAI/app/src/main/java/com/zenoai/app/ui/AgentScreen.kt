package com.zenoai.app.ui

import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.zenoai.app.ChatVM
import com.zenoai.app.tools.Prompts
import kotlinx.coroutines.*
import org.json.JSONObject
import org.json.JSONTokener
import kotlin.coroutines.resume

private const val SNAPSHOT_JS = """(function(){var els=[].slice.call(document.querySelectorAll('a,button,input,textarea,select,[role=button]')).filter(function(e){return e.offsetParent!==null}).slice(0,40);
els.forEach(function(e,i){e.setAttribute('data-zid',i)});
return JSON.stringify({url:location.href,title:document.title,text:(document.body?document.body.innerText:'').slice(0,1200),
els:els.map(function(e,i){return {id:i,tag:e.tagName,t:(e.innerText||e.placeholder||e.value||e.getAttribute('aria-label')||'').slice(0,40)}})})})()"""

private suspend fun WebView.js(code: String): String = suspendCancellableCoroutine { c ->
    post { evaluateJavascript(code) { r -> c.resume(runCatching { JSONTokener(r).nextValue().toString() }.getOrDefault(r ?: "")) } }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AgentScreen(vm: ChatVM, back: () -> Unit) {
    var web by remember { mutableStateOf<WebView?>(null) }
    var goal by remember { mutableStateOf("") }
    var log by remember { mutableStateOf("Dis-moi quoi faire : je navigue devant toi.") }
    var job by remember { mutableStateOf<Job?>(null) }
    val scope = rememberCoroutineScope()

    fun startAgent(g: String) {
        job?.cancel()
        job = scope.launch {
            val w = web ?: return@launch
            val direct = Regex("^(https?://\\S+|[\\w-]+\\.(com|fr|org|net|io)\\S*)$").matches(g.trim())
            if (direct) { w.loadUrl(if (g.startsWith("http")) g.trim() else "https://" + g.trim()); log = "Ouverture de $g"; return@launch }
            repeat(15) { step ->
                val snap = w.js(SNAPSHOT_JS)
                log = "Étape ${step + 1} : l'IA réfléchit…"
                val out = vm.ask(Prompts.AGENT, "Objectif : $g\nÉtat de la page : $snap") ?: run { log = "Installe d'abord un modèle."; return@launch }
                val j = try { JSONObject(out.substring(out.indexOf('{'), out.lastIndexOf('}') + 1)) } catch (e: Exception) { log = "Réponse illisible, nouvel essai…"; return@repeat }
                when (j.optString("action")) {
                    "goto" -> { log = "→ ${j.optString("url")}"; w.loadUrl(j.optString("url")) }
                    "click" -> { log = "Clic sur #${j.optInt("id")}"; w.js("(function(){var e=document.querySelector('[data-zid=\"${j.optInt("id")}\"]');if(e){e.scrollIntoView();e.click();return 'ok'}return 'introuvable'})()") }
                    "type" -> {
                        log = "Saisie : ${j.optString("text")}"
                        val t = JSONObject.quote(j.optString("text")); val sub = j.optBoolean("submit", false)
                        w.js("(function(){var e=document.querySelector('[data-zid=\"${j.optInt("id")}\"]');if(!e)return 'introuvable';e.focus();var s=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(e),'value');if(s&&s.set)s.set.call(e,$t);else e.value=$t;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));if($sub&&e.form){if(e.form.requestSubmit)e.form.requestSubmit();else e.form.submit()}return 'ok'})()")
                    }
                    "scroll" -> w.js("window.scrollBy(0,window.innerHeight*0.8);'ok'")
                    "done" -> { log = "✅ " + j.optString("answer"); return@launch }
                }
                delay(1800)
            }
            log = "Je m'arrête après 15 étapes."
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(back) { Icon(Icons.Default.ArrowBack, null) }
            Text("Agent", fontSize = 22.sp)
        }
        AndroidView(factory = { c -> WebView(c).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            webViewClient = WebViewClient(); loadUrl("https://duckduckgo.com"); web = this } },
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp).clip(RoundedCornerShape(16.dp)))
        Text(log, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), fontSize = 13.sp, color = Color(0xFF3A3A55))
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(goal, { goal = it }, Modifier.weight(1f).background(Color.White.copy(alpha = .6f), RoundedCornerShape(28.dp)),
                placeholder = { Text("Cherche ou dis à l'agent quoi faire…") }, shape = RoundedCornerShape(28.dp), maxLines = 3)
            IconButton({ if (goal.isNotBlank()) { startAgent(goal); goal = "" } }) { Icon(Icons.Default.Send, null, tint = Violet) }
        }
    }
}
