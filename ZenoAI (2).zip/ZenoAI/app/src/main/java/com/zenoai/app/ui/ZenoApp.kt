package com.zenoai.app.ui

import android.content.Intent
import android.graphics.BitmapFactory
import android.provider.Settings
import android.annotation.SuppressLint
import android.webkit.WebView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import com.zenoai.app.*
import com.zenoai.app.data.*

val Violet = Color(0xFF7B6FE8)
val SheetBg = Color(0xFFEBE6F2)
val Ink = Color(0xFF1B1B2F)
val BgBrush = Brush.linearGradient(listOf(Color(0xFFB8EEF7), Color(0xFFD0DAF8), Color(0xFFD9CFF5)))

@Composable
fun ZenoApp(vm: ChatVM) {
    var agent by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = lightColorScheme(primary = Violet)) {
        Box(Modifier.fillMaxSize().background(BgBrush).systemBarsPadding().imePadding()) {
            if (agent) AgentScreen(vm) { agent = false } else ChatScreen(vm) { agent = true }
        }
    }
}

@Composable
fun ChatScreen(vm: ChatVM, openAgent: () -> Unit) {
    var showSheet by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    val list = rememberLazyListState()
    LaunchedEffect(vm.messages.size, vm.messages.lastOrNull()?.text) { if (vm.messages.isNotEmpty()) list.scrollToItem(vm.messages.lastIndex) }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Menu, null, Modifier.size(34.dp), tint = Ink)
            Spacer(Modifier.width(18.dp))
            Text("ZENOAI", fontSize = 34.sp, fontWeight = FontWeight.Thin, letterSpacing = 9.sp, color = Ink, modifier = Modifier.weight(1f))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Psychology, null, tint = Color(0xFF5FA2B8), modifier = Modifier.size(34.dp)); Text("Moyen", fontSize = 12.sp, color = Ink)
            }
            Spacer(Modifier.width(14.dp))
            IconButton(onClick = { vm.webOn = !vm.webOn }) {
                Icon(Icons.Default.Public, "Web", tint = if (vm.webOn) Color(0xFF4F9BB5) else Color.Gray, modifier = Modifier.size(38.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Pill(Modifier.weight(1f).clickable { showSheet = true }) {
                Icon(Icons.Default.Memory, null, tint = Color(0xFF5FA2B8)); Spacer(Modifier.width(10.dp))
                Text(vm.chipLabel(), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f), color = Ink)
                Icon(Icons.Default.ArrowDropDown, null)
            }
            Pill(Modifier.clickable { openAgent() }) { Icon(Icons.Default.SmartToy, null, tint = Color.Gray); Spacer(Modifier.width(8.dp)); Text("Agent", color = Ink) }
        }
        if (vm.status.isNotBlank()) Text(vm.status, Modifier.padding(top = 6.dp), fontSize = 12.sp, color = Color(0xFF55557A))
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, contentPadding = PaddingValues(vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.messages, key = { it.id }) { Bubble(it, vm) }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f).clip(RoundedCornerShape(32.dp)).background(Color.White.copy(alpha = .55f)).padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    if (input.isEmpty()) Text("Écris ton message…", color = Color(0xFF6B6B88), fontSize = 18.sp)
                    BasicTextField(input, { input = it }, textStyle = androidx.compose.ui.text.TextStyle(fontSize = 18.sp, color = Ink), maxLines = 5)
                }
                Icon(Icons.Default.GraphicEq, null, tint = Ink); Spacer(Modifier.width(12.dp))
                Icon(Icons.Default.Mic, null, tint = Ink); Spacer(Modifier.width(12.dp))
                Icon(Icons.Default.AttachFile, null, tint = Ink)
            }
            Spacer(Modifier.width(10.dp))
            Box(Modifier.size(62.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF5FA2B8), Violet)))
                .clickable { if (vm.busy) vm.stop() else { vm.send(input); input = "" } }, contentAlignment = Alignment.Center) {
                Icon(if (vm.busy) Icons.Default.Stop else Icons.Default.Send, null, tint = Color.White, modifier = Modifier.size(30.dp))
            }
        }
    }
    if (showSheet) ModelSheet(vm) { showSheet = false }
}

@Composable
fun Pill(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) =
    Row(modifier.clip(RoundedCornerShape(28.dp)).background(Color.White.copy(alpha = .5f)).border(1.dp, Color.White, RoundedCornerShape(28.dp)).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically, content = content)

@Composable
fun Bubble(m: Msg, vm: ChatVM) {
    val me = m.role == "user"
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (me) Alignment.End else Alignment.Start) {
        if (m.text.isNotBlank()) Text(m.text, color = if (me) Color.White else Ink,
            modifier = Modifier.widthIn(max = 320.dp).clip(RoundedCornerShape(20.dp)).background(if (me) Violet else Color.White.copy(alpha = .7f)).padding(14.dp))
        when (val a = m.attach) {
            is Attach.Img -> {
                val bmp = remember(a.path) { BitmapFactory.decodeFile(a.path)?.asImageBitmap() }
                if (bmp != null) Image(bmp, null, Modifier.padding(top = 6.dp).size(300.dp).clip(RoundedCornerShape(16.dp)))
                SmallBtn("Télécharger l'image") { vm.saveToDownloads(a) }
            }
            is Attach.Stl -> SmallBtn("Télécharger ${a.name}") { vm.saveToDownloads(a) }
            is Attach.Game -> {
                GamePreview(a.html)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallBtn("Télécharger en APK") { vm.exportApk(a.html) }
                    SmallBtn("HTML") { vm.saveToDownloads(a) }
                }
            }
            null -> {}
        }
    }
}

@Composable fun SmallBtn(t: String, onClick: () -> Unit) =
    Button(onClick, Modifier.padding(top = 6.dp), colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text(t) }

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun GamePreview(html: String) {
    AndroidView(factory = { c -> WebView(c).apply { settings.javaScriptEnabled = true; settings.domStorageEnabled = true
        loadDataWithBaseURL("https://zeno.local/", html, "text/html", "utf-8", null) } },
        modifier = Modifier.padding(top = 6.dp).fillMaxWidth().height(380.dp).clip(RoundedCornerShape(16.dp)))
}

@Composable
fun ModelSheet(vm: ChatVM, close: () -> Unit) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { it?.let(vm::importFile) }
    Dialog(onDismissRequest = close) {
        Surface(shape = RoundedCornerShape(36.dp), color = SheetBg, modifier = Modifier.fillMaxWidth().fillMaxHeight(.92f)) {
            Column(Modifier.padding(24.dp)) {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    Text("Changer de modèle", fontSize = 34.sp, color = Ink)
                    Spacer(Modifier.height(14.dp))
                    Text("Ta discussion est conservée quand tu changes de modèle.", color = Color(0xFF55557A), fontSize = 17.sp)
                    Spacer(Modifier.height(10.dp))
                    RadioRow(vm.selected == "auto", "Auto", "Choisit le meilleur modèle installé pour chaque tâche : code, écriture, calcul… (change de modèle seulement si besoin).") { vm.selected = "auto" }
                    vm.installed.forEach { m -> RadioRow(vm.selected == m.id, m.label, "${m.sizeMb} Mo") { vm.selected = m.id } }
                    val todo = Catalog.all.filter { c -> vm.installed.none { it.id == c.id } }
                    if (todo.isNotEmpty()) {
                        Spacer(Modifier.height(18.dp)); Text("À installer", fontSize = 26.sp, fontWeight = FontWeight.SemiBold, color = Ink)
                        todo.forEach { m ->
                            Spacer(Modifier.height(14.dp))
                            Text(m.label, fontSize = 20.sp, fontWeight = FontWeight.Medium, color = Color(0xFF3A3A55))
                            Text(m.desc, color = Color(0xFF6B6B88), fontSize = 16.sp)
                            Spacer(Modifier.height(8.dp))
                            val p = vm.progress[m.id]
                            if (p != null) { LinearProgressIndicator(progress = { p }, Modifier.fillMaxWidth()); Text("${(p * 100).toInt()} %", fontSize = 13.sp) }
                            else Button({ vm.install(m) }, colors = ButtonDefaults.buttonColors(containerColor = Violet)) { Text("Installer", fontSize = 18.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text("Les modèles GGUF (llama.cpp) et .task (MediaPipe) sont acceptés. Un gros modèle demande beaucoup de place (jusqu'à 5 Go) et de mémoire vive, et répond lentement sur un téléphone : s'il ne se charge pas, reviens à un modèle léger. Le mode Auto choisit pour toi.", color = Color(0xFF55557A), fontSize = 16.sp)
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton({ picker.launch("*/*") }) { Text("Importer un fichier", Modifier.padding(8.dp), color = Violet, fontSize = 18.sp) }
                        Spacer(Modifier.width(12.dp))
                        TextButton({ ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Réglages", color = Violet, fontSize = 18.sp) }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { TextButton(close) { Text("Fermer", color = Violet, fontSize = 20.sp) } }
            }
        }
    }
}

@Composable
fun RadioRow(sel: Boolean, title: String, sub: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        RadioButton(sel, onClick, colors = RadioButtonDefaults.colors(selectedColor = Violet))
        Column(Modifier.padding(start = 12.dp)) { Text(title, fontSize = 22.sp, fontWeight = FontWeight.Medium, color = Ink); Text(sub, color = Color(0xFF55557A), fontSize = 16.sp) }
    }
}
