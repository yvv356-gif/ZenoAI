package com.zenoai.app

import android.app.Application
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zenoai.app.data.*
import com.zenoai.app.engine.LlmEngine
import com.zenoai.app.tools.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

sealed interface Attach {
    data class Img(val path: String) : Attach
    data class Stl(val path: String, val name: String) : Attach
    data class Game(val html: String) : Attach
}
data class Msg(val id: Long, val role: String, val text: String, val attach: Attach? = null)
enum class Task { CHAT, CODE, WRITE }

class ChatVM(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()
    val store = ModelStore(app)
    val engine = LlmEngine(app)
    private val dl = Downloader()

    val messages = mutableStateListOf<Msg>()
    val progress = mutableStateMapOf<String, Float>()
    var installed by mutableStateOf<List<ModelInfo>>(emptyList()); private set
    var selected by mutableStateOf("auto")
    var activeLabel by mutableStateOf("")
    var busy by mutableStateOf(false)
    var status by mutableStateOf("")
    var webOn by mutableStateOf(true)
    private var nextId = 0L

    init { refresh() }

    fun refresh() { installed = (Catalog.all.filter { store.isInstalled(it) } + store.customs()) }
    fun chipLabel() = if (selected == "auto") "Auto" + (activeLabel.takeIf { it.isNotBlank() }?.let { " · $it" } ?: "")
        else installed.firstOrNull { it.id == selected }?.label ?: "Auto"

    // ---------- téléchargements ----------
    fun install(m: ModelInfo) {
        if (progress.containsKey(m.id)) return
        progress[m.id] = 0f
        viewModelScope.launch(Dispatchers.IO) {
            try { dl.download(Catalog.url(m), store.file(m)) { d, t -> progress[m.id] = if (t > 0) d.toFloat() / t else 0f } }
            catch (e: Exception) { status = "Téléchargement de ${m.label} échoué : ${e.message}" }
            finally { progress.remove(m.id); refresh() }
        }
    }
    fun importFile(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c -> c.moveToFirst(); c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) } ?: "modele.gguf"
        ctx.contentResolver.openInputStream(uri)!!.use { i -> File(store.dir, name).outputStream().use { i.copyTo(it, 1 shl 20) } }
        refresh()
    }

    // ---------- choix du modèle ----------
    private fun taskOf(t: String): Task = when {
        Regex("\\b(code|script|fonction|bug|python|kotlin|java|html|jeu|3d)\\b").containsMatchIn(t) -> Task.CODE
        Regex("\\b(ecris|redige|texte|mail|histoire|poeme|lettre)\\b").containsMatchIn(t) -> Task.WRITE
        else -> Task.CHAT
    }
    private fun resolve(task: Task): ModelInfo? {
        if (selected != "auto") installed.firstOrNull { it.id == selected }?.let { return it }
        val budget = engine.availMb() * 0.75
        val fit = installed.filter { it.ramGb * 1024 <= budget }.ifEmpty { listOfNotNull(installed.minByOrNull { it.sizeMb }) }
        val kind = when (task) { Task.CODE -> Kind.CODE; Task.WRITE -> Kind.WRITE; else -> null }
        val pool = fit.filter { kind != null && it.kind == kind }.ifEmpty { fit }
        return pool.maxByOrNull { it.sizeMb }
    }
    private suspend fun ensure(task: Task): Boolean {
        val m = resolve(task) ?: return false
        if (engine.loadedId != m.id) {
            status = "Chargement de ${m.label}…"
            engine.load(m, store.file(m).takeIf { it.exists() } ?: File(store.dir, m.file))
            status = ""
        }
        activeLabel = m.label.substringBefore(" (")
        return true
    }

    // ---------- messages ----------
    private fun add(role: String, text: String, a: Attach? = null): Int { messages.add(Msg(nextId++, role, text, a)); return messages.lastIndex }
    private fun say(t: String, a: Attach? = null) = add("assistant", t, a)
    fun stop() = engine.stop()

    fun send(text: String) {
        if (text.isBlank() || busy) return
        add("user", text)
        viewModelScope.launch(Dispatchers.Default) {
            busy = true
            try { handle(text) } catch (e: Exception) { say("⚠️ ${e.message ?: e.javaClass.simpleName}") } finally { busy = false; status = "" }
        }
    }

    private suspend fun reply(system: String, task: Task, extra: String? = null, maxTokens: Int = 1024, onDone: ((Int, String) -> Unit)? = null) {
        if (!ensure(task)) { say("Aucun modèle installé. Touche le sélecteur de modèle en haut et installe-en un (ou importe un fichier)."); return }
        val history = messages.filter { it.text.isNotBlank() && it.attach !is Attach.Game }.takeLast(10).map { it.role to it.text }.toMutableList()
        if (extra != null) history[history.lastIndex] = "user" to extra
        val idx = say("")
        val sb = StringBuilder(); var last = 0L
        val out = engine.chat(listOf("system" to system) + history, maxTokens) { t ->
            sb.append(t); val n = System.currentTimeMillis()
            if (n - last > 50) { last = n; messages[idx] = messages[idx].copy(text = sb.toString()) }
        }
        messages[idx] = messages[idx].copy(text = out)
        onDone?.invoke(idx, out)
    }

    /** Appel silencieux (agent). */
    suspend fun ask(system: String, user: String, maxTokens: Int = 300): String? {
        if (!ensure(Task.CODE)) return null
        return engine.chat(listOf("system" to system, "user" to user), maxTokens) {}
    }

    private suspend fun handle(text: String) {
        when (val i = IntentRouter.parse(text)) {
            is Cmd.OpenApp -> say(Phone.openApp(ctx, i.name))
            is Cmd.Torch -> say(Phone.torch(ctx, i.on))
            is Cmd.Back -> say(Phone.back(ctx))
            is Cmd.Home -> say(Phone.home(ctx))
            is Cmd.Click -> say(Phone.click(ctx, i.text))
            is Cmd.Web -> {
                if (!webOn) { say("La recherche web est désactivée (globe en haut à droite)."); return }
                status = "Recherche sur internet…"
                val r = WebSearch.search(i.query)
                if (r.isEmpty()) { say("Aucun résultat trouvé (vérifie ta connexion)."); return }
                val ctxTxt = r.joinToString("\n") { "- ${it.title} (${it.url}) : ${it.snippet}" }
                reply(Prompts.WEB, Task.CHAT, "Question : ${i.query}\n\nRésultats web :\n$ctxTxt")
            }
            is Cmd.Image -> {
                status = "Génération de l'image…"
                val f = ImageTool.generate(ctx, i.prompt)
                say("Voilà ton image 🎨", Attach.Img(f.absolutePath))
            }
            is Cmd.Model3D -> reply(Prompts.MODEL3D, Task.CODE, maxTokens = 1500) { idx, out ->
                val json = out.substringAfter('{', "").let { if (it.isEmpty()) "" else "{$it" }.substringBeforeLast('}', "").let { if (it.isEmpty()) "" else "$it}" }
                try {
                    val stl = StlBuilder.fromJson(json)
                    val name = IntentRouter.norm(i.prompt).replace(Regex("[^a-z0-9]+"), "_").take(30).trim('_') + ".stl"
                    val f = File(ctx.cacheDir, name).also { it.writeBytes(stl) }
                    messages[idx] = messages[idx].copy(text = "Voilà ton fichier 3D 🧊 (${stl.size / 1024} Ko)", attach = Attach.Stl(f.absolutePath, name))
                } catch (e: Exception) { messages[idx] = messages[idx].copy(text = "Le modèle n'a pas produit un JSON 3D valide (${e.message}). Réessaie ou choisis un modèle Coder plus gros.") }
            }
            is Cmd.Game -> reply(Prompts.GAME, Task.CODE, maxTokens = 3500) { idx, out ->
                val html = Regex("```html\\s*(.*?)```", RegexOption.DOT_MATCHES_ALL).find(out)?.groupValues?.get(1)
                    ?: out.indexOf("<html").takeIf { it >= 0 }?.let { out.substring(it) }
                    ?: out.indexOf("<!DOCTYPE").takeIf { it >= 0 }?.let { out.substring(it) }
                messages[idx] = if (html != null) messages[idx].copy(text = "Voilà ton jeu 🎮", attach = Attach.Game(html))
                    else messages[idx].copy(text = "Je n'ai pas réussi à produire un jeu complet. Réessaie.")
            }
            is Cmd.Video -> say("🎬 La génération vidéo locale (LTX-Video) n'est pas encore branchée : elle demande un GPU bien plus puissant qu'un téléphone. Elle est prévue pour le mode PC.")
            Cmd.Chat -> reply(Prompts.CHAT, taskOf(IntentRouter.norm(text)))
        }
    }

    // ---------- exports ----------
    fun saveToDownloads(a: Attach) = viewModelScope.launch(Dispatchers.IO) {
        try {
            val p = when (a) {
                is Attach.Img -> Exporter.saveToDownloads(ctx, File(a.path).name, "image/jpeg", File(a.path).readBytes())
                is Attach.Stl -> Exporter.saveToDownloads(ctx, a.name, "model/stl", File(a.path).readBytes())
                is Attach.Game -> Exporter.saveToDownloads(ctx, "jeu_zenoai.html", "text/html", a.html.toByteArray())
            }
            say("✅ Enregistré dans $p")
        } catch (e: Exception) { say("⚠️ ${e.message}") }
    }
    fun exportApk(html: String) = viewModelScope.launch(Dispatchers.IO) {
        try {
            status = "Création de l'APK…"
            val apk = ApkBuilder.build(ctx, html)
            val p = Exporter.saveToDownloads(ctx, "jeu_zenoai.apk", "application/vnd.android.package-archive", apk.readBytes())
            say("📦 APK enregistré dans $p. Ouverture de l'installation…")
            ApkBuilder.install(ctx, apk)
        } catch (e: Exception) { say("⚠️ APK impossible : ${e.message}") } finally { status = "" }
    }
}
