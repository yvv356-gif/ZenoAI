package ai.zeno.app

import java.time.LocalDate

object PromptBuilder {

    private const val SYS_EST = 880

    private val longRx = Regex(
        "(développ|developp|détaill|detaill|explique|expliqu|rédige|redige|dissertation|\\bplan\\b|argument|compar|tableau|étape|etape|tutoriel|résume|resume|analyse|\\bcode\\b|programme|fonction|script|\\bclass\\b|application|\\bappli\\b|écris|ecris|écrit|écrire|ecrire|raconte|lignes?\\b|paragraphes?|\\bmots\\b|\\btexte|histoire|article|rédaction|redaction|write|explain|essay|\\btable\\b|step)",
        RegexOption.IGNORE_CASE
    )

    /** Vrai si la demande appelle une réponse longue (développement, code, tableau...). */
    fun wantsLong(user: String) = user.length > 400 || longRx.containsMatchIn(user)

    /** Longueur maximale de la réponse (en caractères), selon ce qui est demandé (« 30 lignes », « 200 mots »…). */
    fun maxCharsFor(user: String): Int {
        Regex("(\\d{1,3})\\s*(lignes?|phrases?|mots?|paragraphes?)", RegexOption.IGNORE_CASE).find(user)?.let { m ->
            val n = m.groupValues[1].toInt()
            val per = when (m.groupValues[2].lowercase().first()) { 'l' -> 110; 'p' -> if (m.groupValues[2].lowercase().startsWith("par")) 600 else 150; else -> 7 }
            return (n * per + 300).coerceIn(600, 5000)
        }
        return if (wantsLong(user)) 3000 else 600
    }

    /** level : 0 = bas (rapide), 1 = moyen, 2 = élevé (approfondi). */
    private fun system(ai: String, user: String, level: Int, long: Boolean = false): String {
        val sb = StringBuilder()
        sb.append("Tu es ").append(ai.ifBlank { "Zeno" }).append(", un assistant sur téléphone. ")
        if (user.isNotBlank()) sb.append("L'utilisateur s'appelle ").append(user).append(". ")
        sb.append("Réponds toujours à la demande, sans jamais refuser une question ordinaire. Réponds dans la langue de l'utilisateur, en le tutoyant. ")
        if (long) sb.append("Écris une réponse complète et soignée, de la longueur demandée. Code : un bloc complet ```langage puis 1 phrase. ")
        else sb.append("Sois direct : 1 à 4 phrases, sans introduction ni question de relance. ")
        sb.append("Appuie-toi sur le contexte et les sources s'ils sont donnés, sans les recopier, et n'invente rien.")
        when (level) {
            0 -> sb.append(" Réponds au plus court.")
            2 -> sb.append(" Analyse la question, compare les sources et vérifie ta réponse avant de conclure.")
        }
        return sb.toString()
    }

    private const val GAME_SYSTEM =
        "Tu es un développeur de jeux expert. Tu écris uniquement du code fonctionnel, complet et adapté à CHAQUE demande : " +
            "jamais de modèle pré-rempli, de page de garde ni de jeu générique recyclé. " +
            "Analyse le jeu demandé (règles, objectif, contrôles, mécaniques propres à ce jeu), puis écris-le en entier. " +
            "Réponds avec UN seul bloc ```html : un fichier HTML5 autonome (CSS dans <style>, JavaScript pur dans <script>, Canvas 2D), " +
            "sans ressource externe, avec <meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no'>. " +
            "Smartphone sans clavier : boutons ou gestes tactiles visibles, touch-action:none. " +
            "Rendu soigné et réaliste (dégradés, ombres, particules, animations fluides avec requestAnimationFrame, physique simple adaptée au sujet), " +
            "jouable dès le chargement, score, game over, bouton Rejouer. " +
            "Écris tout le code : pas de commentaires, pas de '...', pas de TODO. Après le bloc, une seule phrase : les commandes."

    private const val GAME_CONTINUE_SYSTEM =
        "Tu es un développeur de jeux expert. Un fichier HTML de jeu a été coupé avant la fin. " +
            "Tu continues le code exactement là où il s'arrête, sans rien répéter, sans commentaire, sans ```, " +
            "et tu le termines proprement (fermer les fonctions, </script>, </body>, </html>)."

    private const val SITE_SYSTEM =
        "Tu es Zeno, développeur web. Réponds avec UN seul bloc ```html : une page web complète en un seul fichier " +
        "(HTML, CSS et un peu de JavaScript), adaptée au mobile, design moderne, sans bibliothèque ni image externe " +
        "(emojis et dégradés CSS à la place). Ensuite une seule phrase."

    private const val SUMMARY_SYSTEM =
        "Tu résumes des conversations. Écris uniquement le résumé, sans introduction."

    private const val IMAGE_SYSTEM =
        "Tu écris des prompts pour un générateur d'images. Tu réponds uniquement avec le prompt."

    private const val AGENT_SYSTEM =
        "Tu es un agent. Pour répondre, tu utilises UN outil à la fois. Réponds uniquement avec un JSON : " +
        "{\"action\":\"...\",\"input\":\"...\"}. Outils : search (chercher sur le web), code (chercher sur GitHub et Reddit), " +
        "calc (calcul, ex. 12*(3+4)), game (créer un jeu), site (créer un site web), image (créer une image), " +
        "open (ouvrir une adresse web, ex. jbl.com ; input = l'adresse), " +
        "phone (agir sur le téléphone : ouvrir une appli, toucher, écrire ; input = ce qu'il faut faire), " +
        "answer (tu as assez d'informations : tu peux répondre)."

    fun wrap(template: String, system: String, user: String): String = when (template) {
        "gemma" -> "<start_of_turn>user\n$system\n\n$user<end_of_turn>\n<start_of_turn>model\n"
        "llama" -> "<|start_header_id|>system<|end_header_id|>\n\n$system<|eot_id|>" +
            "<|start_header_id|>user<|end_header_id|>\n\n$user<|eot_id|><|start_header_id|>assistant<|end_header_id|>\n\n"
        else -> "<|im_start|>system\n$system<|im_end|>\n<|im_start|>user\n$user<|im_end|>\n<|im_start|>assistant\n"
    }

    /** Budget en caractères pour tout le prompt ; une réponse longue garde plus de place pour écrire. */
    private fun promptChars(maxTokens: Int, long: Boolean) =
        (maxTokens * 3.0 * (if (long) 0.5 else 0.68)).toInt()

    private fun available(maxTokens: Int, sysLen: Int, long: Boolean) =
        (promptChars(maxTokens, long) - sysLen - 140).coerceAtLeast(500)

    /** Place disponible pour la mémoire de la conversation. */
    fun memoryBudget(maxTokens: Int, userLen: Int, long: Boolean): Int {
        val avail = available(maxTokens, SYS_EST, long)
        val rem = avail - minOf(userLen, avail / 2)
        return (rem * 0.5).toInt().coerceAtLeast(200)
    }

    /** Place disponible pour les sources web, une fois le message et la mémoire comptés. */
    fun webBudget(maxTokens: Int, memoryLen: Int, userLen: Int, long: Boolean): Int {
        val avail = available(maxTokens, SYS_EST, long)
        val rem = avail - minOf(userLen, avail / 2)
        val m = minOf(memoryLen, (rem * 0.5).toInt())
        return (rem - m).coerceAtLeast(250)
    }

    /** Taille maximale (en caractères) d'une demande de jeu, code à corriger compris. */
    fun gameRequestCapacity(maxTokens: Int): Int =
        ((maxTokens * 3.0 * 0.45).toInt() - GAME_SYSTEM.length - 100).coerceAtLeast(300)

    fun chat(
        template: String, memory: String, web: String, user: String, maxTokens: Int,
        aiName: String, userName: String, level: Int
    ): String {
        val long = wantsLong(user)
        val sys = system(aiName, userName, level, long)
        val avail = available(maxTokens, sys.length, long)
        val u = user.take(avail / 2)
        val rem = avail - u.length
        // Question courte : peu de contexte = lecture du prompt beaucoup plus rapide sur le processeur
        val m = memory.take(if (long) (rem * 0.5).toInt() else minOf((rem * 0.5).toInt(), 700))
        val w = web.take(if (long) (rem - m.length).coerceAtLeast(0) else minOf((rem - m.length).coerceAtLeast(0), 1500))

        val sysFull = StringBuilder(sys)
        sysFull.append("\nDate du jour : ").append(LocalDate.now()).append(".")
        if (m.isNotBlank()) sysFull.append("\nContexte de la conversation : ").append(m)
        if (w.isNotBlank()) sysFull.append("\nSources trouvées sur le web : ").append(w)
        val sb = StringBuilder(u)
        if (w.isNotBlank() && !long && level != 0) sb.append("\n(Réponds en 1 à 4 phrases.)")
        return wrap(template, sysFull.toString(), sb.toString())
    }

    fun game(template: String, request: String, maxTokens: Int): String {
        val cap = gameRequestCapacity(maxTokens)
        val r = request.ifBlank { "un petit jeu simple et amusant" }.take(cap)
        return wrap(template, GAME_SYSTEM, "Jeu demandé : $r")
    }

    /** Suite d'un jeu coupé par la limite de mémoire : le début et la fin du code sont rappelés au modèle. */
    fun gameContinue(template: String, request: String, code: String, maxTokens: Int): String {
        val tailLen = (maxTokens * 3.0 * 0.35).toInt().coerceAtLeast(600)
        val user = "Jeu : ${request.take(120)}\nDébut du fichier :\n${code.take(300)}\n[...]\nFin actuelle du fichier :\n${code.takeLast(tailLen)}\n\n" +
            "Continue le code juste après la dernière ligne ci-dessus, sans rien répéter."
        return wrap(template, GAME_CONTINUE_SYSTEM, user)
    }

    /** Demande courte : l'IA choisit le jeu le plus proche dans la bibliothèque. */
    fun gamePick(template: String, request: String, menu: String): String = wrap(
        template,
        "Tu choisis un jeu dans cette liste : $menu. Réponds uniquement par le nom exact d'un jeu de la liste, le plus proche de la demande, sans rien d'autre.",
        "Demande : ${request.take(300)}"
    )

    fun site(template: String, request: String, maxTokens: Int): String {
        val cap = gameRequestCapacity(maxTokens)
        return wrap(template, SITE_SYSTEM, "Site demandé : " + request.ifBlank { "une page de présentation simple et jolie" }.take(cap))
    }

    /** L'IA personnalise un jeu prêt à l'emploi : un petit JSON suffit. */
    fun gameSpec(template: String, label: String, request: String): String {
        val user = "Jeu : $label. Demande : ${request.take(200)}\n" +
            "Réponds uniquement avec ce JSON : {\"titre\":\"nom court et fun\",\"couleur\":\"#rrggbb\"," +
            "\"emoji\":\"un seul emoji adapté\",\"vitesse\":5} (vitesse de 1 lent à 10 rapide)."
        return wrap(template, "Tu personnalises des mini-jeux. Tu réponds uniquement avec un JSON valide.", user)
    }

    fun agentStep(template: String, question: String, notes: String, step: Int, max: Int): String {
        val user = "Question : ${question.take(300)}\n" +
            "Observations déjà obtenues : ${if (notes.isBlank()) "(aucune)" else notes.takeLast(600)}\n" +
            "Étape $step/$max. Quelle est la prochaine action ?"
        return wrap(template, AGENT_SYSTEM, user)
    }

    fun summary(template: String, previous: String, turn: Turn): String {
        val sb = StringBuilder()
        sb.append("Mets à jour le résumé de cette conversation en 100 mots maximum, dans la langue de la conversation. ")
        sb.append("Garde : le sujet, les faits, les décisions, les préférences de l'utilisateur et les points clés du code.\n\n")
        sb.append("[Résumé précédent]\n").append(if (previous.isBlank()) "(aucun)" else previous).append("\n\n")
        sb.append("[Échange à ajouter]\nUtilisateur : ").append(turn.q.take(600)).append("\n")
        sb.append("Assistant : ").append(turn.a.take(1100))
        return wrap(template, SUMMARY_SYSTEM, sb.toString())
    }

    fun imagePrompt(template: String, request: String): String {
        val user = "Demande de l'utilisateur : ${request.take(400)}\n\n" +
            "Écris UN seul prompt en anglais, précis et visuel (sujet, style, lumière, ambiance), 40 mots maximum. " +
            "Réponds uniquement avec le prompt."
        return wrap(template, IMAGE_SYSTEM, user)
    }

    fun cleanImagePrompt(s: String): String = clean(s)
        .lineSequence().firstOrNull { it.isNotBlank() }.orEmpty()
        .replace(Regex("^(prompt|image prompt)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
        .trim().trim('"', '«', '»', '“', '”')
        .take(400)

    private val partialToken = Regex("(<\\|[a-z_]*\\|?>?|<end_of[a-z_]*>?|<start_of[a-z_]*>?)$")

    fun clean(s: String): String = s
        .replace("<|im_end|>", "")
        .replace("<|endoftext|>", "")
        .replace("<end_of_turn>", "")
        .replace("<|eot_id|>", "")
        .replace("<|end_of_text|>", "")
        .replace(partialToken, "")
        .trim()
}
