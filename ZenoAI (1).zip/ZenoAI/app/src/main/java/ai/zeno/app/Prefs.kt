package ai.zeno.app

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("zeno", Context.MODE_PRIVATE)

    var modelUrl: String
        get() = sp.getString("url", QWEN_URL) ?: QWEN_URL
        set(v) { sp.edit().putString("url", v).apply() }

    /** "chatml" (Qwen, Phi...) ou "gemma" */
    var template: String
        get() = sp.getString("template", "chatml") ?: "chatml"
        set(v) { sp.edit().putString("template", v).apply() }

    /** Taille de contexte (prompt + réponse). Doit correspondre au modèle (ekv1280 = 1280). */
    var maxTokens: Int
        get() = sp.getInt("maxTokens", 1280)
        set(v) { sp.edit().putInt("maxTokens", v).apply() }

    var web: Boolean
        get() = sp.getBoolean("web", true)
        set(v) { sp.edit().putBoolean("web", v).apply() }

    /** Service de génération d'images. {prompt} et {seed} sont remplacés. */
    var imageUrl: String
        get() = sp.getString("imageUrl", IMAGE_URL) ?: IMAGE_URL
        set(v) { sp.edit().putString("imageUrl", v).apply() }

    /** Jeton Hugging Face (optionnel, pour les modèles protégés comme Gemma). */
    var hfToken: String
        get() = sp.getString("hfToken", "") ?: ""
        set(v) { sp.edit().putString("hfToken", v).apply() }

    companion object {
        const val QWEN_URL =
            "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task"
        const val GEMMA_URL =
            "https://huggingface.co/litert-community/Gemma3-1B-IT/resolve/main/Gemma3-1B-IT_multi-prefill-seq_q4_ekv2048.task"
        const val IMAGE_URL =
            "https://image.pollinations.ai/prompt/{prompt}?width=768&height=768&model=flux&nologo=true&seed={seed}"
    }
}
