package ai.zeno.app

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import org.json.JSONObject
import org.jsoup.Jsoup
import java.net.URLEncoder
import java.util.Locale

data class WebResult(val context: String, val sources: List<String>) {
    companion object { val EMPTY = WebResult("", emptyList()) }
}

private data class Item(val host: String, val text: String)

/**
 * Accès internet : croise plusieurs sources (Wikipédia dans ta langue, Wikipédia anglais, DuckDuckGo)
 * pour limiter les erreurs. Seule la requête sort du téléphone.
 */
object WebSearch {

    private const val UA = "ZenoAI/1.0 (Android; assistant local)"

    private val timeWords = listOf(
        "aujourd'hui", "actualité", "actu ", "météo", "meteo", "dernier", "dernière", "récent", "prix",
        "cours de", "score", "résultat", "horaire", "news", "latest", "today", "weather",
        "current", "price", "2025", "2026", "combien coûte", "recherche"
    )
    private val factRx = Regex(
        "\\b(qui|quand|combien|quel|quelle|quels|quelles|date|mort|mourut|décès|décédé|né|naissance|capitale|président|population|histoire|année|siècle|who|when|how many|what is|which|died|death|born|capital|president|year)\\b",
        RegexOption.IGNORE_CASE
    )
    private val codeWords = listOf(
        "```", "code", "fonction", "function", "python", "kotlin", "java", "javascript", "html", "css",
        "bug", "erreur", "compile", "script", "algorithme", "sql", "class "
    )
    private val stopWords = setOf(
        "quand", "qui", "quel", "quelle", "quels", "quelles", "est", "était", "etait", "a", "été", "ete", "combien",
        "comment", "pourquoi", "que", "qu", "le", "la", "les", "un", "une", "de", "du", "des", "l", "d", "en", "et",
        "au", "aux", "dis", "moi", "peux", "tu", "me", "donne", "what", "is", "was", "who", "when", "the", "of",
        "how", "did", "do", "does", "a", "an", "in", "on", "to", "web"
    )

    fun needsWeb(q: String): Boolean {
        val l = q.lowercase()
        if (l.startsWith("/web")) return true
        if (codeWords.any { l.contains(it) }) return false
        if (timeWords.any { l.contains(it) }) return true
        return l.length < 250 && factRx.containsMatchIn(l)
    }

    private fun cleanQuery(q: String): String =
        q.removePrefix("/web").lowercase()
            .split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.isNotBlank() && it !in stopWords }
            .joinToString(" ")
            .ifBlank { q }
            .take(120)

    suspend fun gather(rawQuery: String, budget: Int): WebResult = coroutineScope {
        val q = rawQuery.removePrefix("/web").trim().take(200)
        val cleaned = cleanQuery(q)
        val lang = Locale.getDefault().language.ifBlank { "fr" }

        val a = async(Dispatchers.IO) { runCatching { wiki(lang, cleaned, 2) }.getOrDefault(emptyList()) }
        val b = async(Dispatchers.IO) {
            if (lang == "en") emptyList() else runCatching { wiki("en", cleaned, 1) }.getOrDefault(emptyList())
        }
        val c = async(Dispatchers.IO) { runCatching { duck(q, 3) }.getOrDefault(emptyList()) }

        val la = a.await(); val lb = b.await(); val lc = c.await()
        // On alterne les sources pour qu'elles se recoupent
        val ordered = listOfNotNull(
            la.getOrNull(0), lb.getOrNull(0), lc.getOrNull(0),
            la.getOrNull(1), lc.getOrNull(1), lc.getOrNull(2)
        )
        if (ordered.isEmpty()) return@coroutineScope WebResult.EMPTY

        val perItem = (budget / minOf(ordered.size, 4)).coerceIn(150, 450)
        val sb = StringBuilder()
        val used = mutableListOf<String>()
        for ((i, it) in ordered.withIndex()) {
            val line = "[${i + 1}] ${it.host} — ${it.text.take(perItem)}\n"
            if (sb.length + line.length > budget && sb.isNotEmpty()) break
            sb.append(line)
            if (it.host !in used) used += it.host
        }
        WebResult(sb.toString().trim(), used)
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun wiki(lang: String, q: String, n: Int): List<Item> {
        val url = "https://$lang.wikipedia.org/w/api.php?action=query&format=json&generator=search" +
            "&gsrlimit=$n&gsrsearch=${enc(q)}&prop=extracts&exintro=1&explaintext=1&exsentences=4&exlimit=$n&redirects=1"
        val body = Jsoup.connect(url).ignoreContentType(true).userAgent(UA).timeout(8000).execute().body()
        val pages = JSONObject(body).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val list = pages.keys().asSequence().map { pages.getJSONObject(it) }
            .sortedBy { it.optInt("index", 99) }.toList()
        return list.mapNotNull { p ->
            val ex = p.optString("extract").replace(Regex("\\s+"), " ").trim()
            if (ex.isBlank()) null else Item("$lang.wikipedia.org", "${p.optString("title")} : $ex")
        }
    }

    private fun duck(q: String, max: Int): List<Item> {
        val doc = Jsoup.connect("https://html.duckduckgo.com/html/?q=" + enc(q))
            .userAgent("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36")
            .timeout(8000)
            .get()
        val out = mutableListOf<Item>()
        for (r in doc.select("div.result")) {
            val title = r.selectFirst("a.result__a")?.text().orEmpty()
            val snippet = r.selectFirst(".result__snippet")?.text().orEmpty()
            val href = r.selectFirst("a.result__a")?.attr("href").orEmpty()
            val real = Uri.parse(href).getQueryParameter("uddg") ?: href
            val host = runCatching { Uri.parse(real).host }.getOrNull().orEmpty().ifBlank { "duckduckgo.com" }
            if (title.isNotBlank() && snippet.isNotBlank()) out += Item(host.removePrefix("www."), "$title : $snippet")
            if (out.size >= max) break
        }
        return out
    }
}
