package ai.zeno.app

import java.time.LocalDate

object PromptBuilder {

    private const val SYSTEM =
        "Tu es Zeno, un assistant qui discute comme un ami cultivé et bienveillant. " +
        "Parle naturellement, avec des phrases simples et chaleureuses, comme à l'oral. " +
        "Tutoie l'utilisateur, sauf s'il te vouvoie. Réponds dans sa langue. " +
        "Va droit au but : pas de formule d'intro, pas de « en tant qu'IA », pas de liste à rallonge quand une phrase suffit. " +
        "Montre un peu d'émotion et d'humour quand c'est naturel, et pose parfois une courte question pour relancer. " +
        "Ne te présente pas sauf si on te le demande. " +
        "Code : tu es expert, donne du code complet et correct dans des blocs ```langage puis 1 à 2 phrases d'explication. " +
        "Faits, dates, chiffres : base-toi sur les sources web fournies plutôt que sur ta mémoire ; " +
        "compare-les, et si elles se contredisent ou ne suffisent pas, dis-le honnêtement. N'invente jamais."

    private const val SUMMARY_SYSTEM =
        "Tu résumes des conversations. Écris uniquement le résumé, sans introduction."

    private const val IMAGE_SYSTEM =
        "Tu écris des prompts pour un générateur d'images. Tu réponds uniquement avec le prompt."

    fun wrap(template: String, system: String, user: String): String = when (template) {
        "gemma" -> "<start_of_turn>user\n$system\n\n$user<end_of_turn>\n<start_of_turn>model\n"
        else -> "<|im_start|>system\n$system<|im_end|>\n<|im_start|>user\n$user<|im_end|>\n<|im_start|>assistant\n"
    }

    /** Budget en caractères pour tout le prompt (le reste du contexte sert à la réponse). */
    private fun promptChars(maxTokens: Int) = (maxTokens * 3.0 * 0.68).toInt()

    private fun available(maxTokens: Int) = (promptChars(maxTokens) - SYSTEM.length - 140).coerceAtLeast(500)

    /** Place disponible pour les sources web, une fois le message et le résumé comptés. */
    fun webBudget(maxTokens: Int, summaryLen: Int, userLen: Int): Int {
        val avail = available(maxTokens)
        val u = minOf(userLen, avail / 2)
        val rem = avail - u
        val s = minOf(summaryLen, (rem * 0.35).toInt())
        return (rem - s).coerceAtLeast(250)
    }

    fun chat(template: String, summary: String, web: String, user: String, maxTokens: Int): String {
        val avail = available(maxTokens)
        val u = user.take(avail / 2)
        val rem = avail - u.length
        val s = summary.take((rem * 0.35).toInt())
        val w = web.take((rem - s.length).coerceAtLeast(0))

        val sb = StringBuilder()
        sb.append("Date du jour : ").append(LocalDate.now()).append("\n\n")
        if (s.isNotBlank()) sb.append("[Résumé de la conversation jusqu'ici]\n").append(s).append("\n\n")
        if (w.isNotBlank()) {
            sb.append("[Sources web : compare-les entre elles, privilégie ce que plusieurs sources confirment]\n")
                .append(w).append("\n\n")
        }
        sb.append("[Message de l'utilisateur]\n").append(u)
        return wrap(template, SYSTEM, sb.toString())
    }

    fun summary(template: String, previous: String, user: String, ai: String): String {
        val sb = StringBuilder()
        sb.append("Mets à jour le résumé de cette conversation en 100 mots maximum, dans la langue de la conversation. ")
        sb.append("Garde : le sujet, les faits, les décisions, les préférences de l'utilisateur et les points clés du code.\n\n")
        sb.append("[Résumé précédent]\n").append(if (previous.isBlank()) "(aucun)" else previous).append("\n\n")
        sb.append("[Dernier échange]\nUtilisateur : ").append(user.take(600)).append("\n")
        sb.append("Assistant : ").append(ai.take(1100))
        return wrap(template, SUMMARY_SYSTEM, sb.toString())
    }

    fun imagePrompt(template: String, request: String): String {
        val user = "Demande de l'utilisateur : ${request.take(400)}\n\n" +
            "Écris UN seul prompt en anglais, précis et visuel (sujet, style, lumière, ambiance), 40 mots maximum. " +
            "Réponds uniquement avec le prompt."
        return wrap(template, IMAGE_SYSTEM, user)
    }

    fun cleanImagePrompt(s: String): String = clean(s)
        .lineSequence().firstOrNull { it.isNotBlank() }.orEmpty()
        .replace(Regex("^(prompt|image prompt)\\s*:\\s*", RegexOption.IGNORE_CASE), "")
        .trim().trim('"', '«', '»', '“', '”')
        .take(400)

    private val partialToken = Regex("(<\\|[a-z_]*\\|?>?|<end_of[a-z_]*>?|<start_of[a-z_]*>?)$")

    fun clean(s: String): String = s
        .replace("<|im_end|>", "")
        .replace("<|endoftext|>", "")
        .replace("<end_of_turn>", "")
        .replace(partialToken, "")
        .trim()
}
