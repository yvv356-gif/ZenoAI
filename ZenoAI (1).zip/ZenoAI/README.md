# ZenoAI

Assistant IA mobile (Android) : texte généré **sur le téléphone**, avec accès internet pour la recherche web et les images.

- Moteur : MediaPipe LLM Inference (modèles `.task` : Qwen2.5-1.5B par défaut, ou Gemma 3 1B)
- Style humain : tutoiement, ton chaleureux, direct
- À chaque message, l'IA relit un **résumé** de la conversation
- Recherche web **multi-sources** (Wikipédia dans ta langue, Wikipédia EN, DuckDuckGo) pour les questions de faits ; `/web` pour forcer
- Images : « dessine… », « génère une image de… » ou `/image …` (service en ligne Pollinations)
- Historique : chaque discussion est gardée sur le téléphone ; un clic la recharge, la précédente est déchargée de la mémoire

## Compiler
Pousse le zip (ou le dossier) sur GitHub avec `.github/workflows/build.yml` :
**Actions → Build ZenoAI APK → Artifacts**.

## Premier lancement
Menu ☰ → *Modèle et réglages* → **Télécharger** (≈ 1,6 Go) ou **Importer** un `.task`.
