package com.example.assistantcode

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.webkit.ConsoleMessage
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var etCodeEditor: EditText
    private lateinit var webViewPreview: WebView
    private lateinit var tvConsoleOutput: TextView
    private lateinit var scrollConsole: ScrollView
    private lateinit var tvStatus: TextView

    private lateinit var btnTabHtml: Button
    private lateinit var btnTabCss: Button
    private lateinit var btnTabJs: Button

    private var currentTab = "html"

    private val codeFiles = mutableMapOf(
        "html" to "<h1>Bonjour Android !</h1>\n<p>Live Preview opérationnel.</p>\n<button onclick=\"testerScript()\">Lancer le test JS</button>",
        "css" to "body { font-family: sans-serif; padding: 16px; background: #f4f4f9; }\nh1 { color: #007acc; }\nbutton { padding: 10px 16px; background: #007acc; color: white; border: none; border-radius: 6px; }",
        "js" to "function testerScript() {\n    console.log('Exécution du script réussie !');\n    console.log('Calcul : ' + (21 * 2));\n}"
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etCodeEditor = findViewById(R.id.etCodeEditor)
        webViewPreview = findViewById(R.id.webViewPreview)
        tvConsoleOutput = findViewById(R.id.tvConsoleOutput)
        scrollConsole = findViewById(R.id.scrollConsole)
        tvStatus = findViewById(R.id.tvStatus)

        btnTabHtml = findViewById(R.id.btnTabHtml)
        btnTabCss = findViewById(R.id.btnTabCss)
        btnTabJs = findViewById(R.id.btnTabJs)

        val btnSaveAndRun: Button = findViewById(R.id.btnSaveAndRun)
        val btnClearConsole: Button = findViewById(R.id.btnClearConsole)

        // Configuration du WebView pour le Live Preview et la capture de console
        webViewPreview.settings.javaScriptEnabled = true
        webViewPreview.settings.domStorageEnabled = true
        webViewPreview.webViewClient = WebViewClient()
        webViewPreview.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                val prefix = when (consoleMessage.messageLevel()) {
                    ConsoleMessage.MessageLevel.ERROR -> "[ERREUR] "
                    ConsoleMessage.MessageLevel.WARNING -> "[WARN] "
                    else -> "[LOG] "
                }
                appendConsole("$prefix${consoleMessage.message()}")
                return true
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                appendConsole("[ALERT] $message")
                result?.confirm()
                return true
            }
        }

        // Charger les fichiers existants depuis le workspace local s'ils existent
        loadWorkspaceFiles()
        etCodeEditor.setText(codeFiles[currentTab])

        btnTabHtml.setOnClickListener { switchTab("html") }
        btnTabCss.setOnClickListener { switchTab("css") }
        btnTabJs.setOnClickListener { switchTab("js") }

        btnSaveAndRun.setOnClickListener {
            saveCurrentTabContent()
            saveFilesToInternalWorkspace()
            renderLivePreview()
        }

        btnClearConsole.setOnClickListener {
            tvConsoleOutput.text = "> Console vidée.\n"
        }

        // Rendu initial
        renderLivePreview()
    }

    private fun switchTab(newTab: String) {
        saveCurrentTabContent()
        currentTab = newTab
        etCodeEditor.setText(codeFiles[currentTab])

        val activeColor = Color.parseColor("#007ACC")
        val inactiveColor = Color.parseColor("#252526")

        btnTabHtml.setBackgroundColor(if (newTab == "html") activeColor else inactiveColor)
        btnTabCss.setBackgroundColor(if (newTab == "css") activeColor else inactiveColor)
        btnTabJs.setBackgroundColor(if (newTab == "js") activeColor else inactiveColor)
    }

    private fun saveCurrentTabContent() {
        codeFiles[currentTab] = etCodeEditor.text.toString()
    }

    private fun saveFilesToInternalWorkspace() {
        try {
            val workspaceDir = File(filesDir, "workspace")
            if (!workspaceDir.exists()) workspaceDir.mkdirs()

            File(workspaceDir, "index.html").writeText(codeFiles["html"] ?: "")
            File(workspaceDir, "style.css").writeText(codeFiles["css"] ?: "")
            File(workspaceDir, "app.js").writeText(codeFiles["js"] ?: "")

            tvStatus.text = "Sauvegardé dans /workspace"
            appendConsole("> Fichiers enregistrés dans ${workspaceDir.absolutePath}")
        } catch (e: Exception) {
            tvStatus.text = "Erreur sauvegarde"
            appendConsole("[ERREUR] Impossible de sauvegarder : ${e.message}")
        }
    }

    private fun loadWorkspaceFiles() {
        val workspaceDir = File(filesDir, "workspace")
        if (!workspaceDir.exists()) return

        val htmlFile = File(workspaceDir, "index.html")
        val cssFile = File(workspaceDir, "style.css")
        val jsFile = File(workspaceDir, "app.js")

        if (htmlFile.exists()) codeFiles["html"] = htmlFile.readText()
        if (cssFile.exists()) codeFiles["css"] = cssFile.readText()
        if (jsFile.exists()) codeFiles["js"] = jsFile.readText()
    }

    private fun renderLivePreview() {
        val combinedHtml = """
            <!DOCTYPE html>
            <html>
            <head>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <style>${codeFiles["css"]}</style>
            </head>
            <body>
                ${codeFiles["html"]}
                <script>
                    try {
                        ${codeFiles["js"]}
                    } catch (err) {
                        console.error(err.message);
                    }
                </script>
            </body>
            </html>
        """.trimIndent()

        webViewPreview.loadDataWithBaseURL(null, combinedHtml, "text/html", "UTF-8", null)
    }

    private fun appendConsole(msg: String) {
        runOnUiThread {
            tvConsoleOutput.append("$msg\n")
            scrollConsole.post { scrollConsole.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }
}
