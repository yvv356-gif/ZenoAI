# Assistant Code IDE (Projet Android Kotlin)

Application Android native permettant d'éditer, sauvegarder localement et prévisualiser en direct du code HTML/CSS/JS avec console de logs intégrée.

## Compilation en APK
1. **Via Android Studio** : Ouvrez directement ce dossier dans Android Studio, attendez la synchronisation Gradle, puis allez dans `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
2. **Via GitHub Actions** : Poussez ce dossier sur un dépôt GitHub ; le workflow `.github/workflows/build-apk.yml` compilera automatiquement `app-debug.apk`.
