package ai.zeno.app

import android.content.Context

class LlmEngine(private val context: Context) {

    fun generateResponse(
        prompt: String,
        history: List<ChatMessage>,
        selectedModel: ModelChoice,
        agentMode: Boolean,
        onResult: (ChatMessage) -> Unit
    ) {
        // 1. Détermination du modèle final si AUTO est sélectionné
        val effectiveModel = if (selectedModel == ModelChoice.AUTO) {
            if (prompt.contains("code", ignoreCase = true) || 
                prompt.contains("jeu", ignoreCase = true) || 
                prompt.contains("navigateur", ignoreCase = true) ||
                prompt.contains("recherche", ignoreCase = true) ||
                prompt.length > 100) {
                ModelChoice.QWEN_7B
            } else {
                ModelChoice.GEMMA_2B
            }
        } else {
            selectedModel
        }

        // 2. Transmettre TOUT l'historique sans rien oublier
        val fullHistoryBuilder = StringBuilder()
        if (agentMode) {
            fullHistoryBuilder.append("[MODE AGENT AUTONOME ACTIF : Contrôle web, navigation et exécution de tâches.]\n\n")
        }
        
        fullHistoryBuilder.append("Historique complet de la discussion :\n")
        history.forEach { msg ->
            val role = if (msg.sender == "user") "Utilisateur" else "IA"
            fullHistoryBuilder.append("$role: ${msg.text}\n")
        }
        fullHistoryBuilder.append("Utilisateur: $prompt\n")
        fullHistoryBuilder.append("IA ($effectiveModel): ")

        val lowerPrompt = prompt.lowercase()

        // 3. Routage des fonctionnalités avancées
        when {
            // Mode Agent avec navigateur dédié
            agentMode && (lowerPrompt.contains("cherche") || lowerPrompt.contains("va sur") || lowerPrompt.contains("ouvre") || lowerPrompt.contains("navigateur")) -> {
                val targetUrl = extractUrlFromPrompt(prompt)
                onResult(
                    ChatMessage(
                        sender = "assistant",
                        text = "🤖 Mode Agent : J'ouvre mon navigateur dédié et je prends le contrôle de la navigation sur $targetUrl.",
                        type = MessageType.BROWSER_CONTROL,
                        initialBrowserUrl = targetUrl
                    )
                )
            }
            // Création de jeu interactif HTML5
            lowerPrompt.contains("créer un jeu") || lowerPrompt.contains("fait un jeu") || lowerPrompt.contains("génère un jeu") -> {
                val gameHtmlCode = GameTool.generateSampleGameHtml(prompt)
                onResult(
                    ChatMessage(
                        sender = "assistant",
                        text = "Voici le jeu généré directement jouable ci-dessous ! Vous pouvez le tester ou télécharger l'APK.",
                        type = MessageType.GAME,
                        gameHtml = gameHtmlCode
                    )
                )
            }
            // Vidéo ultra-réaliste
            lowerPrompt.contains("vidéo") && (lowerPrompt.contains("réaliste") || lowerPrompt.contains("ultra")) -> {
                onResult(
                    ChatMessage(
                        sender = "assistant",
                        text = "🎬 Génération de la vidéo ultra-réaliste terminée.\nVoici votre aperçu HD ci-dessous :",
                        type = MessageType.VIDEO,
                        videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
                    )
                )
            }
            // Réponse textuelle avec liens cliquables directes
            else -> {
                val responseText = "Réponse [Modèle : ${effectiveModel.displayName}] :\n\n" +
                        "Voici les liens directs demandés :\n" +
                        "• Consulter [Google](https://www.google.com)\n" +
                        "• Explorer le code sur [GitHub](https://github.com)"
                
                onResult(
                    ChatMessage(
                        sender = "assistant",
                        text = responseText,
                        type = MessageType.TEXT
                    )
                )
            }
        }
    }

    private fun extractUrlFromPrompt(prompt: String): String {
        val words = prompt.split(" ", "\n")
        for (w in words) {
            if (w.startsWith("http://") || w.startsWith("https://") || w.contains(".com") || w.contains(".org") || w.contains(".fr")) {
                return w.replace("\"", "").replace("'", "")
            }
        }
        return "https://www.google.com"
    }
}
