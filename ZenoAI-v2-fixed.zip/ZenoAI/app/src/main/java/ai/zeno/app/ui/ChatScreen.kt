package ai.zeno.app.ui

import android.content.Intent
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import ai.zeno.app.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    messages: List<ChatMessage>,
    selectedModel: ModelChoice,
    agentMode: Boolean,
    webAgentManager: WebAgentManager,
    onModelSelected: (ModelChoice) -> Unit,
    onAgentModeToggled: (Boolean) -> Unit,
    onSendMessage: (String) -> Unit
) {
    var textState by remember { mutableStateOf("") }
    var expandedMenu by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF101014))
    ) {
        // --- BARRE SUPÉRIEURE ACCUEIL (Changement de Modèle + Switch Mode Agent) ---
        Surface(
            color = Color(0xFF1A1A22),
            shadowElevation = 6.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Menu déroulant de sélection du modèle
                Box {
                    Button(
                        onClick = { expandedMenu = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF282836))
                    ) {
                        Text(selectedModel.displayName, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    DropdownMenu(
                        expanded = expandedMenu,
                        onDismissRequest = { expandedMenu = false },
                        modifier = Modifier.background(Color(0xFF282836))
                    ) {
                        ModelChoice.values().forEach { model ->
                            DropdownMenuItem(
                                text = { Text(model.displayName, color = Color.White) },
                                onClick = {
                                    onModelSelected(model)
                                    expandedMenu = false
                                }
                            )
                        }
                    }
                }

                // Switch Mode Agent Autonome
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (agentMode) "⚡ Agent Actif" else "Agent Off",
                        color = if (agentMode) Color(0xFF00E5FF) else Color.Gray,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Switch(
                        checked = agentMode,
                        onCheckedChange = onAgentModeToggled,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF00E5FF),
                            checkedTrackColor = Color(0xFF005B66)
                        )
                    )
                }
            }
        }

        // --- LISTE DU FIL DE DISCUSSION (Conserve tout le fil) ---
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(messages) { message ->
                MessageBubble(message = message, webAgentManager = webAgentManager)
            }
        }

        // --- ZONE DE SAISIE PRINCIPALE ---
        Surface(
            color = Color(0xFF1A1A22),
            shadowElevation = 8.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = textState,
                    onValueChange = { textState = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Écrivez votre message...", color = Color.Gray) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF00E5FF),
                        unfocusedBorderColor = Color(0xFF333344),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        if (textState.isNotBlank()) {
                            onSendMessage(textState)
                            textState = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Text("Envoyer", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun MessageBubble(message: ChatMessage, webAgentManager: WebAgentManager) {
    val isUser = message.sender == "user"
    val context = LocalContext.current

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            color = if (isUser) Color(0xFF00E5FF) else Color(0xFF22222E),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.widthIn(max = 340.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                // Rendu Texte avec détection de liens cliquables
                ClickableTextWithLinks(
                    text = message.text,
                    textColor = if (isUser) Color.Black else Color.White
                )

                // --- MODULE NAVIGATEUR EN MODE AGENT ---
                if (message.type == MessageType.BROWSER_CONTROL) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "🌐 Navigateur Dédié de l'Agent",
                        color = Color(0xFF00E5FF),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    
                    val agentState by webAgentManager.agentState.collectAsState()

                    // Composant Navigateur Embarqué contrôlable par l'Agent
                    AndroidView(
                        factory = { ctx ->
                            WebView(ctx).apply {
                                webAgentManager.attachWebView(this)
                                message.initialBrowserUrl?.let { url ->
                                    webAgentManager.navigateTo(url)
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(300.dp)
                            .border(1.dp, Color(0xFF00E5FF), RoundedCornerShape(8.dp))
                    )

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "Log Agent: ${agentState.lastActionLog}",
                        color = Color.LightGray,
                        fontSize = 11.sp
                    )
                }

                // --- MODULE JEU HTML5 JOUABLE ET APK ---
                if (message.type == MessageType.GAME && message.gameHtml != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    AndroidView(
                        factory = { ctx ->
                            WebView(ctx).apply {
                                webViewClient = WebViewClient()
                                settings.javaScriptEnabled = true
                                loadDataWithBaseURL(null, message.gameHtml, "text/html", "UTF-8", null)
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(260.dp)
                            .border(1.dp, Color(0xFF00E5FF), RoundedCornerShape(8.dp))
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { GameTool.downloadAndInstallApk(context, message.gameHtml) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("📥 Télécharger l'APK du Jeu", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }

                // --- MODULE VIDÉO ULTRA-RÉALISTE ---
                if (message.type == MessageType.VIDEO && message.videoUrl != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    AndroidView(
                        factory = { ctx ->
                            VideoView(ctx).apply {
                                setVideoURI(Uri.parse(message.videoUrl))
                                start()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .border(1.dp, Color(0xFFFF0055), RoundedCornerShape(8.dp))
                    )
                }
            }
        }
    }
}

@Composable
fun ClickableTextWithLinks(text: String, textColor: Color) {
    val context = LocalContext.current
    val annotatedString = buildAnnotatedString {
        // Express regular match for markdown links [Text](URL) or raw HTTP links
        val mdLinkRegex = Regex("""\[([^\]]+)\]\((https?://[^\s)]+)\)""")
        var lastIdx = 0
        val matches = mdLinkRegex.findAll(text)

        for (match in matches) {
            append(text.substring(lastIdx, match.range.first))
            val linkText = match.groupValues[1]
            val url = match.groupValues[2]
            
            pushStringAnnotation(tag = "URL", annotation = url)
            withStyle(
                style = SpanStyle(
                    color = Color(0xFF00E5FF),
                    textDecoration = TextDecoration.Underline,
                    fontWeight = FontWeight.Bold
                )
            ) {
                append(linkText)
            }
            pop()
            lastIdx = match.range.last + 1
        }
        if (lastIdx < text.length) {
            append(text.substring(lastIdx))
        }
    }

    ClickableText(
        text = annotatedString,
        style = androidx.compose.ui.text.TextStyle(color = textColor, fontSize = 15.sp),
        onClick = { offset ->
            annotatedString.getStringAnnotations(tag = "URL", start = offset, end = offset)
                .firstOrNull()?.let { annotation ->
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(annotation.item))
                    context.startActivity(intent)
                }
        }
    )
}
