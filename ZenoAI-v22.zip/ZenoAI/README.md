# ZenoAI

Assistant IA mobile (Android) : texte généré **sur le téléphone**, avec accès internet pour la recherche web et les images.

- Moteur : MediaPipe LLM Inference (modèles `.task` : Qwen2.5-1.5B par défaut, ou Gemma 3 1B)
- Réponses directes : 1 à 4 phrases par défaut ; plus long seulement pour un développement, du code ou un tableau (Zeno décide)
- Niveau de réflexion **bas / moyen / élevé** (cerveau en haut de l'écran) : vitesse contre profondeur
- À chaque message, l'IA relit un **résumé** de la conversation
- Recherche web **multi-sources** : Wikipédia (langue + EN) et DuckDuckGo pour les faits ; GitHub, Reddit et DuckDuckGo pour le code ; `/web` pour forcer
- Tableaux Markdown affichés dans les bulles
- Jeux : `/jeu snake` → jeu HTML/JS écrit par Zeno, bouton **Jouer** pour le tester dans l'app (WebView sans réseau), erreurs captées et bouton **Corriger**
- Menu ☰ → **Personnalisation** : fond d'écran, profil (nom + photo) de toi et de l'IA, couleur du texte et des encadrés, opacité
- Images : « dessine… », « génère une image de… » ou `/image …` (service en ligne Pollinations)
- Historique : chaque discussion est gardée sur le téléphone ; un clic la recharge, la précédente est déchargée de la mémoire

## Compiler
Pousse le zip (ou le dossier) sur GitHub avec `.github/workflows/build.yml` :
**Actions → Build ZenoAI APK → Artifacts**.

## Premier lancement
Menu ☰ → *Modèle et réglages* → **Télécharger** (≈ 1,6 Go) ou **Importer** un `.task`.

## Nouveautés
- Bouton du modèle sur l'écran d'accueil : Auto, Qwen, Gemma… (la discussion est conservée), mode agent, niveau de réflexion
- Mémoire : les 3 premières questions, le dernier échange et les échanges pertinents restent dans le prompt
- Jeux prêts à l'emploi (assets/games) personnalisés par l'IA, aperçu jouable, export APK (module `gameshell`, signé sur le téléphone avec apksig)
- Sites web : `/site …` (aperçu + APK) ; images : `/image …` (en ligne, clé Pollinations facultative)
- Liens cliquables dans les réponses et les sources
- Le workflow compile d'abord `:gameshell:assembleRelease` et copie l'APK dans `app/src/main/assets/game-shell.apk`

## Moteurs IA
- `.task` : MediaPipe (Gemma, Qwen 1,5B…)
- `.gguf` : llama.cpp via `io.github.ljcamargo:llamacpp-kotlin` (Qwen2.5-Coder 7B, Llama 3.1 8B, Llama 3.2 3B, Gemma 2 2B — fichiers bartowski, quantification Q4_K_M)
- Le mode Auto choisit parmi les modèles installés : code → Coder/Qwen, écriture → Gemma, tâche complexe → le plus gros, sinon le modèle déjà chargé

## Téléchargement en arrière-plan
`DownloadService` (service de premier plan, type dataSync) : notification avec progression et bouton Annuler, reprise automatique (en-tête Range) après une coupure réseau, wake lock. L'état passe par `DownloadState` ; `ChatViewModel` l'observe et active le modèle à la fin.

## Mise à jour v22 — aperçu, exécution et dossier de travail
- **Aperçu en direct** : sous un bloc de code HTML, bouton **Aperçu**. Le HTML, le CSS et le JavaScript écrits dans des blocs séparés de la même réponse sont assemblés. Page dans une WebView isolée (sans réseau, bouton 🌐 pour l'autoriser), onglet **Console** (`console.log`, erreurs avec numéro de ligne), bouton **Corriger** qui renvoie l'erreur à l'IA.
- **Exécuter** : bouton sous les blocs **JavaScript** (WebView isolée, 10 s maximum, bouton Stop) et **Python** (facultatif, voir `optional-python/LISEZMOI.md`). Jamais lancé automatiquement.
- **Dossier de travail** : le code des réponses est enregistré tout seul dans un projet (un par discussion) ; une carte « Enregistré dans… » l'indique. Les fichiers sont créés ou mis à jour (nom lu dans la réponse : `### app.py`, `# fichier: app.py`…, sinon `main.py`, `index.html`, `style.css`, `script.js`). L'ancienne version est gardée dans `.history` (10 par fichier).
- **Modifier un fichier** : cite son nom (« modifie app.py pour… ») : l'IA relit le fichier (s'il tient dans le contexte du modèle) et la réponse le met à jour.
- Menu ☰ → **Projets et fichiers** : liste des projets, éditeur de texte, enregistrer, lancer, supprimer, **exporter en ZIP** (Téléchargements), interrupteur de l'enregistrement automatique. « crée un dossier avec… » écrit aussi dans le dossier de travail.
- Emplacement : `Android/data/ai.zeno.app/files/workspace` (visible en branchant le téléphone à un ordinateur ; supprimé si l'appli est désinstallée).

## Correctif v21 — jeux
- **Serpent « Perdu ! » dès le départ** : le jeu démarrait quand la fenêtre faisait encore 0 pixel. Reproduit en simulation puis corrigé : la page ne se charge plus qu'une fois la WebView dimensionnée, et un garde-fou donne une taille raisonnable aux jeux.
- **Nouveaux jeux** : **FPS** (tir 3D à la première personne : pouce gauche = avancer, pouce droit = tourner, bouton 💥) et **Plateforme** (saut, pièces, pics, arrivée).
- **Fini le même jeu à chaque fois** : si aucun jeu connu ne correspond, l'IA écrit le code elle-même ; si elle échoue, le jeu le plus proche (par mots-clés) est proposé, avec une explication honnête.

## Correctif v20 — chargements sans fin
- **Cause trouvée** : quand l'IA atteignait la longueur maximale d'une réponse (images, recherche web, agent, 3D…), l'appli demandait l'arrêt du moteur *depuis le moteur lui-même* et attendait la réponse : blocage définitif, et tout ce qui suivait restait en attente.
- L'arrêt ne bloque plus ; le moteur est surveillé (aucun mot pendant 90 s → erreur et repli automatique sur l'ancien mode) ; le bouton Stop arrête vraiment la génération.
- Délais maximum : prompt d'image 25 s, modèle 3D 90 s (puis objet de base), étapes de l'agent 60 s.
- Images : 3 essais Pollinations (au lieu de 7), délais réseau plus courts, file AI Horde limitée à 2 min 30.

## Mise à jour v18
- **Jeux** : le prompt « moteur de mini-jeux web » (viewport mobile, boutons tactiles, `touch-action:none`, design sombre) est utilisé quand l'IA écrit un jeu elle-même ; si elle échoue, un jeu prêt à l'emploi prend le relais.
- **Cartes mémoire interactives** : format simple « question :: réponse » (beaucoup plus fiable pour les petits modèles), cartes à retourner **directement dans le chat** (bouton **Ici**), score à la fin.
- **Modèles 3D** : objets de base prêts à l'emploi (maison, table, chaise, arbre, voiture, robot, tour, bonhomme de neige) quand le modèle n'arrive pas à décrire l'objet ; export **.stl** (Blender, impression 3D) + visionneuse tournante.
- Corrections de compilation, nouveau workflow GitHub (journal d'erreurs téléchargeable).

## Mise à jour v17
- **Threads CPU choisis par ZenoAI** : l'appli accède directement au moteur llama.cpp et utilise seulement les cœurs rapides du téléphone (2 à 6 threads, détectés automatiquement), au lieu des réglages imposés par la bibliothèque. Si l'accès direct échoue, retour automatique à l'ancien mode (journal : tag `ZenoLlm`).
- Le GPU n'est pas géré par ce moteur (la bibliothèque répond « Currently not supported »). Les modèles `.task` (MediaPipe) utilisent le GPU.

## Mise à jour v16
- **Textes longs** : « écris 30 lignes sur… » est compris (longueur calculée : lignes, phrases, mots, paragraphes). Fini les réponses coupées à 600 caractères.
- **Refus à tort** : si un petit modèle répond « je ne peux pas… », nouvel essai automatique avec une consigne minimale.
- **Vitesse** : affichage du texte limité à ~14 fois par seconde (l'écran ne ralentit plus l'IA) ; modèles légers en **Q4_0**, le format le mieux optimisé pour les processeurs ARM.

## Mise à jour v15
- **Dossiers, fichiers et ZIP** : « crée un dossier avec un README et un script Python » → l'IA écrit les fichiers, l'appli crée l'arborescence, la range dans un ZIP et propose **Enregistrer**. Un seul fichier = fichier seul. Si le projet contient un `index.html`, on peut le **jouer** tout de suite.
- **Jeu dans la bulle** : bouton **Ici** sur la carte du jeu = il se joue directement dans le chat, sans rien télécharger (**Jouer** = plein écran).
- **Plus rapide sur les petits modèles** : moins de contexte envoyé pour une question courte, réponses courtes plafonnées, réécriture du prompt d'image limitée.

## Mise à jour v14
- **PowerPoint** : « fais un PowerPoint sur les volcans » → l'IA écrit le plan, l'appli crée un vrai fichier `.pptx` (compatible PowerPoint, Google Slides, Keynote) et un **aperçu à feuilleter** (boutons ◀ ▶ ou balayage). Bouton **Enregistrer** → Téléchargements.

## Mise à jour v13
- **Conversation vocale en direct** : bouton ondes (à gauche du micro). Tu parles, Zeno répond à voix haute, puis se remet à t'écouter. Touche le texte d'état pour arrêter. Utilise la reconnaissance et la synthèse vocales d'Android (la reconnaissance peut passer par internet selon le téléphone).

## Mise à jour v12
- **Actions immédiates** (sans IA, instantanées) : « ouvre les paramètres », « ouvre WhatsApp », « va sur jbl.com » (navigateur du téléphone), « allume la lampe », « monte le volume ». Wi-Fi / Bluetooth : l'écran s'ouvre (Android interdit de les basculer depuis une appli).
- **Jeux prêts à l'emploi** (flappy, snake, 2048…) : créés instantanément, sans attendre le modèle.
- **Modèle 3D** : l'IA décrit l'objet en formes simples ; visionneuse tournante (glisser, pincer, boutons Dessus / Dessous / Côté).
- **Menu** : « Mes cartes », « Modèle 3D » et « Contrôler le téléphone » retirés ; tout se demande dans la discussion.
- **Anti-écho** : si le modèle GGUF recopie la consigne, l'appli bascule automatiquement en texte simple.

## Mise à jour v11
- **Plus de slash** : on écrit simplement « crée un jeu de… », « ouvre les paramètres », « modélise en 3D… ». Les anciennes commandes marchent encore.
- **Godot retiré**. À la place : **modèles 3D OpenSCAD** (`.scad`, exportable en STL) écrits par l'IA.
- **Contrôle du téléphone en langage naturel** (service d'accessibilité) ; les réglages (Wi-Fi, Bluetooth, luminosité…) s'ouvrent directement.
- **Modèles légers ajoutés** (GGUF Q4_K_M) : SmolLM2 1,7B, Qwen 2.5 1,5B, Qwen 2.5 Coder 1,5B, Llama 3.2 1B. Les 7B/8B restent en bas, marqués « lourd ».
- **Vitesse** : les modèles `.task` essaient le **GPU** (repli CPU automatique). Les GGUF (llama.cpp) restent sur CPU : la bibliothèque utilisée n'a pas de backend GPU.

## Mise à jour v10 (100 % local)
- **Plus de serveur PC** : `LocalServer`, le dossier `server/` et le réglage « Serveur local » sont supprimés. Le téléphone ne se connecte à aucun PC.
- **Vidéo et 3D retirées** : `/video` et `/3d` n'existent plus (ni dans le menu, ni dans l'agent). Les téléphones actuels ne peuvent pas les faire tourner.
- **Images** : toujours en ligne pour l'instant (Pollinations avec clé facultative, puis AI Horde sans compte). La génération locale (MediaPipe, SD 1.5) n'est pas encore branchée.
- **Godot 4**, navigateur agent, contrôle du téléphone, cartes mémoire et reprise des téléchargements sont conservés.
- `usesCleartextTraffic` repasse à `false` : seules les connexions HTTPS sont autorisées.

## Mise à jour v9
- **Navigateur agent** : « va sur jbl.com » ouvre le site tout de suite, sans attendre le modèle. En mode agent, Zeno lit la page et clique, écrit, défile à ta place, étape par étape, avec une barre de statut et un bouton **Arrêter**.
- **Contrôle du téléphone** (`/tel ouvre la calculatrice…`) : service d'accessibilité que tu actives toi-même dans les réglages Android. Il lit l'écran et touche, écrit, défile, ouvre une appli.
- *(Supprimé en v10 : serveur local, vidéo et 3D.)*
- **Godot 4** (`/godot un jeu de plateforme`) : l'IA écrit le script, l'appli fabrique le projet complet en ZIP à ouvrir dans Godot sur PC.
- **Cartes mémoire** : decks sauvegardés (menu ☰ → Mes cartes), révision avec niveaux, mode **Quiz** (tu tapes la réponse).
- **Téléchargements** : les coupures réseau ne comptent plus sur la durée totale ; la reprise est plus robuste.
- **Images** : chaîne de secours (Pollinations avec clé → AI Horde sans compte), messages d'erreur précis.

Limites : les images passent encore par internet (services en ligne).

## Mise à jour v8
- Agent : une adresse citée (« va sur jbl.com », « jbl. com ») s'ouvre dans un navigateur intégré visible à l'écran ; le texte de la page sert à la réponse.
- Cartes mémoire : `/cartes <sujet>` crée 8 cartes avec l'IA locale ; touche une carte pour voir la réponse, puis « Je savais » ou « À revoir ».
- Téléchargements : nouvel essai automatique aussi après HTTP 408, 425, 429 (limite de débit) et 5xx.
- Images : message d'erreur précis (clé absente ou refusée) au lieu d'un message de connexion.
