plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "ai.zeno.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "ai.zeno.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 22
        versionName = "2.9"
        ndk { abiFilters += listOf("arm64-v8a") }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildFeatures { compose = true }
    packaging {
        resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.03")
    implementation(composeBom)
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")

    // Moteur IA local : modèles .task (MediaPipe) et modèles .gguf (llama.cpp)
    implementation("com.google.mediapipe:tasks-genai:0.10.24")
    // Cette bibliothèque réclame androidx.core 1.18 (compileSdk 36, AGP 8.9) : on garde notre version
    implementation("io.github.ljcamargo:llamacpp-kotlin:0.4.0") {
        exclude(group = "androidx.core")
    }
    // Lecture des résultats de recherche web
    implementation("org.jsoup:jsoup:1.18.1")
    // Signature des APK de jeux, directement sur le téléphone
    implementation("com.android.tools.build:apksig:8.5.2")
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

configurations.all {
    resolutionStrategy {
        force("androidx.core:core-ktx:1.13.1", "androidx.core:core:1.13.1")
    }
}
