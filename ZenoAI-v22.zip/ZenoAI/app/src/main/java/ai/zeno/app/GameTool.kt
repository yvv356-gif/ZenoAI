package ai.zeno.app

/**
 * Outil « jeux ». Si la demande correspond à un jeu prêt à l'emploi (GameLib), l'IA le personnalise ;
 * sinon elle écrit un jeu HTML/JavaScript. Dans les deux cas, l'appli le lance dans une WebView isolée
 * (sans réseau) pour le tester sans rien installer, et peut l'exporter en APK.
 */
object GameTool {

    private val verbRx = Regex(
        "\\b(crée|cree|créer|creer|fais|fais-moi|faire|génère|genere|générer|generer|programme|développe|developpe|propose|donne|veux|voudrais|peux|jouer|make|create|build|write|want)\\b",
        RegexOption.IGNORE_CASE
    )
    private val nounRx = Regex(
        "\\b(jeu|jeux|mini-jeu|minijeu|game|snake|serpent|casse-?briques?|flappy|2048|morpion|tic-?tac-?toe|space invaders|invaders|pong|tetris|pacman|puzzle|labyrinthe|plateforme|platformer|runner|taupe|simon|d[ée]mineur|demineur|fps|doom|wolfenstein|mario|pacman|pac-man|shooter)\\b",
        RegexOption.IGNORE_CASE
    )
    private val otherLangRx = Regex(
        "\\b(python|kotlin|java|c\\+\\+|c#|unity|godot|lua|rust|swift|unreal|pygame)\\b",
        RegexOption.IGNORE_CASE
    )

    fun isRequest(text: String): Boolean {
        val t = text.trim()
        if (t.startsWith("/jeu", ignoreCase = true)) return true
        if (t.contains("```")) return false
        // Le verbe et le nom du jeu suffisent, même dans un long message (on regarde le début)
        val head = t.take(200)
        if (otherLangRx.containsMatchIn(head)) return false
        return verbRx.containsMatchIn(head) && nounRx.containsMatchIn(head)
    }

    fun request(text: String): String =
        text.trim().replace(Regex("^/jeu\\s*", RegexOption.IGNORE_CASE), "").trim()
}

/** Outil « site web » : l'IA écrit une page web complète, aperçue dans l'appli et exportable en APK. */
object SiteTool {
    private val verbRx = Regex("\\b(crée|cree|créer|creer|fais|fais-moi|faire|génère|genere|générer|programme|développe|developpe|construis|make|create|build)\\b", RegexOption.IGNORE_CASE)
    private val nounRx = Regex("\\b(site web|site internet|page web|landing page|site vitrine|mon site|un site)\\b", RegexOption.IGNORE_CASE)

    fun isRequest(text: String): Boolean {
        val t = text.trim()
        if (t.startsWith("/site", ignoreCase = true)) return true
        if (t.length > 300 || t.contains("```")) return false
        return verbRx.containsMatchIn(t) && nounRx.containsMatchIn(t)
    }

    fun request(text: String): String = text.trim().replace(Regex("^/site\\s*", RegexOption.IGNORE_CASE), "").trim()
}
