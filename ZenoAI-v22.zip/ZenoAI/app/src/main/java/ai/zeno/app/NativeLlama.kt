package ai.zeno.app

import android.content.ContentResolver
import android.net.Uri
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import org.nehuatl.llamacpp.LlamaAndroid
import java.io.File

/** Choix du nombre de threads : uniquement les cœurs rapides (les petits cœurs ralentissent tout le monde). */
object CpuPlan {
    fun threads(): Int {
        val cores = Runtime.getRuntime().availableProcessors()
        val freqs = (0 until cores).mapNotNull { i ->
            runCatching { File("/sys/devices/system/cpu/cpu$i/cpufreq/cpuinfo_max_freq").readText().trim().toLong() }.getOrNull()
        }
        if (freqs.size == cores && freqs.isNotEmpty()) {
            val max = freqs.max()
            return freqs.count { it >= max * 0.55 }.coerceIn(2, 8)
        }
        return (cores * 3 / 4).coerceIn(2, 8)
    }
}

/**
 * Accès direct au moteur llama.cpp (sans l'assistant LlamaHelper, qui impose ses réglages) :
 * nombre de threads et taille de lot choisis par ZenoAI. Le GPU n'est pas géré par cette version du moteur.
 */
class NativeLlama(private val resolver: ContentResolver) {
    private val llama = LlamaAndroid(resolver)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var id = -1
    @Volatile private var sink: ((String) -> Boolean)? = null
    @Volatile private var interrupted = false
    @Volatile private var lastToken = 0L
    @Volatile private var gotToken = false
    @Volatile private var signal: CompletableDeferred<Unit>? = null
    @Volatile private var running: Job? = null

    fun load(path: String, ctx: Int, threads: Int, batch: Int = 512) {
        val uri = Uri.fromFile(File(path))
        val pfd = resolver.openFileDescriptor(uri, "r") ?: error("Impossible d'ouvrir le modèle")
        val fd = pfd.detachFd()
        val config = hashMapOf<String, Any>(
            "model" to uri.toString(),
            "model_fd" to fd,
            "use_mmap" to true,
            "use_mlock" to false,
            "n_ctx" to ctx,
            "embedding" to false,
            "n_batch" to batch,
            "n_threads" to threads,
            "n_gpu_layers" to 0,
            "vocab_only" to false,
            "lora" to "",
            "lora_scaled" to 1.0f,
            "rope_freq_base" to 0.0f,
            "rope_freq_scale" to 0.0f,
            "mmproj_fd" to -1
        )
        val res = llama.startEngine(config) { tokenMap ->
            val tok = (tokenMap as? Map<*, *>)?.get("token") as? String
            // IMPORTANT : ce rappel tourne dans le fil du moteur. Il ne doit JAMAIS attendre l'arrêt
            // (c'était la cause des chargements sans fin) : il note seulement qu'il faut s'arrêter.
            if (tok != null && !interrupted) {
                lastToken = System.currentTimeMillis()
                gotToken = true
                if (sink?.invoke(tok) == false) {
                    interrupted = true
                    signal?.complete(Unit)
                }
            }
        }
        id = ((res as? Map<*, *>)?.get("contextId") as? Number)?.toInt() ?: error("Contexte non créé")
    }

    private fun requestStop() {
        val my = id
        scope.launch { runCatching { llama.stopCompletion(my) } }
    }

    /**
     * Génération. `onToken` renvoie false pour arrêter. Se termine toujours : arrêt demandé, fin normale,
     * annulation (bouton Stop), ou moteur bloqué (aucun mot pendant trop longtemps -> exception).
     */
    suspend fun generate(prompt: String, threads: Int, onToken: (String) -> Boolean) {
        // Un arrêt précédent peut encore se terminer côté moteur : on l'attend un peu
        running?.let { withTimeoutOrNull(30_000) { it.join() } }
        if (running?.isActive == true) error("moteur encore occupé")
        interrupted = false
        gotToken = false
        val sig = CompletableDeferred<Unit>()
        signal = sig
        sink = onToken
        lastToken = System.currentTimeMillis()
        val job = scope.launch {
            try {
                llama.launchCompletion(
                    id,
                    hashMapOf<String, Any>("prompt" to prompt, "emit_partial_completion" to true, "n_threads" to threads)
                )
            } catch (e: Throwable) {
                sig.completeExceptionally(e)
            } finally {
                sig.complete(Unit)
            }
        }
        running = job
        try {
            while (!sig.isCompleted) {
                withTimeoutOrNull(2_000) { sig.await() }
                if (sig.isCompleted) break
                val idle = System.currentTimeMillis() - lastToken
                // Le premier mot peut demander du temps (lecture du prompt), les suivants non
                if (idle > (if (gotToken) 90_000L else 300_000L)) {
                    interrupted = true
                    requestStop()
                    error("le moteur ne répond plus")
                }
            }
            sig.await() // relance l'erreur éventuelle du moteur
            if (interrupted) requestStop()
        } catch (e: CancellationException) {
            interrupted = true
            requestStop()
            throw e
        } finally {
            sink = null
        }
    }

    fun release() {
        interrupted = true
        if (id >= 0) {
            val my = id
            runCatching { runBlocking { withTimeoutOrNull(5_000) { running?.join() } } }
            runCatching { llama.releaseContext(my) }
        }
        id = -1
    }
}
