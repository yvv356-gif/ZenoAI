package ai.zeno.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

data class Slide(val title: String, val points: List<String>)
data class Deck(val title: String, val subtitle: String, val slides: List<Slide>)

/**
 * Présentations PowerPoint : l'IA écrit le plan en JSON ; l'appli fabrique un vrai fichier .pptx
 * (ouvrable dans PowerPoint, Google Slides, Keynote) et un aperçu à feuilleter dans l'appli.
 */
object Pptx {

    private val verbRx = Regex(
        "\\b(crée|cree|créer|creer|fais|fais-moi|faire|génère|genere|générer|generer|prépare|prepare|rédige|redige|make|create|build)\\b",
        RegexOption.IGNORE_CASE
    )
    private val nounRx = Regex(
        "(power ?point|\\bpptx?\\b|diaporama|\\bdiapos?\\b|\\bslides?\\b|présentation|presentation)",
        RegexOption.IGNORE_CASE
    )

    fun isRequest(text: String): Boolean {
        val t = text.trim()
        if (t.startsWith("/ppt", ignoreCase = true)) return true
        if (t.length > 400 || t.contains("```")) return false
        return verbRx.containsMatchIn(t) && nounRx.containsMatchIn(t)
    }

    fun request(text: String): String =
        text.trim().replace(Regex("^/ppt\\s*", RegexOption.IGNORE_CASE), "").trim()

    private const val SYSTEM =
        "Tu crées des présentations PowerPoint. Réponds uniquement avec un JSON, sans texte autour : " +
            "{\"titre\":\"titre de la présentation\",\"soustitre\":\"une courte phrase\"," +
            "\"diapos\":[{\"titre\":\"titre de la diapo\",\"points\":[\"idée courte\",\"idée courte\",\"idée courte\"]}]}. " +
            "5 à 7 diapos, 3 à 5 points par diapo, chaque point de 12 mots maximum, dans la langue de la demande."

    fun prompt(template: String, request: String): String =
        PromptBuilder.wrap(template, SYSTEM, "Sujet : ${request.take(300)}\nRéponds uniquement avec le JSON.")

    /** Lit la réponse du modèle ; null si elle ne contient aucune diapo exploitable. */
    fun parse(raw: String, fallbackTitle: String): Deck? = runCatching {
        val obj = JSONObject(Regex("\\{[\\s\\S]*\\}").find(raw)?.value ?: return null)
        val arr = obj.optJSONArray("diapos") ?: obj.optJSONArray("slides") ?: return null
        val slides = mutableListOf<Slide>()
        for (i in 0 until minOf(arr.length(), 12)) {
            val o = arr.optJSONObject(i) ?: continue
            val title = o.optString("titre", o.optString("title")).trim()
            val pts = o.optJSONArray("points") ?: o.optJSONArray("bullets") ?: JSONArray()
            val list = (0 until minOf(pts.length(), 6)).map { pts.optString(it).trim().take(140) }.filter { it.isNotBlank() }
            if (title.isNotBlank() && list.isNotEmpty()) slides += Slide(title.take(80), list)
        }
        if (slides.isEmpty()) return null
        Deck(
            obj.optString("titre", obj.optString("title")).trim().ifBlank { fallbackTitle }.take(80),
            obj.optString("soustitre", obj.optString("subtitle")).trim().take(120),
            slides
        )
    }.getOrNull()

    // ---------- Fichier .pptx ----------

    private const val HDR = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"
    private const val NS = "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
        "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
        "xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\""
    private const val REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val RELS_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
    private const val CT = "application/vnd.openxmlformats-officedocument.presentationml"
    private const val GRP = "<p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm>" +
        "<a:off x=\"0\" y=\"0\"/><a:ext cx=\"0\" cy=\"0\"/><a:chOff x=\"0\" y=\"0\"/><a:chExt cx=\"0\" cy=\"0\"/></a:xfrm></p:grpSpPr>"

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun contentTypes(n: Int): String {
        val sb = StringBuilder(HDR)
        sb.append("<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">")
        sb.append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>")
        sb.append("<Default Extension=\"xml\" ContentType=\"application/xml\"/>")
        sb.append("<Override PartName=\"/ppt/presentation.xml\" ContentType=\"$CT.presentation.main+xml\"/>")
        sb.append("<Override PartName=\"/ppt/slideMasters/slideMaster1.xml\" ContentType=\"$CT.slideMaster+xml\"/>")
        sb.append("<Override PartName=\"/ppt/slideLayouts/slideLayout1.xml\" ContentType=\"$CT.slideLayout+xml\"/>")
        sb.append("<Override PartName=\"/ppt/theme/theme1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.theme+xml\"/>")
        for (i in 1..n) sb.append("<Override PartName=\"/ppt/slides/slide$i.xml\" ContentType=\"$CT.slide+xml\"/>")
        return sb.append("</Types>").toString()
    }

    private val ROOT_RELS = HDR + "<Relationships xmlns=\"$RELS_NS\"><Relationship Id=\"rId1\" " +
        "Type=\"$REL/officeDocument\" Target=\"ppt/presentation.xml\"/></Relationships>"

    private fun presentation(n: Int): String {
        val sb = StringBuilder(HDR)
        sb.append("<p:presentation $NS><p:sldMasterIdLst><p:sldMasterId id=\"2147483648\" r:id=\"rId1\"/></p:sldMasterIdLst><p:sldIdLst>")
        for (i in 1..n) sb.append("<p:sldId id=\"${255 + i}\" r:id=\"rId${i + 1}\"/>")
        sb.append("</p:sldIdLst><p:sldSz cx=\"12192000\" cy=\"6858000\"/><p:notesSz cx=\"6858000\" cy=\"9144000\"/></p:presentation>")
        return sb.toString()
    }

    private fun presRels(n: Int): String {
        val sb = StringBuilder(HDR)
        sb.append("<Relationships xmlns=\"$RELS_NS\"><Relationship Id=\"rId1\" Type=\"$REL/slideMaster\" Target=\"slideMasters/slideMaster1.xml\"/>")
        for (i in 1..n) sb.append("<Relationship Id=\"rId${i + 1}\" Type=\"$REL/slide\" Target=\"slides/slide$i.xml\"/>")
        return sb.append("</Relationships>").toString()
    }

    private val MASTER = HDR + "<p:sldMaster $NS><p:cSld><p:bg><p:bgRef idx=\"1001\"><a:schemeClr val=\"bg1\"/></p:bgRef></p:bg>" +
        "<p:spTree>$GRP</p:spTree></p:cSld><p:clrMap bg1=\"lt1\" tx1=\"dk1\" bg2=\"lt2\" tx2=\"dk2\" accent1=\"accent1\" accent2=\"accent2\" " +
        "accent3=\"accent3\" accent4=\"accent4\" accent5=\"accent5\" accent6=\"accent6\" hlink=\"hlink\" folHlink=\"folHlink\"/>" +
        "<p:sldLayoutIdLst><p:sldLayoutId id=\"2147483649\" r:id=\"rId1\"/></p:sldLayoutIdLst></p:sldMaster>"

    private val MASTER_RELS = HDR + "<Relationships xmlns=\"$RELS_NS\"><Relationship Id=\"rId1\" Type=\"$REL/slideLayout\" " +
        "Target=\"../slideLayouts/slideLayout1.xml\"/><Relationship Id=\"rId2\" Type=\"$REL/theme\" Target=\"../theme/theme1.xml\"/></Relationships>"

    private val LAYOUT = HDR + "<p:sldLayout $NS type=\"blank\" preserve=\"1\"><p:cSld name=\"Vide\"><p:spTree>$GRP</p:spTree></p:cSld>" +
        "<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>"

    private val LAYOUT_RELS = HDR + "<Relationships xmlns=\"$RELS_NS\"><Relationship Id=\"rId1\" Type=\"$REL/slideMaster\" " +
        "Target=\"../slideMasters/slideMaster1.xml\"/></Relationships>"

    private const val LN = "<a:ln w=\"9525\" cap=\"flat\" cmpd=\"sng\" algn=\"ctr\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill><a:prstDash val=\"solid\"/></a:ln>"
    private const val FILL = "<a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill>"
    private const val EFF = "<a:effectStyle><a:effectLst/></a:effectStyle>"

    private val THEME = HDR + "<a:theme xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" name=\"Zeno\"><a:themeElements>" +
        "<a:clrScheme name=\"Zeno\"><a:dk1><a:srgbClr val=\"1F2A44\"/></a:dk1><a:lt1><a:srgbClr val=\"FFFFFF\"/></a:lt1>" +
        "<a:dk2><a:srgbClr val=\"3A4565\"/></a:dk2><a:lt2><a:srgbClr val=\"F3F5FA\"/></a:lt2>" +
        "<a:accent1><a:srgbClr val=\"3FA7B8\"/></a:accent1><a:accent2><a:srgbClr val=\"7C6FD6\"/></a:accent2>" +
        "<a:accent3><a:srgbClr val=\"E4875B\"/></a:accent3><a:accent4><a:srgbClr val=\"6BBF8A\"/></a:accent4>" +
        "<a:accent5><a:srgbClr val=\"E0B84C\"/></a:accent5><a:accent6><a:srgbClr val=\"D2678E\"/></a:accent6>" +
        "<a:hlink><a:srgbClr val=\"3FA7B8\"/></a:hlink><a:folHlink><a:srgbClr val=\"7C6FD6\"/></a:folHlink></a:clrScheme>" +
        "<a:fontScheme name=\"Zeno\"><a:majorFont><a:latin typeface=\"Calibri\"/><a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:majorFont>" +
        "<a:minorFont><a:latin typeface=\"Calibri\"/><a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:minorFont></a:fontScheme>" +
        "<a:fmtScheme name=\"Zeno\"><a:fillStyleLst>$FILL$FILL$FILL</a:fillStyleLst><a:lnStyleLst>$LN$LN$LN</a:lnStyleLst>" +
        "<a:effectStyleLst>$EFF$EFF$EFF</a:effectStyleLst><a:bgFillStyleLst>$FILL$FILL$FILL</a:bgFillStyleLst></a:fmtScheme>" +
        "</a:themeElements></a:theme>"

    private val SLIDE_RELS = HDR + "<Relationships xmlns=\"$RELS_NS\"><Relationship Id=\"rId1\" Type=\"$REL/slideLayout\" " +
        "Target=\"../slideLayouts/slideLayout1.xml\"/></Relationships>"

    private fun rect(id: Int, x: Int, y: Int, w: Int, h: Int, fill: String) =
        "<p:sp><p:nvSpPr><p:cNvPr id=\"$id\" name=\"Forme $id\"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x=\"$x\" y=\"$y\"/>" +
            "<a:ext cx=\"$w\" cy=\"$h\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val=\"$fill\"/></a:solidFill>" +
            "<a:ln><a:noFill/></a:ln></p:spPr></p:sp>"

    private fun textbox(id: Int, x: Int, y: Int, w: Int, h: Int, paras: String, anchor: String = "t") =
        "<p:sp><p:nvSpPr><p:cNvPr id=\"$id\" name=\"Texte $id\"/><p:cNvSpPr txBox=\"1\"/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x=\"$x\" y=\"$y\"/>" +
            "<a:ext cx=\"$w\" cy=\"$h\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom><a:noFill/></p:spPr><p:txBody>" +
            "<a:bodyPr wrap=\"square\" lIns=\"0\" rIns=\"0\" anchor=\"$anchor\"><a:normAutofit/></a:bodyPr><a:lstStyle/>$paras</p:txBody></p:sp>"

    private fun para(text: String, size: Int, color: String, bold: Boolean = false, bullet: Boolean = false, after: Int = 0): String {
        val ppr = if (bullet)
            "<a:pPr marL=\"342900\" indent=\"-342900\"><a:spcAft><a:spcPts val=\"$after\"/></a:spcAft><a:buClr><a:srgbClr val=\"3FA7B8\"/></a:buClr>" +
                "<a:buFont typeface=\"Arial\"/><a:buChar char=\"&#8226;\"/></a:pPr>"
        else "<a:pPr marL=\"0\" indent=\"0\"><a:spcAft><a:spcPts val=\"$after\"/></a:spcAft><a:buNone/></a:pPr>"
        return "<a:p>$ppr<a:r><a:rPr lang=\"fr-FR\" sz=\"${size * 100}\" b=\"${if (bold) 1 else 0}\" dirty=\"0\"><a:solidFill><a:srgbClr val=\"$color\"/>" +
            "</a:solidFill></a:rPr><a:t>${esc(text)}</a:t></a:r></a:p>"
    }

    private fun slideXml(inner: String, bg: String) =
        HDR + "<p:sld $NS><p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val=\"$bg\"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>" +
            "<p:spTree>$GRP$inner</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>"

    private fun titleSlide(title: String, sub: String) = slideXml(
        rect(2, 0, 0, 12192000, 6858000, "1F2A44") + rect(3, 914400, 3200400, 1371600, 73152, "3FA7B8") +
            textbox(4, 914400, 1371600, 10363200, 1737360, para(title, 44, "FFFFFF", true), "b") +
            textbox(5, 914400, 3474720, 10363200, 1371600, para(sub, 22, "C9D1E8")),
        "1F2A44"
    )

    private fun contentSlide(title: String, points: List<String>): String {
        val body = points.joinToString("") { para(it, 22, "2B3350", false, true, 1000) }
        return slideXml(
            rect(2, 0, 0, 12192000, 137160, "3FA7B8") +
                textbox(3, 685800, 411480, 10820400, 1005840, para(title, 34, "1F2A44", true), "ctr") +
                rect(4, 685800, 1417320, 1097280, 45720, "7C6FD6") +
                textbox(5, 685800, 1737360, 10820400, 4572000, body),
            "FFFFFF"
        )
    }

    fun write(deck: Deck, file: File) {
        file.parentFile?.mkdirs()
        val n = deck.slides.size + 1
        ZipOutputStream(file.outputStream().buffered()).use { z ->
            fun put(name: String, text: String) {
                z.putNextEntry(ZipEntry(name))
                z.write(text.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
            put("[Content_Types].xml", contentTypes(n))
            put("_rels/.rels", ROOT_RELS)
            put("ppt/presentation.xml", presentation(n))
            put("ppt/_rels/presentation.xml.rels", presRels(n))
            put("ppt/slideMasters/slideMaster1.xml", MASTER)
            put("ppt/slideMasters/_rels/slideMaster1.xml.rels", MASTER_RELS)
            put("ppt/slideLayouts/slideLayout1.xml", LAYOUT)
            put("ppt/slideLayouts/_rels/slideLayout1.xml.rels", LAYOUT_RELS)
            put("ppt/theme/theme1.xml", THEME)
            put("ppt/slides/slide1.xml", titleSlide(deck.title, deck.subtitle))
            put("ppt/slides/_rels/slide1.xml.rels", SLIDE_RELS)
            deck.slides.forEachIndexed { i, s ->
                put("ppt/slides/slide${i + 2}.xml", contentSlide(s.title, s.points))
                put("ppt/slides/_rels/slide${i + 2}.xml.rels", SLIDE_RELS)
            }
        }
    }

    fun fileName(title: String): String {
        val safe = title.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').take(24).ifBlank { "presentation" }
        return "Zeno_${safe}_${System.currentTimeMillis() % 100000}.pptx"
    }

    // ---------- Aperçu à feuilleter ----------

    fun preview(deck: Deck): String {
        val data = JSONObject()
            .put("t", deck.title).put("s", deck.subtitle)
            .put("d", JSONArray(deck.slides.map { JSONObject().put("t", it.title).put("p", JSONArray(it.points)) }))
            .toString().replace("</", "<\\/")
        return PAGE.replace("__DATA__", data)
    }

    private val PAGE = """<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>html,body{margin:0;height:100%;background:#0e1018;font-family:sans-serif;overflow:hidden}
#w{position:absolute;inset:0 0 64px 0;display:flex;align-items:center;justify-content:center}
#s{width:min(96vw,calc((100vh - 90px)*1.7778));aspect-ratio:16/9;background:#fff;border-radius:10px;overflow:hidden;position:relative;container-type:inline-size;box-shadow:0 8px 30px #0008}
.bar{position:absolute;left:0;top:0;right:0;height:2%;background:#3FA7B8}
.tt{position:absolute;left:5.6%;right:5.6%;top:6%;height:15%;display:flex;align-items:center;font-weight:bold;font-size:4.6cqw;color:#1F2A44}
.ul{position:absolute;left:5.6%;top:21%;width:9%;height:0.7%;background:#7C6FD6}
.ls{position:absolute;left:5.6%;right:5.6%;top:27%;margin:0;padding:0;list-style:none;font-size:3cqw;color:#2B3350}
.ls li{margin:0 0 2.2cqw;padding-left:4cqw;position:relative;line-height:1.25}
.ls li:before{content:"";position:absolute;left:1cqw;top:1.2cqw;width:1cqw;height:1cqw;border-radius:50%;background:#3FA7B8}
.cover{background:#1F2A44}.cover .big{position:absolute;left:7.5%;right:7.5%;top:20%;height:26%;display:flex;align-items:flex-end;font-weight:bold;font-size:6.4cqw;color:#fff}
.cover .ac{position:absolute;left:7.5%;top:50%;width:11%;height:1.1%;background:#3FA7B8}.cover .sub{position:absolute;left:7.5%;right:7.5%;top:54%;font-size:3.1cqw;color:#C9D1E8}
#c{position:fixed;left:0;right:0;bottom:0;height:64px;display:flex;align-items:center;justify-content:center;gap:16px;color:#cfd3ff}
button{background:#2b3050;color:#fff;border:0;border-radius:16px;padding:12px 22px;font-size:16px}</style></head><body>
<div id="w"><div id="s"></div></div>
<div id="c"><button onclick="go(-1)">◀</button><span id="n"></span><button onclick="go(1)">▶</button></div>
<script>
var D=__DATA__,i=0,s=document.getElementById('s');
function x(t){var d=document.createElement('div');d.textContent=t;return d.innerHTML}
function show(){var h='';
 if(i==0){h='<div class="cover" style="position:absolute;inset:0"><div class="big">'+x(D.t)+'</div><div class="ac"></div><div class="sub">'+x(D.s)+'</div></div>'}
 else{var sl=D.d[i-1];h='<div class="bar"></div><div class="tt">'+x(sl.t)+'</div><div class="ul"></div><ul class="ls">'+sl.p.map(function(p){return '<li>'+x(p)+'</li>'}).join('')+'</ul>'}
 s.innerHTML=h;document.getElementById('n').textContent=(i+1)+' / '+(D.d.length+1)}
function go(k){i=Math.max(0,Math.min(D.d.length,i+k));show()}
var sx=0;document.addEventListener('touchstart',function(e){sx=e.touches[0].clientX});
document.addEventListener('touchend',function(e){var d=e.changedTouches[0].clientX-sx;if(Math.abs(d)>50)go(d<0?1:-1)});
document.addEventListener('keydown',function(e){if(e.key=='ArrowRight')go(1);if(e.key=='ArrowLeft')go(-1)});
show();
</script></body></html>"""
}
