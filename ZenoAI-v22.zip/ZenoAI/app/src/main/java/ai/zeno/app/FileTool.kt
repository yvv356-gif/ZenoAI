package ai.zeno.app

import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Un fichier à créer : chemin relatif (avec dossiers) et contenu. */
data class ProjFile(val path: String, val content: String)

/**
 * Dossiers, fichiers et archives ZIP : l'IA écrit les fichiers (avec leurs dossiers),
 * l'appli les crée sur le téléphone, les range dans un ZIP et propose de l'enregistrer.
 */
object FileTool {

    private val verbRx = Regex(
        "\\b(crée|cree|créer|creer|fais|fais-moi|faire|génère|genere|générer|generer|prépare|prepare|écris|ecris|make|create|generate)\\b",
        RegexOption.IGNORE_CASE
    )
    private val nounRx = Regex(
        "(\\bdossiers?\\b|\\bzip\\b|archive|\\bfichiers?\\b|arborescence|\\bprojet\\b|\\bfolders?\\b|\\bfiles?\\b)",
        RegexOption.IGNORE_CASE
    )
    private val otherRx = Regex(
        "\\b(jeu|jeux|game|site web|site internet|page web|powerpoint|power point|pptx|diaporama|présentation|presentation|3d|image|dessin|cartes? mémoire|flashcards?)\\b",
        RegexOption.IGNORE_CASE
    )

    fun isRequest(text: String): Boolean {
        val t = text.trim()
        if (t.startsWith("/fichier", ignoreCase = true) || t.startsWith("/zip", ignoreCase = true)) return true
        if (t.length > 500 || t.contains("```")) return false
        if (otherRx.containsMatchIn(t)) return false
        return verbRx.containsMatchIn(t) && nounRx.containsMatchIn(t)
    }

    fun request(text: String): String =
        text.trim().replace(Regex("^/(fichier|zip)\\s*", RegexOption.IGNORE_CASE), "").trim()

    private const val SYSTEM =
        "Tu crées des fichiers et des dossiers. Réponds uniquement avec ce format, sans aucun autre texte : " +
            "chaque fichier commence par une ligne « ### chemin/du/fichier.ext » (les dossiers font partie du chemin, " +
            "ex. src/main.py), suivie du contenu complet du fichier. Exemple :\n" +
            "### README.md\nContenu du readme\n### src/main.py\nprint('bonjour')\n" +
            "Pas de balises ```. 1 à 8 fichiers, contenus courts et fonctionnels."

    fun prompt(template: String, request: String): String =
        PromptBuilder.wrap(template, SYSTEM, "Demande : ${request.take(400)}\nRéponds uniquement avec les fichiers au format indiqué.")

    private fun cleanPath(raw: String): String? {
        val p = raw.trim().trim('`', '"', '\'', '*').replace('\\', '/').trimStart('/')
        val parts = p.split('/').filter { it.isNotBlank() && it != "." }
        if (parts.isEmpty() || parts.any { it == ".." } || parts.size > 6) return null
        val safe = parts.map { seg -> seg.filter { it.isLetterOrDigit() || it in "._- " }.trim().take(60) }
        if (safe.any { it.isBlank() }) return null
        return safe.joinToString("/").take(150)
    }

    /** Fichiers lus dans la réponse du modèle ; liste vide si le format n'est pas respecté. */
    fun parse(raw: String): List<ProjFile> {
        val head = Regex("(?m)^#{2,4}\\s*(.+?)\\s*$")
        val marks = head.findAll(raw).toList()
        val out = mutableListOf<ProjFile>()
        for ((i, m) in marks.withIndex()) {
            val path = cleanPath(m.groupValues[1]) ?: continue
            if (!path.substringAfterLast('/').contains('.')) continue
            val end = if (i + 1 < marks.size) marks[i + 1].range.first else raw.length
            var body = raw.substring(m.range.last + 1, end).trim('\n', '\r')
            body = body.lines().filter { !it.trimStart().startsWith("```") }.joinToString("\n").trimEnd()
            if (body.isBlank()) continue
            if (out.none { it.path == path }) out += ProjFile(path, body.take(100_000))
            if (out.size >= 25) break
        }
        return out
    }

    fun projectName(request: String): String =
        request.lowercase().replace(Regex("[^a-z0-9àâçéèêëîïôûùüÿ]+"), "_").trim('_').take(24).ifBlank { "projet" }

    /** Écrit les dossiers et fichiers, puis le ZIP. Renvoie le fichier à proposer (ZIP, ou le fichier seul s'il n'y en a qu'un à la racine). */
    fun write(base: File, name: String, files: List<ProjFile>): File {
        val stamp = System.currentTimeMillis() % 100000
        val root = File(base, "${name}_$stamp")
        for (f in files) {
            val dest = File(root, f.path)
            if (!dest.canonicalPath.startsWith(root.canonicalPath)) continue
            dest.parentFile?.mkdirs()
            dest.writeText(f.content)
        }
        if (files.size == 1 && !files[0].path.contains('/')) {
            val single = File(base, files[0].path)
            single.parentFile?.mkdirs()
            File(root, files[0].path).copyTo(single, overwrite = true)
            return single
        }
        val zip = File(base, "$name.zip".let { "${name}_$stamp.zip" })
        ZipOutputStream(zip.outputStream().buffered()).use { z ->
            val dirs = mutableSetOf<String>()
            for (f in files) {
                var d = ""
                for (seg in f.path.split('/').dropLast(1)) {
                    d += "$seg/"
                    if (dirs.add(d)) { z.putNextEntry(ZipEntry("$name/$d")); z.closeEntry() }
                }
                z.putNextEntry(ZipEntry("$name/${f.path}"))
                z.write(f.content.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
        }
        return zip
    }

    /** Arborescence lisible : dossiers et fichiers. */
    fun tree(name: String, files: List<ProjFile>): String {
        val sb = StringBuilder("$name/\n")
        val seen = mutableSetOf<String>()
        for (f in files.sortedBy { it.path }) {
            val parts = f.path.split('/')
            var d = ""
            for ((i, seg) in parts.withIndex()) {
                d += "$seg/"
                val last = i == parts.size - 1
                if (last) sb.append("  ".repeat(i + 1)).append(seg).append('\n')
                else if (seen.add(d)) sb.append("  ".repeat(i + 1)).append(seg).append("/\n")
            }
        }
        return sb.toString().trimEnd()
    }

    /** Si le projet contient un index.html, une page autonome (css et js locaux intégrés) à jouer dans l'appli. */
    fun webPage(files: List<ProjFile>): String? {
        val index = files.firstOrNull { it.path.equals("index.html", true) || it.path.endsWith("/index.html", true) } ?: return null
        val dir = index.path.substringBeforeLast('/', "")
        fun find(ref: String): String? {
            val p = (if (dir.isEmpty()) ref else "$dir/$ref").removePrefix("./")
            return files.firstOrNull { it.path.equals(p, true) || it.path.equals(ref.removePrefix("./"), true) }?.content
        }
        var html = index.content
        html = Regex("<link[^>]+href=[\"']([^\"']+\\.css)[\"'][^>]*>", RegexOption.IGNORE_CASE).replace(html) { m ->
            find(m.groupValues[1])?.let { "<style>$it</style>" } ?: m.value
        }
        html = Regex("<script[^>]+src=[\"']([^\"']+\\.js)[\"'][^>]*>\\s*</script>", RegexOption.IGNORE_CASE).replace(html) { m ->
            find(m.groupValues[1])?.let { "<script>${it.replace("</", "<\\/")}</script>" } ?: m.value
        }
        return html
    }

    fun mimeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        "zip" -> "application/zip"
        "stl" -> "model/stl"
        "txt", "md", "py", "kt", "java", "js", "css", "csv", "xml", "yml", "yaml", "toml", "ini", "sh" -> "text/plain"
        "html", "htm" -> "text/html"
        "json" -> "application/json"
        else -> "application/octet-stream"
    }
}
