package ai.zeno.app

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color as AndroidColor
import android.os.Bundle
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import ai.zeno.app.ui.ChatScreen
import ai.zeno.app.ui.ZenoTheme
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        installCrashReporter()
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(AndroidColor.TRANSPARENT, AndroidColor.TRANSPARENT)
        )
        setContent {
            ZenoTheme {
                val vm: ChatViewModel = viewModel()
                ChatScreen(vm)
            }
        }
        showLastCrash()
    }

    /** Écrit la cause d'un plantage dans un fichier, pour l'afficher au lancement suivant. */
    private fun installCrashReporter() {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            runCatching {
                File(filesDir, "crash.txt").writeText(
                    "Thread : ${t.name}\n" + android.util.Log.getStackTraceString(e).take(6000)
                )
            }
            previous?.uncaughtException(t, e)
        }
    }

    private fun showLastCrash() {
        val f = File(filesDir, "crash.txt")
        if (!f.exists()) return
        val txt = runCatching { f.readText() }.getOrDefault("")
        f.delete()
        if (txt.isBlank()) return
        val view = TextView(this).apply {
            text = txt
            textSize = 11f
            setTextIsSelectable(true)
            setPadding(32, 24, 32, 24)
        }
        val scroll = android.widget.ScrollView(this).apply { addView(view) }
        AlertDialog.Builder(this)
            .setTitle("Zeno a planté la dernière fois")
            .setView(scroll)
            .setPositiveButton("Copier") { _, _ ->
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("crash", txt))
            }
            .setNegativeButton("Fermer", null)
            .show()
    }
}
