package ai.zeno.app

import kotlinx.coroutines.delay
import org.json.JSONObject

/**
 * Contrôle du téléphone, en langage naturel : « ouvre les paramètres », « active le wifi »,
 * « lance YouTube »… (« /tel … » reste accepté mais n'est plus nécessaire).
 */
object PhoneCmd {
    private val cmdRx = Regex("^/(tel|telephone|téléphone)\\b", RegexOption.IGNORE_CASE)
    private val verbRx = Regex(
        "^(?:(?:s'il te plaît|stp|peux-tu|tu peux|zeno)[ ,]+)*(ouvre|ouvrir|lance|lancer|démarre|demarre|active|activer|désactive|desactive|coupe|mets|met|baisse|monte|augmente|diminue|va dans|va sur|vas dans|appuie|clique|touche|retourne|reviens|ferme|éteins|allume|appelle|envoie|écris sur|scrolle|fais défiler)\\b",
        RegexOption.IGNORE_CASE
    )
    private val targetRx = Regex(
        "\\b(paramètres?|parametres?|réglages?|reglages?|wi-?fi|bluetooth|données mobiles|mode avion|ne pas déranger|luminosité|volume|lampe|torche|écran d'accueil|ecran d'accueil|appli(?:cation)?|calculatrice|caméra|camera|appareil photo|galerie|photos|horloge|alarme|contacts|messages|sms|téléphone|telephone|whatsapp|youtube|chrome|play store|maps|spotify|instagram|tiktok|snapchat|facebook|netflix|gmail|agenda|calendrier|notes|fichiers)\\b",
        RegexOption.IGNORE_CASE
    )
    private val phoneRx = Regex("\\b(sur|de) (mon|ma) (tel|téléphone|telephone|portable|écran)\\b", RegexOption.IGNORE_CASE)

    fun isRequest(text: String): Boolean {
        val t = text.trim()
        if (cmdRx.containsMatchIn(t)) return true
        if (t.length > 160 || t.contains("```") || Regex("https?://|www\\.|\\.(com|fr|org|net)\\b", RegexOption.IGNORE_CASE).containsMatchIn(t)) return false
        if (Regex("\\b(jeu|jeux|site|image|dessin|carte|cartes|modèle 3d|objet 3d)\\b", RegexOption.IGNORE_CASE).containsMatchIn(t)) return false
        return (verbRx.containsMatchIn(t) && targetRx.containsMatchIn(t)) ||
            (phoneRx.containsMatchIn(t) && verbRx.containsMatchIn(t))
    }

    fun request(text: String): String = text.trim().replace(cmdRx, "").trim()
}

/**
 * Ce que l'agent peut regarder et faire : la page du navigateur intégré (WebDriver)
 * ou l'écran du téléphone (PhoneDriver). La même boucle pilote les deux.
 */
interface Driver {
    /** Description lisible de ce qui est affiché : texte + éléments numérotés, en JSON. */
    suspend fun snapshot(): String

    /** Exécute une action du modèle et renvoie un court compte rendu (ok, élément introuvable…). */
    suspend fun perform(action: JSONObject): String
}

object ActLoop {

    /** Une action à la fois. Le modèle répond uniquement par un JSON. */
    fun webSystem(): String =
        "Tu pilotes un navigateur web pour l'utilisateur. Tu vois le titre, le texte de la page et des éléments numérotés. " +
            "Réponds uniquement avec un JSON, une seule action à la fois : " +
            "{\"action\":\"click\"|\"type\"|\"scroll\"|\"goto\"|\"done\",\"id\":numéro,\"text\":\"...\",\"enter\":true|false,\"dir\":\"down\"|\"up\",\"url\":\"https://...\",\"answer\":\"...\"}. " +
            "click : clique sur l'élément id (lien, bouton). type : écrit text dans le champ id, enter=true pour valider la recherche. " +
            "scroll : fait défiler. goto : ouvre une autre adresse. " +
            "done : la tâche est finie ; écris dans answer la réponse à l'utilisateur, en français, en 1 à 5 phrases, avec les infos trouvées."

    fun phoneSystem(): String =
        "Tu pilotes le téléphone Android de l'utilisateur. Tu vois le nom de l'appli au premier plan et les éléments numérotés de l'écran. " +
            "Réponds uniquement avec un JSON, une seule action à la fois : " +
            "{\"action\":\"click\"|\"type\"|\"scroll\"|\"back\"|\"home\"|\"open\"|\"done\",\"id\":numéro,\"text\":\"...\",\"dir\":\"down\"|\"up\",\"answer\":\"...\"}. " +
            "click : touche l'élément id. type : écrit text dans le champ id. scroll : fait défiler. back : bouton retour. home : accueil. " +
            "open : ouvre l'appli nommée dans text. done : la tâche est finie ; answer = compte rendu en français."

    /** Premier objet JSON trouvé dans la réponse du modèle, ou null. */
    fun parseAction(raw: String): JSONObject? = runCatching {
        val m = Regex("\\{[\\s\\S]*\\}").find(raw)?.value ?: return null
        JSONObject(m)
    }.getOrNull()

    /**
     * Boucle : observer → décider → agir, jusqu'à « done » ou à la limite d'étapes.
     * status(...) met à jour la barre de statut visible ; ask(prompt) interroge le modèle local.
     * Renvoie la réponse finale (vide si la tâche n'a pas été terminée).
     */
    suspend fun run(
        task: String,
        driver: Driver,
        system: String,
        template: String,
        maxSteps: Int,
        ask: suspend (String) -> String,
        status: (String) -> Unit,
        log: MutableList<String>
    ): String {
        for (step in 1..maxSteps) {
            status("étape $step/$maxSteps : je regarde l'écran…")
            val snap = driver.snapshot()
            if (snap.isBlank()) return "Je ne vois pas l'écran pour le moment."
            // Le modèle local a une mémoire courte : on ne lui donne que le début de l'écran
            val user = "Tâche : ${task.take(300)}\n" +
                "Écran : ${snap.take(1800)}\n" +
                "Actions déjà faites : ${if (log.isEmpty()) "(aucune)" else log.takeLast(6).joinToString(" ; ")}\n" +
                "Quelle est la prochaine action ?"
            status("étape $step/$maxSteps : je réfléchis…")
            val raw = ask(PromptBuilder.wrap(template, system, user))
            val a = parseAction(raw) ?: JSONObject().put("action", "done").put("answer", raw.trim().take(600))
            val kind = a.optString("action")
            if (kind == "done") return a.optString("answer").ifBlank { "Tâche terminée." }
            val what = when (kind) {
                "click" -> "je clique sur ${a.optString("id")}"
                "type" -> "j'écris « ${a.optString("text").take(30)} »"
                "scroll" -> "je fais défiler"
                "goto" -> "j'ouvre ${a.optString("url").take(50)}"
                "open" -> "j'ouvre ${a.optString("text").take(30)}"
                "back" -> "retour"
                "home" -> "accueil"
                else -> "action inconnue"
            }
            status("étape $step/$maxSteps : $what")
            val result = driver.perform(a)
            log += "$kind ${a.optString("id")} → $result"
        }
        return ""
    }
}
