package ai.zeno.app

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.lang.reflect.InvocationTargetException

enum class LogLevel { LOG, INFO, WARN, ERROR, SYSTEM }

data class LogLine(val level: LogLevel, val text: String)

/** Langages qu'on sait exécuter dans l'appli. */
enum class RunKind { PAGE, JS, PYTHON }

object CodeRunner {

    const val JS_TIMEOUT_MS = 10_000L
    const val JS_IDLE_MS = 1_500L
    const val PY_TIMEOUT_S = 15

    /** Ce qu'on peut lancer pour ce bloc, ou null (Kotlin, Java, C… : pas de compilateur sur le téléphone). */
    fun kindFor(lang: String, code: String): RunKind? {
        val l = lang.trim().lowercase()
        return when {
            l == "html" || l == "htm" || code.contains("<!doctype html", true) || code.contains("<html", true) ||
                code.contains("<canvas", true) -> RunKind.PAGE
            l in setOf("javascript", "js", "node", "mjs") -> RunKind.JS
            l in setOf("python", "py", "python3") -> RunKind.PYTHON
            else -> null
        }
    }

    /** Le script commence à la ligne 1 : les numéros de ligne des erreurs correspondent au code affiché. */
    fun jsPage(code: String): String =
        "<!DOCTYPE html><meta charset=\"utf-8\"><script>" + code.replace("</", "<\\/") + "\n</script>"

    /** HTML : viewport mobile, balises <script> non fermées (réponse coupée) refermées. */
    fun preparePage(src: String): String {
        var h = src.trim()
        val meta = "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
        h = when {
            h.contains("viewport", true) -> h
            h.contains("<head>", true) -> h.replaceFirst(Regex("<head>", RegexOption.IGNORE_CASE), "<head>" + meta)
            h.startsWith("<!doctype", true) -> h
            else -> meta + "\n" + h
        }
        val open = Regex("<script", RegexOption.IGNORE_CASE).findAll(h).count()
        val close = Regex("</script", RegexOption.IGNORE_CASE).findAll(h).count()
        if (open > close) h += "\n</script>"
        return h
    }

    /** Explication ajoutée sous une erreur quand la cause est classique. */
    fun hint(kind: RunKind, message: String): String? = when {
        kind == RunKind.JS && Regex("(require|process|module|exports) is not defined").containsMatchIn(message) ->
            "Ce code est écrit pour Node.js. Ici, seul le JavaScript « navigateur » est disponible (pas de require, fs ni process)."
        kind == RunKind.PYTHON && message.contains("input()") ->
            "input() n'est pas disponible ici : mets les valeurs directement dans le code."
        kind == RunKind.PYTHON && Regex("No module named '(\\w+)'").containsMatchIn(message) ->
            "Ce module n'est pas installé dans l'interpréteur embarqué (bibliothèque standard seulement, sauf ajout dans build.gradle)."
        else -> null
    }
}

class PyResult(
    val available: Boolean,
    val output: String = "",
    val error: String? = null,
    val timedOut: Boolean = false
)

/**
 * Python sur le téléphone via Chaquopy (https://chaquo.com/chaquopy/), branché par réflexion : si la
 * bibliothèque n'est pas dans l'appli, le bouton Exécuter l'explique au lieu de faire planter la compilation.
 * Voir optional-python/LISEZMOI.md pour l'activer.
 * Attention : contrairement au JavaScript (WebView isolée), le script tourne dans le processus de l'appli,
 * avec ses droits (réseau, fichiers de l'appli). On ne lance donc que sur appui du bouton, jamais automatiquement.
 */
object PythonBackend {

    fun isAvailable(): Boolean = runCatching { Class.forName("com.chaquo.python.Python") }.isSuccess

    /** À appeler hors du thread principal. [cwd] : dossier de travail du script. */
    fun run(ctx: Context, code: String, timeoutSec: Int, cwd: File): PyResult {
        if (!isAvailable()) return PyResult(available = false)
        return try {
            val pyCls = Class.forName("com.chaquo.python.Python")
            if (!(pyCls.getMethod("isStarted").invoke(null) as Boolean)) {
                val platform = Class.forName("com.chaquo.python.android.AndroidPlatform")
                    .getConstructor(Context::class.java).newInstance(ctx.applicationContext)
                pyCls.getMethod("start", Class.forName("com.chaquo.python.Python\$Platform")).invoke(null, platform)
            }
            val py = pyCls.getMethod("getInstance").invoke(null)
            val module = pyCls.getMethod("getModule", String::class.java).invoke(py, "runner")
            cwd.mkdirs()
            val res = Class.forName("com.chaquo.python.PyObject")
                .getMethod("callAttr", String::class.java, Array<Any?>::class.java)
                .invoke(module, "run", arrayOf<Any?>(code, timeoutSec, cwd.absolutePath))
            val o = JSONObject(res.toString())
            PyResult(
                available = true,
                output = o.optString("out"),
                error = o.optString("err").takeIf { it.isNotBlank() },
                timedOut = o.optBoolean("timeout")
            )
        } catch (e: InvocationTargetException) {
            PyResult(true, error = "Python : " + (e.targetException?.message ?: e.targetException?.javaClass?.simpleName))
        } catch (e: Throwable) {
            PyResult(true, error = "Python : " + (e.message ?: e.javaClass.simpleName))
        }
    }
}
