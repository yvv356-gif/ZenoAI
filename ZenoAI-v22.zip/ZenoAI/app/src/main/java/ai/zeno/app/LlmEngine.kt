package ai.zeno.app

import android.content.Context
import android.net.Uri
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import com.google.mediapipe.tasks.genai.llminference.LlmInferenceSession
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import org.nehuatl.llamacpp.LlamaHelper
import java.io.File
import kotlin.coroutines.resume

/**
 * Moteur IA local, deux formats :
 * - .task : MediaPipe (Gemma, Qwen, Phi… convertis pour Google)
 * - .gguf : llama.cpp (Qwen2.5-Coder, Llama 3.x, Gemma 2…)
 */
class LlmEngine(private val context: Context) {

    private var llm: LlmInference? = null
    private var gguf: LlamaHelper? = null
    private var native: NativeLlama? = null
    private var ggufPath = ""
    private val threads = CpuPlan.threads()
    private var ggufCtx = 2048
    private val mutex = Mutex()

    private val ggufScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val ggufFlow = MutableSharedFlow<LlamaHelper.LLMEvent>(
        replay = 0,
        extraBufferCapacity = 256,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )

    suspend fun load(path: String, maxTokens: Int) = withContext(Dispatchers.Default) {
        mutex.withLock {
            releaseAll()
            plainMode = false
            if (path.endsWith(".gguf", ignoreCase = true)) loadGguf(path, maxTokens) else loadTask(path, maxTokens)
        }
    }

    private fun loadTask(path: String, maxTokens: Int) {
        // GPU d'abord (beaucoup plus rapide, moins de chauffe) ; repli sur le CPU si le téléphone ne le gère pas.
        llm = runCatching {
            LlmInference.createFromOptions(
                context,
                LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(path)
                    .setMaxTokens(maxTokens)
                    .setPreferredBackend(LlmInference.Backend.GPU)
                    .build()
            )
        }.getOrElse {
            LlmInference.createFromOptions(
                context,
                LlmInference.LlmInferenceOptions.builder()
                    .setModelPath(path)
                    .setMaxTokens(maxTokens)
                    .build()
            )
        }
    }

    private suspend fun loadGguf(path: String, ctx: Int) {
        ggufPath = path
        // D'abord le chargement direct (threads choisis par ZenoAI) ; repli sur l'assistant de la bibliothèque s'il échoue.
        val nl = NativeLlama(context.contentResolver)
        val mi = android.app.ActivityManager.MemoryInfo()
        (context.getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(mi)
        // Beaucoup de RAM : lots de lecture du prompt plus grands (réponse qui démarre plus vite)
        val batch = if (mi.totalMem >= 7_000_000_000L) 1024 else 512
        val ok = runCatching { withContext(Dispatchers.IO) { nl.load(path, ctx, threads, batch) } }
            .onFailure { android.util.Log.w("ZenoLlm", "chargement direct impossible : ${it.message}") }.isSuccess
        if (ok) {
            native = nl
            ggufCtx = ctx
            warmUp(path)
            return
        }
        runCatching { nl.release() }
        loadGgufHelper(path, ctx)
    }

    /**
     * Lit le modèle en arrière-plan pour le charger en mémoire vive : la première réponse démarre plus vite
     * (sinon Android ne charge que les morceaux utilisés, au fil de la génération, depuis le stockage).
     * On ne force rien si la RAM libre est trop juste.
     */
    private fun warmUp(path: String) {
        ggufScope.launch {
            runCatching {
                android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND)
                val f = File(path)
                val mi = android.app.ActivityManager.MemoryInfo()
                (context.getSystemService(android.content.Context.ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(mi)
                if (mi.availMem < f.length() * 12 / 10) return@runCatching
                val buf = ByteArray(4 shl 20)
                f.inputStream().use { s -> while (s.read(buf) >= 0) { /* lecture seule */ } }
            }
        }
    }

    /** Navigateur ouvert : on laisse 2 cœurs à la page web pour qu'elle s'affiche pendant que l'IA réfléchit. */
    private fun genThreads(): Int = if (WebDriver.isOpen()) (threads - 2).coerceAtLeast(2) else threads

    private suspend fun loadGgufHelper(path: String, ctx: Int) {
        val helper = LlamaHelper(
            contentResolver = context.contentResolver,
            scope = ggufScope,
            sharedFlow = ggufFlow
        )
        val loaded = CompletableDeferred<Unit>()
        val watcher = ggufScope.launch {
            ggufFlow.collect { ev ->
                if (ev is LlamaHelper.LLMEvent.Error) {
                    loaded.completeExceptionally(IllegalStateException("chargement impossible : ${ev.message}"))
                }
            }
        }
        try {
            withTimeoutOrNull(2_000) { ggufFlow.subscriptionCount.first { it > 0 } }
            helper.load(path = Uri.fromFile(File(path)).toString(), contextLength = ctx) {
                loaded.complete(Unit)
            }
            withTimeout(300_000) { loaded.await() }
        } catch (e: Throwable) {
            runCatching { helper.release() }
            throw e
        } finally {
            watcher.cancel()
        }
        gguf = helper
        ggufCtx = ctx
    }

    /**
     * Réponse en streaming. Une session neuve par requête : le contexte vient de la mémoire de la conversation.
     * (La température ne s'applique qu'aux modèles .task ; llama.cpp utilise ses réglages par défaut.)
     */
    suspend fun generate(
        prompt: String,
        temperature: Float = 0.6f,
        maxChars: Int = 0,
        onPartial: (String) -> Unit
    ): String = withContext(Dispatchers.Default) {
        mutex.withLock {
            if (gguf != null || native != null) {
                var out = generateGguf(if (plainMode) unwrap(prompt) else prompt, maxChars, onPartial)
                if (!plainMode && echoed(out, prompt)) {
                    // La bibliothèque ajoute déjà son propre gabarit de chat : on envoie du texte simple.
                    plainMode = true
                    onPartial("")
                    out = generateGguf(unwrap(prompt), maxChars, onPartial)
                }
                out
            } else generateTask(prompt, temperature, onPartial)
        }
    }

    private suspend fun generateTask(prompt: String, temperature: Float, onPartial: (String) -> Unit): String {
        val engine = llm ?: error("Modèle non chargé")
        val sessionOptions = LlmInferenceSession.LlmInferenceSessionOptions.builder()
            .setTopK(40)
            .setTopP(0.9f)
            .setTemperature(temperature)
            .build()
        val session = LlmInferenceSession.createFromOptions(engine, sessionOptions)
        try {
            session.addQueryChunk(prompt)
            val sb = StringBuilder()
            suspendCancellableCoroutine<Unit> { cont ->
                session.generateResponseAsync { partial, done ->
                    sb.append(partial)
                    onPartial(sb.toString())
                    if (done && cont.isActive) cont.resume(Unit)
                }
                cont.invokeOnCancellation {
                    runCatching { session.cancelGenerateResponseAsync() }
                }
            }
            return sb.toString()
        } finally {
            runCatching { session.close() }
        }
    }

    private suspend fun generateGguf(prompt: String, maxCharsArg: Int, onPartial: (String) -> Unit): String {
        val nl = native
        if (nl != null) {
            try {
                val r = generateNative(nl, prompt, maxCharsArg, onPartial)
                if (r.isBlank()) error("réponse vide du moteur direct")
                return r
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                // Le chargement direct a échoué en cours de route : retour à l'assistant de la bibliothèque.
                android.util.Log.w("ZenoLlm", "génération directe impossible : ${e.message}")
                runCatching { nl.release() }
                native = null
                loadGgufHelper(ggufPath, ggufCtx)
            }
        }
        return generateGgufHelper(prompt, maxCharsArg, onPartial)
    }

    private suspend fun generateNative(nl: NativeLlama, prompt: String, maxCharsArg: Int, onPartial: (String) -> Unit): String {
        val sb = StringBuilder()
        val maxChars = if (maxCharsArg > 0) minOf(maxCharsArg, ggufCtx * 4) else ggufCtx * 4
        var lastShown = 0L
        nl.generate(prompt, genThreads()) { tok ->
            sb.append(tok)
            val cut = STOPS.map { sb.indexOf(it) }.filter { it >= 0 }.minOrNull()
            if (cut != null) {
                sb.setLength(cut)
                false
            } else {
                val now = System.currentTimeMillis()
                if (now - lastShown >= 70) { lastShown = now; onPartial(sb.toString()) }
                sb.length <= maxChars
            }
        }
        onPartial(sb.toString())
        return sb.toString()
    }

    private suspend fun generateGgufHelper(prompt: String, maxCharsArg: Int, onPartial: (String) -> Unit): String = coroutineScope {
        val helper = gguf ?: error("Modèle non chargé")
        val sb = StringBuilder()
        val done = CompletableDeferred<Unit>()
        val maxChars = if (maxCharsArg > 0) minOf(maxCharsArg, ggufCtx * 4) else ggufCtx * 4
        var lastShown = 0L
        val collector = launch(Dispatchers.IO) {
            ggufFlow.collect { ev ->
                when (ev) {
                    is LlamaHelper.LLMEvent.Ongoing -> {
                        sb.append(ev.word)
                        // Le modèle ne s'arrête pas toujours seul : on coupe dès qu'il ouvre un nouveau tour.
                        val cut = STOPS.map { sb.indexOf(it) }.filter { it >= 0 }.minOrNull()
                        if (cut != null) {
                            sb.setLength(cut)
                            onPartial(sb.toString())
                            runCatching { helper.abort() }
                            done.complete(Unit)
                            return@collect
                        }
                        // Affichage au plus toutes les 70 ms : l'écran ne vole plus de processeur à l'IA
                        val now = System.currentTimeMillis()
                        if (now - lastShown >= 70) { lastShown = now; onPartial(sb.toString()) }
                        if (sb.length > maxChars) {
                            runCatching { helper.abort() }
                            done.complete(Unit)
                        }
                    }
                    is LlamaHelper.LLMEvent.Done -> done.complete(Unit)
                    is LlamaHelper.LLMEvent.Error ->
                        done.completeExceptionally(IllegalStateException("génération interrompue : ${ev.message}"))
                    else -> {}
                }
            }
        }
        try {
            withTimeoutOrNull(2_000) { ggufFlow.subscriptionCount.first { it > 0 } }
            helper.predict(prompt)
            done.await()
            onPartial(sb.toString())
        } catch (e: CancellationException) {
            runCatching { helper.abort() }
            throw e
        } finally {
            collector.cancel()
            runCatching { helper.stopPrediction() }
        }
        sb.toString()
    }

    private var plainMode = false

    private val chatml = Regex("<\\|im_start\\|>system\\n([\\s\\S]*?)<\\|im_end\\|>\\n<\\|im_start\\|>user\\n([\\s\\S]*?)<\\|im_end\\|>")
    private val llama3 = Regex("<\\|start_header_id\\|>system<\\|end_header_id\\|>\\n\\n([\\s\\S]*?)<\\|eot_id\\|><\\|start_header_id\\|>user<\\|end_header_id\\|>\\n\\n([\\s\\S]*?)<\\|eot_id\\|>")
    private val gemma = Regex("<start_of_turn>user\\n([\\s\\S]*?)<end_of_turn>")

    private fun parts(prompt: String): Pair<String, String> {
        chatml.find(prompt)?.let { return it.groupValues[1] to it.groupValues[2] }
        llama3.find(prompt)?.let { return it.groupValues[1] to it.groupValues[2] }
        gemma.find(prompt)?.let { return "" to it.groupValues[1] }
        return "" to prompt
    }

    /** Le même prompt sans balises de chat : consigne + question, en texte simple. */
    private fun unwrap(prompt: String): String {
        val (sys, user) = parts(prompt)
        return if (sys.isBlank()) user else "$sys\n\n$user"
    }

    /** Vrai si le modèle a recopié la consigne système au lieu de répondre. */
    private fun echoed(out: String, prompt: String): Boolean {
        val sys = parts(prompt).first.trim()
        if (sys.length < 25) return false
        return out.trimStart().startsWith(sys.take(25))
    }

    private companion object {
        val STOPS = listOf(
            "<|im_end|>", "<|im_start|>", "<|endoftext|>", "<|eot_id|>", "<|end_of_text|>",
            "<end_of_turn>", "<start_of_turn>", "\n[Message de l'utilisateur]", "\nUtilisateur :"
        )
    }

    private fun releaseAll() {
        runCatching { llm?.close() }
        llm = null
        native?.release()
        native = null
        gguf?.let { h ->
            runCatching { h.abort() }
            runCatching { h.release() }
        }
        gguf = null
    }

    fun close() {
        releaseAll()
    }
}
