package ai.zeno.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.Locale

/**
 * Conversation vocale en direct : tu parles, Zeno t'écoute, répond, puis lit sa réponse à voix haute
 * et se remet à t'écouter. Utilise la reconnaissance vocale et la synthèse vocale d'Android (rien à télécharger).
 */
class VoiceChat(private val ctx: Context, private val onHeard: (String) -> Unit) {

    var live by mutableStateOf(false)
        private set
    var status by mutableStateOf("")
        private set

    /** Vrai quand on attend la réponse de l'IA pour la lire. */
    var awaiting = false

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            status = "Reconnaissance vocale indisponible sur ce téléphone."
            return
        }
        live = true
        status = "Je prépare la voix…"
        if (tts == null) {
            tts = TextToSpeech(ctx) { st ->
                ttsReady = st == TextToSpeech.SUCCESS
                if (ttsReady) {
                    val t = tts ?: return@TextToSpeech
                    val loc = Locale.getDefault()
                    t.language = if (t.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE) loc else Locale.FRENCH
                    t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(id: String?) {}
                        override fun onDone(id: String?) { main.post { if (live) listen() } }
                        @Deprecated("Deprecated in Java")
                        override fun onError(id: String?) { main.post { if (live) listen() } }
                    })
                }
                main.post { if (live) listen() }
            }
        } else listen()
    }

    fun stop() {
        live = false
        awaiting = false
        status = ""
        runCatching { recognizer?.destroy() }
        recognizer = null
        tts?.stop()
    }

    fun release() {
        stop()
        tts?.shutdown()
        tts = null
    }

    fun listen() {
        if (!live) return
        runCatching { recognizer?.destroy() }
        status = "🎤 Je t'écoute…"
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() { status = "🎤 …" }
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() { status = "Je réfléchis…" }
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onPartialResults(p: Bundle?) {
                val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) status = "🎤 $t"
            }
            override fun onResults(res: Bundle?) {
                val t = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) { main.postDelayed({ listen() }, 300); return }
                awaiting = true
                status = "Je réfléchis…"
                onHeard(t)
            }
            override fun onError(code: Int) {
                when (code) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT,
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> main.postDelayed({ listen() }, 400)
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { stop(); status = "Autorise le micro pour parler avec moi." }
                    else -> { stop(); status = "La reconnaissance vocale a échoué (code $code). Vérifie ta connexion." }
                }
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        runCatching { r.startListening(i) }.onFailure { stop(); status = "Micro indisponible." }
    }

    /** Lit la réponse à voix haute (sans le code ni la mise en forme), puis se remet à écouter. */
    fun speak(text: String) {
        if (!live) return
        val clean = text
            .replace(Regex("```[\\s\\S]*?(```|$)"), " ")
            .replace(Regex("https?://\\S+"), " ")
            .replace(Regex("[*_#`>|]"), " ")
            .replace(Regex("\\s+"), " ").trim().take(700)
        if (clean.isBlank() || !ttsReady) { listen(); return }
        runCatching { recognizer?.cancel() }
        status = "🔊 Zeno parle… (touche pour arrêter)"
        tts?.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "zeno")
    }
}
