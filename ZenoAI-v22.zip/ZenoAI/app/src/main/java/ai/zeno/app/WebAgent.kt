package ai.zeno.app

import android.annotation.SuppressLint
import android.graphics.Color
import android.text.TextUtils
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.resume

/**
 * Pilote le navigateur intégré (la WebView affichée à l'écran) : ouvrir, lire la page,
 * cliquer, écrire, défiler. Tout se voit dans la fenêtre du navigateur, étape par étape.
 */
object WebDriver : Driver {

    @Volatile private var view: WebView? = null
    @Volatile private var loaded: CompletableDeferred<Unit>? = null
    @Volatile private var lastUrl = ""
    @Volatile private var lastError: String? = null
    @Volatile private var textSnap: String? = null
    private var textLinks: List<Pair<String, String>> = emptyList()

    fun isOpen(): Boolean = view != null

    /** Appelé si le moteur web est tué (manque de mémoire) : le dialogue recrée la WebView. */
    @Volatile var onRenderGone: (() -> Unit)? = null

    private const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

    @SuppressLint("SetJavaScriptEnabled")
    fun configure(v: WebView) {
        with(v.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            javaScriptCanOpenWindowsAutomatically = false
            setSupportMultipleWindows(false)
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString = UA
        }
        v.setBackgroundColor(Color.WHITE)
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(v, true)
        }
        v.webChromeClient = WebChromeClient()
        v.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url?.toString().orEmpty()
                return !(u.startsWith("http://") || u.startsWith("https://"))
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                loaded?.takeIf { !it.isCompleted }?.complete(Unit)
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                val req = request ?: return
                if (!req.isForMainFrame) return
                val why = "${error?.description ?: "erreur"} (${req.url.host})"
                lastError = why
                view?.loadDataWithBaseURL(
                    null,
                    "<html><body style='font-family:sans-serif;padding:24px'><h3>Page impossible à ouvrir</h3>" +
                        "<p>${TextUtils.htmlEncode(why)}</p></body></html>",
                    "text/html", "utf-8", null
                )
                loaded?.takeIf { !it.isCompleted }?.complete(Unit)
            }

            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                lastError = "le moteur web a manqué de mémoire"
                this@WebDriver.view = null
                onRenderGone?.invoke()
                return true
            }
        }
        view = v
    }

    /** Après recréation de la WebView : recharge la dernière adresse. */
    fun restore() {
        if (lastUrl.isNotBlank()) view?.loadUrl(lastUrl)
    }

    fun problem(): String? = lastError

    fun detach() {
        view = null
        lastUrl = ""
        lastError = null
        onRenderGone = null
    }

    /** Ouvre une adresse, attend la fin du chargement, vérifie que la page n'est pas blanche (2 essais). */
    suspend fun open(url0: String) {
        withContext(Dispatchers.Main) {
            val url = url0.replaceFirst("http://", "https://")
            var waited = 0
            while (view == null && waited < 15_000) {
                delay(150)
                waited += 150
            }
            if (view == null) error("le navigateur ne s'est pas ouvert")
            lastUrl = url
            textSnap = null
            for (attempt in 1..2) {
                val v = view ?: break
                val done = CompletableDeferred<Unit>()
                loaded = done
                lastError = null
                if (attempt == 2) v.clearCache(true)
                v.loadUrl(url)
                withTimeoutOrNull(30_000) { done.await() }
                delay(1_000)
                if (lastError == null && hasContent()) return@withContext
                if (lastError != null) break
                delay(3_500) // site lourd : il finit d'afficher
                if (hasContent()) return@withContext
                lastError = "la page est restée blanche"
            }
            // L'affichage n'a pas marché : l'agent lit la page en mode texte, pour pouvoir quand même travailler
            val why = lastError
            if (view != null && loadTextFallback(url)) {
                lastError = "affichage impossible (${why ?: "page vide"}) : je lis la page en mode texte"
            }
        }
    }

    /** Lecture de la page sans la WebView (texte + liens) ; la page lue s'affiche aussi à l'écran. */
    private suspend fun loadTextFallback(url: String): Boolean {
        val ok = withContext(Dispatchers.IO) {
            runCatching {
                val doc = org.jsoup.Jsoup.connect(url).userAgent(UA).timeout(9_000).followRedirects(true).get()
                val links = doc.select("a[href]").mapNotNull { a ->
                    val t = a.text().trim().take(80)
                    val h = a.absUrl("href")
                    if (t.isNotBlank() && h.startsWith("http")) t to h else null
                }.distinctBy { it.second }.take(30)
                val body = doc.body()?.text().orEmpty().replace(Regex("\\s+"), " ").trim()
                if (body.length < 20 && links.isEmpty()) return@runCatching false
                textLinks = links
                textSnap = JSONObject()
                    .put("url", doc.location())
                    .put("title", doc.title())
                    .put("text", body.take(700))
                    .put("elements", JSONArray(links.mapIndexed { i, (t, h) ->
                        JSONObject().put("id", i + 1).put("tag", "a").put("label", t).put("href", h.take(120))
                    }))
                    .toString()
                val html = "<html><body style='font-family:sans-serif;padding:16px;line-height:1.4'><h3>" +
                    TextUtils.htmlEncode(doc.title()) + "</h3><p>" + TextUtils.htmlEncode(body.take(2500)) + "</p><hr>" +
                    links.joinToString("") { "<p>• " + TextUtils.htmlEncode(it.first) + "</p>" } + "</body></html>"
                withContext(Dispatchers.Main) { view?.loadDataWithBaseURL(null, html, "text/html", "utf-8", null) }
                true
            }.getOrDefault(false)
        }
        return ok
    }

    private suspend fun hasContent(): Boolean {
        val n = decode(
            evaluate("(function(){var b=document.body;if(!b)return 0;return String(b.innerText||'').trim().length+document.images.length*40})()")
        )
        return (n.toIntOrNull() ?: 0) > 30
    }

    override suspend fun snapshot(): String = textSnap ?: decode(evaluate(SNAPSHOT_JS))

    override suspend fun perform(action: JSONObject): String {
        // Mode texte : seuls « aller à » et « cliquer sur un lien » sont possibles
        if (textSnap != null && action.optString("action") != "goto") {
            if (action.optString("action") != "click") return "pas disponible : la page est lue en mode texte (clique un lien ou change d'adresse)"
            val href = textLinks.getOrNull(action.optInt("id") - 1)?.second ?: return "élément introuvable"
            open(href)
            return "ok : ouvert $href"
        }
        return when (action.optString("action")) {
            "goto" -> {
                val u = Agent.findUrl(action.optString("url")) ?: return "adresse invalide"
                open(u)
                "ok : ouvert $u"
            }
            "click", "type", "scroll" -> {
                val r = decode(evaluate(ACT_JS.replace("__A__", action.toString())))
                delay(1200) // la page peut changer après l'action
                r.ifBlank { "pas de réponse de la page" }
            }
            else -> "action inconnue"
        }
    }

    /** JavaScript exécuté sur le fil principal, avec délai maximum (plus de blocage si la page ne répond pas). */
    private suspend fun evaluate(js: String): String = withTimeoutOrNull(8_000) {
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine<String> { cont ->
                val v = view
                if (v == null) {
                    cont.resume("")
                } else {
                    v.evaluateJavascript(js) { r -> if (cont.isActive) cont.resume(r ?: "") }
                }
            }
        }
    } ?: ""

    /** evaluateJavascript renvoie une chaîne encodée en JSON : on la décode. */
    private fun decode(raw: String): String {
        if (raw.isBlank() || raw == "null") return ""
        return runCatching { JSONArray("[$raw]").optString(0) }.getOrDefault("")
    }

    /** Repère les éléments utiles (liens, boutons, champs) et leur donne un numéro lisible par le modèle. */
    private val SNAPSHOT_JS = """
        (function(){
          var sel = 'a[href],button,input,textarea,select,[role=button],[role=link],[role=tab],[onclick],[contenteditable=true]';
          var old = document.querySelectorAll('[data-zid]');
          for (var k = 0; k < old.length; k++) { old[k].removeAttribute('data-zid'); }
          var els = [], n = 0;
          var all = document.querySelectorAll(sel);
          for (var i = 0; i < all.length && els.length < 35; i++) {
            var e = all[i];
            var r = e.getBoundingClientRect();
            var cs = window.getComputedStyle(e);
            if (r.width < 2 || r.height < 2 || cs.visibility === 'hidden' || cs.display === 'none' || e.disabled) continue;
            if (r.bottom < 0 || r.top > window.innerHeight * 2) continue;
            n++;
            e.setAttribute('data-zid', String(n));
            var label = e.innerText || e.value || e.placeholder || e.getAttribute('aria-label') || e.title || '';
            if (!label && e.querySelector && e.querySelector('img')) { label = 'image ' + (e.querySelector('img').alt || ''); }
            label = String(label).replace(/\s+/g, ' ').trim().slice(0, 80);
            els.push({
              id: n,
              tag: e.tagName.toLowerCase(),
              type: e.type || '',
              label: label,
              value: String(e.value || '').slice(0, 60),
              href: (e.getAttribute('href') || '').slice(0, 120)
            });
          }
          var body = document.body ? document.body.innerText : '';
          return JSON.stringify({
            url: location.href,
            title: document.title,
            text: String(body).replace(/\s+/g, ' ').trim().slice(0, 700),
            elements: els
          });
        })()
    """.trimIndent()

    /** Clique, écrit ou fait défiler. __A__ est remplacé par l'action en JSON. */
    private val ACT_JS = """
        (function(a){
          if (a.action === 'scroll') {
            window.scrollBy(0, (a.dir === 'up' ? -0.8 : 0.8) * window.innerHeight);
            return 'ok : défilé';
          }
          var el = a.id ? document.querySelector('[data-zid="' + a.id + '"]') : null;
          if (!el) { return 'élément introuvable'; }
          if (a.action === 'click') {
            el.scrollIntoView({block: 'center'});
            el.click();
            return 'ok : cliqué';
          }
          if (a.action === 'type') {
            el.focus();
            var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
            var d = Object.getOwnPropertyDescriptor(proto, 'value');
            if (d && d.set) { d.set.call(el, a.text || ''); } else { el.value = a.text || ''; }
            el.dispatchEvent(new Event('input', {bubbles: true}));
            el.dispatchEvent(new Event('change', {bubbles: true}));
            if (a.enter) {
              var ev = {key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true};
              el.dispatchEvent(new KeyboardEvent('keydown', ev));
              el.dispatchEvent(new KeyboardEvent('keyup', ev));
              if (el.form) {
                if (el.form.requestSubmit) { el.form.requestSubmit(); } else { el.form.submit(); }
              }
            }
            return 'ok : écrit';
          }
          return 'action inconnue';
        })(__A__)
    """.trimIndent()
}
