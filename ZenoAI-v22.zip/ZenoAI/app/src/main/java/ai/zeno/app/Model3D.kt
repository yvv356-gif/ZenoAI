package ai.zeno.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * Modélisation 3D : l'IA décrit l'objet avec des formes simples (boîtes, cylindres, sphères) en JSON ;
 * l'appli l'affiche dans une visionneuse 3D qu'on fait tourner au doigt (dessus, dessous, face…).
 */
object Model3D {

    private val verbRx = Regex(
        "\\b(crée|cree|créer|creer|fais|fais-moi|faire|génère|genere|générer|generer|modélise|modelise|modéliser|dessine|conçois|concois|make|create|design|build)\\b",
        RegexOption.IGNORE_CASE
    )
    private val nounRx = Regex("(modèle 3d|modele 3d|objet 3d|pièce 3d|piece 3d|en 3d|impression 3d|\\b3d\\b)", RegexOption.IGNORE_CASE)

    fun isRequest(text: String): Boolean {
        val t = text.trim()
        if (t.startsWith("/3d", ignoreCase = true)) return true
        if (t.length > 300 || t.contains("```")) return false
        if (Regex("\\b(jeu|jeux|game)\\b", RegexOption.IGNORE_CASE).containsMatchIn(t)) return false
        return verbRx.containsMatchIn(t) && nounRx.containsMatchIn(t)
    }

    fun request(text: String): String =
        text.trim().replace(Regex("^/3d\\s*", RegexOption.IGNORE_CASE), "").trim()

    private const val SYSTEM =
        "Tu modélises des objets 3D avec des formes simples. Réponds uniquement avec un tableau JSON, sans texte. " +
            "Formes : {\"t\":\"box\",\"x\":0,\"y\":0,\"z\":0,\"w\":40,\"h\":10,\"d\":20,\"c\":\"#ff8844\"} (boîte), " +
            "{\"t\":\"cyl\",\"x\":0,\"y\":0,\"z\":0,\"r\":5,\"h\":20,\"c\":\"#44aaff\"} (cylindre vertical), " +
            "{\"t\":\"sph\",\"x\":0,\"y\":0,\"z\":0,\"r\":8,\"c\":\"#66dd88\"} (sphère). " +
            "y est la hauteur. 3 à 20 formes, objet centré autour de 0, tailles en millimètres, couleurs variées."

    fun prompt(template: String, request: String): String =
        PromptBuilder.wrap(template, SYSTEM, "Objet : ${request.take(300)}\nRéponds uniquement avec le JSON.")

    /** Formes valides extraites de la réponse du modèle (JSON nettoyé), ou null. */
    fun shapes(raw: String): String? = runCatching {
        val arr = JSONArray(Regex("\\[[\\s\\S]*\\]").find(raw)?.value ?: return null)
        val out = JSONArray()
        for (i in 0 until minOf(arr.length(), 40)) {
            val o = arr.optJSONObject(i) ?: continue
            val t = o.optString("t")
            if (t !in listOf("box", "cyl", "sph")) continue
            val c = JSONObject()
            c.put("t", t)
            for (k in listOf("x", "y", "z", "w", "h", "d", "r")) if (o.has(k)) c.put(k, o.optDouble(k, 0.0))
            c.put("c", o.optString("c", "#6c8cff").filter { it.isLetterOrDigit() || it == '#' }.take(7))
            out.put(c)
        }
        if (out.length() == 0) null else out.toString()
    }.getOrNull()

    private fun sh(t: String, c: String, vararg kv: Pair<String, Double>): JSONObject {
        val o = JSONObject().put("t", t).put("c", c)
        kv.forEach { o.put(it.first, it.second) }
        return o
    }

    /** Objets de base écrits à la main, utilisés quand le modèle n'arrive pas à décrire l'objet. */
    fun fallback(request: String): String {
        val r = request.lowercase()
        val a = JSONArray()
        fun add(o: JSONObject) { a.put(o) }
        when {
            Regex("maison|house|cabane|villa").containsMatchIn(r) -> {
                add(sh("box", "#e8c39e", "x" to 0.0, "y" to 20.0, "z" to 0.0, "w" to 60.0, "h" to 40.0, "d" to 50.0))
                add(sh("box", "#b5533c", "x" to 0.0, "y" to 44.0, "z" to 0.0, "w" to 72.0, "h" to 8.0, "d" to 62.0))
                add(sh("box", "#b5533c", "x" to 0.0, "y" to 52.0, "z" to 0.0, "w" to 50.0, "h" to 8.0, "d" to 44.0))
                add(sh("box", "#b5533c", "x" to 0.0, "y" to 60.0, "z" to 0.0, "w" to 26.0, "h" to 8.0, "d" to 28.0))
                add(sh("box", "#6b4423", "x" to 0.0, "y" to 11.0, "z" to 25.5, "w" to 12.0, "h" to 22.0, "d" to 2.0))
                add(sh("box", "#9fd8ff", "x" to -18.0, "y" to 26.0, "z" to 25.5, "w" to 12.0, "h" to 12.0, "d" to 2.0))
                add(sh("box", "#9fd8ff", "x" to 18.0, "y" to 26.0, "z" to 25.5, "w" to 12.0, "h" to 12.0, "d" to 2.0))
            }
            Regex("table|bureau|desk").containsMatchIn(r) -> {
                add(sh("box", "#8b5a2b", "x" to 0.0, "y" to 38.0, "z" to 0.0, "w" to 80.0, "h" to 6.0, "d" to 50.0))
                for (sx in listOf(-35.0, 35.0)) for (sz in listOf(-20.0, 20.0))
                    add(sh("cyl", "#6b4423", "x" to sx, "y" to 19.0, "z" to sz, "r" to 3.0, "h" to 38.0))
            }
            Regex("chaise|chair|siège|siege|tabouret").containsMatchIn(r) -> {
                add(sh("box", "#c9884a", "x" to 0.0, "y" to 22.0, "z" to 0.0, "w" to 40.0, "h" to 5.0, "d" to 40.0))
                add(sh("box", "#c9884a", "x" to 0.0, "y" to 42.0, "z" to -18.0, "w" to 40.0, "h" to 36.0, "d" to 5.0))
                for (sx in listOf(-16.0, 16.0)) for (sz in listOf(-16.0, 16.0))
                    add(sh("cyl", "#6b4423", "x" to sx, "y" to 10.0, "z" to sz, "r" to 2.5, "h" to 20.0))
            }
            Regex("arbre|tree|sapin|plante").containsMatchIn(r) -> {
                add(sh("cyl", "#6b4423", "x" to 0.0, "y" to 15.0, "z" to 0.0, "r" to 5.0, "h" to 30.0))
                add(sh("sph", "#3fa34d", "x" to 0.0, "y" to 45.0, "z" to 0.0, "r" to 22.0))
                add(sh("sph", "#57bb62", "x" to 10.0, "y" to 55.0, "z" to 6.0, "r" to 14.0))
            }
            Regex("voiture|car|auto|camion|bus").containsMatchIn(r) -> {
                add(sh("box", "#d33a3a", "x" to 0.0, "y" to 12.0, "z" to 0.0, "w" to 80.0, "h" to 14.0, "d" to 36.0))
                add(sh("box", "#9fd8ff", "x" to -4.0, "y" to 25.0, "z" to 0.0, "w" to 40.0, "h" to 12.0, "d" to 30.0))
                for (sx in listOf(-25.0, 25.0)) for (sz in listOf(-18.0, 18.0))
                    add(sh("sph", "#222222", "x" to sx, "y" to 7.0, "z" to sz, "r" to 8.0))
            }
            Regex("robot|androïde|android").containsMatchIn(r) -> {
                add(sh("box", "#8fa3c7", "x" to 0.0, "y" to 32.0, "z" to 0.0, "w" to 30.0, "h" to 36.0, "d" to 20.0))
                add(sh("box", "#b6c4e0", "x" to 0.0, "y" to 60.0, "z" to 0.0, "w" to 24.0, "h" to 20.0, "d" to 20.0))
                add(sh("sph", "#3fa7b8", "x" to -6.0, "y" to 62.0, "z" to 10.0, "r" to 3.0))
                add(sh("sph", "#3fa7b8", "x" to 6.0, "y" to 62.0, "z" to 10.0, "r" to 3.0))
                add(sh("box", "#8fa3c7", "x" to -21.0, "y" to 34.0, "z" to 0.0, "w" to 8.0, "h" to 30.0, "d" to 8.0))
                add(sh("box", "#8fa3c7", "x" to 21.0, "y" to 34.0, "z" to 0.0, "w" to 8.0, "h" to 30.0, "d" to 8.0))
                add(sh("box", "#6c7fa3", "x" to -8.0, "y" to 8.0, "z" to 0.0, "w" to 10.0, "h" to 16.0, "d" to 10.0))
                add(sh("box", "#6c7fa3", "x" to 8.0, "y" to 8.0, "z" to 0.0, "w" to 10.0, "h" to 16.0, "d" to 10.0))
            }
            Regex("tour|château|chateau|castle|fort").containsMatchIn(r) -> {
                add(sh("cyl", "#b9b2a5", "x" to 0.0, "y" to 35.0, "z" to 0.0, "r" to 15.0, "h" to 70.0))
                add(sh("cyl", "#9d968a", "x" to 0.0, "y" to 74.0, "z" to 0.0, "r" to 19.0, "h" to 8.0))
                for (sx in listOf(-12.0, 12.0)) for (sz in listOf(-12.0, 12.0))
                    add(sh("box", "#9d968a", "x" to sx, "y" to 82.0, "z" to sz, "w" to 7.0, "h" to 8.0, "d" to 7.0))
            }
            Regex("bonhomme|neige|snowman").containsMatchIn(r) -> {
                add(sh("sph", "#ffffff", "x" to 0.0, "y" to 14.0, "z" to 0.0, "r" to 16.0))
                add(sh("sph", "#ffffff", "x" to 0.0, "y" to 38.0, "z" to 0.0, "r" to 12.0))
                add(sh("sph", "#ffffff", "x" to 0.0, "y" to 56.0, "z" to 0.0, "r" to 9.0))
                add(sh("cyl", "#e4875b", "x" to 0.0, "y" to 56.0, "z" to 9.0, "r" to 1.5, "h" to 8.0))
            }
            else -> {
                add(sh("cyl", "#7c6fd6", "x" to 0.0, "y" to 5.0, "z" to 0.0, "r" to 20.0, "h" to 10.0))
                add(sh("cyl", "#3fa7b8", "x" to 0.0, "y" to 30.0, "z" to 0.0, "r" to 12.0, "h" to 40.0))
                add(sh("sph", "#e4875b", "x" to 0.0, "y" to 56.0, "z" to 0.0, "r" to 14.0))
            }
        }
        return a.toString()
    }

    /** Triangles de toutes les formes (9 nombres par triangle : x y z, trois fois), repère Z vers le haut pour l'impression 3D. */
    private fun triangles(shapes: String): List<DoubleArray> {
        val out = mutableListOf<DoubleArray>()
        fun tri(a: DoubleArray, b: DoubleArray, c: DoubleArray) {
            // (x, y, z) de l'affichage -> (x, -z, y) : Z vers le haut
            out.add(doubleArrayOf(a[0], -a[2], a[1], b[0], -b[2], b[1], c[0], -c[2], c[1]))
        }
        val arr = JSONArray(shapes)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val x = o.optDouble("x", 0.0); val y = o.optDouble("y", 0.0); val z = o.optDouble("z", 0.0)
            when (o.optString("t")) {
                "box" -> {
                    val w = o.optDouble("w", 10.0) / 2; val h = o.optDouble("h", 10.0) / 2; val d = o.optDouble("d", 10.0) / 2
                    val v = Array(8) { k -> doubleArrayOf(x + (if (k and 1 != 0) w else -w), y + (if (k and 2 != 0) h else -h), z + (if (k and 4 != 0) d else -d)) }
                    val faces = arrayOf(intArrayOf(0, 1, 3, 2), intArrayOf(4, 6, 7, 5), intArrayOf(0, 4, 5, 1), intArrayOf(2, 3, 7, 6), intArrayOf(0, 2, 6, 4), intArrayOf(1, 5, 7, 3))
                    for (f in faces) { tri(v[f[0]], v[f[1]], v[f[2]]); tri(v[f[0]], v[f[2]], v[f[3]]) }
                }
                "cyl" -> {
                    val r = o.optDouble("r", 5.0); val h = o.optDouble("h", 10.0) / 2; val n = 24
                    for (k in 0 until n) {
                        val a1 = k.toDouble() / n * 2 * Math.PI; val a2 = (k + 1).toDouble() / n * 2 * Math.PI
                        val p = doubleArrayOf(x + r * Math.cos(a1), z + r * Math.sin(a1)); val q = doubleArrayOf(x + r * Math.cos(a2), z + r * Math.sin(a2))
                        tri(doubleArrayOf(p[0], y - h, p[1]), doubleArrayOf(q[0], y - h, q[1]), doubleArrayOf(q[0], y + h, q[1]))
                        tri(doubleArrayOf(p[0], y - h, p[1]), doubleArrayOf(q[0], y + h, q[1]), doubleArrayOf(p[0], y + h, p[1]))
                        tri(doubleArrayOf(x, y + h, z), doubleArrayOf(p[0], y + h, p[1]), doubleArrayOf(q[0], y + h, q[1]))
                        tri(doubleArrayOf(x, y - h, z), doubleArrayOf(q[0], y - h, q[1]), doubleArrayOf(p[0], y - h, p[1]))
                    }
                }
                "sph" -> {
                    val r = o.optDouble("r", 5.0); val la = 8; val lo = 12
                    fun pt(i2: Int, j: Int): DoubleArray {
                        val t = i2.toDouble() / la * Math.PI; val f = j.toDouble() / lo * 2 * Math.PI
                        return doubleArrayOf(x + r * Math.sin(t) * Math.cos(f), y + r * Math.cos(t), z + r * Math.sin(t) * Math.sin(f))
                    }
                    for (i2 in 0 until la) for (j in 0 until lo) {
                        tri(pt(i2, j), pt(i2 + 1, j), pt(i2 + 1, j + 1))
                        tri(pt(i2, j), pt(i2 + 1, j + 1), pt(i2, j + 1))
                    }
                }
            }
        }
        return out
    }

    /** Fichier STL (texte) : s'ouvre dans Blender, Cura, PrusaSlicer, Windows 3D Viewer… */
    fun stl(title: String, shapes: String): String {
        val sb = StringBuilder("solid ${title.filter { it.isLetterOrDigit() || it == ' ' }.ifBlank { "zeno" }.replace(' ', '_')}\n")
        for (t in triangles(shapes)) {
            val ux = t[3] - t[0]; val uy = t[4] - t[1]; val uz = t[5] - t[2]
            val vx = t[6] - t[0]; val vy = t[7] - t[1]; val vz = t[8] - t[2]
            var nx = uy * vz - uz * vy; var ny = uz * vx - ux * vz; var nz = ux * vy - uy * vx
            val l = Math.sqrt(nx * nx + ny * ny + nz * nz).let { if (it == 0.0) 1.0 else it }
            nx /= l; ny /= l; nz /= l
            sb.append("facet normal ").append(nx).append(' ').append(ny).append(' ').append(nz).append("\nouter loop\n")
            for (k in 0..2) sb.append("vertex ").append(t[k * 3]).append(' ').append(t[k * 3 + 1]).append(' ').append(t[k * 3 + 2]).append('\n')
            sb.append("endloop\nendfacet\n")
        }
        return sb.append("endsolid\n").toString()
    }

    fun fileName(request: String): String {
        val safe = request.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').take(24).ifBlank { "objet" }
        return "Zeno3D_${safe}_${System.currentTimeMillis() % 100000}.stl"
    }

    fun html(title: String, shapes: String): String = PAGE
        .replace("__TITLE__", title.replace(Regex("[<>&\"']"), " "))
        .replace("__DATA__", shapes)

    private val PAGE = """<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<style>html,body{margin:0;height:100%;background:#12141c;overflow:hidden;touch-action:none;font-family:sans-serif}
canvas{display:block;width:100%;height:100%}
#b{position:fixed;left:0;right:0;bottom:12px;display:flex;gap:6px;justify-content:center;flex-wrap:wrap}
button{background:#2b3050;color:#fff;border:0;border-radius:14px;padding:9px 13px;font-size:14px}
#t{position:fixed;top:10px;left:0;right:0;text-align:center;color:#cfd3ff;font-size:14px}</style></head><body>
<div id="t">__TITLE__ · glisse pour tourner, pince pour zoomer</div><canvas id="c"></canvas>
<div id="b"><button onclick="v(0.5,0.5)">Face</button><button onclick="v(0,1.5)">Dessus</button><button onclick="v(0,-1.5)">Dessous</button>
<button onclick="v(1.57,0.3)">Côté</button><button onclick="v(3.14,0.3)">Arrière</button><button id="r" onclick="auto=!auto">Rotation</button></div>
<script>
var S=__DATA__,cv=document.getElementById('c'),g=cv.getContext('2d'),W=0,H=0,yaw=0.6,pit=0.5,zoom=1,auto=true,tris=[];
function rs(){W=cv.width=innerWidth;H=cv.height=innerHeight}rs();addEventListener('resize',rs);
function hex(c){c=(c||'#6c8cff').replace('#','');if(c.length==3)c=c.split('').map(function(x){return x+x}).join('');
 return[parseInt(c.slice(0,2),16)||100,parseInt(c.slice(2,4),16)||140,parseInt(c.slice(4,6),16)||255]}
function tri(a,b,c,col){tris.push([a,b,c,col])}
function box(s){var x=s.x||0,y=s.y||0,z=s.z||0,w=(s.w||10)/2,h=(s.h||10)/2,d=(s.d||10)/2,col=hex(s.c),v=[],i;
 for(i=0;i<8;i++)v.push([x+(i&1?w:-w),y+(i&2?h:-h),z+(i&4?d:-d)]);
 [[0,1,3,2],[4,6,7,5],[0,4,5,1],[2,3,7,6],[0,2,6,4],[1,5,7,3]].forEach(function(q){tri(v[q[0]],v[q[1]],v[q[2]],col);tri(v[q[0]],v[q[2]],v[q[3]],col)})}
function cyl(s){var x=s.x||0,y=s.y||0,z=s.z||0,r=s.r||5,h=(s.h||10)/2,col=hex(s.c),N=24,i,a,b,p,q;
 for(i=0;i<N;i++){a=i/N*6.2832;b=(i+1)/N*6.2832;
  p=[x+r*Math.cos(a),z+r*Math.sin(a)];q=[x+r*Math.cos(b),z+r*Math.sin(b)];
  tri([p[0],y-h,p[1]],[q[0],y-h,q[1]],[q[0],y+h,q[1]],col);tri([p[0],y-h,p[1]],[q[0],y+h,q[1]],[p[0],y+h,p[1]],col);
  tri([x,y+h,z],[p[0],y+h,p[1]],[q[0],y+h,q[1]],col);tri([x,y-h,z],[q[0],y-h,q[1]],[p[0],y-h,p[1]],col)}}
function sph(s){var x=s.x||0,y=s.y||0,z=s.z||0,r=s.r||5,col=hex(s.c),A=10,B=16,i,j;
 function P(i,j){var t=i/A*3.1416,f=j/B*6.2832;return[x+r*Math.sin(t)*Math.cos(f),y+r*Math.cos(t),z+r*Math.sin(t)*Math.sin(f)]}
 for(i=0;i<A;i++)for(j=0;j<B;j++){tri(P(i,j),P(i+1,j),P(i+1,j+1),col);tri(P(i,j),P(i+1,j+1),P(i,j+1),col)}}
S.forEach(function(s){if(s.t=='box')box(s);else if(s.t=='cyl')cyl(s);else if(s.t=='sph')sph(s)});
var R=1;tris.forEach(function(t){for(var i=0;i<3;i++){var p=t[i];R=Math.max(R,Math.sqrt(p[0]*p[0]+p[1]*p[1]+p[2]*p[2]))}});
function rot(p){var cy=Math.cos(yaw),sy=Math.sin(yaw),cp=Math.cos(pit),sp=Math.sin(pit);
 var x=p[0]*cy+p[2]*sy,z=-p[0]*sy+p[2]*cy,y=p[1]*cp-z*sp;z=p[1]*sp+z*cp;return[x,y,z]}
function draw(){if(auto)yaw+=0.01;g.fillStyle='#12141c';g.fillRect(0,0,W,H);
 var f=Math.min(W,H)*0.42/R*zoom,D=R*4,out=[];
 tris.forEach(function(t){var a=rot(t[0]),b=rot(t[1]),c=rot(t[2]);
  var ux=b[0]-a[0],uy=b[1]-a[1],uz=b[2]-a[2],vx=c[0]-a[0],vy=c[1]-a[1],vz=c[2]-a[2];
  var nx=uy*vz-uz*vy,ny=uz*vx-ux*vz,nz=ux*vy-uy*vx,l=Math.sqrt(nx*nx+ny*ny+nz*nz)||1;
  var sh=0.35+0.65*Math.abs((nx*0.3+ny*0.5-nz*0.8)/l/0.97);
  out.push([(a[2]+b[2]+c[2])/3,a,b,c,t[3],sh])});
 out.sort(function(m,n){return n[0]-m[0]});
 out.forEach(function(o){g.beginPath();
  for(var i=1;i<4;i++){var p=o[i],k=D/(D+p[2]),X=W/2+p[0]*f*k,Y=H/2-p[1]*f*k;if(i==1)g.moveTo(X,Y);else g.lineTo(X,Y)}
  g.closePath();var c=o[4],s=Math.min(1,o[5]);g.fillStyle='rgb('+Math.round(c[0]*s)+','+Math.round(c[1]*s)+','+Math.round(c[2]*s)+')';g.fill()});
 requestAnimationFrame(draw)}
function v(a,b){yaw=a;pit=b;auto=false}
var pts={},last=0;
cv.addEventListener('pointerdown',function(e){pts[e.pointerId]=[e.clientX,e.clientY];auto=false});
cv.addEventListener('pointerup',function(e){delete pts[e.pointerId];last=0});
cv.addEventListener('pointermove',function(e){var p=pts[e.pointerId];if(!p)return;var ids=Object.keys(pts);
 if(ids.length==2){var q=pts[ids[0]==e.pointerId?ids[1]:ids[0]],d=Math.hypot(e.clientX-q[0],e.clientY-q[1]);if(last)zoom=Math.max(0.3,Math.min(4,zoom*d/last));last=d}
 else{yaw+=(e.clientX-p[0])*0.012;pit+=(e.clientY-p[1])*0.012}
 pts[e.pointerId]=[e.clientX,e.clientY]});
cv.addEventListener('wheel',function(e){zoom=Math.max(0.3,Math.min(4,zoom*(e.deltaY<0?1.1:0.9)))});
draw();
</script></body></html>"""
}
