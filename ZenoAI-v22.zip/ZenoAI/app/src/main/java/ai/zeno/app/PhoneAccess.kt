package ai.zeno.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/**
 * Service d'accessibilité : permet à Zeno de lire l'écran et d'agir (toucher, écrire, défiler,
 * retour, accueil, ouvrir une appli). Il ne fonctionne que si TU l'actives dans les réglages Android
 * (Accessibilité → ZenoAI). Il ne fait rien en arrière-plan sans que tu lances /tel ou le mode agent.
 */
class ZenoAccessService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Rien à faire à chaque événement : on lit l'écran seulement quand l'agent le demande.
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        var instance: ZenoAccessService? = null
    }
}

/** Lecture et actions sur l'écran du téléphone, pour la boucle agent. */
object PhoneDriver : Driver {

    /** Éléments numérotés de la dernière lecture : le numéro du modèle renvoie vers ce nœud. */
    private val nodes = mutableListOf<AccessibilityNodeInfo>()

    fun connected(): Boolean = ZenoAccessService.instance != null

    override suspend fun snapshot(): String {
        val svc = ZenoAccessService.instance ?: return ""
        val root = svc.rootInActiveWindow ?: return ""
        nodes.clear()
        val elements = JSONArray()
        val texts = StringBuilder()
        walk(root, elements, texts, 0)
        return JSONObject()
            .put("appli", root.packageName?.toString().orEmpty())
            .put("texte", texts.toString().take(1200))
            .put("elements", elements)
            .toString()
    }

    private fun walk(n: AccessibilityNodeInfo?, out: JSONArray, texts: StringBuilder, depth: Int) {
        if (n == null || depth > 40 || nodes.size >= 80) return
        val label = listOfNotNull(n.text, n.contentDescription, n.hintText)
            .map { it.toString().trim() }
            .firstOrNull { it.isNotBlank() }
            .orEmpty()
        if (label.isNotBlank()) texts.append(label).append(' ')
        val interesting = n.isClickable || n.isEditable || n.isScrollable || n.isCheckable
        if (interesting && (label.isNotBlank() || n.isEditable)) {
            nodes += n
            out.put(
                JSONObject()
                    .put("id", nodes.size)
                    .put(
                        "sorte",
                        when {
                            n.isEditable -> "champ"
                            n.isScrollable -> "liste"
                            else -> "bouton"
                        }
                    )
                    .put("libelle", label.take(80))
            )
        }
        for (i in 0 until n.childCount) walk(n.getChild(i), out, texts, depth + 1)
    }

    override suspend fun perform(action: JSONObject): String {
        val svc = ZenoAccessService.instance ?: return "contrôle du téléphone désactivé (Réglages → Accessibilité → ZenoAI)"
        return when (action.optString("action")) {
            "click" -> {
                val n = nodes.getOrNull(action.optInt("id") - 1) ?: return "élément introuvable"
                if (clickNode(svc, n)) "ok : touché" else "impossible de toucher cet élément"
            }
            "type" -> {
                val n = nodes.getOrNull(action.optInt("id") - 1) ?: return "élément introuvable"
                n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, action.optString("text"))
                }
                if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) "ok : écrit" else "saisie refusée"
            }
            "scroll" -> {
                val m = svc.resources.displayMetrics
                val x = m.widthPixels / 2f
                val up = m.heightPixels * 0.75f
                val down = m.heightPixels * 0.3f
                val (from, to) = if (action.optString("dir") == "up") down to up else up to down
                if (gesture(svc, x, from, x, to, 300)) "ok : défilé" else "défilement refusé"
            }
            "back" -> if (svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)) "ok : retour" else "retour refusé"
            "home" -> if (svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)) "ok : accueil" else "accueil refusé"
            "open" -> openApp(svc, action.optString("text"))
            else -> "action inconnue"
        }.also { delay(1200) }
    }

    /** Touche le nœud, ou son parent cliquable, ou le centre de sa zone en dernier recours. */
    private fun clickNode(svc: AccessibilityService, n: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = n
        var depth = 0
        while (cur != null && depth < 5) {
            if (cur.isClickable) return cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = cur.parent
            depth++
        }
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        val x = r.exactCenterX()
        val y = r.exactCenterY()
        return gesture(svc, x, y, x, y, 80)
    }

    private fun gesture(svc: AccessibilityService, x1: Float, y1: Float, x2: Float, y2: Float, ms: Long): Boolean {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, ms))
            .build()
        return svc.dispatchGesture(g, null, null)
    }

    /** Ouvre une appli d'après son nom affiché (ex. « WhatsApp »). */
    private fun openApp(svc: AccessibilityService, name: String): String {
        val wanted = name.trim().lowercase()
        if (wanted.isBlank()) return "nom d'appli manquant"
        settingsAction(wanted)?.let { action ->
            return runCatching {
                svc.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "ok : réglages ouverts"
            }.getOrElse { "impossible d'ouvrir les réglages : ${it.message}" }
        }
        val pm = svc.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == wanted }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(wanted) }
            ?: return "appli « $name » introuvable"
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "impossible d'ouvrir « $name »"
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        svc.startActivity(intent)
        return "ok : ouvert ${match.loadLabel(pm)}"
    }

    /** Écrans de réglages ouverts directement (plus fiable que de chercher l'icône). */
    private fun settingsAction(name: String): String? = when {
        Regex("^(paramètres?|parametres?|réglages?|reglages?|settings)$").matches(name) -> android.provider.Settings.ACTION_SETTINGS
        name.contains("wi-fi") || name.contains("wifi") -> android.provider.Settings.ACTION_WIFI_SETTINGS
        name.contains("bluetooth") -> android.provider.Settings.ACTION_BLUETOOTH_SETTINGS
        name.contains("avion") -> android.provider.Settings.ACTION_AIRPLANE_MODE_SETTINGS
        name.contains("luminosité") || name.contains("luminosite") || name.contains("affichage") -> android.provider.Settings.ACTION_DISPLAY_SETTINGS
        name.contains("son") || name.contains("volume") -> android.provider.Settings.ACTION_SOUND_SETTINGS
        name.contains("batterie") -> android.provider.Settings.ACTION_BATTERY_SAVER_SETTINGS
        name.contains("données") || name.contains("donnees") -> android.provider.Settings.ACTION_DATA_ROAMING_SETTINGS
        name.contains("localisation") -> android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS
        else -> null
    }
}
