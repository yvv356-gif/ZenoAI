package ai.zeno.app

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings

/**
 * Actions immédiates sur le téléphone, sans passer par le modèle (instantané) :
 * « ouvre les paramètres », « ouvre WhatsApp », « va sur jbl.com », « allume la lampe », « monte le volume ».
 * Renvoie le message à afficher, ou null si la demande n'est pas de ce type (le chat normal prend le relais).
 */
object QuickPhone {

    private val polite = Regex("^(?:(?:s'il te plaît|s'il te plait|stp|peux-tu|peux tu|tu peux|zeno|please)[ ,]+)+", RegexOption.IGNORE_CASE)
    private val openVerb = Regex(
        "^(?:ouvre|ouvrir|lance|lancer|démarre|demarre|va dans|va sur|vas dans|vas sur|affiche|montre-moi|montre)\\s+",
        RegexOption.IGNORE_CASE
    )
    private val article = Regex("^(?:moi\\s+)?(?:les|le|la|l'|mes|mon|ma|une|un|des|du|de la|de l'|l’)\\s*", RegexOption.IGNORE_CASE)
    private val phoneTail = Regex("\\s*(?:de|sur|dans) (?:mon|ma|le) (?:téléphone|telephone|tel|portable|smartphone)\\s*$", RegexOption.IGNORE_CASE)
    private val urlRx = Regex("^(?:https?://)?(?:www\\.)?([a-z0-9-]+(?:\\.[a-z0-9-]+)*\\.(?:com|fr|org|net|io|be|ch|ca|co|app|tv|gg|dev|eu|info))(?:/\\S*)?$", RegexOption.IGNORE_CASE)

    fun handle(ctx: Context, raw: String): String? {
        var t = raw.trim().trimEnd('.', '!', '?', ' ')
        if (t.isEmpty() || t.length > 90 || t.contains('\n') || t.contains("```")) return null
        t = t.replace(polite, "")
        val l = t.lowercase()

        // Lampe torche
        if (Regex("\\b(lampe|torche|flash)\\b").containsMatchIn(l) && Regex("^(allume|active|éteins|eteins|coupe|désactive|desactive|mets)").containsMatchIn(l)) {
            val on = Regex("^(allume|active|mets)").containsMatchIn(l)
            return runCatching {
                val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                val id = cm.cameraIdList.first()
                cm.setTorchMode(id, on)
                if (on) "Lampe allumée 🔦" else "Lampe éteinte."
            }.getOrElse { "Je n'ai pas pu changer la lampe : ${it.message}" }
        }

        // Volume
        if (Regex("^(monte|augmente|baisse|diminue|coupe|mets)\\s+(?:le|la)?\\s*(?:son|volume)").containsMatchIn(l)) {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val up = Regex("^(monte|augmente)").containsMatchIn(l)
            val mute = Regex("^coupe").containsMatchIn(l)
            repeat(if (mute) 0 else 3) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            }
            if (mute) am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            return if (mute) "Son coupé 🔇" else if (up) "Volume monté 🔊" else "Volume baissé 🔉"
        }

        // Wi-Fi / Bluetooth / mode avion : Android interdit de les basculer depuis une appli, on ouvre l'écran
        if (Regex("^(active|désactive|desactive|coupe|allume|éteins|eteins)").containsMatchIn(l)) {
            val action = settingsFor(l)
            if (action != null && action != Settings.ACTION_SETTINGS) return launchSettings(ctx, action, "Voilà l'écran, touche l'interrupteur (Android ne me laisse pas le faire seul).")
        }

        // Ouvrir quelque chose
        var target = t
        if (!openVerb.containsMatchIn(target)) return null
        target = target.replace(openVerb, "").replace(article, "").replace(phoneTail, "").trim().trim('«', '»', '"')
        if (target.length < 2) return null

        urlRx.find(target)?.let {
            val url = if (target.startsWith("http", true)) target else "https://$target"
            return runCatching {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "J'ouvre $target dans ton navigateur 🌐"
            }.getOrElse { "Je n'ai pas pu ouvrir $target." }
        }

        settingsFor(target.lowercase())?.let { return launchSettings(ctx, it, "Voilà les réglages ✅") }

        // Une appli installée
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val want = target.lowercase()
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == want }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().startsWith(want) }
            ?: return null
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return null
        return runCatching {
            ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "J'ouvre ${match.loadLabel(pm)} ✅"
        }.getOrElse { "Je n'ai pas pu ouvrir ${match.loadLabel(pm)}." }
    }

    private fun launchSettings(ctx: Context, action: String, ok: String): String = runCatching {
        ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        ok
    }.getOrElse { "Je n'ai pas pu ouvrir les réglages : ${it.message}" }

    fun settingsFor(n: String): String? = when {
        Regex("^(paramètres?|parametres?|réglages?|reglages?|settings)$").matches(n) -> Settings.ACTION_SETTINGS
        n.contains("wi-fi") || n.contains("wifi") -> Settings.ACTION_WIFI_SETTINGS
        n.contains("bluetooth") -> Settings.ACTION_BLUETOOTH_SETTINGS
        n.contains("avion") -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
        n.contains("luminosité") || n.contains("luminosite") || n.contains("affichage") || n.contains("écran") -> Settings.ACTION_DISPLAY_SETTINGS
        n.contains("son") || n.contains("volume") -> Settings.ACTION_SOUND_SETTINGS
        n.contains("batterie") -> Settings.ACTION_BATTERY_SAVER_SETTINGS
        n.contains("localisation") || n.contains("gps") -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
        n.contains("accessibilité") || n.contains("accessibilite") -> Settings.ACTION_ACCESSIBILITY_SETTINGS
        n.contains("notifications") -> Settings.ACTION_APP_NOTIFICATION_SETTINGS
        n.contains("applications") || n.contains("applis") -> Settings.ACTION_APPLICATION_SETTINGS
        n.contains("stockage") -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
        n.contains("langue") -> Settings.ACTION_LOCALE_SETTINGS
        n.contains("date") || n.contains("heure") -> Settings.ACTION_DATE_SETTINGS
        else -> null
    }
}
