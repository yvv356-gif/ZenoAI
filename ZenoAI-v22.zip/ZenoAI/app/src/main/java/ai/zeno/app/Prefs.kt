package ai.zeno.app

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("zeno", Context.MODE_PRIVATE)

    var modelUrl: String
        get() = sp.getString("url", QWEN_URL) ?: QWEN_URL
        set(v) { sp.edit().putString("url", v).apply() }

    /** "chatml" (Qwen, Phi...) ou "gemma" */
    var template: String
        get() = sp.getString("template", "chatml") ?: "chatml"
        set(v) { sp.edit().putString("template", v).apply() }

    /** Taille de contexte (prompt + réponse). Doit correspondre au modèle (ekv1280 = 1280). */
    var maxTokens: Int
        get() = sp.getInt("maxTokens", 1280)
        set(v) { sp.edit().putInt("maxTokens", v).apply() }

    var web: Boolean
        get() = sp.getBoolean("web", true)
        set(v) { sp.edit().putBoolean("web", v).apply() }

    /** Service de génération d'images. {prompt} et {seed} sont remplacés. */
    var imageUrl: String
        get() = (sp.getString("imageUrl", IMAGE_URL) ?: IMAGE_URL).let { if (it.contains("image.pollinations.ai")) IMAGE_URL else it }
        set(v) { sp.edit().putString("imageUrl", v).apply() }

    /** Jeton Hugging Face (optionnel, pour les modèles protégés comme Gemma). */
    var hfToken: String
        get() = sp.getString("hfToken", "") ?: ""
        set(v) { sp.edit().putString("hfToken", v).apply() }

    /** Niveau de réflexion : 0 = bas (rapide), 1 = moyen, 2 = élevé (plus de sources, vérifie). */
    var thinking: Int
        get() = sp.getInt("thinking", 1).coerceIn(0, 2)
        set(v) { sp.edit().putInt("thinking", v).apply() }

    /** Fichier du modèle actif (dans le dossier des modèles). */
    var activeModel: String
        get() = sp.getString("activeModel", "") ?: ""
        set(v) { sp.edit().putString("activeModel", v).apply() }

    /** Dernier modèle réellement chargé (utile pour le mode Auto). */
    var lastModel: String
        get() = sp.getString("lastModel", "") ?: ""
        set(v) { sp.edit().putString("lastModel", v).apply() }

    /** Enregistre automatiquement le code des réponses dans le dossier de travail. */
    var autoSave: Boolean
        get() = sp.getBoolean("autoSave", true)
        set(v) { sp.edit().putBoolean("autoSave", v).apply() }

    /** Mode agent : l'IA planifie, utilise ses outils, puis répond. */
    var agent: Boolean
        get() = sp.getBoolean("agent", false)
        set(v) { sp.edit().putBoolean("agent", v).apply() }

    /** Réglages propres à chaque modèle : famille (template) et contexte. */
    fun modelCfg(name: String): Pair<String, Int>? {
        val s = sp.getString("cfg_$name", null) ?: return null
        val p = s.split("|")
        val t = p.getOrNull(0)?.takeIf { it.isNotBlank() } ?: return null
        val c = p.getOrNull(1)?.toIntOrNull() ?: return null
        return t to c
    }

    fun setModelCfg(name: String, tpl: String, ctx: Int) {
        sp.edit().putString("cfg_$name", "$tpl|$ctx").apply()
    }

    /** Clé gratuite Pollinations pour les images (facultatif). */
    var imageKey: String
        get() = sp.getString("imageKey", "") ?: ""
        set(v) { sp.edit().putString("imageKey", v).apply() }

    fun loadLook() = Look(
        wallpaper = sp.getString("wallpaper", "") ?: "",
        userName = sp.getString("userName", "Toi") ?: "Toi",
        aiName = sp.getString("aiName", "Zeno") ?: "Zeno",
        userAvatar = sp.getString("userAvatar", "") ?: "",
        aiAvatar = sp.getString("aiAvatar", "") ?: "",
        textColor = sp.getInt("textColor", 0),
        userBubble = sp.getInt("userBubble", 0),
        aiBubble = sp.getInt("aiBubble", 0),
        bubbleAlpha = sp.getFloat("bubbleAlpha", 0.4f)
    )

    fun saveLook(l: Look) {
        sp.edit()
            .putString("wallpaper", l.wallpaper)
            .putString("userName", l.userName)
            .putString("aiName", l.aiName)
            .putString("userAvatar", l.userAvatar)
            .putString("aiAvatar", l.aiAvatar)
            .putInt("textColor", l.textColor)
            .putInt("userBubble", l.userBubble)
            .putInt("aiBubble", l.aiBubble)
            .putFloat("bubbleAlpha", l.bubbleAlpha)
            .apply()
    }

    companion object {
        const val QWEN_URL =
            "https://huggingface.co/litert-community/Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task"
        const val GEMMA_URL =
            "https://huggingface.co/litert-community/Gemma3-1B-IT/resolve/main/Gemma3-1B-IT_multi-prefill-seq_q4_ekv2048.task"
        const val IMAGE_URL =
            "https://gen.pollinations.ai/image/{prompt}?model=flux&width=768&height=768&seed={seed}&nologo=true"
    }
}
