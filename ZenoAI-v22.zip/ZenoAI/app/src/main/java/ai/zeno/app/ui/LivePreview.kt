package ai.zeno.app.ui

import ai.zeno.app.ChatViewModel
import ai.zeno.app.CodeRunner
import ai.zeno.app.LogLevel
import ai.zeno.app.LogLine
import ai.zeno.app.PythonBackend
import ai.zeno.app.RunKind
import android.annotation.SuppressLint
import android.os.Build
import android.webkit.ConsoleMessage
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebViewRenderProcess
import android.webkit.WebViewRenderProcessClient
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Job
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Ce que l'utilisateur a demandé de lancer depuis un bloc de code du chat. */
data class RunRequest(val title: String, val kind: RunKind, val lang: String, val code: String)

private val Bg = Color(0xFF101018)
private val Panel = Color(0xFF181824)
private val Green = Color(0xFF7EE787)

private fun levelColor(l: LogLevel) = when (l) {
    LogLevel.ERROR -> Color(0xFFFF7B72)
    LogLevel.WARN -> Color(0xFFE3B341)
    LogLevel.INFO -> Color(0xFF79C0FF)
    LogLevel.SYSTEM -> Color(0xFF8B93B8)
    LogLevel.LOG -> Color(0xFFE6E6F0)
}

/** Charge la page seulement quand la WebView a une taille (une page lancée à 0 pixel démarre de travers). */
private fun WebView.loadPageWhenSized(page: String) {
    var done = false
    val go = {
        if (!done && width > 0 && height > 0) {
            done = true
            // Origine https factice (.invalid ne se résout jamais) : localStorage fonctionne, sans réseau réel
            loadDataWithBaseURL("https://preview.zeno.invalid/", page, "text/html", "utf-8", null)
        }
    }
    addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> go() }
    post { go() }
}

@SuppressLint("SetJavaScriptEnabled")
private fun WebView.sandbox(allowNetwork: Boolean) {
    setBackgroundColor(android.graphics.Color.WHITE)
    settings.javaScriptEnabled = true
    settings.domStorageEnabled = true
    settings.allowFileAccess = false
    settings.allowContentAccess = false
    settings.blockNetworkLoads = !allowNetwork
    settings.mediaPlaybackRequiresUserGesture = false
}

/** Une boucle infinie gèle le moteur web : Android nous prévient, on le coupe au lieu de laisser l'écran figé. */
@RequiresApi(29)
private fun WebView.killWhenUnresponsive(onKilled: () -> Unit) {
    setWebViewRenderProcessClient(object : WebViewRenderProcessClient() {
        override fun onRenderProcessUnresponsive(view: WebView, renderer: WebViewRenderProcess?) {
            onKilled()
            renderer?.terminate()
        }
        override fun onRenderProcessResponsive(view: WebView, renderer: WebViewRenderProcess?) {}
    })
}

@Composable
private fun ConsolePane(lines: List<LogLine>, emptyText: String, modifier: Modifier) {
    val state = rememberLazyListState()
    LaunchedEffect(lines.size) { if (lines.isNotEmpty()) state.scrollToItem(lines.size - 1) }
    LazyColumn(state = state, modifier = modifier.background(Color(0xFF0B0B12)).padding(10.dp)) {
        if (lines.isEmpty()) {
            item { Text(emptyText, color = Color(0xFF8B93B8), fontSize = 13.sp) }
        }
        items(lines.size) { i ->
            val l = lines[i]
            Text(
                l.text, color = levelColor(l.level), fontFamily = FontFamily.Monospace,
                fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(vertical = 1.dp)
            )
        }
    }
}

/**
 * Aperçu et exécution en direct.
 *  - PAGE : HTML (avec css/js) dans une WebView isolée + console (console.log, erreurs).
 *  - JS : le script tourne dans une WebView invisible isolée ; la console affiche console.log et les erreurs.
 *  - PYTHON : interpréteur embarqué (Chaquopy), si activé.
 * Pas de réseau par défaut (🌐 pour l'autoriser dans un aperçu de page).
 */
@Composable
fun LivePreviewDialog(
    title: String, kind: RunKind, lang: String, code: String, cwd: File,
    onClose: () -> Unit, onFix: (String, String, String) -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    val lines = remember { mutableStateListOf<LogLine>() }
    val webRef = remember { arrayOfNulls<WebView>(1) }
    val jobs = remember { arrayOfNulls<Job>(2) } // 0 = attente d'inactivité, 1 = délai maximum
    var run by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(kind != RunKind.PAGE) }
    var network by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(if (kind == RunKind.PAGE) 0 else 1) }
    var note by remember { mutableStateOf<String?>(null) }
    var networkHinted by remember { mutableStateOf(false) }

    val page = remember(code, kind) { if (kind == RunKind.PAGE) CodeRunner.preparePage(code) else CodeRunner.jsPage(code) }
    val truncated = remember(code) {
        kind == RunKind.PAGE && Regex("<script", RegexOption.IGNORE_CASE).findAll(code).count() >
            Regex("</script", RegexOption.IGNORE_CASE).findAll(code).count()
    }

    fun add(level: LogLevel, text: String) {
        if (lines.size < 500) lines.add(LogLine(level, text.take(2000)))
        else if (lines.size == 500) lines.add(LogLine(LogLevel.SYSTEM, "… console pleine (500 lignes)"))
    }

    fun finishJs(reason: String) {
        if (!running) return
        running = false
        jobs.forEach { it?.cancel() }
        webRef[0]?.loadUrl("about:blank")
        add(LogLevel.SYSTEM, reason)
    }

    fun scheduleIdle() {
        jobs[0]?.cancel()
        jobs[0] = scope.launch { delay(CodeRunner.JS_IDLE_MS); finishJs("— terminé —") }
    }

    fun restart() {
        jobs.forEach { it?.cancel() }
        lines.clear()
        note = null
        running = kind != RunKind.PAGE
        run++
    }

    // Python : lancé à l'ouverture et à chaque « relancer »
    LaunchedEffect(run) {
        if (kind != RunKind.PYTHON) return@LaunchedEffect
        running = true
        add(LogLevel.SYSTEM, "▶ python (maximum ${CodeRunner.PY_TIMEOUT_S} s)")
        val res = withContext(Dispatchers.Default) { PythonBackend.run(ctx, code, CodeRunner.PY_TIMEOUT_S, cwd) }
        if (!res.available) {
            note = "ℹ Python n'est pas activé dans cette version de ZenoAI."
            add(LogLevel.SYSTEM, "Python n'est pas inclus dans cette version. Pour l'activer : ajoute Chaquopy au projet (voir optional-python/LISEZMOI.md). Les pages HTML et le JavaScript s'exécutent déjà ici.")
        } else {
            res.output.trimEnd('\n').takeIf { it.isNotEmpty() }?.lines()?.forEach { add(LogLevel.LOG, it) }
            res.error?.let { e ->
                add(LogLevel.ERROR, e)
                CodeRunner.hint(RunKind.PYTHON, e)?.let { add(LogLevel.SYSTEM, "💡 $it") }
            }
            add(LogLevel.SYSTEM, "— terminé —")
        }
        running = false
    }

    DisposableEffect(Unit) { onDispose { jobs.forEach { it?.cancel() } } }

    val firstError = lines.firstOrNull { it.level == LogLevel.ERROR }?.text
    val statusColor = when {
        firstError != null -> Color(0xFF4A1620)
        running -> Color(0xFF1B2A4A)
        note != null -> Color(0xFF1B2A4A)
        else -> Color(0xFF14361F)
    }
    val statusText = when {
        firstError != null -> "⚠ $firstError"
        running -> "⏳ En cours…"
        note != null -> note!!
        truncated -> "Aucune erreur, mais le code semble coupé (mémoire du modèle atteinte)."
        kind == RunKind.PAGE -> "✅ Aucune erreur détectée"
        else -> "✅ Terminé sans erreur"
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize().systemBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Fermer", tint = Color.White) }
                    Text(
                        title, color = Color.White, fontSize = 17.sp, maxLines = 1,
                        overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                    )
                    if (kind == RunKind.PAGE) {
                        IconButton(onClick = { network = !network; restart() }) {
                            Icon(
                                Icons.Default.Language, if (network) "Réseau autorisé" else "Réseau bloqué",
                                tint = if (network) Green else Color(0xFF6A7088)
                            )
                        }
                    }
                    IconButton(onClick = {
                        clipboard.setText(AnnotatedString(lines.joinToString("\n") { it.text }))
                        Toast.makeText(ctx, "Console copiée", Toast.LENGTH_SHORT).show()
                    }) { Icon(Icons.Default.ContentCopy, "Copier la console", tint = Color.White) }
                    if (kind == RunKind.JS && running) {
                        IconButton(onClick = { finishJs("■ arrêté") }) { Icon(Icons.Default.Stop, "Arrêter", tint = Color(0xFFFF7B72)) }
                    } else {
                        IconButton(onClick = { restart() }, enabled = !(kind == RunKind.PYTHON && running)) {
                            Icon(
                                if (kind == RunKind.PAGE) Icons.Default.Refresh else Icons.Default.PlayArrow,
                                if (kind == RunKind.PAGE) "Recharger" else "Relancer", tint = Color.White
                            )
                        }
                    }
                }
                Row(
                    Modifier.fillMaxWidth().background(statusColor).padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        statusText, color = Color.White, fontSize = 13.sp, maxLines = 3,
                        overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                    )
                    if (firstError != null || truncated) {
                        TextButton(onClick = { onFix(lang, firstError ?: "code coupé : termine-le", code) }) {
                            Text("Corriger", color = Green)
                        }
                    }
                }
                if (kind == RunKind.PAGE) {
                    TabRow(selectedTabIndex = tab, containerColor = Panel, contentColor = Color.White) {
                        Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Aperçu") })
                        Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Console (${lines.size})") })
                    }
                }
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    if (kind != RunKind.PYTHON) {
                        key(run, network) {
                            AndroidView(
                                modifier = if (kind == RunKind.PAGE) Modifier.fillMaxSize() else Modifier.size(1.dp),
                                factory = { c ->
                                    WebView(c).apply {
                                        webRef[0] = this
                                        sandbox(network)
                                        var loaded = false
                                        webViewClient = object : WebViewClient() {
                                            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = true
                                            override fun onPageFinished(view: WebView?, url: String?) {
                                                if (kind == RunKind.JS && url?.startsWith("about:blank") != true) {
                                                    loaded = true
                                                    scheduleIdle()
                                                }
                                            }
                                            override fun onRenderProcessGone(view: WebView?, detail: RenderProcessGoneDetail?): Boolean {
                                                add(LogLevel.ERROR, "Le moteur web s'est arrêté (boucle infinie ou manque de mémoire).")
                                                if (kind == RunKind.JS) running = false
                                                return true
                                            }
                                        }
                                        webChromeClient = object : WebChromeClient() {
                                            override fun onConsoleMessage(m: ConsoleMessage?): Boolean {
                                                if (m == null) return true
                                                val level = when (m.messageLevel()) {
                                                    ConsoleMessage.MessageLevel.ERROR -> LogLevel.ERROR
                                                    ConsoleMessage.MessageLevel.WARNING -> LogLevel.WARN
                                                    ConsoleMessage.MessageLevel.TIP -> LogLevel.INFO
                                                    else -> LogLevel.LOG
                                                }
                                                val msg = m.message().orEmpty()
                                                add(level, if (level == LogLevel.ERROR && m.lineNumber() > 0) "$msg (ligne ${m.lineNumber()})" else msg)
                                                if (level == LogLevel.ERROR) {
                                                    CodeRunner.hint(kind, msg)?.let { add(LogLevel.SYSTEM, "💡 $it") }
                                                    if (!network && !networkHinted && (msg.contains("Failed to load resource") || msg.contains("ERR_"))) {
                                                        networkHinted = true
                                                        add(LogLevel.SYSTEM, "💡 Le réseau est bloqué : touche 🌐 pour charger des ressources externes (CDN, images…).")
                                                    }
                                                }
                                                if (loaded) scheduleIdle()
                                                return true
                                            }
                                        }
                                        if (Build.VERSION.SDK_INT >= 29) {
                                            killWhenUnresponsive {
                                                add(LogLevel.ERROR, "Le script ne répond plus (boucle infinie ?) : arrêt forcé.")
                                                if (kind == RunKind.JS) running = false
                                            }
                                        }
                                        if (kind == RunKind.JS) {
                                            jobs[1] = scope.launch {
                                                delay(CodeRunner.JS_TIMEOUT_MS)
                                                finishJs("⏱ Arrêté après ${CodeRunner.JS_TIMEOUT_MS / 1000} s (boucle infinie ?)")
                                            }
                                        }
                                        loadPageWhenSized(page)
                                    }
                                },
                                onRelease = { it.stopLoading(); it.destroy(); if (webRef[0] === it) webRef[0] = null }
                            )
                        }
                    }
                    if (kind != RunKind.PAGE || tab == 1) {
                        ConsolePane(
                            lines,
                            when {
                                running -> "En attente de sortie…"
                                kind == RunKind.PYTHON -> "Rien n'a été affiché. Utilise print(...) pour afficher des valeurs."
                                else -> "Rien n'a été affiché. Utilise console.log(...) pour afficher des valeurs."
                            },
                            Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }
    }
}

/** Carte « Enregistré dans le dossier de travail » sous une réponse. [saved] : voir Workspace.encodeSaved. */
@Composable
fun SavedFilesCard(saved: String, onOpen: (String) -> Unit) {
    val rows = saved.lines().filter { it.isNotBlank() }
    if (rows.size < 2) return
    val project = rows.first()
    val files = rows.drop(1)
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0x22000000))
            .clickable { onOpen(project) }.padding(12.dp)
    ) {
        Text("💾 Enregistré dans le projet « $project »", fontSize = 13.sp, color = Color(0xFF14361F))
        files.take(6).forEach { r ->
            val created = r.startsWith("C ")
            Text(
                (if (created) "＋ " else "✎ ") + r.drop(2) + if (created) "  (créé)" else "  (modifié)",
                fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF2B2D42)
            )
        }
        if (files.size > 6) Text("… et ${files.size - 6} autre(s)", fontSize = 12.sp, color = Color(0xFF2B2D42))
        Text("Touche pour ouvrir le dossier", fontSize = 11.sp, color = Color(0xFF5A6078))
    }
}

private fun langOf(path: String): String = when (path.substringAfterLast('.', "").lowercase()) {
    "html", "htm" -> "html"
    "js", "mjs" -> "js"
    "py" -> "python"
    else -> ""
}

/**
 * Projets et fichiers du dossier de travail : voir, modifier, enregistrer, lancer, supprimer, exporter en ZIP.
 * [startProject] : projet à ouvrir directement (celui de la discussion), ou null pour la liste.
 */
@Composable
fun WorkspaceDialog(vm: ChatViewModel, startProject: String?, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val ws = vm.workspace
    var project by remember { mutableStateOf(startProject?.takeIf { ws.dir(it).isDirectory }) }
    var openFile by remember { mutableStateOf<String?>(null) }
    var version by remember { mutableIntStateOf(0) }
    var runReq by remember { mutableStateOf<RunRequest?>(null) }
    var confirm by remember { mutableStateOf<Pair<String, String?>?>(null) } // (projet, fichier ou null)

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()
    fun back() {
        if (openFile != null) openFile = null
        else if (project != null) project = null
        else onClose()
    }

    Dialog(onDismissRequest = { back() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
                val p = project
                val f = openFile
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { back() }) {
                        Icon(if (p == null) Icons.Default.Close else Icons.AutoMirrored.Filled.ArrowBack, "Retour", tint = Color.White)
                    }
                    Text(
                        when {
                            f != null -> f
                            p != null -> p
                            else -> "Projets et fichiers"
                        },
                        color = Color.White, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (p != null && f == null) {
                        IconButton(onClick = {
                            vm.exportProject(p) { toast(it) }
                        }) { Icon(Icons.Default.Download, "Exporter en ZIP", tint = Green) }
                        IconButton(onClick = { confirm = p to null }) {
                            Icon(Icons.Default.Delete, "Supprimer le projet", tint = Color(0xFFFF7B72))
                        }
                    }
                }

                when {
                    // ---- Éditeur d'un fichier ----
                    p != null && f != null -> {
                        val original = remember(p, f, version) { ws.read(p, f) }
                        var text by remember(p, f, version) { mutableStateOf(original ?: "") }
                        val dirty = original != null && text != original
                        if (original == null) {
                            Text(
                                "Ce fichier est trop gros ou illisible : il reste dans le dossier mais ne peut pas être modifié ici.",
                                color = Color(0xFF8B93B8), modifier = Modifier.padding(16.dp)
                            )
                        } else {
                            val lang = langOf(f)
                            val kind = CodeRunner.kindFor(lang, text)
                            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    enabled = dirty,
                                    onClick = {
                                        val r = ws.write(p, f, text)
                                        toast(if (r != null) "Enregistré ✅ (l'ancienne version est gardée)" else "Enregistrement impossible")
                                        version++
                                    }
                                ) { Text("Enregistrer") }
                                if (kind != null) {
                                    OutlinedButton(onClick = {
                                        if (dirty) ws.write(p, f, text)
                                        val code = if (kind == RunKind.PAGE && f.equals("index.html", true)) ws.page(p) ?: text else text
                                        runReq = RunRequest(f, kind, lang, code)
                                    }) { Text(if (kind == RunKind.PAGE) "Aperçu" else "Exécuter") }
                                }
                                OutlinedButton(onClick = { confirm = p to f }) { Text("Supprimer") }
                            }
                            OutlinedTextField(
                                value = text, onValueChange = { text = it },
                                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = Color.White),
                                modifier = Modifier.fillMaxWidth().weight(1f).padding(8.dp)
                            )
                        }
                    }
                    // ---- Fichiers d'un projet ----
                    p != null -> {
                        val files = remember(p, version) { ws.files(p) }
                        val hasPage = remember(p, version) { ws.page(p) != null }
                        if (hasPage) {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp)) {
                                Button(onClick = {
                                    ws.page(p)?.let { runReq = RunRequest("Aperçu · $p", RunKind.PAGE, "html", it) }
                                }) {
                                    Icon(Icons.Default.PlayArrow, null)
                                    Spacer(Modifier.width(4.dp))
                                    Text("Aperçu du site")
                                }
                            }
                        }
                        if (files.isEmpty()) {
                            Text("Ce projet est vide.", color = Color(0xFF8B93B8), modifier = Modifier.padding(16.dp))
                        }
                        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                            items(files) { path ->
                                Row(
                                    Modifier.fillMaxWidth().clickable { openFile = path }.padding(horizontal = 16.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("📄", fontSize = 16.sp)
                                    Spacer(Modifier.width(10.dp))
                                    Text(path, color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 14.sp, modifier = Modifier.weight(1f))
                                    if (langOf(path).isNotEmpty()) Icon(Icons.Default.PlayArrow, null, tint = Green)
                                }
                            }
                        }
                        Text(
                            "Dossier : ${ws.dir(p).absolutePath}",
                            color = Color(0xFF6A7088), fontSize = 11.sp, modifier = Modifier.padding(12.dp)
                        )
                    }
                    // ---- Liste des projets ----
                    else -> {
                        val projects = remember(version) { ws.projects() }
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Enregistrer automatiquement le code des réponses", color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                            Switch(checked = vm.autoSave, onCheckedChange = { vm.setAutoSave(it) })
                        }
                        if (projects.isEmpty()) {
                            Text(
                                "Aucun projet pour l'instant. Demande du code à Zeno (« écris un script Python qui… », « crée une page web… ») : " +
                                    "les fichiers apparaissent ici, sans copier-coller.",
                                color = Color(0xFF8B93B8), modifier = Modifier.padding(16.dp)
                            )
                        }
                        LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                            items(projects) { name ->
                                Row(
                                    Modifier.fillMaxWidth().clickable { project = name }.padding(horizontal = 16.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("📁", fontSize = 18.sp)
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(name, color = Color.White, fontSize = 15.sp)
                                        Text("${ws.files(name).size} fichier(s)", color = Color(0xFF8B93B8), fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                        Text(
                            "Emplacement : ${ws.root.absolutePath}",
                            color = Color(0xFF6A7088), fontSize = 11.sp, modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }
        }
    }

    confirm?.let { (proj, file) ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(if (file == null) "Supprimer le projet ?" else "Supprimer le fichier ?") },
            text = { Text(if (file == null) "« $proj » et tous ses fichiers seront supprimés (l'historique aussi)." else "« $file » sera supprimé.") },
            confirmButton = {
                TextButton(onClick = {
                    if (file == null) { ws.deleteProject(proj); project = null } else { ws.delete(proj, file); openFile = null }
                    confirm = null
                    version++
                }) { Text("Supprimer") }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Annuler") } }
        )
    }

    runReq?.let { r ->
        LivePreviewDialog(
            r.title, r.kind, r.lang, r.code, project?.let { ws.dir(it) } ?: vm.scratchDir(),
            onClose = { runReq = null },
            onFix = { lang, err, code ->
                val msg = vm.fixCode(lang, err, code)
                if (msg != null) toast(msg) else { runReq = null; onClose() }
            }
        )
    }
}
