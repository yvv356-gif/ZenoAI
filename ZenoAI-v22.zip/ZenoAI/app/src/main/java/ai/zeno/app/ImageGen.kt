package ai.zeno.app

import android.graphics.BitmapFactory
import android.util.Base64
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.random.Random

/**
 * Génération d'images, par ordre d'essai (en ligne pour l'instant) :
 *  1. Pollinations, avec ta clé gratuite si tu en as une ;
 *  2. AI Horde, sans compte (clé publique « 0000000000 ») : plus lent, file d'attente possible.
 * La génération 100 % locale (MediaPipe, SD 1.5) n'est pas encore branchée.
 */
object ImageGen {

    private val verbRx = Regex(
        "\\b(génère|génere|générer|generer|genere|crée|cree|créer|creer|dessine|dessiner|fais|fais-moi|imagine|montre|make|generate|create|draw|paint)\\b",
        RegexOption.IGNORE_CASE
    )
    private val nounRx = Regex(
        "\\b(image|images|photo|photos|illustration|dessin|logo|affiche|wallpaper|fond d'écran|picture|drawing|painting|portrait|avatar)\\b",
        RegexOption.IGNORE_CASE
    )

    // Verbes « forts » : en début de phrase, ils suffisent (« génère un chat astronaute »)
    private val strongVerbRx = Regex(
        "^\\s*(?:(?:peux|pourrais)[- ]tu\\s+|stp\\s+|s'il te pla[iî]t\\s+)?(génère|génere|genere|générer|generer|dessine|dessiner|peins|generate|draw|paint|imagine)(?:[- ]moi)?\\b",
        RegexOption.IGNORE_CASE
    )
    // Ce qui n'est clairement pas une image
    private val notImageRx = Regex(
        "\\b(jeu|jeux|game|site|page|code|programme|script|app|application|texte|poème|poeme|histoire|résumé|resume|liste|tableau|e-?mail|mail|lettre|plan|quiz|présentation|presentation|powerpoint|pptx|diaporama|fichier|pdf|word|excel|docx|xlsx|flashcards?|cartes?|fiches?|3d|exercices?|devoir|dissertation|rédaction|redaction|article|message|sms|phrase|idées?|idee|question|réponses?|reponses?|cv|contrat|rapport|fonction|mots?|noms?|titre|slogan|blague|chanson|paroles|synthèse|calcul|équation|csv|json|graphique|schéma)\\b",
        RegexOption.IGNORE_CASE
    )

    fun isRequest(text: String): Boolean {
        val t = text.trim()
        if (t.startsWith("/image", ignoreCase = true)) return true
        if (t.contains("```") || t.length > 600) return false
        val head = t.take(200)
        if (verbRx.containsMatchIn(head) && nounRx.containsMatchIn(head)) return true
        if (notImageRx.containsMatchIn(head)) return false
        // « génère … », « dessine … » en début de message : l'IA comprend toute seule que c'est une image
        return strongVerbRx.containsMatchIn(head) && head.length >= 12
    }

    private const val GEN = "https://gen.pollinations.ai/image/{prompt}?model=flux&width=768&height=768&seed={seed}&nologo=true"
    private const val GEN_TURBO = "https://gen.pollinations.ai/image/{prompt}?model=turbo&width=768&height=768&seed={seed}&nologo=true"
    private const val LEGACY = "https://image.pollinations.ai/prompt/{prompt}?model=flux&width=768&height=768&seed={seed}&nologo=true"
    private const val LEGACY_TURBO = "https://image.pollinations.ai/prompt/{prompt}?model=turbo&width=768&height=768&seed={seed}&nologo=true"
    private const val P_SHORT = "https://pollinations.ai/p/{prompt}?width=768&height=768&seed={seed}&nologo=true"
    private const val HORDE = "https://stablehorde.net/api/v2"

    suspend fun fetch(template: String, prompt: String, key: String = ""): ByteArray {
        val errors = mutableListOf<String>()

        // 1. Pollinations (avec ta clé si tu en as une)
        val k = key.trim()
        val withKey = { t: String -> if (k.isBlank()) t else t + (if (t.contains("?")) "&" else "?") + "key=" + URLEncoder.encode(k, "UTF-8") }
        val variants = listOf(withKey(template), withKey(GEN_TURBO), LEGACY_TURBO).distinct()
        var denied = false
        var pollError: String? = null
        for (t in variants) {
            try {
                return checked(download(build(t, prompt), k))
            } catch (e: CancellationException) {
                throw e
            } catch (e: SecurityException) {
                denied = true
                pollError = e.message
            } catch (e: Exception) {
                pollError = e.message ?: "erreur réseau"
            }
        }
        errors += when {
            denied && k.isBlank() -> "Pollinations demande une clé gratuite (https://enter.pollinations.ai/keys, à coller dans Réglages → Images)"
            denied -> "ta clé Pollinations est refusée ou sans crédit"
            else -> "Pollinations : ${pollError ?: "indisponible"}"
        }

        // 2. AI Horde, sans compte
        try {
            return horde(prompt)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            errors += "AI Horde : ${e.message ?: "erreur"}"
        }

        throw IllegalStateException(errors.joinToString(" ; ") + ".")
    }

    private fun build(template: String, prompt: String): String {
        val enc = URLEncoder.encode(prompt, "UTF-8").replace("+", "%20")
        return template
            .replace("{prompt}", enc)
            .replace("{seed}", Random.nextInt(1, 999_999).toString())
    }

    private fun checked(bytes: ByteArray): ByteArray {
        if (bytes.size > 15_000_000) error("image trop lourde")
        val ok = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) != null
        if (!ok) error("réponse du service d'images invalide")
        return bytes
    }

    private fun download(url: String, key: String): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8_000
        c.readTimeout = 30_000
        c.setRequestProperty("Accept", "image/*")
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "ZenoAI/1.0")
        if (key.isNotBlank() && url.contains("gen.pollinations.ai")) c.setRequestProperty("Authorization", "Bearer $key")
        try {
            c.connect()
            if (c.responseCode in listOf(401, 402, 403)) throw SecurityException("accès refusé (HTTP ${c.responseCode})")
            if (c.responseCode !in 200..299) error("HTTP ${c.responseCode}")
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    /** AI Horde : la demande part dans une file, on attend le résultat (quelques dizaines de secondes en général). */
    private suspend fun horde(prompt: String): ByteArray {
        val headers = mapOf("apikey" to "0000000000", "Client-Agent" to "ZenoAI:1.0:android")
        val body = JSONObject()
            .put("prompt", prompt.take(800))
            .put("params", JSONObject().put("width", 512).put("height", 512).put("steps", 25).put("n", 1))
            .put("nsfw", false)
            .put("censor_nsfw", true)
        val id = JSONObject(hordeCall("$HORDE/generate/async", "POST", body.toString(), headers)).getString("id")
        val deadline = System.currentTimeMillis() + 150_000L
        while (true) {
            currentCoroutineContext().ensureActive()
            val st = JSONObject(hordeCall("$HORDE/generate/check/$id", "GET", null, headers))
            if (st.optBoolean("faulted")) error("le service a échoué")
            if (st.optBoolean("done")) break
            if (System.currentTimeMillis() > deadline) error("trop d'attente dans la file")
            delay(4_000)
        }
        val res = JSONObject(hordeCall("$HORDE/generate/status/$id", "GET", null, headers))
        val img = res.optJSONArray("generations")?.optJSONObject(0)?.optString("img").orEmpty()
        if (img.isBlank()) error("aucune image reçue")
        val bytes = if (img.startsWith("http")) {
            val c = URL(img).openConnection() as HttpURLConnection
            c.connectTimeout = 20_000
            c.readTimeout = 60_000
            try { c.inputStream.use { it.readBytes() } } finally { c.disconnect() }
        } else {
            Base64.decode(img, Base64.DEFAULT)
        }
        return checked(bytes)
    }

    private fun hordeCall(url: String, method: String, body: String?, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 20_000
        c.readTimeout = 60_000
        c.requestMethod = method
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        try {
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            if (c.responseCode !in 200..299) error("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
