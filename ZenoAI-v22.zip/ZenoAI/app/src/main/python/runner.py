"""Exécute un script Python pour ZenoAI (Chaquopy) : capture la sortie, gère le délai maximum.

run(code, timeout, cwd) -> chaîne JSON {"out": ..., "err": ..., "timeout": bool}
"""
import builtins
import ctypes
import io
import json
import os
import sys
import threading
import traceback

_LOCK = threading.Lock()
_MAX = 20000


def _no_input(prompt=""):
    raise EOFError("input() n'est pas disponible ici : mets les valeurs directement dans le code.")


def run(code, timeout=15, cwd=None):
    with _LOCK:
        out = io.StringIO()
        state = {"err": None}

        def target():
            try:
                compiled = compile(code, "<script>", "exec")
                exec(compiled, {"__name__": "__main__"})
            except SystemExit:
                pass
            except SyntaxError as e:
                state["err"] = "".join(traceback.format_exception_only(type(e), e)).strip()
            except BaseException as e:
                tb = e.__traceback__.tb_next if e.__traceback__ else None
                state["err"] = "".join(traceback.format_exception(type(e), e, tb)).strip()

        old = (sys.stdout, sys.stderr, sys.stdin, builtins.input, os.getcwd())
        sys.stdout = sys.stderr = out
        sys.stdin = io.StringIO("")
        builtins.input = _no_input
        if cwd:
            os.chdir(cwd)
        timed_out = False
        try:
            t = threading.Thread(target=target, daemon=True)
            t.start()
            t.join(timeout)
            if t.is_alive():
                timed_out = True
                ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(t.ident), ctypes.py_object(TimeoutError))
                t.join(2)
        finally:
            sys.stdout, sys.stderr, sys.stdin, builtins.input = old[:4]
            os.chdir(old[4])
        text = out.getvalue()
        if len(text) > _MAX:
            text = text[:_MAX] + "\n… (sortie coupée)"
        err = state["err"]
        if timed_out:
            err = "Arrêté après %d s (boucle infinie ?)" % timeout
        return json.dumps({"out": text, "err": err, "timeout": timed_out})
