# Activer Python (facultatif)

Sans rien faire, ZenoAI exécute déjà **les pages HTML et le JavaScript**. Pour exécuter aussi **Python**,
il faut embarquer un interpréteur avec [Chaquopy](https://chaquo.com/chaquopy/). Ce n'est pas activé par défaut :
cela alourdit l'APK (≈ 10 à 20 Mo) et peut demander d'ajuster les versions de Gradle. Sans Chaquopy, le bouton
« Exécuter » d'un bloc Python affiche simplement comment l'activer (rien ne plante).

> ⚠ Ces étapes n'ont pas été testées par ZenoAI : vérifie la table de compatibilité
> *version de Chaquopy ↔ version du plugin Android Gradle* (ici AGP 8.5.2) dans la documentation de Chaquopy.

1. `build.gradle.kts` (racine), dans `plugins { … }` :
   ```kotlin
   id("com.chaquo.python") version "16.0.0" apply false   // version à vérifier selon ton AGP
   ```
2. `app/build.gradle.kts` :
   ```kotlin
   plugins {
       id("com.android.application")
       id("org.jetbrains.kotlin.android")
       id("org.jetbrains.kotlin.plugin.compose")
       id("com.chaquo.python")            // ← ajouter
   }

   chaquopy {                              // ← ajouter (hors du bloc android)
       defaultConfig {
           version = "3.11"
           // pip { install("requests") }  // bibliothèques supplémentaires, si besoin
       }
   }
   ```
   `abiFilters` est déjà réglé sur `arm64-v8a`, comme Chaquopy l'exige.
3. Le fichier `app/src/main/python/runner.py` est déjà en place : c'est lui qui lance le script, capture `print`,
   applique le délai maximum (15 s) et renvoie les erreurs.
4. Recompile. `PythonBackend` (CodeRunner.kt) détecte la bibliothèque tout seul.

## Ce que Python peut et ne peut pas faire ici
- Bibliothèque standard : oui. Paquets pip : seulement ceux ajoutés dans `chaquopy { … pip { … } }` (et ceux qui existent pour Android).
- `input()` : indisponible (mets les valeurs dans le code).
- **Pas d'isolation** : contrairement au JavaScript (WebView sans réseau ni fichiers), un script Python tourne dans
  l'appli, avec ses droits (réseau, fichiers de l'appli). C'est pourquoi il ne se lance **que** quand tu touches
  « Exécuter ». Lance seulement du code que tu as relu.
- Dossier courant : celui du projet quand on lance depuis « Projets et fichiers » (les fichiers écrits par le script y restent),
  un dossier temporaire quand on lance depuis le chat.
