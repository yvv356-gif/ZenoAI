package ai.zeno.app

enum class Role { USER, AI }

data class ChatMessage(
    val id: Long,
    val role: Role,
    val text: String,
    val streaming: Boolean = false,
    val status: String = "",
    val imagePath: String? = null,
    val imagePrompt: String = "",
    val sources: String = "",
    val gamePath: String? = null,
    val gameTitle: String = "",
    val zipPath: String? = null
)

data class ChatMeta(val id: String, val title: String, val updatedAt: Long)

sealed interface ModelState {
    data object None : ModelState
    data class Busy(val label: String, val progress: Float? = null) : ModelState
    data object Ready : ModelState
    data class Error(val message: String) : ModelState
}

/** Personnalisation de l'interface. Une couleur à 0 = couleur par défaut. */
data class Look(
    val wallpaper: String = "",
    val userName: String = "Toi",
    val aiName: String = "Zeno",
    val userAvatar: String = "",
    val aiAvatar: String = "",
    val textColor: Int = 0,
    val userBubble: Int = 0,
    val aiBubble: Int = 0,
    val bubbleAlpha: Float = 0.4f
)

/** Modèles proposés. « key » sert à reconnaître le fichier installé d'après son nom. */
data class ModelPreset(val label: String, val sub: String, val url: String, val key: String)

object ModelPresets {
    private const val HF = "https://huggingface.co/"

    val list = listOf(
        ModelPreset(
            "SmolLM2 · 1,7 Md (ultra léger)",
            "Très réactif · ≈ 1,1 Go · ≈ 2 Go de mémoire vive (GGUF Q4_0, format rapide sur téléphone).",
            HF + "bartowski/SmolLM2-1.7B-Instruct-GGUF/resolve/main/SmolLM2-1.7B-Instruct-Q4_0.gguf",
            "smollm2-1.7b"
        ),
        ModelPreset(
            "Qwen 2.5 · 1,5 Md (polyvalent)",
            "Rapide, bon en code · ≈ 1 Go · ≈ 2 Go de mémoire vive (GGUF Q4_0, format rapide sur téléphone).",
            HF + "bartowski/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/Qwen2.5-1.5B-Instruct-Q4_0.gguf",
            "qwen2.5-1.5b-instruct-q4"
        ),
        ModelPreset(
            "Qwen 2.5 Coder · 1,5 Md (code, jeux, 3D)",
            "Spécialisé code, logique de jeu et scripts 3D OpenSCAD · ≈ 1 Go (GGUF Q4_0, format rapide sur téléphone).",
            HF + "bartowski/Qwen2.5-Coder-1.5B-Instruct-GGUF/resolve/main/Qwen2.5-Coder-1.5B-Instruct-Q4_0.gguf",
            "qwen2.5-coder-1.5b"
        ),
        ModelPreset(
            "Llama 3.2 · 1 Md (rapide, rédaction)",
            "Rapide pour écrire et discuter · ≈ 0,8 Go (GGUF Q4_0, format rapide sur téléphone).",
            HF + "bartowski/Llama-3.2-1B-Instruct-GGUF/resolve/main/Llama-3.2-1B-Instruct-Q4_0.gguf",
            "llama-3.2-1b"
        ),
        ModelPreset(
            "Llama 3.2 · 3 Md",
            "Bon compromis vitesse / qualité · 2,0 Go · ≈ 3 Go de mémoire vive (GGUF).",
            HF + "bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf",
            "llama-3.2-3b"
        ),
        ModelPreset(
            "Gemma 2 · 2 Md",
            "Très à l'aise à l'écrit · 1,7 Go · ≈ 2,5 Go de mémoire vive (GGUF).",
            HF + "bartowski/gemma-2-2b-it-GGUF/resolve/main/gemma-2-2b-it-Q4_K_M.gguf",
            "gemma-2-2b"
        ),
        ModelPreset(
            "Qwen 2.5 · 1,5 Md (.task, GPU)",
            "Format MediaPipe : utilise le GPU du téléphone quand il le permet · 1,6 Go.",
            Prefs.QWEN_URL, "qwen2.5-1.5b-instruct_multi"
        ),
        ModelPreset(
            "Qwen2.5-Coder · 7 Md (lourd)",
            "Le meilleur pour le code · 4,7 Go · ≈ 6 Go de mémoire vive · lent sur téléphone.",
            HF + "bartowski/Qwen2.5-Coder-7B-Instruct-GGUF/resolve/main/Qwen2.5-Coder-7B-Instruct-Q4_K_M.gguf",
            "qwen2.5-coder-7b"
        ),
        ModelPreset(
            "Llama 3.1 · 8 Md (lourd)",
            "Le plus puissant en général · 4,9 Go · ≈ 7 Go de mémoire vive · lent sur téléphone.",
            HF + "bartowski/Meta-Llama-3.1-8B-Instruct-GGUF/resolve/main/Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf",
            "llama-3.1-8b"
        )
    )

    fun presetFor(name: String): ModelPreset? = list.firstOrNull { name.lowercase().contains(it.key) }
}
