# ZenoAI – IA locales sur Android

## Compiler avec GitHub
1. Crée un dépôt GitHub et pousse tout le contenu de ce dossier (le dossier `.github` compris).
2. Onglet **Actions** → « Build ZenoAI » (se lance au push, ou « Run workflow »).
3. Récupère l'APK dans les **Artifacts** : `ZenoAI-apk`.

Le workflow : (1) compile le modèle d'APK « jeu », (2) génère une clé de signature,
(3) compile l'app (llama.cpp est téléchargé et compilé automatiquement, arm64-v8a).

## Ce qui est dedans
- Catalogue de modèles identique à l'écran + Qwen 2.5 Coder 32 Md ; mode Auto ; import de fichier .gguf/.task.
- Téléchargement en 16 connexions parallèles, sans limite.
- Tous les cœurs CPU + contexte/RAM dimensionnés sur la mémoire libre.
- Compréhension des phrases naturelles (sans commande) : ouvrir une app, lampe, retour/accueil, clic sur un texte, recherche web, image, fichier 3D (.stl), jeu.
- Contrôle du téléphone : Réglages → Accessibilité → « ZenoAI – contrôle du téléphone ».
- Jeux HTML jouables dans le chat + bouton « Télécharger en APK » (signé sur le téléphone).
- Mode Agent : navigateur visible + barre de recherche en bas.
