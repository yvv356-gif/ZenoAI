plugins { id("com.android.library"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.zenoai.sd"
    compileSdk = 35
    defaultConfig {
        minSdk = 29
        ndk { abiFilters += listOf("arm64-v8a") }
        externalNativeBuild { cmake { arguments += listOf("-DANDROID_STL=c++_shared", "-DCMAKE_BUILD_TYPE=Release", "-DGGML_OPENMP=OFF",
            "-DCMAKE_C_FLAGS=-march=armv8.2-a+dotprod+fp16", "-DCMAKE_CXX_FLAGS=-march=armv8.2-a+dotprod+fp16") } }
    }
    externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt"); version = "3.22.1" } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
