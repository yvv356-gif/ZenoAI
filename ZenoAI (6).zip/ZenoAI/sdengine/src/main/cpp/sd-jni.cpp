#include <jni.h>
#include <string>
#include <vector>
#include <cstdlib>
#include "stable-diffusion.h"

static sd_ctx_t *g_ctx = nullptr;
static std::string g_path;

extern "C" JNIEXPORT jboolean JNICALL
Java_com_zenoai_sd_NativeSd_load(JNIEnv *env, jobject, jstring jpath, jint threads) {
    const char *p = env->GetStringUTFChars(jpath, nullptr);
    g_path = p;
    env->ReleaseStringUTFChars(jpath, p);
    if (g_ctx) { free_sd_ctx(g_ctx); g_ctx = nullptr; }
    sd_ctx_params_t cp;
    sd_ctx_params_init(&cp);
    cp.model_path = g_path.c_str();
    cp.n_threads = threads;
    cp.vae_decode_only = true;
    cp.free_params_immediately = false;
    g_ctx = new_sd_ctx(&cp);
    return g_ctx != nullptr;
}

extern "C" JNIEXPORT jintArray JNICALL
Java_com_zenoai_sd_NativeSd_generate(JNIEnv *env, jobject, jstring jprompt, jint w, jint h, jint steps, jlong seed) {
    if (!g_ctx) return nullptr;
    const char *p = env->GetStringUTFChars(jprompt, nullptr);
    std::string prompt = p;
    env->ReleaseStringUTFChars(jprompt, p);
    sd_img_gen_params_t gp;
    sd_img_gen_params_init(&gp);
    gp.prompt = prompt.c_str();
    gp.negative_prompt = "";
    gp.width = w;
    gp.height = h;
    gp.seed = seed;
    gp.batch_count = 1;
    gp.sample_params.sample_steps = steps;
    gp.sample_params.guidance.txt_cfg = 1.0f;   // SD-Turbo : pas de guidage
    sd_image_t *r = generate_image(g_ctx, &gp);
    if (!r || !r[0].data) return nullptr;
    int n = (int) (r[0].width * r[0].height);
    jintArray arr = env->NewIntArray(2 + n);
    std::vector<jint> buf(2 + n);
    buf[0] = (jint) r[0].width; buf[1] = (jint) r[0].height;
    for (int i = 0; i < n; i++) {
        const uint8_t *px = r[0].data + i * r[0].channel;
        buf[2 + i] = (jint) (0xFF000000u | (px[0] << 16) | (px[1] << 8) | px[2]);
    }
    env->SetIntArrayRegion(arr, 0, 2 + n, buf.data());
    free(r[0].data);
    free(r);
    return arr;
}
