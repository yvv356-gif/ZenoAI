package com.zenoai.sd

/** Pont JNI vers stable-diffusion.cpp. Appelé par réflexion depuis l'app. */
class NativeSd {
    companion object { init { System.loadLibrary("sdjni") } }
    external fun load(path: String, threads: Int): Boolean
    /** Retourne [largeur, hauteur, pixels ARGB...] ou null. */
    external fun generate(prompt: String, w: Int, h: Int, steps: Int, seed: Long): IntArray?
}
