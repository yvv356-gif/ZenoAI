#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <string>
#include <vector>
#include <algorithm>
#include "llama.h"
static llama_model *g_model = nullptr;
static llama_context_params g_cp;
static std::atomic<bool> g_stop{false};

static size_t utf8_valid_prefix(const std::string &s) {
    size_t i = 0, n = s.size(), last = 0;
    while (i < n) {
        unsigned char c = s[i];
        size_t l = c < 0x80 ? 1 : (c >> 5) == 6 ? 2 : (c >> 4) == 14 ? 3 : (c >> 3) == 30 ? 4 : 1;
        if (i + l > n) break;
        i += l; last = i;
    }
    return last;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_zenoai_app_engine_NativeLlm_load(JNIEnv *env, jobject, jstring jpath, jint threads, jint nctx, jboolean mlock) {
    const char *p = env->GetStringUTFChars(jpath, nullptr);
    llama_backend_init();
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    llama_model_params mp = llama_model_default_params();
    mp.use_mmap = true;
    mp.use_mlock = mlock;
    g_model = llama_model_load_from_file(p, mp);
    env->ReleaseStringUTFChars(jpath, p);
    g_cp = llama_context_default_params();
    g_cp.n_ctx = nctx; g_cp.n_batch = 512; g_cp.n_ubatch = 512;
    g_cp.n_threads = threads; g_cp.n_threads_batch = threads;
    g_cp.flash_attn = false;
    return g_model != nullptr;
}

extern "C" JNIEXPORT void JNICALL
Java_com_zenoai_app_engine_NativeLlm_stop(JNIEnv *, jobject) { g_stop = true; }

extern "C" JNIEXPORT void JNICALL
Java_com_zenoai_app_engine_NativeLlm_unload(JNIEnv *, jobject) {
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
}

static std::string chatml(const std::vector<std::string> &r, const std::vector<std::string> &c) {
    std::string s;
    for (size_t i = 0; i < r.size(); i++) s += "<|im_start|>" + r[i] + "\n" + c[i] + "<|im_end|>\n";
    return s + "<|im_start|>assistant\n";
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_zenoai_app_engine_NativeLlm_generate(JNIEnv *env, jobject, jobjectArray roles, jobjectArray contents, jint maxTokens, jobject cb) {
    if (!g_model) return env->NewStringUTF("");
    g_stop = false;
    int n = env->GetArrayLength(roles);
    std::vector<std::string> r(n), c(n);
    std::vector<llama_chat_message> msgs(n);
    for (int i = 0; i < n; i++) {
        jstring a = (jstring) env->GetObjectArrayElement(roles, i);
        jstring b = (jstring) env->GetObjectArrayElement(contents, i);
        const char *sa = env->GetStringUTFChars(a, nullptr); r[i] = sa; env->ReleaseStringUTFChars(a, sa);
        const char *sb = env->GetStringUTFChars(b, nullptr); c[i] = sb; env->ReleaseStringUTFChars(b, sb);
        env->DeleteLocalRef(a); env->DeleteLocalRef(b);
    }
    for (int i = 0; i < n; i++) msgs[i] = {r[i].c_str(), c[i].c_str()};
    const char *tmpl = llama_model_chat_template(g_model, nullptr);
    std::string prompt;
    if (tmpl) {
        std::vector<char> buf(16384);
        int len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int) buf.size());
        if (len > (int) buf.size()) {
            buf.resize(len);
            len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(), (int) buf.size());
        }
        if (len > 0) prompt.assign(buf.data(), len);
    }
    if (prompt.empty()) prompt = chatml(r, c);

    const llama_vocab *vocab = llama_model_get_vocab(g_model);
    int nt = -llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(), nullptr, 0, true, true);
    std::vector<llama_token> toks(nt);
    llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(), toks.data(), (int) toks.size(), true, true);
    int keep = (int) g_cp.n_ctx - maxTokens - 8;
    if (keep < 256) keep = 256;
    if ((int) toks.size() > keep) toks.erase(toks.begin(), toks.begin() + (toks.size() - keep));

    llama_context *ctx = llama_init_from_model(g_model, g_cp);
    if (!ctx) return env->NewStringUTF("");
    llama_sampler *smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    jclass cls = env->GetObjectClass(cb);
    jmethodID mid = env->GetMethodID(cls, "onToken", "(Ljava/lang/String;)V");
    std::string full, pending;
    bool ok = true;
    for (size_t i = 0; i < toks.size() && ok; i += 512) {
        int cnt = (int) std::min<size_t>(512, toks.size() - i);
        llama_batch b = llama_batch_get_one(toks.data() + i, cnt);
        if (llama_decode(ctx, b) != 0) ok = false;
        if (g_stop) ok = false;
    }
    for (int k = 0; ok && k < maxTokens && !g_stop; k++) {
        llama_token id = llama_sampler_sample(smpl, ctx, -1);
        if (llama_vocab_is_eog(vocab, id)) break;
        char piece[256];
        int pl = llama_token_to_piece(vocab, id, piece, sizeof(piece), 0, true);
        if (pl > 0) {
            pending.append(piece, pl);
            size_t v = utf8_valid_prefix(pending);
            if (v > 0) {
                std::string out = pending.substr(0, v);
                pending.erase(0, v);
                full += out;
                jstring js = env->NewStringUTF(out.c_str());
                env->CallVoidMethod(cb, mid, js);
                env->DeleteLocalRef(js);
            }
        }
        llama_batch nb = llama_batch_get_one(&id, 1);
        if (llama_decode(ctx, nb) != 0) break;
    }
    llama_sampler_free(smpl);
    llama_free(ctx);
    return env->NewStringUTF(full.c_str());
}
