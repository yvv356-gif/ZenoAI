package com.zenoai.app.tools

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.android.apksig.ApkSigner
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyFactory
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlin.math.*

object Exporter {
    fun saveToDownloads(ctx: Context, name: String, mime: String, bytes: ByteArray): String {
        val v = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, name); put(MediaStore.Downloads.MIME_TYPE, mime)
            put(MediaStore.Downloads.RELATIVE_PATH, "Download/ZenoAI")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: error("Écriture impossible")
        ctx.contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
        return "Download/ZenoAI/$name"
    }
}

object ImageTool {
    fun mediaDir(ctx: Context) = File(ctx.filesDir, "media").also { it.mkdirs() }
}

/** JSON de primitives -> fichier STL binaire pour imprimante 3D. */
object StlBuilder {
    private fun box(): List<FloatArray> {
        val c = arrayOf(floatArrayOf(-.5f,-.5f,-.5f), floatArrayOf(.5f,-.5f,-.5f), floatArrayOf(.5f,.5f,-.5f), floatArrayOf(-.5f,.5f,-.5f),
            floatArrayOf(-.5f,-.5f,.5f), floatArrayOf(.5f,-.5f,.5f), floatArrayOf(.5f,.5f,.5f), floatArrayOf(-.5f,.5f,.5f))
        val faces = listOf(intArrayOf(0,3,2,1), intArrayOf(4,5,6,7), intArrayOf(0,1,5,4), intArrayOf(2,3,7,6), intArrayOf(3,0,4,7), intArrayOf(1,2,6,5))
        return faces.flatMap { f -> listOf(tri(c[f[0]], c[f[1]], c[f[2]]), tri(c[f[0]], c[f[2]], c[f[3]])) }
    }
    private fun tri(a: FloatArray, b: FloatArray, c: FloatArray) = floatArrayOf(a[0],a[1],a[2], b[0],b[1],b[2], c[0],c[1],c[2])
    private fun sphere(): List<FloatArray> {
        val st = 12; val sl = 20
        fun p(i: Int, j: Int): FloatArray {
            val th = PI * i / st; val ph = 2 * PI * (j % sl) / sl
            return floatArrayOf((.5 * sin(th) * cos(ph)).toFloat(), (.5 * sin(th) * sin(ph)).toFloat(), (.5 * cos(th)).toFloat())
        }
        val out = ArrayList<FloatArray>()
        for (i in 0 until st) for (j in 0 until sl) {
            out.add(tri(p(i, j), p(i + 1, j), p(i + 1, j + 1))); out.add(tri(p(i, j), p(i + 1, j + 1), p(i, j + 1)))
        }
        return out
    }
    private fun cyl(rTop: Float): List<FloatArray> {
        val n = 24; val out = ArrayList<FloatArray>()
        fun pt(i: Int, r: Float, z: Float) = floatArrayOf(r * cos(2 * PI * i / n).toFloat(), r * sin(2 * PI * i / n).toFloat(), z)
        val cb = floatArrayOf(0f, 0f, -.5f); val ct = floatArrayOf(0f, 0f, .5f)
        for (i in 0 until n) {
            val b0 = pt(i, .5f, -.5f); val b1 = pt(i + 1, .5f, -.5f); val t0 = pt(i, rTop, .5f); val t1 = pt(i + 1, rTop, .5f)
            out.add(tri(cb, b1, b0))
            if (rTop > 0f) { out.add(tri(b0, b1, t1)); out.add(tri(b0, t1, t0)); out.add(tri(ct, t0, t1)) } else out.add(tri(b0, b1, ct))
        }
        return out
    }
    private fun arr(o: JSONObject, k: String, d: Double): DoubleArray {
        val a = o.optJSONArray(k) ?: return doubleArrayOf(d, d, d)
        return DoubleArray(3) { a.optDouble(it, d) }
    }
    fun fromJson(json: String): ByteArray {
        val parts = JSONObject(json).getJSONArray("parts")
        val tris = ArrayList<FloatArray>()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            val unit = when (p.optString("type", "box")) { "sphere" -> sphere(); "cylinder" -> cyl(.5f); "cone" -> cyl(0f); else -> box() }
            val pos = arr(p, "pos", 0.0); val sz = arr(p, "size", 10.0); val rot = arr(p, "rot", 0.0)
            val (rx, ry, rz) = rot.map { Math.toRadians(it) }
            fun tf(v: FloatArray, o: Int): FloatArray {
                var x = v[o] * sz[0]; var y = v[o + 1] * sz[1]; var z = v[o + 2] * sz[2]
                var t = y * cos(rx) - z * sin(rx); z = y * sin(rx) + z * cos(rx); y = t
                t = x * cos(ry) + z * sin(ry); z = -x * sin(ry) + z * cos(ry); x = t
                t = x * cos(rz) - y * sin(rz); y = x * sin(rz) + y * cos(rz); x = t
                return floatArrayOf((x + pos[0]).toFloat(), (y + pos[1]).toFloat(), (z + pos[2]).toFloat())
            }
            for (t in unit) { val a = tf(t, 0); val b = tf(t, 3); val c = tf(t, 6); tris.add(a + b + c) }
        }
        require(tris.isNotEmpty()) { "modèle vide" }
        val buf = ByteBuffer.allocate(84 + 50 * tris.size).order(ByteOrder.LITTLE_ENDIAN)
        buf.position(80); buf.putInt(tris.size)
        for (t in tris) {
            val ux = t[3]-t[0]; val uy = t[4]-t[1]; val uz = t[5]-t[2]; val vx = t[6]-t[0]; val vy = t[7]-t[1]; val vz = t[8]-t[2]
            var nx = uy*vz-uz*vy; var ny = uz*vx-ux*vz; var nz = ux*vy-uy*vx
            val l = sqrt(nx*nx+ny*ny+nz*nz).let { if (it == 0f) 1f else it }; nx /= l; ny /= l; nz /= l
            buf.putFloat(nx).putFloat(ny).putFloat(nz); t.forEach { buf.putFloat(it) }; buf.putShort(0)
        }
        return buf.array()
    }
}

/** Jeu HTML -> APK installable, 100 % sur le téléphone (modèle d'APK + signature apksig). */
object ApkBuilder {
    fun build(ctx: Context, html: String): File {
        val unsigned = File(ctx.cacheDir, "game_unsigned.apk"); val signed = File(ctx.cacheDir, "jeu_zenoai.apk")
        ZipInputStream(ctx.assets.open("game_template.apk")).use { zin ->
            ZipOutputStream(unsigned.outputStream()).use { zout ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    if (e.name.startsWith("META-INF/") || e.name == "assets/index.html") continue
                    zout.putNextEntry(ZipEntry(e.name)); zin.copyTo(zout); zout.closeEntry()
                }
                zout.putNextEntry(ZipEntry("assets/index.html")); zout.write(html.toByteArray()); zout.closeEntry()
            }
        }
        val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(ctx.assets.open("sign_key.pk8").readBytes()))
        val cert = CertificateFactory.getInstance("X.509").generateCertificate(ctx.assets.open("sign_cert.der")) as X509Certificate
        ApkSigner.Builder(listOf(ApkSigner.SignerConfig.Builder("zeno", key, listOf(cert)).build()))
            .setInputApk(unsigned).setOutputApk(signed).setMinSdkVersion(29)
            .setV1SigningEnabled(true).setV2SigningEnabled(true).build().sign()
        return signed
    }
    fun install(ctx: Context, apk: File) {
        val uri: Uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", apk)
        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
