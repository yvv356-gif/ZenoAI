package com.zenoai.app.tools

import java.text.Normalizer

sealed interface Cmd {
    data class OpenApp(val name: String) : Cmd
    data class Torch(val on: Boolean) : Cmd
    data class Click(val text: String) : Cmd
    data object Back : Cmd
    data object Home : Cmd
    data class Web(val query: String) : Cmd
    data class Ask(val query: String) : Cmd
    data class Image(val prompt: String) : Cmd
    data class Model3D(val prompt: String) : Cmd
    data class Game(val prompt: String) : Cmd
    data class Video(val prompt: String) : Cmd
    data object Chat : Cmd
}

/** Comprend les phrases naturelles SANS passer par le modèle : instantané. */
object IntentRouter {
    fun norm(s: String) = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").trim()

    private val open = Regex("^(?:peux[- ]tu |tu peux |stp |s'il te plait )?(?:ouvre|ouvrir|lance|lancer|demarre|va sur)(?:-moi)?\\s+(?:l'application |l'app |application |app |l'|la |le |les )?(.+)$")
    private val torch = Regex("(allume|eteins|eteint|active|desactive|coupe)\\s+(?:la\\s+)?(lampe|torche|flash)")
    private val click = Regex("^(?:clique|appuie|touche|tape)\\s+sur\\s+(.+)$")
    private val web = Regex("^(?:cherche|recherche|trouve|google)(?:-moi)?\\s+(?:sur (?:internet|le web|google)\\s+)?(.+)$")
    private val webHint = Regex("\\b(meteo|actualites?|dernieres nouvelles|score du match|cours du bitcoin|prix de|sur internet)\\b")
    private val verbCreate = Regex("\\b(genere|generer|cree|creer|fais|fabrique|construis|programme|developpe|dessine|modelise|imagine)\\b")

    fun parse(raw: String): Cmd {
        val t = norm(raw)
        if (t == "retour" || t == "reviens en arriere") return Cmd.Back
        if (t.contains("ecran d'accueil") || t == "accueil" || t == "va a l'accueil") return Cmd.Home
        torch.find(t)?.let { return Cmd.Torch(it.groupValues[1].startsWith("allume") || it.groupValues[1] == "active") }
        click.find(t)?.let { return Cmd.Click(it.groupValues[1]) }
        open.find(t)?.let { m ->
            val n = m.groupValues[1]
            if (!n.contains("http") && !n.contains(".com") && n.split(" ").size <= 4) return Cmd.OpenApp(n)
        }
        val hasVerb = verbCreate.containsMatchIn(t)
        if (hasVerb && t.contains("video")) return Cmd.Video(raw)
        if (hasVerb && Regex("\\b(jeu|game|jouable)\\b").containsMatchIn(t)) return Cmd.Game(raw)
        if (hasVerb && Regex("\\b(3d|stl|impression 3d|imprimante)\\b").containsMatchIn(t)) return Cmd.Model3D(raw)
        val imgNoun = Regex("\\b(image|photo|dessin|illustration|logo|portrait|affiche|wallpaper|fond d'ecran)\\b")
        val gen = Regex("^(genere|generer|dessine|imagine)(?:-moi)?\\s+(un|une|des|le|la|les|l')\\b")
        if (hasVerb && imgNoun.containsMatchIn(t)) return Cmd.Image(raw)
        if (gen.containsMatchIn(t) && !Regex("\\b(code|script|fonction|texte|resume|application|site|programme|histoire|mail|poeme)\\b").containsMatchIn(t)) return Cmd.Image(raw)
        web.find(t)?.let { return Cmd.Web(it.groupValues[1]) }
        if (webHint.containsMatchIn(t)) return Cmd.Web(raw)
        if (Regex("^(quand|qui|combien|quel|quelle|quels|quelles|ou est|ou se|c'est quoi|qu'est-ce|qu'est ce|en quelle annee|age de|d'ou)\\b").containsMatchIn(t)) return Cmd.Ask(raw)
        return Cmd.Chat
    }
}
