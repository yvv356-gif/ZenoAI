package com.zenoai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.zenoai.app.tools.Notifier
import com.zenoai.app.ui.ZenoApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Notifier.ensureChannels(this)
        setContent { val vm: ChatVM = viewModel(); ZenoApp(vm) }
    }
    override fun onStart() { super.onStart(); Notifier.foreground = true }
    override fun onStop() { super.onStop(); Notifier.foreground = false }
}
