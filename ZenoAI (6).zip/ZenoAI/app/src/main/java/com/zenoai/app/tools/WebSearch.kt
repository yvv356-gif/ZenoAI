package com.zenoai.app.tools

import org.jsoup.Jsoup
import java.net.URLDecoder
import java.net.URLEncoder

data class WebResult(val title: String, val url: String, val snippet: String)

object WebSearch {
    private const val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36"
    private fun real(href: String): String {
        Regex("uddg=([^&]+)").find(href)?.let { return URLDecoder.decode(it.groupValues[1], "UTF-8") }
        return if (href.startsWith("//")) "https:$href" else href
    }
    /** DuckDuckGo version HTML : aucune clé API. */
    fun search(q: String, max: Int = 5): List<WebResult> = try {
        val doc = Jsoup.connect("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8")).userAgent(UA).timeout(8000).get()
        doc.select(".result").mapNotNull { r ->
            val a = r.selectFirst(".result__a") ?: return@mapNotNull null
            WebResult(a.text(), real(a.attr("href")), r.selectFirst(".result__snippet")?.text().orEmpty())
        }.take(max)
    } catch (e: Exception) { emptyList() }

    /** Début du texte d'une page (pour donner de la vraie matière à l'IA). */
    fun excerpt(url: String): String = try {
        Jsoup.connect(url).userAgent(UA).timeout(5000).get().select("p").eachText().joinToString(" ").take(1500)
    } catch (e: Exception) { "" }
}
