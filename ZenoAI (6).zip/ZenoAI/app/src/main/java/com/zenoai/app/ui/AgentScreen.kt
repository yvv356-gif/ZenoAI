package com.zenoai.app.ui

import android.annotation.SuppressLint
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.zenoai.app.ChatVM
import com.zenoai.app.tools.Prompts
import kotlinx.coroutines.*
import org.json.JSONObject
import org.json.JSONTokener
import java.net.URLEncoder
import kotlin.coroutines.resume

private const val SNAPSHOT_JS = """(function(){var els=[].slice.call(document.querySelectorAll('a,button,input,textarea,select,[role=button]')).filter(function(e){return e.offsetParent!==null}).slice(0,40);
els.forEach(function(e,i){e.setAttribute('data-zid',i)});
return JSON.stringify({url:location.href,title:document.title,text:(document.body?document.body.innerText:'').slice(0,1200),
els:els.map(function(e,i){return {id:i,tag:e.tagName,t:(e.innerText||e.placeholder||e.value||e.getAttribute('aria-label')||'').slice(0,40)}})})})()"""

private suspend fun WebView.js(code: String): String = suspendCancellableCoroutine { c ->
    post { evaluateJavascript(code) { r -> if (c.isActive) c.resume(runCatching { JSONTokener(r).nextValue().toString() }.getOrDefault(r ?: "")) } }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AgentScreen(vm: ChatVM, back: () -> Unit) {
    var web by remember { mutableStateOf<WebView?>(null) }
    var goal by remember { mutableStateOf("") }
    var log by remember { mutableStateOf("Dis-moi quoi faire : je navigue devant toi.") }
    var job by remember { mutableStateOf<Job?>(null) }
    var running by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun stopAgent() { vm.engine.stop(); job?.cancel(); running = false; log = "Arrêté." }

    fun startAgent(g: String) {
        job?.cancel(); vm.engine.resetStop(); running = true
        job = scope.launch {
            try {
                val w = web ?: return@launch
                val domain = Regex("([a-z0-9][a-z0-9-]*(?:\\.[a-z0-9-]+)*\\.(?:com|fr|org|net|io|co|be|ch|de|uk|app|shop|store|eu|info))(/\\S*)?", RegexOption.IGNORE_CASE).find(g)
                val actionWords = Regex("(clique|tape|ecri|écri|saisi|remplis|teste|essaie|code|champ|case|bouton|connecte|ajoute|selectionne|sélectionne|panier|achete|achète)", RegexOption.IGNORE_CASE)
                val onlyNav = domain != null && g.length < 70 && !actionWords.containsMatchIn(g)
                if (domain != null) {
                    val url = (if (g.contains("http")) Regex("https?://\\S+").find(g)?.value else null) ?: ("https://" + domain.value)
                    log = "Ouverture de $url"; w.loadUrl(url); delay(3500)
                    if (onlyNav) { log = "✅ $url ouvert."; return@launch }
                } else if (actionWords.containsMatchIn(g) && (w.url ?: "").let { it.isNotBlank() && !it.contains("duckduckgo.com") && it != "about:blank" }) {
                    log = "Je travaille sur la page ouverte…"      // on agit sur la page actuelle, sans refaire de recherche
                } else {
                    log = "Recherche : $g"
                    w.loadUrl("https://duckduckgo.com/?q=" + URLEncoder.encode(g, "UTF-8")); delay(3500)
                }
                val past = ArrayList<String>()
                for (step in 1..25) {
                    val snap = w.js(SNAPSHOT_JS)
                    log = "Étape $step : l'IA réfléchit…"
                    val out = vm.ask(Prompts.AGENT, "Objectif : $g\nActions déjà faites : ${past.takeLast(6).joinToString(" ; ").ifEmpty { "aucune" }}\nÉtat de la page : $snap")
                    if (out == null) { log = "Installe d'abord un modèle (sélecteur en haut du chat)."; return@launch }
                    val a = out.indexOf('{'); val b = out.lastIndexOf('}')
                    if (a < 0 || b <= a) { log = "💬 " + out.trim(); return@launch }
                    val j = try { JSONObject(out.substring(a, b + 1)) } catch (e: Exception) { log = "💬 " + out.trim(); return@launch }
                    when (j.optString("action")) {
                        "wait" -> { log = "Attente…"; delay(2000) }
                        "goto" -> { log = "→ ${j.optString("url")}"; w.loadUrl(j.optString("url")) }
                        "click" -> { log = "Clic sur #${j.optInt("id")}"; w.js("(function(){var e=document.querySelector('[data-zid=\"${j.optInt("id")}\"]');if(e){e.scrollIntoView();e.click();return 'ok'}return 'introuvable'})()") }
                        "type" -> {
                            log = "Saisie : ${j.optString("text")}"
                            val t = JSONObject.quote(j.optString("text")); val sub = j.optBoolean("submit", false)
                            w.js("(function(){var e=document.querySelector('[data-zid=\"${j.optInt("id")}\"]');if(!e)return 'introuvable';e.focus();var s=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(e),'value');if(s&&s.set)s.set.call(e,$t);else e.value=$t;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));if($sub&&e.form){if(e.form.requestSubmit)e.form.requestSubmit();else e.form.submit()}return 'ok'})()")
                        }
                        "scroll" -> w.js("window.scrollBy(0,window.innerHeight*0.8);'ok'")
                        "done" -> { log = "✅ " + j.optString("answer"); return@launch }
                        else -> { log = "💬 " + out.trim(); return@launch }
                    }
                    past.add(j.toString().take(80))
                    delay(2000)
                }
                log = "Je m'arrête après 25 étapes."
            } catch (e: CancellationException) {
                log = "Arrêté."
            } catch (e: Exception) {
                log = "⚠️ ${e.message ?: e.javaClass.simpleName}"
            } finally { running = false }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton({ stopAgent(); back() }) { Icon(Icons.Default.ArrowBack, null) }
            Text("Agent", fontSize = 20.sp)
        }
        AndroidView(factory = { c -> WebView(c).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            webViewClient = WebViewClient(); loadUrl("https://duckduckgo.com"); web = this } },
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp).clip(RoundedCornerShape(16.dp)))
        Text(log, Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), fontSize = 13.sp, color = Color(0xFF3A3A55), maxLines = 6)
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(goal, { goal = it }, Modifier.weight(1f).background(Color.White.copy(alpha = .6f), RoundedCornerShape(28.dp)),
                placeholder = { Text("Cherche ou dis à l'agent quoi faire…", fontSize = 14.sp) }, shape = RoundedCornerShape(28.dp), maxLines = 3)
            IconButton({ if (running) stopAgent() else if (goal.isNotBlank()) { startAgent(goal); goal = "" } }) {
                Icon(if (running) Icons.Default.Stop else Icons.Default.Send, null, tint = Violet)
            }
        }
    }
}
