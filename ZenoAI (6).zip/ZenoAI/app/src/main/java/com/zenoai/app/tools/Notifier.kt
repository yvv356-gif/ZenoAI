package com.zenoai.app.tools

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.ServiceCompat
import com.zenoai.app.MainActivity

object Notifier {
    @Volatile var foreground = false
    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("zeno_run", "Réflexion en cours", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("zeno_done", "Réponse prête", NotificationManager.IMPORTANCE_DEFAULT))
    }
    /** Notification quand l'IA a fini de répondre (seulement si l'app n'est pas au premier plan). */
    fun done(ctx: Context, title: String, text: String) {
        if (foreground) return
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        ensureChannels(ctx)
        val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(ctx, "zeno_done").setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(text.take(120)).setStyle(Notification.BigTextStyle().bigText(text.take(400)))
            .setContentIntent(pi).setAutoCancel(true).build()
        ctx.getSystemService(NotificationManager::class.java).notify(2, n)
    }
}

/** Garde l'IA en vie quand l'app passe en arrière-plan pendant une réponse. */
class KeepAliveService : Service() {
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        Notifier.ensureChannels(this)
        val n = Notification.Builder(this, "zeno_run").setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("ZenoAI réfléchit…").setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        return START_NOT_STICKY
    }
}
