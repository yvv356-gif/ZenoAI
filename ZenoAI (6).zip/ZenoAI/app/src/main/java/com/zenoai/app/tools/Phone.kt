package com.zenoai.app.tools

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.view.accessibility.AccessibilityNodeInfo
import android.provider.Settings

class ZenoAccessibility : AccessibilityService() {
    companion object { @Volatile var inst: ZenoAccessibility? = null }
    override fun onServiceConnected() { inst = this }
    override fun onAccessibilityEvent(e: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }

    fun clickText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val key = IntentRouter.norm(t)
        val all = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val label = IntentRouter.norm((n.text ?: n.contentDescription ?: "").toString())
            if (label.isNotEmpty() && label.contains(key)) all.add(n)
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        for (n in all) {
            var x: AccessibilityNodeInfo? = n
            while (x != null && !x.isClickable) x = x.parent
            if (x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) return true
        }
        return false
    }
}

object Phone {
    private val aliases = mapOf("parametres" to "settings", "reglages" to "settings", "appareil photo" to "camera", "photos" to "gallery",
        "galerie" to "gallery", "horloge" to "clock", "calculatrice" to "calculator", "telephone" to "phone")

    fun openApp(ctx: Context, nameRaw: String): String {
        val name = IntentRouter.norm(nameRaw).trim('.', '!', ' ')
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        fun score(label: String, pkg: String): Int {
            val l = IntentRouter.norm(label)
            val alias = aliases[name]
            return when {
                l == name -> 100
                l.startsWith(name) -> 80
                l.contains(name) -> 60
                alias != null && (l.contains(alias) || pkg.contains(alias)) -> 50
                pkg.contains(name.replace(" ", "")) -> 30
                else -> 0
            }
        }
        val best = apps.maxByOrNull { score(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        if (best == null || score(best.loadLabel(pm).toString(), best.activityInfo.packageName) == 0) return "Je ne trouve pas d'application « $nameRaw »."
        val i = pm.getLaunchIntentForPackage(best.activityInfo.packageName) ?: return "Impossible d'ouvrir ${best.loadLabel(pm)}."
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return "✅ ${best.loadLabel(pm)} ouvert."
    }

    fun torch(ctx: Context, on: Boolean): String = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.first { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        cm.setTorchMode(id, on); if (on) "🔦 Lampe allumée." else "Lampe éteinte."
    } catch (e: Exception) { "Lampe indisponible : ${e.message}" }

    private fun needA11y(ctx: Context): String {
        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Active d'abord « ZenoAI – contrôle du téléphone » dans Accessibilité, puis redis-moi la commande."
    }
    fun back(ctx: Context) = ZenoAccessibility.inst?.let { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); "↩️ Retour." } ?: needA11y(ctx)
    fun home(ctx: Context) = ZenoAccessibility.inst?.let { it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME); "🏠 Accueil." } ?: needA11y(ctx)
    fun click(ctx: Context, t: String) = ZenoAccessibility.inst?.let { if (it.clickText(t)) "👆 Clic sur « $t »." else "Je ne vois pas « $t » à l'écran." } ?: needA11y(ctx)
}
