package com.zenoai.app.data

import kotlinx.coroutines.*
import okhttp3.*
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicLong

/** Téléchargement multi-connexions (16 segments en parallèle), sans aucun plafond de débit. */
class Downloader {
    private val client = OkHttpClient.Builder()
        .protocols(listOf(Protocol.HTTP_1_1))            // 1 connexion TCP par segment (pas de multiplexage HTTP/2)
        .dispatcher(Dispatcher().apply { maxRequests = 64; maxRequestsPerHost = 64 })
        .connectionPool(ConnectionPool(32, 5, TimeUnit.MINUTES))
        .readTimeout(60, TimeUnit.SECONDS).connectTimeout(20, TimeUnit.SECONDS)
        .build()
    val http get() = client

    suspend fun download(url: String, dest: File, segments: Int = 16, onProgress: (Long, Long) -> Unit) =
        withContext(Dispatchers.IO) {
            val probe = client.newCall(Request.Builder().url(url).header("Range", "bytes=0-0").build()).execute()
            val rangeOk = probe.code == 206
            val total = probe.header("Content-Range")?.substringAfter('/')?.toLongOrNull()
                ?: probe.header("Content-Length")?.toLongOrNull() ?: -1L
            probe.close()
            val part = File(dest.path + ".part")
            val done = AtomicLong(0)
            var lastTick = 0L
            fun tick(force: Boolean = false) {
                val now = System.currentTimeMillis()
                if (force || now - lastTick > 250) { lastTick = now; onProgress(done.get(), total) }
            }
            if (!rangeOk || total <= 0) {
                client.newCall(Request.Builder().url(url).build()).execute().use { r ->
                    require(r.isSuccessful) { "HTTP ${r.code}" }
                    part.outputStream().use { out ->
                        val buf = ByteArray(1 shl 18); val s = r.body!!.byteStream()
                        while (true) { val n = s.read(buf); if (n < 0) break; out.write(buf, 0, n); done.addAndGet(n.toLong()); tick() }
                    }
                }
            } else {
                RandomAccessFile(part, "rw").use { it.setLength(total) }
                val chunk = total / segments + 1
                coroutineScope {
                    (0 until segments).map { i ->
                        async {
                            val start = i * chunk
                            val end = minOf(total - 1, start + chunk - 1)
                            if (start <= end) fetch(url, part, start, end, done) { tick() }
                        }
                    }.awaitAll()
                }
            }
            tick(true)
            dest.delete(); part.renameTo(dest)
        }

    private suspend fun fetch(url: String, f: File, s: Long, e: Long, done: AtomicLong, tick: () -> Unit) {
        var pos = s
        var tries = 0
        while (pos <= e) {
            try {
                val req = Request.Builder().url(url).header("Range", "bytes=$pos-$e").build()
                client.newCall(req).execute().use { r ->
                    require(r.code == 206) { "HTTP ${r.code}" }
                    RandomAccessFile(f, "rw").use { raf ->
                        raf.seek(pos)
                        val buf = ByteArray(1 shl 18); val st = r.body!!.byteStream()
                        while (pos <= e) {
                            val n = st.read(buf); if (n < 0) break
                            raf.write(buf, 0, n); pos += n; done.addAndGet(n.toLong()); tick()
                            yield()
                        }
                    }
                }
                if (pos <= e) throw java.io.IOException("flux interrompu")
            } catch (ex: java.io.IOException) {
                if (++tries > 6) throw ex
                delay(800L * tries)
            }
        }
    }
}
