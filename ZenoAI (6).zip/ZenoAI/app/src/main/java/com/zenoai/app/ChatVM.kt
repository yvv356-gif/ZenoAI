package com.zenoai.app

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zenoai.app.data.*
import com.zenoai.app.engine.ImageEngine
import com.zenoai.app.engine.LlmEngine
import com.zenoai.app.tools.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File

sealed interface Attach {
    data class Img(val path: String) : Attach
    data class Stl(val path: String, val name: String) : Attach
    data class Game(val html: String) : Attach
}
/** ctxText = texte réellement envoyé à l'IA (ex. contenu d'un fichier joint), absent de l'affichage. */
data class Msg(val id: Long, val role: String, val text: String, val attach: Attach? = null, val ctxText: String? = null)
enum class Task { CHAT, CODE, WRITE }

class ChatVM(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()
    val store = ModelStore(app)
    val engine = LlmEngine(app)
    val prefs = Prefs(app)
    private val chats = ChatStore(app)
    private val dl = Downloader()

    val messages = mutableStateListOf<Msg>()
    val progress = mutableStateMapOf<String, Float>()
    var installed by mutableStateOf<List<ModelInfo>>(emptyList()); private set
    val installedLlm get() = installed.filter { it.kind != Kind.IMAGE }
    var history by mutableStateOf<List<Conv>>(emptyList()); private set
    var selected by mutableStateOf("auto")
    var activeLabel by mutableStateOf("")
    var busy by mutableStateOf(false)
    var busySince by mutableStateOf(0L)
    var status by mutableStateOf("")
    var webOn by mutableStateOf(true)
    /** 0 = bas, 1 = moyen, 2 = élevé */
    var effort by mutableStateOf(1)
    var pendingName by mutableStateOf<String?>(null); private set
    private var pendingText: String? = null
    private var nextId = 0L
    private var convId = System.currentTimeMillis().toString()
    private var job: Job? = null

    init { refresh(); refreshHistory(); engine.threadsOverride = prefs.threads }
    fun applyThreads() { engine.threadsOverride = prefs.threads; viewModelScope.launch { engine.invalidate() } }

    fun refresh() { installed = (Catalog.all.filter { store.isInstalled(it) } + store.customs()) }
    fun chipLabel() = if (selected == "auto") "Auto" + (activeLabel.takeIf { it.isNotBlank() }?.let { " · $it" } ?: "")
        else installed.firstOrNull { it.id == selected }?.label ?: "Auto"
    fun effortLabel() = arrayOf("Bas", "Moyen", "Élevé")[effort]

    // ---------- téléchargements ----------
    fun install(m: ModelInfo) {
        if (progress.containsKey(m.id)) return
        progress[m.id] = 0f
        viewModelScope.launch(Dispatchers.IO) {
            try { dl.download(Catalog.url(m), store.file(m)) { d, t -> progress[m.id] = if (t > 0) d.toFloat() / t else 0f } }
            catch (e: Exception) { status = "Téléchargement de ${m.label} échoué : ${e.message}" }
            finally { progress.remove(m.id); refresh() }
        }
    }
    private fun nameOf(uri: Uri, def: String) = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null } ?: def
    fun importFile(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        val name = nameOf(uri, "modele.gguf")
        ctx.contentResolver.openInputStream(uri)!!.use { i -> File(store.dir, name).outputStream().use { i.copyTo(it, 1 shl 20) } }
        refresh()
    }

    // ---------- fichier joint (trombone) ----------
    fun attachFile(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        val name = nameOf(uri, "fichier")
        val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
        val txt = bytes.take(60_000).toByteArray().toString(Charsets.UTF_8)
        val bad = txt.count { it == '\uFFFD' || (it.code < 9) } 
        if (bytes.isEmpty() || bad > txt.length / 20) { status = "Ce type de fichier (PDF, image…) n'est pas encore lisible. Utilise un fichier texte, code, CSV, JSON…"; return@launch }
        pendingName = name; pendingText = txt.take(20_000)
    }
    fun clearAttachment() { pendingName = null; pendingText = null }

    // ---------- personnalisation ----------
    fun setImage(kind: String, uri: Uri?) = viewModelScope.launch(Dispatchers.IO) {
        val dir = ImageTool.mediaDir(ctx)
        if (uri == null) { when (kind) { "bg" -> prefs.bgPath = null; "ai" -> prefs.aiAvatar = null; else -> prefs.userAvatar = null }; prefs.save(); return@launch }
        val f = File(dir, "${kind}_${System.currentTimeMillis()}.img")
        ctx.contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } }
        when (kind) { "bg" -> prefs.bgPath = f.absolutePath; "ai" -> prefs.aiAvatar = f.absolutePath; else -> prefs.userAvatar = f.absolutePath }
        prefs.save()
    }

    // ---------- discussions ----------
    private fun persist() {
        if (messages.isEmpty()) return
        val title = messages.firstOrNull { it.role == "user" }?.text?.lineSequence()?.last()?.take(40) ?: "Discussion"
        chats.save(convId, title, messages.toList()); refreshHistory()
    }
    fun refreshHistory() { history = chats.list() }
    fun newChat() { if (busy) return; persist(); messages.clear(); convId = System.currentTimeMillis().toString(); nextId = 0 }
    fun openChat(id: String) {
        if (busy) return
        persist(); messages.clear(); messages.addAll(chats.load(id)); convId = id; nextId = (messages.maxOfOrNull { it.id } ?: -1) + 1
    }
    fun deleteChat(id: String) { chats.delete(id); if (id == convId) { messages.clear(); nextId = 0 }; refreshHistory() }

    // ---------- choix du modèle ----------
    private fun taskOf(t: String): Task = when {
        Regex("\\b(code|script|fonction|bug|python|kotlin|java|html|jeu|3d)\\b").containsMatchIn(t) -> Task.CODE
        Regex("\\b(ecris|redige|texte|mail|histoire|poeme|lettre)\\b").containsMatchIn(t) -> Task.WRITE
        else -> Task.CHAT
    }
    private fun resolve(task: Task): ModelInfo? {
        if (selected != "auto") installed.firstOrNull { it.id == selected }?.let { return it }
        val budget = engine.availMb() * 0.75
        val fit = installedLlm.filter { it.ramGb * 1024 <= budget }.ifEmpty { listOfNotNull(installedLlm.minByOrNull { it.sizeMb }) }
        val kind = when (task) { Task.CODE -> Kind.CODE; Task.WRITE -> Kind.WRITE; else -> null }
        val pool = fit.filter { kind != null && it.kind == kind }.ifEmpty { fit }
        return pool.maxByOrNull { it.sizeMb }
    }
    private suspend fun ensure(task: Task): Boolean {
        val m = resolve(task) ?: return false
        if (engine.loadedId != m.id) {
            status = "Chargement de ${m.label}…"
            engine.load(m, File(store.dir, m.file))
            status = ""
        }
        activeLabel = m.label.substringBefore(" (")
        return true
    }

    // ---------- messages ----------
    private fun add(role: String, text: String, a: Attach? = null): Int { messages.add(Msg(nextId++, role, text, a)); return messages.lastIndex }
    private fun say(t: String, a: Attach? = null) = add("assistant", t, a)

    private fun markBusy(b: Boolean) {
        busy = b; busySince = if (b) System.currentTimeMillis() else 0L
        try {
            val i = Intent(ctx, KeepAliveService::class.java)
            if (b) ContextCompat.startForegroundService(ctx, i) else ctx.stopService(i)
        } catch (_: Exception) {}
    }

    fun stop() {
        engine.stop(); job?.cancel(); status = ""
        if (busy) markBusy(false)
    }

    fun send(raw: String) {
        if (raw.isBlank() || busy) return
        val file = pendingText; val fname = pendingName
        messages.add(Msg(nextId++, "user", if (fname != null) "📎 $fname\n$raw" else raw, null,
            if (file != null) "Contenu du fichier « $fname » :\n$file\n\nQuestion : $raw" else null))
        clearAttachment()
        engine.resetStop()
        markBusy(true)
        job = viewModelScope.launch(Dispatchers.Default) {
            var ok = true
            try { handle(raw) }
            catch (e: CancellationException) { ok = false }
            catch (e: Exception) { say("⚠️ ${e.message ?: e.javaClass.simpleName}") }
            finally {
                status = ""; if (busy) markBusy(false); persist()
                if (ok) messages.lastOrNull { it.role == "assistant" }?.let { Notifier.done(ctx, prefs.aiName, it.text.ifBlank { "Réponse prête" }) }
            }
        }
    }

    private suspend fun reply(system: String, task: Task, extra: String? = null, maxTokens: Int = 1024, stream: Boolean = true, fresh: Boolean = false, onDone: ((Int, String) -> Unit)? = null) {
        if (!ensure(task)) { say("Aucun modèle installé. Touche le sélecteur de modèle en haut et installe-en un (ou importe un fichier)."); return }
        val hist = if (fresh) listOf(messages.last { it.role == "user" }.let { "user" to (extra ?: it.ctxText ?: it.text) })
            else messages.filter { (it.ctxText ?: it.text).isNotBlank() && it.attach !is Attach.Game }.takeLast(20).map { it.role to (it.ctxText ?: it.text) }.toMutableList().also {
                if (extra != null) it[it.lastIndex] = "user" to extra }
        val identity = if (system == Prompts.CHAT || system == Prompts.WEB)
            " Tu t'appelles ${prefs.aiName}." + (if (prefs.userName.isNotBlank()) " L'utilisateur s'appelle ${prefs.userName}." else "") else ""
        val effortTxt = when (effort) { 0 -> " Réponds de façon très courte."; 2 -> " Raisonne étape par étape et sois détaillé."; else -> "" }
        val maxTok = minOf(when (effort) { 0 -> minOf(maxTokens, 300); 2 -> maxTokens * 2; else -> maxTokens }, 3500)
        val idx = say("")
        val sb = StringBuilder(); var last = 0L
        val out = engine.chat(listOf("system" to system + identity + effortTxt) + hist, maxTok) { t ->
            sb.append(t); val n = System.currentTimeMillis()
            if (n - last > 150) { last = n; messages[idx] = messages[idx].copy(text = if (stream) sb.toString() else "✍️ ${prefs.aiName} écrit le code… (${sb.length} caractères)") }
        }
        messages[idx] = messages[idx].copy(text = out.ifBlank { sb.toString() })
        onDone?.invoke(idx, out.ifBlank { sb.toString() })
    }

    /** Appel silencieux (agent). */
    suspend fun ask(system: String, user: String, maxTokens: Int = 300): String? {
        if (!ensure(Task.CODE)) return null
        return engine.chat(listOf("system" to system, "user" to user), maxTokens) {}
    }

    private fun extractHtml(out: String): String? {
        val fenced = Regex("```(?:html)?\\s*(.*?)(?:```|$)", RegexOption.DOT_MATCHES_ALL).find(out)?.groupValues?.get(1)
        val body = fenced?.takeIf { it.contains("<") } ?: out
        val start = Regex("<!DOCTYPE|<html", RegexOption.IGNORE_CASE).find(body)?.range?.first
        var html = when {
            start != null -> body.substring(start)
            body.contains("<script") || body.contains("<canvas") ->
                "<!DOCTYPE html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"></head><body style=\"margin:0\">$body</body></html>"
            else -> return null
        }
        val e = html.lastIndexOf("</html>")
        html = if (e >= 0) html.substring(0, e + 7) else html + (if (html.count { it == '<' } > 0 && !html.contains("</script>") && html.contains("<script")) "\n</script>" else "") + "</body></html>"
        return html
    }

    private suspend fun webAnswer(q: String, explicit: Boolean) {
        status = "Recherche sur internet…"
        val r = WebSearch.search(q)
        if (r.isEmpty()) {
            if (explicit) say("Aucun résultat trouvé (vérifie ta connexion).") else reply(Prompts.CHAT, Task.CHAT)
            return
        }
        status = "Lecture des résultats…"
        val page = WebSearch.excerpt(r.first().url)
        val ctxTxt = r.joinToString("\n") { "- ${it.title} (${it.url}) : ${it.snippet}" } + (if (page.isNotBlank()) "\n\nExtrait de la première page :\n$page" else "")
        reply(Prompts.WEB, Task.CHAT, "Question : $q\n\nRésultats web :\n$ctxTxt")
    }

    private suspend fun handle(text: String) {
        when (val i = IntentRouter.parse(text)) {
            is Cmd.OpenApp -> say(Phone.openApp(ctx, i.name))
            is Cmd.Torch -> say(Phone.torch(ctx, i.on))
            is Cmd.Back -> say(Phone.back(ctx))
            is Cmd.Home -> say(Phone.home(ctx))
            is Cmd.Click -> say(Phone.click(ctx, i.text))
            is Cmd.Web -> if (!webOn) say("La recherche web est désactivée (globe en haut à droite).") else webAnswer(i.query, true)
            is Cmd.Ask -> if (webOn) webAnswer(i.query, false) else reply(Prompts.CHAT, Task.CHAT)
            is Cmd.Image -> {
                val im = installed.firstOrNull { it.kind == Kind.IMAGE }
                when {
                    !ImageEngine.available -> say("Le moteur d'images hors ligne n'est pas inclus dans cette version de l'app (sa compilation a échoué sur GitHub).")
                    im == null -> say("Pour générer des images sans internet, installe « Images hors ligne · SD-Turbo » dans le sélecteur de modèle (≈ 2 Go).")
                    else -> {
                        status = "Préparation de l'image…"
                        val en = if (installedLlm.isNotEmpty()) ask("Translate the user's image request into one short English image prompt. Output only the prompt.", i.prompt, 80)
                            ?.trim()?.trim('"')?.takeIf { it.isNotBlank() } ?: i.prompt else i.prompt
                        status = "Génération de l'image hors ligne… (≈ 30 s)"
                        val f = ImageEngine.generate(ctx, File(store.dir, im.file).absolutePath, en, engine.threadsCount())
                        say("Voilà ton image 🎨", Attach.Img(f.absolutePath))
                    }
                }
            }
            is Cmd.Model3D -> reply(Prompts.MODEL3D, Task.CODE, maxTokens = 1500, stream = false, fresh = true) { idx, out ->
                val json = out.substringAfter('{', "").let { if (it.isEmpty()) "" else "{$it" }.substringBeforeLast('}', "").let { if (it.isEmpty()) "" else "$it}" }
                try {
                    val stl = StlBuilder.fromJson(json)
                    val name = IntentRouter.norm(i.prompt).replace(Regex("[^a-z0-9]+"), "_").take(30).trim('_') + ".stl"
                    val f = File(ImageTool.mediaDir(ctx), name).also { it.writeBytes(stl) }
                    messages[idx] = messages[idx].copy(text = "Voilà ton fichier 3D 🧊 (${stl.size / 1024} Ko)", attach = Attach.Stl(f.absolutePath, name))
                } catch (e: Exception) { messages[idx] = messages[idx].copy(text = "Le modèle n'a pas produit un JSON 3D valide (${e.message}). Réessaie ou choisis un modèle Coder plus gros.") }
            }
            is Cmd.Game -> reply(Prompts.GAME, Task.CODE, maxTokens = 3500, stream = false, fresh = true) { idx, out ->
                val html = extractHtml(out)
                messages[idx] = if (html != null) messages[idx].copy(text = "Voilà ton jeu 🎮 — joue directement ici, ou télécharge-le en APK.", attach = Attach.Game(html))
                    else messages[idx].copy(text = "Je n'ai pas réussi à produire un jeu complet. Essaie avec un modèle Coder (1,5 ou 7 Md) dans le sélecteur.")
            }
            is Cmd.Video -> say("🎬 La génération vidéo locale (LTX-Video) n'est pas encore branchée : elle demande un GPU bien plus puissant qu'un téléphone. Elle est prévue pour le mode PC.")
            Cmd.Chat -> reply(Prompts.CHAT, taskOf(IntentRouter.norm(text)))
        }
    }

    // ---------- exports ----------
    fun saveToDownloads(a: Attach) = viewModelScope.launch(Dispatchers.IO) {
        try {
            val p = when (a) {
                is Attach.Img -> Exporter.saveToDownloads(ctx, File(a.path).name.replace(".img", ".jpg"), "image/jpeg", File(a.path).readBytes())
                is Attach.Stl -> Exporter.saveToDownloads(ctx, a.name, "model/stl", File(a.path).readBytes())
                is Attach.Game -> Exporter.saveToDownloads(ctx, "jeu_zenoai.html", "text/html", a.html.toByteArray())
            }
            status = "✅ Enregistré dans $p"
        } catch (e: Exception) { status = "⚠️ ${e.message}" }
    }
    fun exportApk(html: String) = viewModelScope.launch(Dispatchers.IO) {
        try {
            status = "Création de l'APK…"
            val apk = ApkBuilder.build(ctx, html)
            val p = Exporter.saveToDownloads(ctx, "jeu_zenoai.apk", "application/vnd.android.package-archive", apk.readBytes())
            status = "📦 APK enregistré dans $p"
            ApkBuilder.install(ctx, apk)
        } catch (e: Exception) { status = "⚠️ APK impossible : ${e.message}" }
    }
}
