package com.zenoai.app.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Réglages de personnalisation (sauvegardés). */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("zeno", Context.MODE_PRIVATE)
    var aiName by mutableStateOf(sp.getString("ai", "ZenoAI")!!)
    var userName by mutableStateOf(sp.getString("user", "")!!)
    var bgPath by mutableStateOf(sp.getString("bg", null))
    var aiAvatar by mutableStateOf(sp.getString("aiAvatar", null))
    var userAvatar by mutableStateOf(sp.getString("userAvatar", null))
    var threads by mutableStateOf(sp.getInt("threads", 0))
    var fontScale by mutableStateOf(sp.getFloat("font", 1f))
    fun save() = sp.edit().putString("ai", aiName).putString("user", userName).putString("bg", bgPath)
        .putString("aiAvatar", aiAvatar).putString("userAvatar", userAvatar).putFloat("font", fontScale).putInt("threads", threads).apply()
}
