package com.zenoai.app.engine

import android.content.Context
import android.graphics.Bitmap
import com.zenoai.app.tools.ImageTool
import java.io.File

/** Images 100 % hors ligne (Stable Diffusion / SD-Turbo via stable-diffusion.cpp), chargé par réflexion :
 *  si le module natif n'a pas pu être compilé, l'app fonctionne quand même sans lui. */
object ImageEngine {
    private val cls = runCatching { Class.forName("com.zenoai.sd.NativeSd") }.getOrNull()
    private val inst by lazy { cls?.getDeclaredConstructor()?.newInstance() }
    private var loaded: String? = null
    val available get() = cls != null

    @Synchronized
    fun generate(ctx: Context, modelPath: String, prompt: String, threads: Int): File {
        val c = cls ?: error("moteur d'images absent"); val o = inst!!
        if (loaded != modelPath) {
            val ok = c.getMethod("load", String::class.java, Int::class.javaPrimitiveType).invoke(o, modelPath, threads) as Boolean
            check(ok) { "Impossible de charger le modèle d'image (RAM insuffisante ?)" }
            loaded = modelPath
        }
        val px = c.getMethod("generate", String::class.java, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Int::class.javaPrimitiveType, Long::class.javaPrimitiveType)
            .invoke(o, prompt, 512, 512, 4, System.currentTimeMillis()) as IntArray? ?: error("La génération a échoué")
        val w = px[0]; val h = px[1]
        val bmp = Bitmap.createBitmap(px, 2, w, w, h, Bitmap.Config.ARGB_8888)
        val f = File(ImageTool.mediaDir(ctx), "img_${System.currentTimeMillis()}.png")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        return f
    }
}
