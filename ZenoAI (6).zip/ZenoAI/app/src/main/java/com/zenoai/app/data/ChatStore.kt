package com.zenoai.app.data

import android.content.Context
import com.zenoai.app.Attach
import com.zenoai.app.Msg
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Conv(val id: String, val title: String, val updated: Long)

/** Historique des discussions : un fichier JSON par discussion. */
class ChatStore(ctx: Context) {
    private val dir = File(ctx.filesDir, "chats").also { it.mkdirs() }

    fun save(id: String, title: String, msgs: List<Msg>) {
        val arr = JSONArray()
        msgs.forEach { m ->
            val o = JSONObject().put("id", m.id).put("role", m.role).put("text", m.text)
            m.ctxText?.let { o.put("ctx", it) }
            when (val a = m.attach) {
                is Attach.Img -> o.put("a", JSONObject().put("t", "img").put("p", a.path))
                is Attach.Stl -> o.put("a", JSONObject().put("t", "stl").put("p", a.path).put("n", a.name))
                is Attach.Game -> o.put("a", JSONObject().put("t", "game").put("h", a.html))
                null -> {}
            }
            arr.put(o)
        }
        File(dir, "$id.json").writeText(JSONObject().put("id", id).put("title", title).put("updated", System.currentTimeMillis()).put("msgs", arr).toString())
    }

    fun list(): List<Conv> = dir.listFiles().orEmpty().mapNotNull { f ->
        runCatching { JSONObject(f.readText()).let { Conv(it.getString("id"), it.getString("title"), it.getLong("updated")) } }.getOrNull()
    }.sortedByDescending { it.updated }

    fun load(id: String): List<Msg> {
        val arr = JSONObject(File(dir, "$id.json").readText()).getJSONArray("msgs")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val a = o.optJSONObject("a")?.let {
                when (it.getString("t")) {
                    "img" -> Attach.Img(it.getString("p"))
                    "stl" -> Attach.Stl(it.getString("p"), it.getString("n"))
                    else -> Attach.Game(it.getString("h"))
                }
            }
            Msg(o.getLong("id"), o.getString("role"), o.getString("text"), a, o.optString("ctx").ifEmpty { null })
        }
    }

    fun delete(id: String) { File(dir, "$id.json").delete() }
}
