pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "ZenoAI"
include(":app", ":gametemplate")
// Moteur d'images hors ligne : optionnel (-PwithSD=true) pour ne jamais casser le build principal
if (providers.gradleProperty("withSD").isPresent) include(":sdengine")
