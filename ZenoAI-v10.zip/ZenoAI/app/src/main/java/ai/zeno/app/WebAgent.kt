package ai.zeno.app

import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import kotlin.coroutines.resume

/**
 * Pilote le navigateur intégré (la WebView affichée à l'écran) : ouvrir, lire la page,
 * cliquer, écrire, défiler. Tout se voit dans la fenêtre du navigateur, étape par étape.
 */
object WebDriver : Driver {

    @Volatile
    private var view: WebView? = null
    private var loaded: CompletableDeferred<Unit>? = null

    /** Configure la WebView du navigateur et la relie au pilote. */
    fun configure(v: WebView) {
        v.settings.javaScriptEnabled = true
        v.settings.domStorageEnabled = true
        // Certains sites refusent la WebView (mention « wv » dans le navigateur) : on la retire
        v.settings.userAgentString = v.settings.userAgentString?.replace("; wv", "")
        v.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                loaded?.takeIf { !it.isCompleted }?.complete(Unit)
            }
        }
        view = v
    }

    fun detach() {
        view = null
    }

    /** Ouvre une adresse dans le navigateur visible et attend la fin du chargement. */
    suspend fun open(url: String) {
        var waited = 0
        while (view == null && waited < 15_000) {
            delay(150)
            waited += 150
        }
        val v = view ?: error("le navigateur ne s'est pas ouvert")
        val done = CompletableDeferred<Unit>()
        loaded = done
        v.loadUrl(url)
        withTimeoutOrNull(25_000) { done.await() }
        delay(800) // laisse le JavaScript du site finir d'afficher la page
    }

    override suspend fun snapshot(): String = decode(evaluate(SNAPSHOT_JS))

    override suspend fun perform(action: JSONObject): String = when (action.optString("action")) {
        "goto" -> {
            val u = Agent.findUrl(action.optString("url")) ?: return "adresse invalide"
            open(u)
            "ok : ouvert $u"
        }
        "click", "type", "scroll" -> {
            val r = decode(evaluate(ACT_JS.replace("__A__", action.toString())))
            delay(1200) // la page peut changer après l'action
            r.ifBlank { "pas de réponse de la page" }
        }
        else -> "action inconnue"
    }

    /** Exécute du JavaScript dans la page (sur le fil principal, là où la WebView doit être utilisée). */
    private suspend fun evaluate(js: String): String = suspendCancellableCoroutine { cont ->
        val v = view
        if (v == null) {
            cont.resume("")
        } else {
            v.evaluateJavascript(js) { r -> if (cont.isActive) cont.resume(r ?: "") }
        }
    }

    /** evaluateJavascript renvoie une chaîne encodée en JSON : on la décode. */
    private fun decode(raw: String): String {
        if (raw.isBlank() || raw == "null") return ""
        return runCatching { JSONArray("[$raw]").optString(0) }.getOrDefault("")
    }

    /** Repère les éléments utiles (liens, boutons, champs) et leur donne un numéro lisible par le modèle. */
    private val SNAPSHOT_JS = """
        (function(){
          var sel = 'a[href],button,input,textarea,select,[role=button],[role=link],[role=tab],[onclick],[contenteditable=true]';
          var old = document.querySelectorAll('[data-zid]');
          for (var k = 0; k < old.length; k++) { old[k].removeAttribute('data-zid'); }
          var els = [], n = 0;
          var all = document.querySelectorAll(sel);
          for (var i = 0; i < all.length && els.length < 35; i++) {
            var e = all[i];
            var r = e.getBoundingClientRect();
            var cs = window.getComputedStyle(e);
            if (r.width < 2 || r.height < 2 || cs.visibility === 'hidden' || cs.display === 'none' || e.disabled) continue;
            if (r.bottom < 0 || r.top > window.innerHeight * 2) continue;
            n++;
            e.setAttribute('data-zid', String(n));
            var label = e.innerText || e.value || e.placeholder || e.getAttribute('aria-label') || e.title || '';
            if (!label && e.querySelector && e.querySelector('img')) { label = 'image ' + (e.querySelector('img').alt || ''); }
            label = String(label).replace(/\s+/g, ' ').trim().slice(0, 80);
            els.push({
              id: n,
              tag: e.tagName.toLowerCase(),
              type: e.type || '',
              label: label,
              value: String(e.value || '').slice(0, 60),
              href: (e.getAttribute('href') || '').slice(0, 120)
            });
          }
          var body = document.body ? document.body.innerText : '';
          return JSON.stringify({
            url: location.href,
            title: document.title,
            text: String(body).replace(/\s+/g, ' ').trim().slice(0, 700),
            elements: els
          });
        })()
    """.trimIndent()

    /** Clique, écrit ou fait défiler. __A__ est remplacé par l'action en JSON. */
    private val ACT_JS = """
        (function(a){
          if (a.action === 'scroll') {
            window.scrollBy(0, (a.dir === 'up' ? -0.8 : 0.8) * window.innerHeight);
            return 'ok : défilé';
          }
          var el = a.id ? document.querySelector('[data-zid="' + a.id + '"]') : null;
          if (!el) { return 'élément introuvable'; }
          if (a.action === 'click') {
            el.scrollIntoView({block: 'center'});
            el.click();
            return 'ok : cliqué';
          }
          if (a.action === 'type') {
            el.focus();
            var proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
            var d = Object.getOwnPropertyDescriptor(proto, 'value');
            if (d && d.set) { d.set.call(el, a.text || ''); } else { el.value = a.text || ''; }
            el.dispatchEvent(new Event('input', {bubbles: true}));
            el.dispatchEvent(new Event('change', {bubbles: true}));
            if (a.enter) {
              var ev = {key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true};
              el.dispatchEvent(new KeyboardEvent('keydown', ev));
              el.dispatchEvent(new KeyboardEvent('keyup', ev));
              if (el.form) {
                if (el.form.requestSubmit) { el.form.requestSubmit(); } else { el.form.submit(); }
              }
            }
            return 'ok : écrit';
          }
          return 'action inconnue';
        })(__A__)
    """.trimIndent()
}
