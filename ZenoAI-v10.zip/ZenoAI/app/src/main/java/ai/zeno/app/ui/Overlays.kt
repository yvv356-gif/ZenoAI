package ai.zeno.app.ui

import android.annotation.SuppressLint
import android.webkit.WebView
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import ai.zeno.app.Flashcards
import ai.zeno.app.FlashcardSet
import ai.zeno.app.WebDriver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Navigateur intégré : la page s'affiche tout de suite, et l'agent y agit sous tes yeux.
 * La barre du haut indique ce qu'il fait ; « Arrêter » coupe l'agent sans fermer la page.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserDialog(url: String, status: String, busy: Boolean, onStop: () -> Unit, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        url,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.labelLarge,
                        modifier = Modifier.weight(1f).padding(start = 12.dp)
                    )
                    if (busy) {
                        TextButton(onClick = onStop) { Text("Arrêter") }
                    }
                    IconButton(onClick = onClose) {
                        Icon(Icons.Filled.Close, contentDescription = "Fermer le navigateur")
                    }
                }
                if (status.isNotBlank()) {
                    Text(
                        status,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.secondaryContainer)
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
                AndroidView(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    factory = { ctx -> WebView(ctx).also { WebDriver.configure(it) } }
                )
            }
        }
    }
    DisposableEffect(Unit) {
        onDispose { WebDriver.detach() }
    }
}

/**
 * Révision de cartes. Mode « retourner » : touche la carte pour voir la réponse, puis indique si tu la savais.
 * Mode « quiz » : tu tapes la réponse, Zeno la compare, puis tu notes la carte.
 * Chaque note change le niveau de la carte (les cartes mal sues reviennent plus souvent).
 */
@Composable
fun FlashcardDialog(set: FlashcardSet, quiz: Boolean, onGrade: (Int, Boolean) -> Unit, onClose: () -> Unit) {
    var order by remember(set.id, quiz) { mutableStateOf(Flashcards.session(set)) }
    var pos by remember(set.id, quiz) { mutableIntStateOf(0) }
    var showBack by remember(set.id, quiz) { mutableStateOf(false) }
    var known by remember(set.id, quiz) { mutableIntStateOf(0) }
    var done by remember(set.id, quiz) { mutableStateOf(false) }
    var typed by remember(set.id, quiz) { mutableStateOf("") }
    var verdict by remember(set.id, quiz) { mutableStateOf<Boolean?>(null) }
    val flip by animateFloatAsState(targetValue = if (showBack) 180f else 0f, label = "flip")

    val total = order.size
    val index = order.getOrNull(pos)?.takeIf { it < set.cards.size }

    fun answer(knewIt: Boolean) {
        val i = index ?: return
        onGrade(i, knewIt)
        if (knewIt) known += 1
        showBack = false
        typed = ""
        verdict = null
        if (pos < total - 1) pos += 1 else done = true
    }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        set.topic + if (quiz) "  ·  quiz" else "",
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = onClose) { Icon(Icons.Filled.Close, contentDescription = "Fermer") }
                }
                Spacer(Modifier.height(24.dp))
                if (total == 0 || index == null) {
                    Text("Ce deck est vide.", style = MaterialTheme.typography.titleLarge)
                } else if (done) {
                    Text(
                        "Révision terminée : $known sur $total sues",
                        style = MaterialTheme.typography.titleLarge,
                        textAlign = TextAlign.Center
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = {
                        order = Flashcards.session(set)
                        pos = 0; known = 0; done = false; showBack = false; typed = ""; verdict = null
                    }) { Text("Recommencer") }
                } else {
                    val card = set.cards[index]
                    Text("Carte ${pos + 1} sur $total", style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(12.dp))
                    if (!quiz) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 260.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer)
                                .clickable { showBack = !showBack }
                                .graphicsLayer { rotationY = flip; cameraDistance = 16f * density },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (flip < 90f) card.front else card.back,
                                style = MaterialTheme.typography.headlineSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .padding(24.dp)
                                    .graphicsLayer { rotationY = if (flip >= 90f) 180f else 0f }
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (showBack) "Touche la carte pour revoir la question" else "Touche la carte pour voir la réponse",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Spacer(Modifier.height(24.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                            OutlinedButton(onClick = { answer(false) }, modifier = Modifier.weight(1f)) { Text("À revoir") }
                            Button(onClick = { answer(true) }, modifier = Modifier.weight(1f)) { Text("Je savais") }
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(24.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer)
                                .padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                card.front,
                                style = MaterialTheme.typography.headlineSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                textAlign = TextAlign.Center
                            )
                        }
                        Spacer(Modifier.height(16.dp))
                        val v = verdict
                        if (v == null) {
                            OutlinedTextField(
                                value = typed,
                                onValueChange = { typed = it },
                                label = { Text("Ta réponse") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(12.dp))
                            Button(
                                onClick = { verdict = Flashcards.matches(typed, card.back) },
                                enabled = typed.isNotBlank(),
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("Vérifier") }
                        } else {
                            Text(
                                if (v) "Bonne réponse ✅" else "Pas tout à fait ❌",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Spacer(Modifier.height(6.dp))
                            Text("Réponse : ${card.back}", style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center)
                            Spacer(Modifier.height(16.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(onClick = { answer(false) }, modifier = Modifier.weight(1f)) { Text("À revoir") }
                                Button(onClick = { answer(true) }, modifier = Modifier.weight(1f)) { Text("Je savais") }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Liste des decks enregistrés : réviser, faire un quiz, ou supprimer. */
@Composable
fun DecksDialog(
    decks: List<FlashcardSet>,
    onOpen: (FlashcardSet, Boolean) -> Unit,
    onDelete: (String) -> Unit,
    onClose: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Mes cartes") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (decks.isEmpty()) {
                    Text("Aucun deck pour l'instant. Écris « /cartes les capitales d'Europe » pour en créer un.")
                }
                decks.forEach { set ->
                    val mastered = set.cards.count { it.box >= 3 }
                    Surface(
                        tonalElevation = 2.dp,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    set.topic,
                                    style = MaterialTheme.typography.titleSmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(onClick = { onDelete(set.id) }) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Supprimer le deck")
                                }
                            }
                            Text(
                                "${set.cards.size} cartes · $mastered bien sues",
                                style = MaterialTheme.typography.bodySmall
                            )
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { onOpen(set, false) }) { Text("Réviser") }
                                OutlinedButton(onClick = { onOpen(set, true) }) { Text("Quiz") }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Fermer") } }
    )
}
