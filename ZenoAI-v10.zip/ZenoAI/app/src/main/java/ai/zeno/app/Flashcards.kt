package ai.zeno.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.Normalizer

/** box : niveau de révision (0 = à revoir, 4 = bien sue). Plus la carte est haute, plus elle revient rarement. */
data class Flashcard(val front: String, val back: String, val box: Int = 0)

data class FlashcardSet(val id: String, val topic: String, val cards: List<Flashcard>)

/** Cartes mémoire écrites par l'IA locale, sauvegardées en decks, révisées à l'écran ou en quiz. */
object Flashcards {

    private val cmdRx = Regex("^/(cartes|flashcards)\\b", RegexOption.IGNORE_CASE)

    private const val SYSTEM =
        "Tu crées des cartes mémoire. Réponds uniquement avec un tableau JSON, sans texte autour ni balises. " +
            "Format : [{\"recto\":\"question ou mot\",\"verso\":\"réponse courte\"}]"

    fun isRequest(text: String): Boolean = cmdRx.containsMatchIn(text.trim())

    fun topic(text: String): String = text.trim().replace(cmdRx, "").trim()

    fun prompt(template: String, topic: String): String =
        PromptBuilder.wrap(
            template, SYSTEM,
            "Sujet : ${topic.take(200)}\nCrée 8 cartes courtes et exactes, dans la langue du sujet. Réponds uniquement avec le JSON."
        )

    fun parse(raw: String): List<Flashcard> {
        val json = Regex("\\[[\\s\\S]*\\]").find(raw)?.value ?: return emptyList()
        return runCatching {
            val arr = JSONArray(json)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                val front = o.optString("recto").trim()
                val back = o.optString("verso").trim()
                if (front.isEmpty() || back.isEmpty()) null else Flashcard(front.take(200), back.take(400))
            }
        }.getOrDefault(emptyList()).take(20)
    }

    /** Ordre de révision : les cartes mal sues d'abord, mélangées à l'intérieur de chaque niveau. */
    fun session(set: FlashcardSet): List<Int> =
        set.cards.indices.sortedWith(compareBy<Int> { set.cards[it].box }.thenBy { (it * 7919) % 97 })

    /** Met à jour le niveau d'une carte après « Je savais » (monte) ou « À revoir » (retombe à zéro). */
    fun grade(set: FlashcardSet, index: Int, knewIt: Boolean): FlashcardSet {
        val cards = set.cards.toMutableList()
        val c = cards[index]
        cards[index] = c.copy(box = if (knewIt) minOf(c.box + 1, 4) else 0)
        return set.copy(cards = cards)
    }

    /** Compare une réponse tapée avec la réponse attendue, sans accents ni ponctuation. */
    fun matches(typed: String, expected: String): Boolean {
        val a = normalize(typed)
        val b = normalize(expected)
        if (a.isEmpty() || b.isEmpty()) return false
        return a == b || (a.length >= 4 && b.contains(a)) || (b.length >= 4 && a.contains(b))
    }

    private fun normalize(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
}

/** Decks sauvegardés sur le téléphone : un fichier JSON par deck. */
class DeckStore(context: Context) {

    private val dir = File(context.filesDir, "cards").apply { mkdirs() }

    fun list(): List<FlashcardSet> = (dir.listFiles { f -> f.name.endsWith(".json") } ?: emptyArray())
        .mapNotNull { f -> runCatching { decode(f.readText()) }.getOrNull() }
        .sortedByDescending { it.id }

    fun save(set: FlashcardSet) {
        val arr = JSONArray()
        set.cards.forEach { c ->
            arr.put(JSONObject().put("recto", c.front).put("verso", c.back).put("box", c.box))
        }
        val o = JSONObject().put("id", set.id).put("topic", set.topic).put("cards", arr)
        File(dir, "${set.id}.json").writeText(o.toString())
    }

    fun delete(id: String) {
        File(dir, "$id.json").delete()
    }

    private fun decode(text: String): FlashcardSet {
        val o = JSONObject(text)
        val arr = o.getJSONArray("cards")
        val cards = (0 until arr.length()).map {
            val c = arr.getJSONObject(it)
            Flashcard(c.getString("recto"), c.getString("verso"), c.optInt("box", 0))
        }
        return FlashcardSet(o.getString("id"), o.getString("topic"), cards)
    }
}
