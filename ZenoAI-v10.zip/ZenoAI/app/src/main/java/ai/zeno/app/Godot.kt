package ai.zeno.app

import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Projets Godot 4. L'IA écrit le script principal (GDScript) ; l'appli fabrique le reste du projet
 * (project.godot, scène, notice) pour qu'il s'ouvre tel quel dans Godot 4.3 ou plus récent, sur ton PC.
 * Godot ne peut pas tourner dans l'appli : on produit le projet, puis on l'exécute dans Godot.
 */
object Godot {

    private val verbRx = Regex(
        "\\b(crée|cree|créer|creer|fais|fais-moi|faire|génère|genere|générer|generer|programme|développe|developpe|make|create|build|écris|ecris)\\b",
        RegexOption.IGNORE_CASE
    )

    fun isRequest(text: String): Boolean {
        val t = text.trim()
        if (t.startsWith("/godot", ignoreCase = true)) return true
        if (t.length > 300 || t.contains("```")) return false
        return Regex("\\bgodot\\b", RegexOption.IGNORE_CASE).containsMatchIn(t) && verbRx.containsMatchIn(t)
    }

    fun request(text: String): String =
        text.trim().replace(Regex("^/godot\\s*", RegexOption.IGNORE_CASE), "").trim()

    private const val SYSTEM =
        "Tu es un programmeur Godot 4. Écris UN script GDScript complet pour le jeu demandé. " +
            "Commence par « extends Node2D ». Crée tout le jeu dans func _ready() : sprites en Polygon2D ou ColorRect, " +
            "aucun fichier externe, aucune image. Gère le clavier avec Input.is_action_pressed(\"ui_left\") ou Input.is_key_pressed(KEY_SPACE). " +
            "Affiche le score avec un Label créé dans le code. Réponds uniquement avec le code, dans un bloc ```gdscript."

    fun prompt(template: String, request: String): String =
        PromptBuilder.wrap(template, SYSTEM, "Jeu demandé : ${request.take(300)}\nRéponds uniquement avec le code GDScript.")

    /** Extrait le script du texte du modèle, ou null s'il n'a pas l'air d'un script Godot. */
    fun script(raw: String): String? {
        val block = Regex("```(?:gdscript|gd)?[ \\t]*\\n([\\s\\S]*?)(?:```|$)").find(raw)?.groupValues?.get(1) ?: raw
        val code = block.trim()
        return code.takeIf { it.contains("extends") && it.contains("func ") }
    }

    /** Les fichiers du projet : ceux de l'IA (main.gd) et ceux fabriqués ici. */
    fun project(name: String, script: String): Map<String, String> = linkedMapOf(
        "project.godot" to "config_version=5\n\n[application]\n\nconfig/name=\"${name.replace("\"", "")}\"\n" +
            "run/main_scene=\"res://main.tscn\"\nconfig/features=PackedStringArray(\"4.3\")\n",
        "main.tscn" to "[gd_scene load_steps=2 format=3]\n\n[ext_resource type=\"Script\" path=\"res://main.gd\" id=\"1\"]\n\n" +
            "[node name=\"Main\" type=\"Node2D\"]\nscript = ExtResource(\"1\")\n",
        "main.gd" to script + "\n",
        "LISEZMOI.txt" to "Projet généré par ZenoAI.\n\n" +
            "1. Installe Godot 4.3 ou plus récent (godotengine.org).\n" +
            "2. Dans Godot : Importer → choisis le fichier project.godot.\n" +
            "3. Touche Lancer (F5). Le jeu est dans main.gd : tu peux le modifier librement.\n"
    )

    fun zip(files: Map<String, String>, out: File) {
        out.parentFile?.mkdirs()
        ZipOutputStream(out.outputStream().buffered()).use { z ->
            files.forEach { (path, text) ->
                z.putNextEntry(ZipEntry(path))
                z.write(text.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
        }
    }

    /** Nom de fichier sûr d'après la demande. */
    fun fileName(request: String): String {
        val safe = request.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_').take(24).ifBlank { "jeu" }
        return "ZenoGodot_${safe}_${System.currentTimeMillis() % 100000}.zip"
    }
}
