package ai.zeno.app

import android.net.Uri
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import org.json.JSONObject
import org.jsoup.Jsoup
import java.net.URLEncoder
import java.util.Locale

data class WebResult(val context: String, val sources: List<String>) {
    companion object { val EMPTY = WebResult("", emptyList()) }
}

private data class Item(val host: String, val text: String)

private fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k)

/**
 * Accès internet. Seule la requête sort du téléphone.
 * - FACTS : Wikipédia (ta langue + anglais) et DuckDuckGo, Reddit en plus au niveau « élevé »
 * - CODE  : GitHub (dépôts, README au niveau « élevé »), Reddit et DuckDuckGo
 */
object WebSearch {

    enum class Mode { NONE, FACTS, CODE }

    private const val UA = "ZenoAI/1.0 (Android; assistant local)"

    private val timeWords = listOf(
        "aujourd'hui", "actualité", "actu ", "météo", "meteo", "dernier", "dernière", "récent", "prix",
        "cours de", "score", "résultat", "horaire", "news", "latest", "today", "weather",
        "current", "price", "2025", "2026", "combien coûte", "recherche"
    )
    private val factRx = Regex(
        "\\b(qui|quand|combien|quel|quelle|quels|quelles|date|mort|mourut|décès|décédé|né|naissance|capitale|président|population|histoire|année|siècle|who|when|how many|what is|which|died|death|born|capital|president|year)\\b",
        RegexOption.IGNORE_CASE
    )
    private val codeWords = listOf(
        "```", "code", "fonction", "function", "python", "kotlin", "java", "javascript", "html", "css",
        "bug", "erreur", "compile", "script", "algorithme", "sql", "class ", "github", "librairie", "library",
        "framework", "android", "react", "api "
    )
    private val stopWords = setOf(
        "quand", "qui", "quel", "quelle", "quels", "quelles", "est", "était", "etait", "a", "été", "ete", "combien",
        "comment", "pourquoi", "que", "qu", "le", "la", "les", "un", "une", "de", "du", "des", "l", "d", "en", "et",
        "au", "aux", "dis", "moi", "peux", "tu", "me", "donne", "what", "is", "was", "who", "when", "the", "of",
        "how", "did", "do", "does", "an", "in", "on", "to", "web", "écris", "ecris", "fais", "crée", "cree",
        "pour", "avec", "sur", "dans", "ce", "cette", "qui", "je", "veux", "voudrais", "stp", "please"
    )

    /** level : 0 = bas, 1 = moyen, 2 = élevé. */
    fun modeFor(q: String, level: Int): Mode {
        val l = q.lowercase().trim()
        if (l.startsWith("/jeu")) return Mode.NONE
        val isCode = codeWords.any { l.contains(it) }
        if (l.startsWith("/web")) return if (isCode) Mode.CODE else Mode.FACTS
        if (isCode) return if (level >= 1) Mode.CODE else Mode.NONE
        if (timeWords.any { l.contains(it) }) return Mode.FACTS
        if (level == 0) return Mode.NONE
        return if (l.length < 250 && factRx.containsMatchIn(l)) Mode.FACTS else Mode.NONE
    }

    private fun cleanQuery(q: String): String =
        q.removePrefix("/web").lowercase()
            .replace(Regex("```[\\s\\S]*?(```|$)"), " ")
            .split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.isNotBlank() && it !in stopWords }
            .joinToString(" ")
            .take(120)

    suspend fun gather(rawQuery: String, budget: Int, mode: Mode, level: Int): WebResult = coroutineScope {
        val q = rawQuery.removePrefix("/web").replace(Regex("```[\\s\\S]*?(```|$)"), " ").trim().take(200)
        val cleaned = cleanQuery(rawQuery)
        if (cleaned.isBlank() || mode == Mode.NONE) return@coroutineScope WebResult.EMPTY
        val short = cleaned.split(" ").take(6).joinToString(" ")
        val lang = Locale.getDefault().language.ifBlank { "fr" }
        val high = level >= 2

        fun job(f: () -> List<Item>): Deferred<List<Item>> =
            async(Dispatchers.IO) { runCatching { f() }.getOrDefault(emptyList()) }

        val jobs: List<Deferred<List<Item>>> = if (mode == Mode.CODE) {
            listOf(
                job { github(short, if (high) 2 else 1, high) },
                job { reddit(short, if (high) 2 else 1) },
                job { duck(q.ifBlank { short }, if (high) 2 else 1) }
            )
        } else if (level == 0) {
            listOf(job { wiki(lang, cleaned, 1) }, job { duck(q, 1) })
        } else {
            buildList<Deferred<List<Item>>> {
                add(job { wiki(lang, cleaned, if (high) 2 else 1) })
                if (lang != "en") add(job { wiki("en", cleaned, 1) })
                add(job { duck(q, if (high) 3 else 2) })
                if (high) add(job { reddit(short, 1) })
            }
        }

        val lists = jobs.map { it.await() }
        // On alterne les sources pour qu'elles se recoupent
        val maxItems = when (level) { 0 -> 2; 1 -> 4; else -> 6 }
        val ordered = mutableListOf<Item>()
        var i = 0
        while (ordered.size < maxItems && i < 4) {
            for (l in lists) { l.getOrNull(i)?.let { if (ordered.size < maxItems) ordered += it } }
            i++
        }
        if (ordered.isEmpty()) return@coroutineScope WebResult.EMPTY

        // Peu de texte = prompt court = réponse plus rapide sur les vieux téléphones
        val cap = minOf(budget, when (level) { 0 -> 500; 1 -> 800; else -> 1500 })
        val perItem = (cap / ordered.size).coerceIn(150, if (high) 420 else 300)
        val sb = StringBuilder()
        val used = mutableListOf<String>()
        for ((n, it) in ordered.withIndex()) {
            val line = "[${n + 1}] ${it.host} — ${it.text.take(perItem)}\n"
            if (sb.length + line.length > cap && sb.isNotEmpty()) break
            sb.append(line)
            if (it.host !in used) used += it.host
        }
        WebResult(sb.toString().trim(), used)
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun wiki(lang: String, q: String, n: Int): List<Item> {
        val url = "https://$lang.wikipedia.org/w/api.php?action=query&format=json&generator=search" +
            "&gsrlimit=$n&gsrsearch=${enc(q)}&prop=extracts&exintro=1&explaintext=1&exsentences=3&exlimit=$n&redirects=1"
        val body = Jsoup.connect(url).ignoreContentType(true).userAgent(UA).timeout(4000).execute().body()
        val pages = JSONObject(body).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
        val list = pages.keys().asSequence().map { pages.getJSONObject(it) }
            .sortedBy { it.optInt("index", 99) }.toList()
        return list.mapNotNull { p ->
            val ex = p.optString("extract").replace(Regex("\\s+"), " ").trim()
            if (ex.isBlank()) null else Item("$lang.wikipedia.org", "${p.optString("title")} : $ex")
        }
    }

    private fun duck(q: String, max: Int): List<Item> {
        val doc = Jsoup.connect("https://html.duckduckgo.com/html/?q=" + enc(q))
            .userAgent("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36")
            .timeout(4000)
            .get()
        val out = mutableListOf<Item>()
        for (r in doc.select("div.result")) {
            val title = r.selectFirst("a.result__a")?.text().orEmpty()
            val snippet = r.selectFirst(".result__snippet")?.text().orEmpty()
            val href = r.selectFirst("a.result__a")?.attr("href").orEmpty()
            val real = Uri.parse(href).getQueryParameter("uddg") ?: href
            val host = runCatching { Uri.parse(real).host }.getOrNull().orEmpty().ifBlank { "duckduckgo.com" }
            if (title.isNotBlank() && snippet.isNotBlank()) out += Item(host.removePrefix("www."), "$title : $snippet")
            if (out.size >= max) break
        }
        return out
    }

    /** Dépôts GitHub les plus pertinents (API publique, sans clé). */
    private fun github(q: String, n: Int, withReadme: Boolean): List<Item> {
        val url = "https://api.github.com/search/repositories?q=${enc(q)}&sort=stars&per_page=$n"
        val body = Jsoup.connect(url).ignoreContentType(true).userAgent(UA)
            .header("Accept", "application/vnd.github+json").timeout(4000).execute().body()
        val arr = JSONObject(body).optJSONArray("items") ?: return emptyList()
        val out = mutableListOf<Item>()
        for (i in 0 until minOf(arr.length(), n)) {
            val o = arr.getJSONObject(i)
            val name = o.str("full_name")
            if (name.isBlank()) continue
            val lang = o.str("language")
            val meta = "★" + o.optInt("stargazers_count") + (if (lang.isNotBlank()) ", $lang" else "")
            var text = "$name ($meta) : ${o.str("description")}"
            if (withReadme && i == 0) {
                val r = readme(name)
                if (r.isNotBlank()) text += " | README : $r"
            }
            out += Item("github.com", text)
        }
        return out
    }

    private fun readme(full: String): String = runCatching {
        Jsoup.connect("https://api.github.com/repos/$full/readme").ignoreContentType(true).userAgent(UA)
            .header("Accept", "application/vnd.github.raw+json").timeout(4000).execute().body()
            .replace(Regex("<[^>]+>|!?\\[[^\\]]*\\]\\([^)]*\\)|[#*`>|]"), " ")
            .replace(Regex("\\s+"), " ").trim().take(350)
    }.getOrDefault("")

    /** Discussions Reddit ; si l'API refuse la requête, repli sur DuckDuckGo limité à reddit.com. */
    private fun reddit(q: String, n: Int): List<Item> {
        val direct = runCatching {
            val url = "https://www.reddit.com/search.json?q=${enc(q)}&sort=relevance&limit=$n&raw_json=1"
            val body = Jsoup.connect(url).ignoreContentType(true).userAgent(UA).timeout(4000).execute().body()
            val ch = JSONObject(body).optJSONObject("data")?.optJSONArray("children")
            val out = mutableListOf<Item>()
            if (ch != null) {
                for (i in 0 until minOf(ch.length(), n)) {
                    val d = ch.getJSONObject(i).optJSONObject("data") ?: continue
                    val title = d.str("title")
                    if (title.isBlank()) continue
                    val self = d.str("selftext").replace(Regex("\\s+"), " ").trim()
                    out += Item("reddit.com/r/" + d.str("subreddit"), if (self.isBlank()) title else "$title : $self")
                }
            }
            out.toList()
        }.getOrDefault(emptyList())
        if (direct.isNotEmpty()) return direct
        return runCatching { duck("$q site:reddit.com", n).map { it.copy(host = "reddit.com") } }.getOrDefault(emptyList())
    }
}
