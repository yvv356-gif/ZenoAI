# ZenoAI v2.0 - Android Application

Projet Android Studio complet mis à jour avec le Navigateur d'Agent Dédié et les fonctionnalités demandées.

## Caractéristiques
1. **Changement de Modèle Direct sur l'Écran d'Accueil** (Mode Auto, Qwen 2.5 7B, Gemma 2 2B).
2. **Mémoire Infinie du Fil de Discussion** : L'historique complet est injecté à chaque requête.
3. **Navigateur Dédié pour le Mode Agent (`WebAgentManager`)** : L'Agent IA dispose de son propre composant `WebView` intégré pour charger des pages, simuler des clics et saisir du texte autonomes.
4. **Générateur de Jeux HTML5 + Aperçu Jouable + Export/Installation APK**.
5. **Générateur de Vidéos Ultra-Réalistes avec Lecteur Vidéo**.
6. **Liens Web Cliquables** envoyant directement sur les sites web dans le navigateur.

## Compilation GitHub Actions
Le workflow `.github/workflows/build.yml` est pré-configuré. Il suffit de pousser ce dépôt sur GitHub pour générer automatiquement l'APK de débogage.
