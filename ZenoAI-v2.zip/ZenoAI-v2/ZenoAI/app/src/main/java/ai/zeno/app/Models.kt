package ai.zeno.app

enum class ModelChoice(val displayName: String, val id: String) {
    AUTO("🤖 Mode Auto", "auto"),
    QWEN_7B("⚡ Qwen 2.5 (7B)", "qwen-2.5-7b"),
    GEMMA_2B("💎 Gemma 2 (2B)", "gemma-2-2b")
}

enum class MessageType {
    TEXT,
    VIDEO,
    GAME,
    BROWSER_CONTROL
}

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: String, // "user" ou "assistant"
    val text: String,
    val type: MessageType = MessageType.TEXT,
    val gameHtml: String? = null,
    val videoUrl: String? = null,
    val initialBrowserUrl: String? = null
)
