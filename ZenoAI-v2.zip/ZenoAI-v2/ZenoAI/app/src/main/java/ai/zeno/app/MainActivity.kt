package ai.zeno.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import ai.zeno.app.ui.ChatScreen

class MainActivity : ComponentActivity() {

    private lateinit var llmEngine: LlmEngine
    private lateinit var webAgentManager: WebAgentManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        llmEngine = LlmEngine(this)
        webAgentManager = WebAgentManager(this)

        setContent {
            var messages by remember { mutableStateOf(listOf<ChatMessage>()) }
            var selectedModel by remember { mutableStateOf(ModelChoice.AUTO) }
            var agentMode by remember { mutableStateOf(false) }

            ChatScreen(
                messages = messages,
                selectedModel = selectedModel,
                agentMode = agentMode,
                webAgentManager = webAgentManager,
                onModelSelected = { selectedModel = it },
                onAgentModeToggled = { agentMode = it },
                onSendMessage = { userText ->
                    val userMsg = ChatMessage(sender = "user", text = userText)
                    val updatedList = messages + userMsg
                    messages = updatedList

                    llmEngine.generateResponse(
                        prompt = userText,
                        history = updatedList,
                        selectedModel = selectedModel,
                        agentMode = agentMode
                    ) { responseMsg ->
                        messages = messages + responseMsg
                    }
                }
            )
        }
    }
}
