package ai.zeno.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class WebAgentState(
    val currentUrl: String = "about:blank",
    val title: String = "",
    val isLoading: Boolean = false,
    val lastActionLog: String = "Navigateur Agent prêt."
)

class WebAgentManager(private val context: Context) {

    private val _agentState = MutableStateFlow(WebAgentState())
    val agentState: StateFlow<WebAgentState> = _agentState

    private var activeWebView: WebView? = null

    @SuppressLint("SetJavaScriptEnabled")
    fun attachWebView(webView: WebView) {
        activeWebView = webView
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.userAgentString = "Mozilla/5.0 (Linux; Android 14) ZenoAI/WebAgent"

        webView.addJavascriptInterface(WebAppInterface(), "ZenoAgentBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                _agentState.value = _agentState.value.copy(
                    currentUrl = url ?: "",
                    isLoading = true,
                    lastActionLog = "Chargement de : $url"
                )
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                _agentState.value = _agentState.value.copy(
                    currentUrl = url ?: "",
                    title = view?.title ?: "",
                    isLoading = false,
                    lastActionLog = "Page chargée : ${view?.title}"
                )
                injectAgentScript(view)
            }
        }
    }

    private fun injectAgentScript(webView: WebView?) {
        val script = """
            (function() {
                console.log("ZenoAgent Script Injected");
                window.zenoHighlightElements = function() {
                    const inputs = document.querySelectorAll('input, button, a');
                    inputs.forEach((el, idx) => {
                        el.style.border = '2px solid #00E5FF';
                    });
                };
            })();
        """.trimIndent()
        webView?.evaluateJavascript(script, null)
    }

    fun navigateTo(url: String) {
        val formattedUrl = if (!url.startsWith("http://") && !url.startsWith("https://")) {
            "https://$url"
        } else url
        activeWebView?.post {
            activeWebView?.loadUrl(formattedUrl)
        }
    }

    fun executeClickSelector(cssSelector: String) {
        val script = "document.querySelector('$cssSelector')?.click();"
        activeWebView?.post {
            activeWebView?.evaluateJavascript(script, null)
            _agentState.value = _agentState.value.copy(
                lastActionLog = "Clic exécuté sur : $cssSelector"
            )
        }
    }

    fun executeTypeText(cssSelector: String, text: String) {
        val script = """
            (function() {
                const el = document.querySelector('$cssSelector');
                if (el) {
                    el.value = '$text';
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                }
            })();
        """.trimIndent()
        activeWebView?.post {
            activeWebView?.evaluateJavascript(script, null)
            _agentState.value = _agentState.value.copy(
                lastActionLog = "Saisie de '$text' dans : $cssSelector"
            )
        }
    }

    fun executeScroll(direction: String) {
        val scrollY = if (direction == "down") "500" else "-500"
        val script = "window.scrollBy(0, $scrollY);"
        activeWebView?.post {
            activeWebView?.evaluateJavascript(script, null)
        }
    }

    inner class WebAppInterface {
        @JavascriptInterface
        fun onPageEvent(eventData: String) {
            _agentState.value = _agentState.value.copy(
                lastActionLog = "Événement Web : $eventData"
            )
        }
    }
}
