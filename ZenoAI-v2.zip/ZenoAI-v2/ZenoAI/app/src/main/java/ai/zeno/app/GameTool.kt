package ai.zeno.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

object GameTool {

    fun generateSampleGameHtml(prompt: String): String {
        return """
            <!DOCTYPE html>
            <html>
            <head>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <style>
                    body { margin: 0; background: #0F0F1A; color: white; text-align: center; font-family: sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; }
                    canvas { background: #181828; border: 2px solid #00E5FF; border-radius: 12px; box-shadow: 0 0 15px rgba(0, 229, 255, 0.4); }
                    .info { margin-top: 12px; font-size: 18px; color: #00E5FF; font-weight: bold; }
                </style>
            </head>
            <body>
                <canvas id="gameCanvas" width="300" height="300"></canvas>
                <div class="info">Score: <span id="score">0</span></div>
                <script>
                    const canvas = document.getElementById('gameCanvas');
                    const ctx = canvas.getContext('2d');
                    let score = 0;
                    let x = 150, y = 150;
                    
                    function draw() {
                        ctx.clearRect(0, 0, canvas.width, canvas.height);
                        ctx.fillStyle = '#FF0055';
                        ctx.shadowBlur = 10;
                        ctx.shadowColor = '#FF0055';
                        ctx.beginPath();
                        ctx.arc(x, y, 22, 0, Math.PI * 2);
                        ctx.fill();
                    }
                    
                    canvas.addEventListener('click', (e) => {
                        const rect = canvas.getBoundingClientRect();
                        const cx = e.clientX - rect.left;
                        const cy = e.clientY - rect.top;
                        const dist = Math.hypot(cx - x, cy - y);
                        if (dist < 25) {
                            score++;
                            document.getElementById('score').innerText = score;
                            x = Math.random() * 240 + 30;
                            y = Math.random() * 240 + 30;
                            draw();
                        }
                    });
                    draw();
                </script>
            </body>
            </html>
        """.trimIndent()
    }

    fun downloadAndInstallApk(context: Context, gameHtml: String) {
        val file = File(context.cacheDir, "ZenoGame_build.apk")
        file.writeText(gameHtml)

        val contentUri: Uri = FileProvider.getUriForFile(
            context,
            "\${context.packageName}.fileprovider",
            file
        )

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(contentUri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }
}
